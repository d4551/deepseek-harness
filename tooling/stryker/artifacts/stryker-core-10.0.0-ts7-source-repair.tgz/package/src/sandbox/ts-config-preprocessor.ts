import path from 'path';

import { StrykerOptions } from '@stryker-mutator/api/core';
import { tokens, commonTokens } from '@stryker-mutator/api/plugin';
import { Logger } from '@stryker-mutator/api/logging';
import type { ParseError } from 'jsonc-parser';

import { Project } from '../fs/project.js';

import { FilePreprocessor } from './file-preprocessor.js';

export interface TSConfig {
  references?: Array<{ path: string }>;
  extends?: string | string[];
  files?: string[];
  exclude?: string[];
  include?: string[];
  compilerOptions?: Record<string, unknown>;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((entry: unknown) => typeof entry === 'string');
}

function validateConfig(value: unknown, fileName: string): asserts value is TSConfig {
  if (!isObject(value)) {
    throw new Error(`Invalid TypeScript config "${fileName}": root must be an object`);
  }
  for (const property of ['files', 'include', 'exclude']) {
    if (value[property] !== undefined && !isStringArray(value[property])) {
      throw new Error(`Invalid TypeScript config "${fileName}": ${property} must be an array of strings`);
    }
  }
  if (value.extends !== undefined && typeof value.extends !== 'string' && !isStringArray(value.extends)) {
    throw new Error(`Invalid TypeScript config "${fileName}": extends must be a string or an array of strings`);
  }
  if (value.compilerOptions !== undefined && !isObject(value.compilerOptions)) {
    throw new Error(`Invalid TypeScript config "${fileName}": compilerOptions must be an object`);
  }
  if (value.references !== undefined) {
    if (!Array.isArray(value.references)) {
      throw new Error(`Invalid TypeScript config "${fileName}": references must be an array`);
    }
    for (const [index, reference] of value.references.entries()) {
      if (!isObject(reference) || typeof reference.path !== 'string') {
        throw new Error(`Invalid TypeScript config "${fileName}": references[${index}] must be an object with a string path`);
      }
    }
  }
}
/**
 * A helper class that rewrites `references` and `extends` file paths if they end up falling outside of the sandbox.
 * @example
 * {
 *   "extends": "../../tsconfig.settings.json",
 *   "references": {
 *      "path": "../model"
 *   }
 * }
 * becomes:
 * {
 *   "extends": "../../../../tsconfig.settings.json",
 *   "references": {
 *      "path": "../../../model"
 *   }
 * }
 */
export class TSConfigPreprocessor implements FilePreprocessor {
  private readonly touched = new Set<string>();
  public static readonly inject = tokens(
    commonTokens.logger,
    commonTokens.options,
  );
  constructor(
    private readonly log: Logger,
    private readonly options: StrykerOptions,
  ) {}

  public async preprocess(project: Project): Promise<void> {
    if (this.options.inPlace) {
      // If stryker is running 'inPlace', we don't have to change the tsconfig file
      return;
    } else {
      this.touched.clear();
      await this.rewriteTSConfigFile(
        project,
        path.resolve(this.options.tsconfigFile),
      );
    }
  }

  private async rewriteTSConfigFile(
    project: Project,
    tsconfigFileName: string,
  ): Promise<void> {
    if (!this.touched.has(tsconfigFileName)) {
      this.touched.add(tsconfigFileName);
      const tsconfigFile = project.files.get(tsconfigFileName);
      if (tsconfigFile) {
        this.log.debug('Rewriting file %s', tsconfigFile);
        const { parseTree, getNodeValue, printParseErrorCode } = await import('jsonc-parser');
        const errors: ParseError[] = [];
        const content = await tsconfigFile.readContent();
        // Preserve diagnostic offsets when consuming TypeScript's optional byte-order mark.
        const jsonc = content.startsWith('\uFEFF') ? ` ${content.slice(1)}` : content;
        const tree = parseTree(
          jsonc,
          errors,
          { allowTrailingComma: true },
        );
        if (errors.length > 0) {
          const diagnostics = errors.map(({ error, offset, length }) =>
            `${printParseErrorCode(error)} at offset ${offset}, length ${length}`,
          );
          throw new Error(`Invalid TypeScript config "${tsconfigFileName}": ${diagnostics.join('; ')}`);
        }
        const config: unknown = tree === undefined ? undefined : getNodeValue(tree);
        validateConfig(config, tsconfigFileName);
        await this.rewriteExtends(project, config, tsconfigFileName);
        await this.rewriteProjectReferences(project, config, tsconfigFileName);
        this.rewriteFileArrayProperty(config, tsconfigFileName, 'include');
        this.rewriteFileArrayProperty(config, tsconfigFileName, 'exclude');
        this.rewriteFileArrayProperty(config, tsconfigFileName, 'files');
        tsconfigFile.setContent(JSON.stringify(config, null, 2));
      }
    }
  }

  private async rewriteExtends(
    project: Project,
    config: TSConfig,
    tsconfigFileName: string,
  ): Promise<void> {
    const extend = config.extends;
    if (typeof extend === 'string') {
      config.extends = await this.rewriteExtendedConfig(project, extend, tsconfigFileName);
    } else if (extend !== undefined) {
      const rewritten: string[] = [];
      for (const reference of extend) {
        rewritten.push(await this.rewriteExtendedConfig(project, reference, tsconfigFileName));
      }
      config.extends = rewritten;
    }
  }

  private async rewriteExtendedConfig(project: Project, reference: string, origin: string): Promise<string> {
    const rewritten = this.tryRewriteReference(reference, origin);
    if (rewritten) return rewritten;
    await this.rewriteTSConfigFile(project, path.resolve(path.dirname(origin), reference));
    return reference;
  }

  private rewriteFileArrayProperty(
    config: TSConfig,
    tsconfigFileName: string,
    prop: 'exclude' | 'files' | 'include',
  ): void {
    const fileArray = config[prop];
    if (Array.isArray(fileArray)) {
      config[prop] = fileArray.map((pattern) => {
        const rewritten = this.tryRewriteReference(pattern, tsconfigFileName);
        if (rewritten) {
          return rewritten;
        } else {
          return pattern;
        }
      });
    }
  }

  private async rewriteProjectReferences(
    project: Project,
    config: TSConfig,
    originTSConfigFileName: string,
  ): Promise<void> {
    if (Array.isArray(config.references)) {
      for (const reference of config.references) {
        const referencePath = reference.path.endsWith('.json')
          ? reference.path
          : path.join(reference.path, 'tsconfig.json');
        const rewritten = this.tryRewriteReference(
          referencePath,
          originTSConfigFileName,
        );
        if (rewritten) {
          reference.path = rewritten;
        } else {
          await this.rewriteTSConfigFile(
            project,
            path.resolve(path.dirname(originTSConfigFileName), referencePath),
          );
        }
      }
    }
  }

  private tryRewriteReference(
    reference: string,
    originTSConfigFileName: string,
  ): string | false {
    const dirName = path.dirname(originTSConfigFileName);
    const fileName = path.resolve(dirName, reference);
    const relativeToSandbox = path.relative(process.cwd(), fileName);
    if (relativeToSandbox.startsWith('..')) {
      return this.join('..', '..', reference);
    }
    return false;
  }

  private join(...pathSegments: string[]) {
    return pathSegments.map((segment) => segment.replace(/\\/g, '/')).join('/');
  }
}
