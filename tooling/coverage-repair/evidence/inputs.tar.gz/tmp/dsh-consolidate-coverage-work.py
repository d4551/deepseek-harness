from pathlib import Path
import difflib
import hashlib
import json
import os
import shutil
import tarfile

destination = Path('/Users/brandon/Downloads/deepseek-harness/tooling/coverage-repair')
destination.mkdir(parents=True, exist_ok=True)
(destination / 'patches').mkdir(exist_ok=True)
(destination / 'artifacts').mkdir(exist_ok=True)
(destination / 'evidence').mkdir(exist_ok=True)
sources = [
    ('vitest', '/tmp/dsh-vitest-5.0.1-source', '/tmp/dsh-vitest-5.0.1-source.tgz', 'https://codeload.github.com/vitest-dev/vitest/tar.gz/refs/tags/v5.0.1', None),
    ('converter', '/tmp/dsh-ast-v8-1.0.6-source', '/tmp/dsh-ast-v8-1.0.6-source.tgz', 'https://codeload.github.com/AriPerkkio/ast-v8-to-istanbul/tar.gz/48f88c789411ce6e96137b16ec348d06ae6c2f6e', None),
    ('local-pkg', '/tmp/dsh-local-pkg-source', '/tmp/dsh-local-pkg-1.2.1-source.tgz', 'https://codeload.github.com/antfu-collective/local-pkg/tar.gz/refs/tags/v1.2.1', None),
    ('istanbul', '/tmp/dsh-istanbul-1.0.1-source', '/tmp/dsh-istanbul-1.0.1-source.tar.gz', 'https://codeload.github.com/vitest-dev/istanbuljs/tar.gz/8bda20d9740143d950ea80e367b0151527faa0a9', None),
    ('esbuild', '/tmp/dsh-esbuild-0.28.2-source', '/tmp/dsh-esbuild-0.28.2-source.tgz', 'https://codeload.github.com/evanw/esbuild/tar.gz/609683d892977362a0f99026cb74b96263d728a9', ['internal/linker/linker.go', 'internal/sourcemap/sourcemap.go', 'internal/sourcemap/unmapped_test.go']),
    ('node', '/tmp/dsh-node26.9.0/node-v26.9.0', '/tmp/dsh-node26.9.0/node-v26.9.0.tar.xz', 'https://nodejs.org/dist/v26.9.0/node-v26.9.0.tar.xz', ['lib/internal/modules/package_json_reader.js', 'test/parallel/test-find-package-json-missing.js']),
    ('pnpm', '/tmp/dsh-pnpm-12.4.2-source', '/tmp/dsh-pnpm-12.4.2-source.tgz', 'https://codeload.github.com/pnpm/pnpm/tar.gz/refs/tags/v12.4.2', ['pnpm/crates/deps-inspection-peers/src/lib.rs', 'pnpm/crates/deps-inspection-peers/src/linked.rs', 'pnpm/crates/deps-inspection-peers/src/artifact_versions.rs', 'pnpm/crates/deps-inspection-peers/src/linked_artifact_versions.rs', '.changeset/archive-peer-versions.md']),
    ('tsx', '/tmp/dsh-tsx-integrated/package', '/tmp/dsh-tsx-integrated/tsx-4.23.13.tgz', 'https://registry.npmjs.org/tsx/-/tsx-4.23.13.tgz', ['package.json']),
    ('rrweb-snapshot', '/tmp/dsh-rrweb-snapshot-metadata/package', '/tmp/dsh-rrweb-snapshot-2.1.1.tgz', 'https://registry.npmjs.org/rrweb-snapshot/-/rrweb-snapshot-2.1.1.tgz', ['package.json']),
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save_asset(path):
    data = path.read_bytes()
    target = destination / 'artifacts' / path.name
    if target.exists():
        assert target.read_bytes() == data, str(path)
    else:
        target.write_bytes(data)
    return target.relative_to(destination).as_posix()

records = []
for name, root, archive_path, url, selected in sources:
    root = Path(root)
    archive_path = Path(archive_path)
    original = {}
    with tarfile.open(archive_path) as archive:
        for member in archive:
            relative = '/'.join(Path(member.name).parts[1:])
            if member.isfile() and (selected is None or relative in selected):
                original[relative] = archive.extractfile(member).read()
    paths = set(original)
    if selected is not None:
        paths.update(selected)
    else:
        for current, directories, filenames in os.walk(root):
            directories[:] = [part for part in directories if part not in {
                'node_modules', '.git', 'dist', 'coverage', '.cache', '.pnpm',
                'target', 'out', '.vite-temp', '.rollup.cache', '__pycache__',
                'ignore-examples',
            }]
            paths.update((Path(current) / filename).relative_to(root).as_posix()
                         for filename in filenames)
    patch = []
    inputs = []
    for path in sorted(paths):
        before = original.get(path, b'')
        actual = root / path
        if name == 'rrweb-snapshot' and path == 'package.json':
            actual = Path('/tmp/dsh-rrweb-snapshot-source-package.json')
        after = actual.read_bytes() if actual.exists() else b''
        if before == after:
            continue
        row = {'path': path, 'beforeSha256': digest(before) if path in original else None,
               'sha256': digest(after) if actual.exists() else None}
        if path.endswith('.tgz'):
            row['asset'] = save_asset(actual)
        else:
            lines = difflib.unified_diff(before.decode().splitlines(keepends=True),
                after.decode().splitlines(keepends=True),
                fromfile='a/' + path if path in original else '/dev/null',
                tofile='b/' + path if actual.exists() else '/dev/null', n=0)
            for line in lines:
                patch.append(line if line.endswith('\n') else line + '\n\\ No newline at end of file\n')
        inputs.append(row)
    patch_path = destination / 'patches' / f'{name}.patch'
    patch_path.write_text(''.join(patch))
    records.append({'name': name, 'originalDirectory': str(root),
        'archive': {'url': url, 'localPath': str(archive_path),
                    'sha256': digest(archive_path.read_bytes())},
        'patch': patch_path.relative_to(destination).as_posix(),
        'patchSha256': digest(patch_path.read_bytes()), 'inputs': inputs})

artifacts = list(Path('/tmp/dsh-toolchain-artifacts').glob('*.tgz')) + [
    Path('/tmp/dsh-ast-v8-integrated-artifact/ast-v8-to-istanbul-1.0.6.tgz'),
    Path('/tmp/dsh-local-pkg-1.2.1-source-repair.tgz'),
    Path('/tmp/dsh-rrweb-snapshot-2.1.1-metadata.tgz'),
    Path('/tmp/dsh-mocker-browser-resolver-artifact/vitest-mocker-5.0.1.tgz'),
]
artifact_rows = []
for path in artifacts:
    artifact_rows.append({'originalPath': str(path), 'path': save_asset(path),
                          'sha256': digest(path.read_bytes())})

with tarfile.open(destination / 'evidence' / 'full-green-plan.tar.gz', 'w:gz') as archive:
    archive.add('/tmp/dsh-full-green-plan', arcname='full-green-plan')
plan_inventory = [{'path': path.relative_to('/tmp/dsh-full-green-plan').as_posix(),
                   'sha256': digest(path.read_bytes())}
                  for path in sorted(Path('/tmp/dsh-full-green-plan').rglob('*')) if path.is_file()]
(destination / 'evidence' / 'full-green-plan-files.json').write_text(json.dumps(plan_inventory, indent=2)+'\n')
manifest = {'rootCommit': '105a97ef9c776a2856118ee02609dc61a0fb9617',
            'status': 'Unpromoted source candidates; complete green is not established.',
            'sources': records, 'artifacts': artifact_rows}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps({row['name']: len(row['inputs']) for row in records}))
