from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import tarfile
import tempfile

source = Path('/tmp/dsh-vitest-5.0.1-source')
archive = Path('/tmp/dsh-vitest-5.0.1-source.tgz')
destination = Path(tempfile.mkdtemp(prefix='dsh-mocker-browser-frozen-', dir='/tmp'))
patch = Path('/tmp/dsh-full-green-plan/vitest-mocker-browser-candidate.patch')
added = [
    'tsconfig.runtime-native.json',
    'test/native-typescript-transform.test.mjs',
    'test/coverage-source-integrity.test.mjs',
    'patches/js-tokens@8.0.2.patch',
    'patches/js-tokens@9.0.1.patch',
    'packages/coverage-v8/src/executed-sources.ts',
    'packages/mocker/tsdown.config.ts',
    'test/e2e/fixtures/mocker/auto-register/index.html',
    'test/e2e/fixtures/mocker/auto-register/entry.js',
    'test/e2e/fixtures/mocker/auto-register/calculation.js',
]
changes = []
inventory = []
with tarfile.open(archive) as contents:
    members = contents.getmembers()
    prefix = Path(members[0].name).parts[0]
    for member in members:
        if not member.isfile():
            continue
        relative = str(Path(*Path(member.name).parts[1:]))
        original = contents.extractfile(member).read()
        revised = (source / relative).read_bytes()
        if original == revised:
            continue
        changes.extend(difflib.unified_diff(
            original.decode().splitlines(keepends=True),
            revised.decode().splitlines(keepends=True),
            fromfile='a/' + relative, tofile='b/' + relative,
        ))
        inventory.append({'path': relative, 'sha256': hashlib.sha256(revised).hexdigest()})
    contents.extractall(destination, filter='data')
for relative in added:
    revised = (source / relative).read_bytes()
    changes.extend(difflib.unified_diff(
        [], revised.decode().splitlines(keepends=True),
        fromfile='/dev/null', tofile='b/' + relative,
    ))
    inventory.append({'path': relative, 'sha256': hashlib.sha256(revised).hexdigest()})
patch.write_text(''.join(changes))
root = destination / prefix
subprocess.run(['git', 'apply', '--check', str(patch)], cwd=root, check=True)
subprocess.run(['git', 'apply', str(patch)], cwd=root, check=True)
for item in inventory:
    assert hashlib.sha256((root / item['path']).read_bytes()).hexdigest() == item['sha256']
record = {
    'root': str(root),
    'archive': str(archive),
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'patch': str(patch),
    'patchSha256': hashlib.sha256(patch.read_bytes()).hexdigest(),
    'inputs': inventory,
}
Path('/tmp/dsh-mocker-browser-frozen-location.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'root': str(root), 'changedInputs': len(inventory), 'archiveSha256': record['archiveSha256']}))
