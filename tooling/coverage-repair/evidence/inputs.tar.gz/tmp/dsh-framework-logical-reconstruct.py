import hashlib
import json
import pathlib
import shutil
import tarfile
import tempfile

source = pathlib.Path('/tmp/dsh-ast-v8-1.0.6-source')
archive = pathlib.Path('/tmp/dsh-ast-v8-1.0.6-source.tgz')
archive_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive_sha == '429aa1cb7add6728d9d0e0dc512e15e04cb34a7a9831a8d16b8ea7d33a221f4f'
paths = [row['path'] for row in json.loads(pathlib.Path('/tmp/dsh-ast-v8-native-source-changes-final.json').read_text())]
paths += ['src/ast.ts', 'src/coverage-mapper.ts', 'src/evaluation.ts',
          'test/declaration-location.test.ts', 'test/evaluation-location.test.ts',
          'test/logical-expression-functions.test.ts']
assert len(paths) == len(set(paths)) == 20
root = pathlib.Path(tempfile.mkdtemp(prefix='dsh-framework-logical-frozen-'))
with tarfile.open(archive) as bundle:
    bundle.extractall(root, filter='data')
directory = root / 'ast-v8-to-istanbul-48f88c789411ce6e96137b16ec348d06ae6c2f6e'
changes = []
for path in paths:
    original = directory / path
    before = hashlib.sha256(original.read_bytes()).hexdigest() if original.exists() else None
    original.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / path, original)
    after = hashlib.sha256(original.read_bytes()).hexdigest()
    assert before != after
    changes.append({'path': path, 'before': before, 'sha256': after})
with tarfile.open(archive) as bundle:
    for member in bundle.getmembers():
        if not member.isfile():
            continue
        path = '/'.join(member.name.split('/')[1:])
        if path not in paths:
            assert (source / path).read_bytes() == bundle.extractfile(member).read(), path
record = {'directory': str(directory), 'cache': str(root / 'dependency-cache'),
          'sourceArchiveSha256': archive_sha,
          'lockSha256': hashlib.sha256((directory / 'pnpm-lock.yaml').read_bytes()).hexdigest(),
          'sourceChanges': changes}
pathlib.Path('/tmp/dsh-framework-logical-frozen-location.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'directory': str(directory), 'sources': len(changes)}))
