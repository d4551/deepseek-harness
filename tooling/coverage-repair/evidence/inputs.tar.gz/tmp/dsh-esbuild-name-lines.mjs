import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises';
import { Session } from 'node:inspector/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { parse } from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/acorn/dist/acorn.mjs';
import convert from '/tmp/dsh-ast-v8-1.0.6-source/dist/index.mjs';

const execute = promisify(execFile);
const binary = process.argv[2];
assert.ok(binary, 'compiler executable required');
for (const format of ['esm', 'cjs']) {
  for (const minified of [false, true]) {
    for (const keepNames of [false, true]) {
      const label = `${format}-${minified}-${keepNames}`;
      test(label, async (t) => {
        const root = await realpath(await mkdtemp(join(tmpdir(), 'esbuild-name-lines-')));
        t.after(() => rm(root, { recursive: true, force: true }));
        const original = 'export function value() { return 17; }\nexport function uncalled() { return 23; }';
        const authored = join(root, 'authored.js');
        const generated = join(root, `generated.${format === 'esm' ? 'mjs' : 'cjs'}`);
        await writeFile(authored, original);
        const args = [authored, `--format=${format}`, '--sourcemap=external', `--outfile=${generated}`];
        if (minified) args.push('--minify');
        if (keepNames) args.push('--keep-names');
        await execute(binary, args);
        const code = await readFile(generated, 'utf8');
        const sourceMap = JSON.parse(await readFile(`${generated}.map`, 'utf8'));
        const session = new Session();
        session.connect();
        t.after(() => session.disconnect());
        await session.post('Debugger.enable');
        await session.post('Profiler.enable');
        await session.post('Profiler.startPreciseCoverage', { callCount: true, detailed: true });
        const loaded = await import(pathToFileURL(generated).href);
        assert.equal(format === 'esm' ? loaded.value() : loaded.default.value(), 17);
        const measured = await session.post('Profiler.takePreciseCoverage');
        await session.post('Profiler.stopPreciseCoverage');
        const coverage = measured.result.find(record => record.url === pathToFileURL(generated).href);
        assert.ok(coverage, 'native execution record required');
        const executed = await session.post('Debugger.getScriptSource', { scriptId: coverage.scriptId });
        const wrapperLength = executed.scriptSource.indexOf(code);
        assert.ok(wrapperLength >= 0);
        assert.equal(executed.scriptSource.lastIndexOf(code), wrapperLength);
        const result = await convert({ code, sourceMap, coverage, wrapperLength,
          ast: parse(code, { ecmaVersion: 'latest', sourceType: 'module', locations: true }) });
        const file = result[authored];
        assert.ok(file);
        await writeFile(`/tmp/dsh-esbuild-name-lines-${label}.json`,
          JSON.stringify({ binary, original, code, sourceMap, coverage, wrapperLength, file }, null, 2));
        assert.equal(Object.keys(file.fnMap).length, 2);
        assert.deepEqual(Object.values(file.f).sort(), [0, 1]);
        const uncalledStatements = Object.entries(file.statementMap)
          .filter(([, statement]) => statement.start.line === 2);
        assert.ok(uncalledStatements.length > 0, 'uncalled body must be represented');
        for (const [id] of uncalledStatements) assert.equal(file.s[id], 0, `uncalled statement ${id}`);
      });
    }
  }
}
