import difflib
import hashlib
import json
import pathlib
import shutil
import tarfile
import tempfile

source = pathlib.Path('/tmp/dsh-ast-v8-1.0.6-source')
archive = pathlib.Path('/tmp/dsh-ast-v8-1.0.6-source.tgz')
baseline = json.loads(pathlib.Path('/tmp/dsh-framework-logical-frozen-location.json').read_text())
archive_sha = hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive_sha == baseline['sourceArchiveSha256']
paths = [row['path'] for row in baseline['sourceChanges']]
paths.append('test/source-map-integrity.test.ts')
assert len(paths) == len(set(paths)) == 21
root = pathlib.Path(tempfile.mkdtemp(prefix='dsh-source-map-integrity-frozen-'))
with tarfile.open(archive) as bundle:
    bundle.extractall(root, filter='data')
directory = root / 'ast-v8-to-istanbul-48f88c789411ce6e96137b16ec348d06ae6c2f6e'
changes = []
patch = []
for path in paths:
    destination = directory / path
    before = destination.read_bytes() if destination.exists() else b''
    after = (source / path).read_bytes()
    assert before != after, path
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / path, destination)
    if not path.endswith('.tgz'):
        patch.extend(difflib.unified_diff(
            before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
            fromfile='a/' + path if before else '/dev/null', tofile='b/' + path))
    changes.append({'path': path, 'before': hashlib.sha256(before).hexdigest() if before else None,
                    'sha256': hashlib.sha256(after).hexdigest()})
with tarfile.open(archive) as bundle:
    for member in bundle.getmembers():
        if member.isfile():
            path = '/'.join(member.name.split('/')[1:])
            if path not in paths:
                assert (source / path).read_bytes() == bundle.extractfile(member).read(), path
record = {'directory': str(directory), 'cache': str(root / 'dependency-cache'),
          'sourceArchiveSha256': archive_sha,
          'lockSha256': hashlib.sha256((directory / 'pnpm-lock.yaml').read_bytes()).hexdigest(),
          'sourceChanges': changes}
pathlib.Path('/tmp/dsh-source-map-integrity-frozen-location.json').write_text(json.dumps(record, indent=2) + '\n')
pathlib.Path('/tmp/dsh-full-green-plan/vitest-source-map-integrity-candidate.patch').write_text(''.join(patch))
print(json.dumps({'directory': str(directory), 'sources': len(changes)}))
