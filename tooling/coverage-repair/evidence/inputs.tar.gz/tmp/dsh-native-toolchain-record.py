from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

plan = Path('/tmp/dsh-full-green-plan')
compiler = Path('/tmp/dsh-esbuild-0.28.2-source')
runtime = Path('/tmp/dsh-node26.9.0/node-v26.9.0')
reconstruction_path = Path('/tmp/dsh-esbuild-generated-location-frozen.json')
reconstruction = json.loads(reconstruction_path.read_text())
frozen = Path(reconstruction['root'])
for item in reconstruction['inputs']:
    for root in [compiler, frozen]:
        assert hashlib.sha256((root / item['path']).read_bytes()).hexdigest() == item['sha256'], (root, item)
reconstruction['state'] = 'patch applied; inputs verified; complete Go tests and native bundled regressions pass; binary byte identity verified'
reconstruction_path.write_text(json.dumps(reconstruction, indent=2) + '\n')

paths = [
    Path('/tmp/dsh-esbuild-0.28.2-source.tgz'),
    Path('/tmp/dsh-node26.9.0/node-v26.9.0.tar.xz'),
    plan / 'esbuild-generated-locations.patch', plan / 'node-package-json-source.patch',
    plan / 'esbuild-generated-locations.md', plan / 'node-package-json-native.md',
    reconstruction_path, Path('/tmp/dsh-esbuild-generated-location-reconstruct.py'),
    Path('/tmp/dsh-esbuild-generated-location-reproducible'), Path('/tmp/dsh-esbuild-generated-location-frozen'),
    Path('/tmp/dsh-esbuild-0.28.2-official'), Path('/tmp/dsh-esbuild-0.28.2-generated-locations'),
    runtime / 'out/Release/node', runtime / 'lib/internal/modules/package_json_reader.js',
    runtime / 'test/parallel/test-find-package-json-missing.js',
    runtime / 'test/parallel/test-find-package-json.js',
    runtime / 'test/parallel/test-module-nearest-parent-package-json-cache.js',
    compiler / 'scripts/verify-source-map.js', compiler / 'scripts/esbuild.js',
    compiler / 'scripts/package.json', compiler / 'scripts/package-lock.json',
    Path('/tmp/dsh-esbuild-bundled-mapping.test.mjs'),
    Path('/tmp/dsh-esbuild-generated-location-probe.mjs'), Path('/tmp/dsh-esbuild-export-map-probe.mjs'),
    Path('/tmp/dsh-mocker-browser-consumer/runtime.test.mjs'),
    Path('/tmp/dsh-mocker-modern-consumer/runtime.test.mjs'),
]
paths += [compiler / item['path'] for item in reconstruction['inputs']]
log_names = [
    'node-package-json-build', 'node-package-json-before', 'node-package-json-after',
    'node-package-json-missing-after', 'node-package-json-existing-after', 'node-package-json-cache-after',
    'node-package-json-native-runner', 'mocker-browser-node-repaired', 'mocker-modern-node-repaired',
    'esbuild-export-map-native', 'esbuild-generated-location-native', 'esbuild-generated-location-go-tests',
    'esbuild-generated-location-go-final', 'esbuild-generated-location-vet',
    'esbuild-generated-location-upstream-maps', 'esbuild-generated-location-upstream-maps-final',
    'esbuild-unmapped-go-tests', 'esbuild-unmapped-go-tests-final',
    'esbuild-unmapped-official-boundary', 'esbuild-unmapped-official-location',
    'esbuild-bundled-official', 'esbuild-bundled-repaired', 'esbuild-bundled-frozen',
    'esbuild-generated-location-frozen-tests', 'esbuild-upstream-fixtures-install',
    'esbuild-map-validation-install',
]
paths += [Path(f'/tmp/dsh-{name}.log') for name in log_names]
for pattern in ['dsh-esbuild-export-map-*.json', 'dsh-esbuild-generated-location-*.json',
                'dsh-esbuild-bundled-official-*.json', 'dsh-esbuild-bundled-repaired-*.json',
                'dsh-esbuild-bundled-frozen-*.json']:
    paths += sorted(Path('/tmp').glob(pattern))
files = []
for path in sorted(set(paths)):
    data = path.read_bytes()
    files.append({'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
record = {
    'recordedAt': datetime.now(timezone.utc).isoformat(),
    'rootHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd='/Users/brandon/Downloads/deepseek-harness', text=True).strip(),
    'rootStatus': subprocess.check_output(['git', 'status', '--porcelain'], cwd='/Users/brandon/Downloads/deepseek-harness', text=True),
    'status': 'isolated compiler and native runtime repairs verified for recorded scopes; no promotion or complete-green acceptance',
    'compiler': {'version': '0.28.2', 'nativeCasesPassed': 16, 'officialNativeCasesFailed': 12,
                 'frozenNativeCasesPassed': 8, 'reconstruction': reconstruction},
    'node': {'version': '26.9.0', 'newCasesPassed': 7, 'officialNewCasesFailed': 5,
             'existingLookupCasesPassed': 11, 'officialRunnerFilesPassed': 3, 'packedConsumerCasesPassed': 4},
    'files': files,
}
(plan / 'native-toolchain-repair-evidence.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'files': len(files), 'rootHead': record['rootHead'], 'rootStatus': record['rootStatus'], 'inputIdentity': True}, indent=2))
