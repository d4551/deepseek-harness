from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

root = Path('/tmp/dsh-esbuild-0.28.2-source')
makefile = (root / 'Makefile').read_text()
targets = re.findall(r'GOOS=(\w+) GOARCH=(\w+) NPMDIR=(npm/@esbuild/[\w-]+) BINPATH=([\w/.]+) platform-internal', makefile)
manifest = json.loads((root / 'npm/esbuild/package.json').read_text())
wasm_packages = re.findall(r'^platform-([\w-]+): platform-wasm$', makefile, re.MULTILINE)
assert len(targets) == 24, len(targets)
native = [item for item in targets if item[2].removeprefix('npm/') in manifest['optionalDependencies']]
assert len(native) == 23, len(native)
assert {item[2].removeprefix('npm/') for item in native} | {f'@esbuild/{name}' for name in wasm_packages} == set(manifest['optionalDependencies'])

def build(target):
    system, architecture, package, binary = target
    destination = root / package / binary
    destination.parent.mkdir(parents=True, exist_ok=True)
    command = ['go', 'build', '-p', '4', '-trimpath', '-buildvcs=false', '-ldflags=-s -w -buildid=', '-o', str(destination), './cmd/esbuild']
    environment = dict(os.environ, GOOS=system, GOARCH=architecture, CGO_ENABLED='0')
    result = subprocess.run(command, cwd=root, env=environment, text=True, capture_output=True)
    log = Path(f'/tmp/dsh-esbuild-platform-{Path(package).name}.log')
    log.write_text(result.stdout + result.stderr)
    print(f'{package}: exit {result.returncode}', flush=True)
    record = {'package': package.removeprefix('npm/'), 'goos': system, 'goarch': architecture,
              'path': str(destination), 'command': command, 'exitCode': result.returncode, 'log': str(log)}
    if result.returncode == 0:
        record['sha256'] = hashlib.sha256(destination.read_bytes()).hexdigest()
    return record

with ThreadPoolExecutor(max_workers=3) as executor:
    results = list(executor.map(build, native))
Path('/tmp/dsh-esbuild-platform-build.json').write_text(json.dumps(results, indent=2) + '\n')
assert all(item['exitCode'] == 0 for item in results), 'Platform compilation failed; inspect individual logs'
