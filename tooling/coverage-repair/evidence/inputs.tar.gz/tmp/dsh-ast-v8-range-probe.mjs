import { readFile, writeFile } from 'node:fs/promises'
import { parse } from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/acorn/dist/acorn.mjs'
import convert from '/tmp/dsh-ast-v8-1.0.6-source/dist/index.mjs'
import * as coverageLibrary from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/@vitest/istanbul-lib-coverage/dist/index.mjs'
import * as sourceMapLibrary from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/@vitest/istanbul-lib-source-maps/dist/index.mjs'

const root = '/tmp/dsh-ast-v8-1.0.6-source/test/fixtures'
const results = []
for (const name of ['svelte-if-statement', 'svelte-for-loop', 'vue-for-loop']) {
  const directory = `${root}/${name}/dist`
  const code = await readFile(`${directory}/index.js`, 'utf8')
  const sourceMap = JSON.parse(await readFile(`${directory}/index.js.map`, 'utf8'))
  const [coverage] = JSON.parse(await readFile(`${directory}/coverage.json`, 'utf8'))
  const actual = coverageLibrary.createCoverageMap(await convert({
    code,
    ast: parse(code, { ecmaVersion: 'latest', sourceType: 'module' }),
    sourceMap,
    coverage,
  }))
  const original = coverageLibrary.createCoverageMap(JSON.parse(await readFile(`${directory}/coverage-istanbul.json`, 'utf8')))
  const expected = await sourceMapLibrary.createSourceMapStore().transformCoverage(original)
  results.push({ name, actual: actual.toJSON(), expected: expected.toJSON(), sourceMap, code })
  console.log(name, JSON.stringify({
    actual: actual.fileCoverageFor(actual.files()[0]).fnMap,
    expected: expected.fileCoverageFor(expected.files()[0]).fnMap,
  }))
}
await writeFile('/tmp/dsh-ast-v8-range-framework-proof.json', JSON.stringify(results, null, 2))
