from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

root = Path('/tmp/dsh-esbuild-0.28.2-source')
artifacts = Path('/tmp/dsh-toolchain-artifacts')
stage = Path('/tmp/dsh-esbuild-package-candidate')
artifacts.mkdir(exist_ok=True)
stage.mkdir(exist_ok=True)
node_bin = '/tmp/dsh-node26.9.0/node-v26.9.0-darwin-arm64/bin'
environment = dict(os.environ, PATH=f'{node_bin}:{os.environ["PATH"]}')
assert 'ESBUILD_BINARY_PATH' not in environment
builds = json.loads(Path('/tmp/dsh-esbuild-platform-build.json').read_text())
assert len(builds) == 23 and all(item['exitCode'] == 0 for item in builds)
subprocess.run([f'{node_bin}/node', 'scripts/esbuild.js', '/tmp/dsh-esbuild-generated-location-reproducible', '--neutral'],
               cwd=root, env=environment, check=True)
manifest = json.loads((root / 'npm/esbuild/package.json').read_text())
for key, expected in manifest['esbuild.binaryHashes'].items():
    assert expected and hashlib.sha256((root / 'npm' / key).read_bytes()).hexdigest() == expected, key
packages = []
for package in manifest['optionalDependencies']:
    location = root / 'npm' / package
    metadata = json.loads((location / 'package.json').read_text())
    assert metadata['name'] == package and metadata['version'] == '0.28.2'
    result = subprocess.run([f'{node_bin}/npm', 'pack', '--json', '--pack-destination', str(artifacts)],
                            cwd=location, env=environment, capture_output=True, text=True, check=True)
    packed = json.loads(result.stdout)[0]
    archive = artifacts / packed['filename']
    packages.append({'name': package, 'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                     'files': packed['files']})
    manifest['optionalDependencies'][package] = f'file:{archive}'
    print(package, archive.name, flush=True)
shutil.copytree(root / 'npm/esbuild', stage, dirs_exist_ok=True)
(stage / 'package.json').write_text(json.dumps(manifest, indent=2) + '\n')
result = subprocess.run([f'{node_bin}/npm', 'pack', '--json', '--pack-destination', str(artifacts)],
                        cwd=stage, env=environment, capture_output=True, text=True, check=True)
packed = json.loads(result.stdout)[0]
archive = artifacts / packed['filename']
packages.append({'name': 'esbuild', 'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                 'files': packed['files']})
Path('/tmp/dsh-esbuild-packed-platforms.json').write_text(json.dumps(packages, indent=2) + '\n')
print('packed', archive, flush=True)
