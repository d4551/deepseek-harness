from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tarfile

owner = Path('/Users/brandon/Downloads/deepseek-harness/tooling/coverage-repair')
prefixes = ['dsh-vitest-', 'dsh-ast-v8-', 'dsh-esbuild-', 'dsh-istanbul-',
            'dsh-local-pkg-', 'dsh-mocker-', 'dsh-pnpm-', 'dsh-source-map-',
            'dsh-framework-logical-', 'dsh-native-typescript-', 'dsh-native-toolchain-',
            'dsh-node-package-json-', 'dsh-runner-', 'dsh-tsx-', 'dsh-converter-',
            'dsh-consolidate-coverage-', 'dsh-consolidation-evidence', 'dsh-rrweb-']
paths = {p for p in Path('/tmp').iterdir() if p.is_file()
         and p.suffix in {'.json', '.log', '.py', '.mjs', '.ts', '.patch'}
         and any(p.name.startswith(prefix) for prefix in prefixes)}
for marker in ['dsh-pnpm-peer-native-official-final.log', 'dsh-pnpm-peer-native-repaired.log']:
    record = Path('/tmp', marker).read_text().strip()
    result = Path(record)
    paths.add(result)
    for command in json.loads(result.read_text()):
        paths.add(Path(command['log']))
inventory = []
with tarfile.open(owner / 'evidence' / 'inputs.tar.gz', 'w:gz') as archive:
    for path in sorted(paths):
        data = path.read_bytes()
        name = path.as_posix().lstrip('/')
        archive.add(path, arcname=name)
        inventory.append({'originalPath': str(path), 'archivePath': name,
                          'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(owner / 'evidence' / 'inputs.json').write_text(json.dumps(inventory, indent=2)+'\n')
status = {
    'recordedAt': datetime.now(timezone.utc).isoformat(),
    'rootCommit': '105a97ef9c776a2856118ee02609dc61a0fb9617',
    'userRequestedHaltAfterConsolidation': True,
    'rootDependencyGraphChanged': False,
    'fullGreen': False,
    'sourceCandidates': 9,
    'pnpm': {
        'owningTests': {'passed': 50, 'failed': 0, 'skipped': 0},
        'freshStoreReconstructedTests': {'passed': 50, 'failed': 0, 'skipped': 0},
        'clippyWarningsDenied': 'pass', 'pinnedFormat': 'pass',
        'nativeCompatibleArchiveStrictInstallAndPeerCheck': 'pass',
        'nativeIncompatibleArchiveStrictInstallAndPeerCheck': 'rejected with actual version 3.9.0',
        'releaseBuild': 'completed',
        'futureRustWarning': 'proc-macro-error2 2.0.1 privately imports and publicly re-exports proc_macro',
        'realRunnerStrictInstall': 'fails with ERR_PNPM_IGNORED_BUILDS for the esbuild file archive despite esbuild: true',
    },
    'coverage': {
        'nativeIntegratedRunner': {'passed': 14, 'failed': 1},
        'namePreservationMatrix': {'passed': 4, 'failed': 4},
        'failure': 'Generated __name calls mark an uncalled function declaration line covered',
    },
    'remaining': [
        'Repair archive build-script approval identity and verify actual runner strict/frozen installation',
        'Repair name-preservation source mapping without changing coverage assertions',
        'Finish complete runner compilation; last full measurement had 89 diagnostics',
        'Relocate candidate file dependencies and regenerate package lockfiles before promotion',
        'Complete maintained toolchain build, platform, and reproducibility acceptance',
        'Resolve all repository debt and complete the original full-green plan',
    ],
    'historicalPlan': 'evidence/full-green-plan.tar.gz',
    'evidence': 'evidence/inputs.json',
}
(owner / 'status.json').write_text(json.dumps(status, indent=2)+'\n')
print(json.dumps({'evidenceFiles': len(inventory), 'bytes': sum(x['bytes'] for x in inventory)}))
