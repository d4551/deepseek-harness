import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readdir, readFile, mkdir, copyFile, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'

const published = '/tmp/dsh-vitest-runtime-published/vitest/package'
const target = '/tmp/dsh-vitest-5.0.1-source/packages/vitest'
const declarations = []
for (const entry of await readdir(published, { recursive: true, withFileTypes: true })) {
  if (!entry.isFile() || !/\.d\.(?:ts|cts)(?:\.map)?$/.test(entry.name)) continue
  const path = join(entry.parentPath, entry.name).slice(published.length + 1)
  const bytes = await readFile(join(published, path))
  await mkdir(dirname(join(target, path)), { recursive: true })
  await copyFile(join(published, path), join(target, path))
  assert.ok(bytes.equals(await readFile(join(target, path))))
  declarations.push({ path, sha256: createHash('sha256').update(bytes).digest('hex') })
}
assert.ok(declarations.length > 30)
declarations.sort((a, b) => a.path.localeCompare(b.path))
await writeFile('/tmp/dsh-vitest-runtime-declaration-hashes.json', `${JSON.stringify(declarations, null, 2)}\n`)
console.log(`Verified ${declarations.length} unchanged official declarations`)
