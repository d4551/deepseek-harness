import argparse
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('command', nargs='+')
args = parser.parse_args()
root = Path(tempfile.mkdtemp(prefix=f'dsh-pnpm-peers-{args.label}-'))
records = []
environment = dict(os.environ)
environment['PATH'] = '/tmp/dsh-node26.9.0/node-v26.9.0-darwin-arm64/bin:' + environment['PATH']

def archive(path, manifest, source):
    with tarfile.open(path, 'w:gz') as output:
        for name, data in [('package.json', json.dumps(manifest)), ('index.js', source)]:
            payload = data.encode()
            entry = tarfile.TarInfo('package/' + name)
            entry.size = len(payload)
            output.addfile(entry, io.BytesIO(payload))

def run(case, command):
    result = subprocess.run(command, cwd=case, env=environment, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = case / f'command-{len(records)}.log'
    log.write_text(result.stdout)
    records.append({'cwd': str(case), 'command': command, 'exitCode': result.returncode,
                    'log': str(log)})
    return result

for version in ['4.23.13', '3.9.0']:
    case = root / version
    case.mkdir()
    archive(case / 'provider.tgz', {'name': 'provider', 'version': version,
            'main': 'index.js'}, f'module.exports = "{version}";\n')
    archive(case / 'consumer.tgz', {'name': 'consumer', 'version': '1.0.0',
            'main': 'index.js', 'peerDependencies': {'provider': '^4.8.1'}},
            'module.exports = require("provider");\n')
    (case / 'package.json').write_text(json.dumps({'name': 'peer-contract',
        'private': True, 'version': '1.0.0', 'dependencies': {
            'consumer': 'file:consumer.tgz', 'provider': 'file:provider.tgz'}}))
    (case / 'pnpm-workspace.yaml').write_text(
        'strictPeerDependencies: true\nautoInstallPeers: false\n')
    install = run(case, args.command + ['install', '--store-dir', str(case / 'store')])
    check = run(case, args.command + ['peers', 'check'])
    runtime = run(case, ['node', '-e',
        'const assert=require("node:assert/strict"); '
        f'assert.equal(require("consumer"), "{version}");'])
    (root / 'results.json').write_text(json.dumps(records, indent=2) + '\n')
    assert runtime.returncode == 0, runtime.stdout
    if args.label == 'official':
        assert install.returncode != 0, install.stdout
        assert 'file:provider.tgz' in install.stdout, install.stdout
        assert check.returncode != 0, check.stdout
        assert 'file:provider.tgz' in check.stdout, check.stdout
    elif version == '4.23.13':
        assert install.returncode == 0, install.stdout
        assert check.returncode == 0, check.stdout
    else:
        assert install.returncode != 0, install.stdout
        assert check.returncode != 0, check.stdout
        assert '3.9.0' in install.stdout, install.stdout
        assert '3.9.0' in check.stdout, check.stdout
print(root / 'results.json')
