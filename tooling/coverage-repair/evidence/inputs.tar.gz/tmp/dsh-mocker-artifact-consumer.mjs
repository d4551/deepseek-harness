import assert from 'node:assert/strict'
import { mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { pathToFileURL } from 'node:url'
import { automockModule } from '@vitest/mocker/node'
import { collectModuleExports, initSyntaxLexers } from '@vitest/mocker/transforms'
import { parseAst } from 'vite'

test('packed module analysis discovers exports from runtime TypeScript syntax', async (t) => {
  const directory = await realpath(await mkdtemp(join(tmpdir(), 'mocker-packed-consumer-')))
  t.after(() => rm(directory, { force: true, recursive: true }))
  const filename = join(directory, 'payload.ts')
  await writeFile(filename, 'export enum Mode { First = 3 }\nexport class Box { constructor(public value: number) {} }')
  await initSyntaxLexers()
  const source = `export * from '${pathToFileURL(filename).href}';`
  const generated = automockModule(source, 'autospy', parseAst, { id: join(directory, 'entry.js') }).toString()
  const exports = collectModuleExports(join(directory, 'result.js'), generated, 'module')
  assert.deepEqual(exports.sort(), ['Box', 'Mode'])
  assert.deepEqual(collectModuleExports(join(directory, 'cjs.js'), 'exports.value = 17;', 'commonjs'), ['value'])
  await writeFile(filename, 'export const broken: = 17;')
  assert.throws(() => automockModule(source, 'autospy', parseAst, { id: join(directory, 'entry.js') }))
})

test('packed manifest owns runtime dependencies and every declared runtime/type entry exists', async () => {
  const url = import.meta.resolve('@vitest/mocker/package.json')
  const manifest = JSON.parse(await readFile(new URL(url), 'utf8'))
  assert.equal(manifest.dependencies.amaro, '1.2.0')
  for (const [name, target] of Object.entries(manifest.exports)) {
    if (typeof target === 'string') continue
    assert.ok((await readFile(new URL(target.default, url))).byteLength > 0, name)
    assert.ok((await readFile(new URL(target.types, url))).byteLength > 0, name)
  }
})
