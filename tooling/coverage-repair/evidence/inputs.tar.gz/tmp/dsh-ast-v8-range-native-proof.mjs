import assert from 'node:assert/strict'
import { Session } from 'node:inspector/promises'
import { test } from 'node:test'
import { pathToFileURL } from 'node:url'
import { Script } from 'node:vm'
import MagicString from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/magic-string/dist/index.mjs'
import { parse } from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/acorn/dist/acorn.mjs'
import { createCoverageMap } from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/@vitest/istanbul-lib-coverage/dist/index.mjs'

const { default: convert } = await import(pathToFileURL(process.argv[2]).href)
test('actual V8 ranges retain authored branching inside generated syntax', async (t) => {
  const filename = '/tmp/dsh-ast-v8-native-range-source.js'
  const url = pathToFileURL(filename).href
  const generated = new MagicString('false ? 11 : 22', { filename })
    .prepend('Boolean(99);\nBoolean(').append(');\nBoolean(77);')
  const code = generated.toString()
  const sourceMap = generated.generateMap({ hires: true, source: filename, includeContent: true })
  const session = new Session()
  session.connect()
  t.after(() => session.disconnect())
  await session.post('Profiler.enable')
  await session.post('Profiler.startPreciseCoverage', { callCount: true, detailed: true })
  assert.equal(new Script(code, { filename: url }).runInNewContext(), true)
  const measured = await session.post('Profiler.takePreciseCoverage')
  await session.post('Profiler.stopPreciseCoverage')
  await session.post('Profiler.disable')
  const coverage = measured.result.find(script => script.url === url)
  assert.ok(coverage)
  const data = await convert({ code, sourceMap, coverage, ast: parse(code, { ecmaVersion: 'latest', sourceType: 'module' }) })
  const result = createCoverageMap(data).fileCoverageFor(filename)
  console.log(JSON.stringify(result.toSummary()))
  assert.equal(result.toSummary().statements.total, 1)
  assert.equal(result.toSummary().statements.covered, 1)
  assert.equal(result.toSummary().branches.total, 2)
  assert.equal(result.toSummary().branches.covered, 1)
  const lines = result.getLineCoverage()
  assert.equal(Object.getPrototypeOf(lines), null)
  assert.deepEqual(Object.entries(lines), [['1', 1]])
})
