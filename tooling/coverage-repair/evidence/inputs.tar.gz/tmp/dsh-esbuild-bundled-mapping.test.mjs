import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises';
import { Session } from 'node:inspector/promises';
import { tmpdir } from 'node:os';
import { join, basename } from 'node:path';
import { test } from 'node:test';
import { pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { parse } from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/acorn/dist/acorn.mjs';
import { TraceMap, originalPositionFor } from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/@jridgewell/trace-mapping/dist/trace-mapping.mjs';
import convert from '/tmp/dsh-ast-v8-1.0.6-source/dist/index.mjs';

const execute = promisify(execFile);
const binary = process.argv[2];
const evidencePrefix = process.argv[3];
assert.ok(binary);
assert.ok(evidencePrefix);
for (const format of ['esm', 'cjs']) {
  for (const target of ['es5', 'esnext']) {
    for (const minify of [false, true]) {
      const label = `${format}-${target}-${minify}`;
      test(label, async (t) => {
        const root = await realpath(await mkdtemp(join(tmpdir(), 'bundled-map-')));
        t.after(() => rm(root, { recursive: true, force: true }));
        const entry = 'import * as dep from "./dependency.js";\n'
          + 'export var box = { get live() { return dep.leaf(16); }, get cold() { return dep.unusedLeaf(22); } };\n'
          + 'export function value() { return box.live; }\n'
          + 'export function uncalled() { return box.cold; }\n'
          + 'export function namespace() { return dep; }';
        const dependency = 'export function leaf(value) { return value + 1; }\n'
          + 'export function unusedLeaf(value) { return value + 1; }';
        await writeFile(join(root, 'entry.js'), entry);
        await writeFile(join(root, 'dependency.js'), dependency);
        const output = join(root, format === 'esm' ? 'bundle.mjs' : 'bundle.cjs');
        const args = [join(root, 'entry.js'), '--bundle', `--format=${format}`, `--target=${target}`,
          '--sourcemap=external', `--outfile=${output}`];
        if (minify) args.push('--minify');
        await execute(binary, args);
        const code = await readFile(output, 'utf8');
        const map = JSON.parse(await readFile(`${output}.map`, 'utf8'));
        const trace = new TraceMap(map);
        const ast = parse(code, { ecmaVersion: 'latest', sourceType: 'module', locations: true });
        const functions = [];
        const visit = node => {
          if (node === null || typeof node !== 'object') return;
          if (['FunctionDeclaration', 'FunctionExpression', 'ArrowFunctionExpression'].includes(node.type)) {
            functions.push({ code: code.slice(node.start, node.end), generated: node.loc.start,
              original: originalPositionFor(trace, node.loc.start) });
          }
          for (const child of Object.values(node)) {
            if (Array.isArray(child)) child.forEach(visit);
            else if (child && typeof child === 'object') visit(child);
          }
        };
        visit(ast);
        const session = new Session();
        session.connect();
        t.after(() => session.disconnect());
        await session.post('Debugger.enable');
        await session.post('Profiler.enable');
        await session.post('Profiler.startPreciseCoverage', { callCount: true, detailed: true });
        const module = await import(pathToFileURL(output).href);
        const exported = format === 'cjs' ? module.default : module;
        assert.equal(exported.value(), 17);
        assert.equal(typeof exported.namespace().unusedLeaf, 'function');
        const measured = await session.post('Profiler.takePreciseCoverage');
        await session.post('Profiler.stopPreciseCoverage');
        const coverage = measured.result.find(item => item.url === pathToFileURL(output).href);
        assert.ok(coverage);
        const executed = await session.post('Debugger.getScriptSource', { scriptId: coverage.scriptId });
        assert.equal(executed.scriptSource, code);
        const converted = await convert({ code, sourceMap: map, coverage, ast, wrapperLength: 0 });
        await writeFile(`${evidencePrefix}-${label}.json`, JSON.stringify({ code, map, functions, coverage, converted }, null, 2));
        const mapped = functions.filter(fn => fn.original.source !== null);
        assert.equal(mapped.length, 7, 'all seven authored functions and accessors, with no compiler functions');
        assert.deepEqual(mapped.map(fn => [basename(fn.original.source), fn.original.line]).sort(), [
          ['dependency.js', 1], ['dependency.js', 2],
          ['entry.js', 2], ['entry.js', 2], ['entry.js', 3], ['entry.js', 4], ['entry.js', 5],
        ]);
        const entryCoverage = converted[join(root, 'entry.js')];
        const dependencyCoverage = converted[join(root, 'dependency.js')];
        assert.equal(Object.keys(entryCoverage.fnMap).length, 5);
        assert.equal(Object.keys(dependencyCoverage.fnMap).length, 2);
        assert.deepEqual(Object.values(entryCoverage.f).sort(), [0, 0, 1, 1, 1]);
        assert.deepEqual(Object.values(dependencyCoverage.f).sort(), [0, 1]);
      });
    }
  }
}
