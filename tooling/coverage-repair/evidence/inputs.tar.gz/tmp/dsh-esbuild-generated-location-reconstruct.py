from pathlib import Path
import difflib
import hashlib
import json
import tarfile
import tempfile

source = Path('/tmp/dsh-esbuild-0.28.2-source')
archive = Path('/tmp/dsh-esbuild-0.28.2-source.tgz')
prefix = 'esbuild-609683d892977362a0f99026cb74b96263d728a9'
paths = ['internal/linker/linker.go', 'internal/sourcemap/sourcemap.go', 'internal/sourcemap/unmapped_test.go']
parent = Path(tempfile.mkdtemp(prefix='dsh-esbuild-generated-location-frozen-'))
with tarfile.open(archive) as packed:
    packed.extractall(parent, filter='data')
root = parent / prefix
patch = []
inputs = []
for relative in paths:
    current = (source / relative).read_bytes()
    previous_path = root / relative
    previous = previous_path.read_bytes() if previous_path.exists() else b''
    patch.extend(difflib.unified_diff(previous.decode().splitlines(True), current.decode().splitlines(True),
        fromfile=f'a/{relative}' if previous_path.exists() else '/dev/null', tofile=f'b/{relative}'))
    inputs.append({'path': relative, 'sha256': hashlib.sha256(current).hexdigest()})
patch_path = Path('/tmp/dsh-full-green-plan/esbuild-generated-locations.patch')
patch_path.write_text(''.join(patch))
(root / paths[-1]).write_bytes((source / paths[-1]).read_bytes())
record = {'root': str(root), 'archive': str(archive), 'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'patch': str(patch_path), 'inputs': inputs, 'state': 'official sources with regression test copied for negative control'}
Path('/tmp/dsh-esbuild-generated-location-frozen.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
