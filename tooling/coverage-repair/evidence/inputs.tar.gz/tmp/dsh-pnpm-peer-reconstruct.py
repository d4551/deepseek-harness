from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile

archive_path = Path('/tmp/dsh-pnpm-12.4.2-source.tgz')
source = Path('/tmp/dsh-pnpm-12.4.2-source')
report = Path('/tmp/dsh-full-green-plan')
paths = [
    'pnpm/crates/deps-inspection-peers/src/lib.rs',
    'pnpm/crates/deps-inspection-peers/src/linked.rs',
    'pnpm/crates/deps-inspection-peers/src/artifact_versions.rs',
    'pnpm/crates/deps-inspection-peers/src/linked_artifact_versions.rs',
    '.changeset/archive-peer-versions.md',
]
directory = Path(tempfile.mkdtemp(prefix='dsh-pnpm-peer-reconstruction-'))
patch = []
with tarfile.open(archive_path) as archive:
    prefix = archive.getmembers()[0].name.split('/')[0]
    members = {member.name: member for member in archive}
    for path in paths:
        name = f'{prefix}/{path}'
        original = archive.extractfile(members[name]).read().decode() if name in members else ''
        revised = (source / path).read_text()
        patch.extend(difflib.unified_diff(original.splitlines(keepends=True),
            revised.splitlines(keepends=True),
            fromfile=f'a/{path}' if name in members else '/dev/null',
            tofile=f'b/{path}', n=0))
    archive.extractall(directory, filter='data')
patch_path = report / 'pnpm-archive-peer-versions.patch'
patch_path.write_text(''.join(patch))
fresh = directory / prefix
command = ['git', 'apply', '--unidiff-zero', str(patch_path)]
result = subprocess.run(command, cwd=fresh, text=True, capture_output=True)
assert result.returncode == 0, result.stderr
fingerprints = {}
for path in paths:
    actual = (fresh / path).read_bytes()
    assert actual == (source / path).read_bytes(), path
    fingerprints[path] = hashlib.sha256(actual).hexdigest()
record = {
    'time': datetime.now(timezone.utc).isoformat(),
    'archive': str(archive_path),
    'archiveSha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    'source': str(source), 'reconstruction': str(fresh),
    'patch': str(patch_path),
    'patchSha256': hashlib.sha256(patch_path.read_bytes()).hexdigest(),
    'command': command, 'exitCode': result.returncode, 'files': fingerprints,
    'scope': 'Source reconstruction only; no fresh-cache build is claimed.'
}
(report / 'pnpm-archive-peer-reconstruction.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
