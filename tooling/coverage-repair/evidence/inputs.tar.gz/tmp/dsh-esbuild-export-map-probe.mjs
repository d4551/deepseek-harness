import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdtemp, readFile, realpath, rm, writeFile } from 'node:fs/promises';
import { Session } from 'node:inspector/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { parse } from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/acorn/dist/acorn.mjs';
import { TraceMap, originalPositionFor } from '/tmp/dsh-ast-v8-1.0.6-source/node_modules/@jridgewell/trace-mapping/dist/trace-mapping.mjs';
import convert from '/tmp/dsh-ast-v8-1.0.6-source/dist/index.mjs';

const execute = promisify(execFile);
for (const format of ['esm', 'cjs']) {
  for (const minifyWhitespace of [false, true]) {
    for (const keepNames of [false, true]) {
      const label = `${format}-${minifyWhitespace}-${keepNames}`;
      test(label, async (t) => {
        const root = await realpath(await mkdtemp(join(tmpdir(), 'esbuild-export-map-')));
        t.after(() => rm(root, { recursive: true, force: true }));
        const original = 'export function value() { return 17; }\nexport function uncalled() { return 23; }';
        const authored = join(root, 'authored.js');
        const generated = join(root, format === 'esm' ? 'generated.mjs' : 'generated.cjs');
        await writeFile(authored, original);
        const args = [authored, `--format=${format}`, '--sourcemap=external', `--outfile=${generated}`];
        if (minifyWhitespace) args.push('--minify-whitespace');
        if (keepNames) args.push('--keep-names');
        await execute('/tmp/dsh-esbuild-0.28.2-official', args);
        const code = await readFile(generated, 'utf8');
        const sourceMap = JSON.parse(await readFile(`${generated}.map`, 'utf8'));
        const session = new Session();
        session.connect();
        t.after(() => session.disconnect());
        await session.post('Debugger.enable');
        await session.post('Profiler.enable');
        await session.post('Profiler.startPreciseCoverage', { callCount: true, detailed: true });
        const loaded = await import(pathToFileURL(generated).href);
        assert.equal(format === 'esm' ? loaded.value() : loaded.default.value(), 17);
        const measured = await session.post('Profiler.takePreciseCoverage');
        await session.post('Profiler.stopPreciseCoverage');
        const coverage = measured.result.find(record => record.url === pathToFileURL(generated).href);
        assert.ok(coverage, 'native module execution must be present');
        const executed = await session.post('Debugger.getScriptSource', { scriptId: coverage.scriptId });
        const wrapperLength = executed.scriptSource.indexOf(code);
        assert.ok(wrapperLength >= 0, 'the executed script must contain the exact compiler output');
        assert.equal(executed.scriptSource.lastIndexOf(code), wrapperLength);
        const result = await convert({ code, sourceMap, coverage, wrapperLength,
          ast: parse(code, { ecmaVersion: 'latest', sourceType: 'module', locations: true }),
        });
        const file = result[authored];
        assert.ok(file);
        const ast = parse(code, { ecmaVersion: 'latest', sourceType: 'module', locations: true });
        const arrows = [];
        const visit = node => {
          if (node === null || typeof node !== 'object') return;
          if (node.type === 'ArrowFunctionExpression') {
            arrows.push({ generated: code.slice(node.start, node.end),
              original: originalPositionFor(new TraceMap(sourceMap), node.loc.start) });
          }
          for (const value of Object.values(node)) {
            if (Array.isArray(value)) value.forEach(visit);
            else if (value && typeof value === 'object') visit(value);
          }
        };
        visit(ast);
        await writeFile(`/tmp/dsh-esbuild-export-map-${label}.json`, JSON.stringify({
          original, code, sourceMap, coverage, wrapperLength, arrows,
          functions: file.fnMap, counts: file.f,
        }, null, 2));
        assert.deepEqual(Object.values(file.fnMap).map(fn => fn.name).sort(), ['uncalled', 'value']);
        assert.deepEqual(Object.values(file.f), [1, 0]);
      });
    }
  }
}
