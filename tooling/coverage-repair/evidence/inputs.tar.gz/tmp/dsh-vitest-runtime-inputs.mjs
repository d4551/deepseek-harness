import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdir, writeFile, cp } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'

const entries = []
for (const name of ['vitest', '@vitest/spy', '@vitest/pretty-format', '@vitest/browser']) {
  const response = await fetch(`https://registry.npmjs.org/${name}/5.0.1`)
  assert.equal(response.status, 200)
  const metadata = await response.json()
  const archive = await fetch(metadata.dist.tarball)
  assert.equal(archive.status, 200)
  const bytes = Buffer.from(await archive.arrayBuffer())
  assert.equal(`sha512-${createHash('sha512').update(bytes).digest('base64')}`, metadata.dist.integrity)
  const directory = `/tmp/dsh-vitest-runtime-published/${name.split('/').at(-1)}`
  await mkdir(directory, { recursive: true })
  await writeFile(`${directory}/package.tgz`, bytes)
  await writeFile(`${directory}/registry.json`, `${JSON.stringify(metadata, null, 2)}\n`)
  const extracted = spawnSync('tar', ['-xzf', `${directory}/package.tgz`, '-C', directory], { stdio: 'inherit' })
  assert.equal(extracted.status, 0)
  if (name !== 'vitest') await cp(`${directory}/package/dist`, `/tmp/dsh-vitest-5.0.1-source/packages/${name.split('/').at(-1)}/dist`, { recursive: true })
  entries.push({ name, version: metadata.version, dist: metadata.dist })
}
await writeFile('/tmp/dsh-vitest-runtime-published/inputs.json', `${JSON.stringify(entries, null, 2)}\n`)
