import assert from 'node:assert/strict'
import { mkdtemp, realpath, rm, writeFile } from 'node:fs/promises'
import { Session } from 'node:inspector/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { pathToFileURL } from 'node:url'
import { createVitest } from '/Users/brandon/Downloads/deepseek-harness/node_modules/vitest/dist/node.js'
import { V8CoverageProvider } from '/Users/brandon/Downloads/deepseek-harness/node_modules/@vitest/coverage-v8/dist/provider.js'

async function project(t, source, viteModuleRunner, plugins = []) {
  const root = await realpath(await mkdtemp(join(tmpdir(), 'vitest-source-baseline-')))
  t.after(() => rm(root, { recursive: true, force: true }))
  const filename = join(root, 'payload.js')
  await writeFile(filename, source)
  const vitest = await createVitest({
    root, config: false, watch: false,
    experimental: { viteModuleRunner },
    coverage: {
      enabled: true, provider: 'v8', include: ['payload.js'], exclude: [],
      reporter: ['json'], thresholds: { 100: true, perFile: true },
    },
  }, { plugins })
  t.after(() => vitest.close())
  const provider = new V8CoverageProvider()
  provider.initialize(vitest)
  return { provider, filename }
}

test('published provider drops invalid native source without rejecting', async (t) => {
  const { provider } = await project(t, 'export const value = ;', false)
  const coverage = await provider.generateCoverage({ allTestsRun: true })
  assert.deepEqual(coverage.files(), [])
})

test('published provider replaces a failed Vite transform with disk text', async (t) => {
  const failure = new Error('source-integrity transform rejected')
  const { provider, filename } = await project(t, 'export const value = 17;', true, [{
    name: 'source-integrity-rejection',
    transform(_code, id) {
      if (id.endsWith('/payload.js')) throw failure
    },
  }])
  const coverage = await provider.generateCoverage({ allTestsRun: true })
  assert.deepEqual(coverage.files(), [filename])
})

test('published provider discards a deleted executed source without rejecting', async (t) => {
  const { provider, filename } = await project(t, 'export function value() { return 17; }', false)
  const session = new Session()
  session.connect()
  t.after(() => session.disconnect())
  await session.post('Profiler.enable')
  await session.post('Profiler.startPreciseCoverage', { callCount: true, detailed: true })
  const loaded = await import(pathToFileURL(filename).href)
  assert.equal(loaded.value(), 17)
  const coverage = await session.post('Profiler.takePreciseCoverage')
  await session.post('Profiler.stopPreciseCoverage')
  await session.post('Profiler.disable')
  const executed = coverage.result.find(entry => entry.url === pathToFileURL(filename).href)
  assert.ok(executed)
  assert.ok(executed.functions.some(fn => fn.functionName === 'value' && fn.ranges.some(range => range.count > 0)))
  const report = `${filename}.coverage.json`
  await writeFile(report, JSON.stringify({ result: [{ ...executed, startOffset: 0, isExtendedContext: true }] }))
  await rm(filename)
  provider.onAfterSuiteRun({ coverage: report, environment: 'ssr', projectName: '', testFiles: [filename] })
  const converted = await provider.generateCoverage({ allTestsRun: false })
  assert.deepEqual(converted.files(), [])
})
