# Additional confirmed findings and unresolved verification

## Newly verified deletion defects

Deleting the final imported per-record entry restores it on the next `loadAll`.
The loader treats an empty current tree as permission to import the unchanged
original unit document again. A real filesystem reproduction exits 1 with the
deleted value back in the returned table; the original source is unchanged:
`/tmp/dsh-storage-last-delete.log`. This is an immediate data-integrity defect,
not merely a missing crash simulation, and remains a high-priority repair.

Per-record deletion also resolves after `unlink` without flushing its parent
directory. The native trace records only two `lstat` pairs and one `unlink`
pair, with no `fsync`, while confirming removal and unchanged neighboring data:
`/tmp/dsh-storage-delete-trace.json` and `/tmp/dsh-storage-delete-trace.log`.
The durable-on-resolution interface contract remains unchanged. Durable
deletion, persistent import completion, and durable first-write ancestors need
one coherent design before claiming this storage surface complete.

These supplement the itemized source, lint, coverage, and mutation inventories.
Line numbers refer to the inspected worktree and must be refreshed after edits.

All prior command-runner storage mutation outputs are withdrawn as acceptance
evidence: shared Vitest/Vite cache failures were counted as kills. Raw reports
remain unchanged. The six-module/440-mutant isolated-cache replay is pending
at `/tmp/dsh-storage-mutation-cache-isolated.log`; no replacement score is
accepted before complete status-reason review.

## Storage test gap

The baseline positive import test in
`packages/storage/storage-json/tests/bootstrap-boundary.spec.ts` could reopen
the unchanged import source. Publishing-loop and filename mutants survived.
The test now verifies exact persisted contents, preserves source/neighbor
bytes, removes only the source fixture, and reopens from generated files.
`mutation-current.md` retains a withdrawn historical output. Its apparent
publishing-loop kills do not prove those mutants are detected. The pending
isolated-cache run must establish current verdicts; whole-task mutation
acceptance remains open.

## Windows gate diagnostic mismatch

The `exit code 1` assertion conflicted with an `exit 1` diagnostic. The source
now emits `exit code`; 61 owning tests pass, including real failing-child
regressions. Native Windows execution remains required.

## Trajectory CSS

Source: `packages/client/ui-trajectory/src/client/TrajectoryCell.module.css`.
Evidence: [/tmp/dsh-trajectory-css-brutalise-current.json](/tmp/dsh-trajectory-css-brutalise-current.json).
Current single-file audit: 15 errors, 2 warnings, no exclusions or overrides.

| Rule | Severity | Lines | Finding |
| --- | --- | --- | --- |
| UI003 | error | 60, 70, 72, 89, 94 | Local color mixing |
| UI007 | error | 8, 24, 31, 41, 121, 129 | Raw fixed dimensions |
| UI016 | error | 44 | Raw radius |
| UI017 | error | 9, 102, 122 | Raw spacing |
| UI010 | warning | 102, 130 | Physical-direction styling |

## Incomplete source enforcement

- `QuestionComposer.tsx` retains rejection callbacks at inspected lines 183 and
  239; assess behavior under the no-evasion contract.
- The coverage directive in `storage-json/src/atomic.ts` was removed; the
  five-module snapshot at that stage reached 100% scoped coverage. Later
  six-module changes require their own final-source evidence.
- The `single-unit.ts` read-method lint directive was removed with the
  publication-before-visibility repair. Its opener catch and assertion remain.
- The empty rejection callback in `storage-json/src/unit-lifecycle.ts` was
  replaced with owned cleanup preserving rejection. A real resource-retention
  regression fails when cleanup is removed in isolation. Its historical 100%
  command-runner mutation score is withdrawn with all earlier storage scores.
- The baseline 2,395-finding scan does not cover every prohibited architectural
  or expression pattern. Some recorded sites are repaired; reconcile them
  before using a fresh outstanding count. Raw findings remain unchanged.

## Derived-cache recovery

The version-4 per-record `session_projcache` remains. Malformed, unreadable,
and stale-format documents read as absent under the backend contract.
Schema-invalid records in explicitly rebuildable domain tables are now deleted
individually and reconstructed from session history. Authoritative records and
globals continue to reject without deletion. Source-loaded native permission
tests pass locally, but Windows/root execution and valid subprocess coverage
remain unverified. Vitest's TypeScript remapping failure is recorded in the
execution ledger.

## JSON inherited-property defect

An absent declared table named `constructor` was read from the JavaScript
prototype and rejected as damaged storage. Own-entry lookup repairs it while
preserving native JSON values and special keys. The isolated original source
fails and the repaired source passes; see `/tmp/dsh-format-before.log` and
`/tmp/dsh-format-after.log`. Parser catch removal remains open.

## Cache durability observation race

The session-disposal test failed once in three focused executions because its
40 ms wait could expire before the real checkpoint write. It now waits for the
actual durable domain event and retains exact disk/cache assertions. Twenty
targeted executions passed without retries. All ten fixed 40 ms waits are now
removed; the complete owning suite passes 24 tests, and 320 stress executions
pass without retries. Existing timer and spying test doubles remain open debt.

## Historical attachment request blockage

A missing admitted image still rejects request preparation after a text-only
followup and persisted-message reload. The real-store reproduction is
`/tmp/dsh-attachment-quarantine-probe.log`. Implementation remains open;
`B4-attachment-recovery.md` specifies the next coherent repair.

## Concurrent attachment integrity

The local request-sharing key admitted different metadata for the same content
ID into one operation. Nine real regressions failed: invalid references could
reuse a valid result, valid references could inherit a failure, and names could
be mixed. Complete-reference sharing and owned cleanup repair the local store.
Ten regressions now pass; the owning suite passes 80 with one Windows-only
test unexecuted locally. Both provider collectors independently used last-wins
ID maps; both now use the shared strict materializer and canonical complete
reference key. The original combined owning replay passes 1,011 tests with one
native-Windows skip. Eight later DeepSeek extension-failure cases pass in its
388-test replay, with 100% changed-source statements, branches, functions and
lines; `/tmp/dsh-extension-failures-owning-coverage.log`. LLM lifecycle coverage
remains open. This does not implement historical attachment quarantine.

The source-based replay-ordering analysis at `/tmp/dsh-b4-replay-ordering.md`
proposes execution-owner selection before image preparation and a mandatory
final-request durability barrier before dispatch. Retained bytes, replay
cursor timing, HMR ownership and recorded preparation outcomes require an
explicit contract migration and real regressions. This remains open design,
alongside session projections, token-meter state, compaction and recovery
authorization in `B4-attachment-recovery.md`.

## Subprocess environment conflict

Two `spawn-env.spec.ts` cases fail under automatic subprocess coverage because
Node propagates `NODE_V8_COVERAGE` into explicitly supplied environments.
Reproduced with package-managed Node 26.8.2. Evidence:

- [/tmp/dsh-spawn-env-node2682-coverage.log](/tmp/dsh-spawn-env-node2682-coverage.log)
- [/tmp/dsh-exact-env-node2682.log](/tmp/dsh-exact-env-node2682.log)

Removing child coverage or weakening exact-environment assertions does not
satisfy both contracts.

## Instruction and environment blockers

- `verify-md-wrap` and `verify-doc-budgets` fail on protected AGENTS files.
  Their current instructions forbid agent edits. No exception was applied.
- `git ls-files '*.bao'` found no tracked Bao archives. Canonical source and
  tooling must be located or the instruction/source conflict resolved.
- Three Landlock tests failed on macOS in the last full run. Actual Linux
  execution is necessary; exclusion does not establish correctness.
- Native Windows/ACL and the complete CI matrix remain unverified for the
  final worktree.

## Evidence that must not be overstated

- Storage: latest owning run passes 131 tests across 12 files
  (`/tmp/dsh-storage-cache-isolated-suite.log`). The earlier five-module
  100% coverage is scoped historical evidence. The historical mutation output
  96.97% (384 killed, 12 survived) is invalid acceptance evidence because cache
  infrastructure failures were counted as kills. The six-module/440-mutant
  replay is pending; native Windows correctness remains unverified.
- Markdown: 89/89 mutants killed; this covers only its scoped implementation.
- Preview accessibility: four axe cases passed; this is not an application
  accessibility audit.
- Composer: browser event replay exists; OS-native IME validation is distinct.
- Documentation: the older aggregate passed 30 and failed two; latest full
  aggregate passes 29 and fails three, with zero skipped
  (`/tmp/dsh-integrity-doc-sync.log`). The generated graph failure has a passing
  post-regeneration freshness check (`/tmp/dsh-integrity-doc-graphs-verify.log`).
  Protected AGENTS wrapping/budget failures remain; scoped checks and graph
  freshness do not replace final aggregate replay.
- Full lint remains at the latest measured 383 errors. Later scoped fixes do
  not establish a lower complete count without a new full measurement.
- Previous full coverage predates subsequent repairs and still contained
  coverage directives. It is neither current nor unsuppressed.
