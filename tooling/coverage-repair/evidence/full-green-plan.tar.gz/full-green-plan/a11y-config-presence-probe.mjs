import { specAuditsPackageSource } from '/Users/brandon/Downloads/deepseek-harness/scripts/client-a11y-coverage.ts'
const source = `import { auditSurface, accessibilityFailures } from '@deepseek-ai/dsh-client-a11y'
import { Widget } from '../src/index.ts'
import { render } from '@testing-library/react'
import { expect, test } from 'vitest'
test('unreached audit', async () => {
  if (false) {
    render(<Widget />)
    const audit = await auditSurface('widget', document.body)
    expect(accessibilityFailures([audit], 100)).toBe('')
  }
})`
console.log(JSON.stringify({ deadBranchAccepted: specAuditsPackageSource(source, 'ui-widget') }))
console.log(JSON.stringify({ skippedTestAccepted: specAuditsPackageSource(source.replace("test('unreached audit'", "test.skip('unreached audit'").replace('if (false) {', '{'), 'ui-widget') }))
