# Complete normal test run: enforcement checkpoint

The complete normal command `bun run test` finished with exit 1 on 2026-09-16:
1,365 passed files, three failed files and seven skipped files; 20,313 passed
tests, five failed tests and 42 skipped tests. Duration: 766.90 seconds.
Accessibility execution verified 67 actual audit tests against the complete
package candidate inventory. No retries or reporter replacement were used.

Raw output: `/tmp/dsh-full-current-enforcement.log`.
Complete failure section: `/tmp/dsh-full-current-enforcement-failures.log`.
HEAD: `8f8780a13e40205c50518fa34b8cf11e3a6d141c` throughout this run.
The external index changed during execution; root and assigned source owners
held edits. A test that writes repository fixtures was discovered in this run;
its removal and subsequent source repairs require affected replay. This run
is not complete-green acceptance or evidence that no test can modify source.

## Failures observed in the complete run

1. `scripts/suppression-justifications.spec.ts`: live authored source has
   2,489 prohibited findings, including 685 directives, 1,445 catch clauses and
   359 static catch-handler accesses. Every finding remains in scope.
2. `scripts/bun-conversion-residue.spec.ts`: truthful official upstream metadata
   in `tooling/stryker/provenance/browser-peer-metadata.json` contains the
   upstream package-manager name. The current word-based gate rejects it.
   No exemption or modified provenance is accepted; user policy decision pending.
3. `packages/experimental/webworker-runtime/tests/node/sandbox-stack.spec.ts`:
   workspace/temp writes and denied outside writes cannot execute because
   the composed host sandbox reports `SandboxUnavailableError`.
4. The same file: read-only and unrestricted policy comparison fails at the
   required confined run with `SandboxUnavailableError`.
5. The same file: concurrent command-policy isolation fails at the required
   confined run with `SandboxUnavailableError`.

The worker setup mixed replaced child-process primitives with native host
platform selection. The subsequent [native Worker repair](worker-sandbox-repair.md)
retains all three scenarios and exact assertions, executes them through the
packed production providers in actual browser Workers, and passes the complete
911-test Worker-runtime package. These three failures are repaired in focused
replay; this is not a new complete repository run. The first two failures remain.
The prior 20-failure report remains `full-run-finish-failures.md`.

## Separate blockers

The 42 skipped tests are not passing target-platform evidence. Coverage was
not enabled in this normal run, so it does not replace strict coverage replay.
Complete documentation replay reports 30 passed, two failed and zero skipped
in `/tmp/dsh-profile-a11y-final-doc-sync.log`: protected AGENTS wrapping and
root AGENTS word budget remain failures. Build and complete typed lint passed
before the next source repairs; their logs remain linked from INDEX.md.
