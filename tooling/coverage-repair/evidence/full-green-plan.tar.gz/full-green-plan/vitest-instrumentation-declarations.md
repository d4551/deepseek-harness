# Instrumentation declaration ownership

The source-built Istanbul instrumenter resolves two strict converter diagnostics:
a circular `programVisitor` parameter declaration and the missing
`@types/convert-source-map` dependency. Its executable is byte-identical to the
official published package. This is a scoped dependency repair; the converter,
runner and repository do not yet meet complete acceptance.

## Source and artifact

The source is `vitest-dev/istanbuljs` commit
`8bda20d9740143d950ea80e367b0151527faa0a9`, identified from the published npm
provenance. The verified archive is
`/tmp/dsh-istanbul-1.0.1-source.tar.gz`, SHA-256
`bc2d8a54ef26abe4f1a11fd7060cccd09fcf8c3d236a0f6065865643453d83aa`.
The published npm archive also matches its registry SHA-512 integrity value.

The source checkout is `/tmp/dsh-istanbul-1.0.1-source`. Five files differ from
the source archive, recorded in `/tmp/dsh-istanbul-source-changes.json`:

- `visitor.ts` names the parameter `babelTypes`, preventing the declaration
  bundler from colliding with its imported `types` identifier.
- The instrumenter owns the source-map declaration package in its dependencies.
- The two owning package versions match the published release, 1.0.1. The
  attested release workflow builds before applying this version increment.
- The workspace catalog and lockfile resolve current dependencies normally.

No instrumentation algorithm, test assertion, source exclusion, or gate is
changed. The executable SHA-256 is
`22eccdfa9e9a0425888fb76f7a128600a80f7417ec9c5d47ade8cfef86017d4e`, identical
before and after the declaration repair. The repaired declaration SHA-256 is
`38d00e4a04282560241d5edf88617c09d00247bbf2a198bbe000ca54bceaac1d`.

The normally packed artifact is
`/tmp/dsh-istanbul-declaration-artifact/vitest-istanbul-lib-instrument-1.0.1.tgz`,
SHA-256 `7f04c226f6bf35ff97499c69d9f25e8052dbe8235145650008436a523196c2fd`.
The converter source tree owns an identical copy under `artifacts/` and uses
a relative file dependency. There is no dependency override for this repair.

## Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Unmodified attested source build | Both emitted files match the published package | `/tmp/dsh-istanbul-baseline-build.log` |
| Repaired source build | Pass | `/tmp/dsh-istanbul-declaration-build.log` |
| Complete strict source and test compilation, library checking enabled | Pass | `/tmp/dsh-istanbul-declaration-types.log` |
| Complete upstream suite | 455 passed across 35 files, zero skipped | `/tmp/dsh-istanbul-declaration-complete-tests.log` |
| Upstream configured lint | Pass | `/tmp/dsh-istanbul-declaration-lint.log` |
| Packed consumer strict compilation | Pass | `/tmp/dsh-istanbul-consumer-types.log` |
| Packed consumer real Babel instrumentation | Exact function and branch counters pass | `/tmp/dsh-istanbul-consumer-runtime.log` |
| Invalid packed consumer arguments | Compiler rejects both invalid calls | `/tmp/dsh-istanbul-consumer-negative.log` |
| Independent frozen installation with fresh cache | Pass | `/tmp/dsh-istanbul-frozen-install.log` |
| Independent build | Both repaired output files match byte-for-byte | `/tmp/dsh-istanbul-frozen-build.log` |
| Independent strict compilation | Pass | `/tmp/dsh-istanbul-frozen-types.log` |
| Independent complete suite | 455 passed across 35 files | `/tmp/dsh-istanbul-frozen-tests.log` |
| Converter compilation immediately after dependency integration | Two dependency diagnostics removed; four emitter diagnostics remain at that checkpoint | `/tmp/dsh-ast-v8-instrumenter-types.log` |

The consumer does not declare `@types/convert-source-map` directly. Its missing
dependency must arrive through the repaired instrumenter. It executes actual
instrumented code with both conditional outcomes and rejects malformed syntax.
The independent reconstruction overlays only the five recorded changes onto
the official source archive, uses a fresh dependency cache, and leaves the
frozen lockfile unchanged. Its exact location is recorded in
`/tmp/dsh-istanbul-frozen-location.json`.

Upstream configured lint still contains pre-existing disabled rules, and its
complete measured coverage is below 100%. Neither is accepted as repository
full-green evidence. This artifact is installed only in the isolated converter;
root application and isolated runner integration remain open.

The dependency ownership follows the
[TypeScript declaration publishing contract](https://www.typescriptlang.org/docs/handbook/declaration-files/publishing.html).
Source and release provenance are from the
[owning Istanbul repository](https://github.com/vitest-dev/istanbuljs).
