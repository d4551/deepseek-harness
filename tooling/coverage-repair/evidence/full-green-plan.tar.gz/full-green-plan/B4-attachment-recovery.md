# B4 execution slice: historical attachment recovery

Status: open. This supplements the full plan; it is not an implemented feature.

The source-based [replay ordering analysis](/tmp/dsh-b4-replay-ordering.md)
specifies early execution-owner selection, retained prepared bytes, a mandatory
final-request durability barrier, and the required consumer migration. Replay
cursor ordering and recorded preparation evidence require explicit contracts
and real regressions before implementation can be accepted.

Selection must retain the chosen replay callback without invoking it or
consuming its script. The proposed durability barrier cannot be bypassed by a
terminal replay listener and must fail before terminal construction. Defining
replay order at actual dispatch is a recommendation, not an established API;
reverse iteration, reverse checkpoint completion and generation disposal need
explicit tests. Existing ReplayEntry data has no prepared-request envelope,
so replay cannot yet verify typed preparation or quarantine outcomes. This
analysis does not implement B4 or replace session/token-meter/compaction work.

## Current implementation boundary

The local store's concurrent-reference integrity repair is implemented and
scoped tests pass. Both provider collectors now use a shared strict
materializer that verifies every distinct complete reference before indexing
results by content ID. The combined owning replay passes 1,011 tests with one
existing native-Windows skip. A later DeepSeek run adds eight extension-failure
cases and passes 388 tests with 100% changed-source coverage in all four metrics
(`/tmp/dsh-extension-failures-owning-coverage.log`). LLM lifecycle coverage
remains open. These repairs stand independently and do not implement
quarantine, retained-byte prepared dispatch, or recovery events.

Source tracing found additional required consumers: cached session message
derivation, token-meter surface/context/breakdown folds, compaction selection,
request reconstruction invariants, API recovery authorization and fork slicing.
Log-only attachment transitions must invalidate model projection without
rewriting raw transcript events. Historical requests must fold their captured
log prefix; later recovery cannot retroactively change an earlier request.

Recovery after current `llm/stream` middleware is incorrect: its durability
checkpoint has already run and the announced request is frozen. The proposed
replacement is one owned prepared-request lifetime that retains the verified
bytes, returns the exact canonical request and dispatches those bytes without
rereading. This is not yet implemented or fully designed. Preparing before the
existing middleware also changes registered-provider replay interception,
which can currently finish without attachment I/O; that contract must be
resolved through actual replay consumers before changing dispatch order.

Token-meter's current constant-size folds do not retain enough information to
reprice arbitrary quarantine/recovery transitions or a later append of an
already-quarantined reference. The implementation must explicitly retain the
required active surface/reference state and migrate checkpoint versions, or
provide another fully enforced token-owner measurement contract. Returning
zero deltas or merely invalidating the live cache is insufficient. Compaction
must select and price the final projected content and detect equal-token-cost
content changes while preparation is outstanding.

The explicit recovery entrypoint belongs in the existing session-controller
service. Resolve references from durable history, not client-supplied metadata;
use Agent maintenance ownership; verify every conflicting same-ID reference;
clear only the exact still-current quarantine transition; and await persistence
flush before acknowledging success. A failed flush must block dispatch or
recovery acknowledgement even if an in-memory event already exists.

## Verified failure and priority

The real local attachment store and pi-ai request conversion succeed with an
admitted image. Removing only the probe-owned object produces
`ATTACHMENT_NOT_FOUND`. A later text-only message fails on the same image, as
does reconstruction of the saved messages with a new store. The original
image block remains intact. Evidence: `/tmp/dsh-attachment-quarantine-probe.log`.

This can make an otherwise usable session permanently unable to send requests.
It follows storage-integrity repairs in priority. A passing conversion probe
alone will not close the feature; actual loop/provider and durable replay
evidence are required.

## Source ownership to preserve

- `packages/attachment/attachment/src/error.ts` owns attachment failure codes.
  Storage retains exact failure reporting and immutable content identity.
- `packages/attachment/attachment-local/src/index.ts` resolves image requests
  through the original verified object and request-version production.
- `packages/llm/llm-pi-ai/src/context.ts` collects nested image references and
  resolves them before provider conversion. Provider implementations must not
  create independent recovery state or silently discard failed images.
- `packages/core/agent-loop/src/agent.ts` derives messages from durable session
  history, freezes the request, and dispatches the prepared model call.
- Session event/projection ownership must be traced completely before adding
  the quarantine and recovery event contracts. Regenerate vocabulary and
  persistence documentation through the existing owning generators.

## Implementation sequence

1. Promote the current real-store reproduction into an owning regression.
   Cover top-level images and images nested in tool results. Keep probe-owned
   object deletion explicit and preserve every original history block.
2. Define one session-owned event contract for quarantine and verified
   recovery. Record the reference identity and stable failure class, without
   host paths, raw image bytes, secrets, or a second attachment schema.
3. Implement deterministic projection from committed events. Every occurrence
   of a quarantined reference receives the same explanatory text, including
   display name when present, ID prefix, and failure class. Do not rewrite
   historical messages. Recovery restores the original image reference.
4. Integrate recovery into actual request preparation before provider dispatch.
   Reproject after recording a newly discovered failure. Repeated references
   and concurrent preparation must produce one effective transition.
5. Classify only documented failures: missing/corrupt objects quarantine
   immediately; general read failure receives one cancellation-aware retry.
   Cancellation and unclassified failures preserve their existing failure
   semantics and append no quarantine event.
6. Bind the prepared image bytes and projection to the dispatched request.
   Resolve the race between preflight and provider-side rereads; an extra
   preliminary read alone does not close the failure path. Preserve route
   image limits and existing unsupported-role validation.
7. Implement explicit recovery through complete original-byte and metadata
   verification. Never clear state merely because a path exists or overwrite
   content under the original immutable identity. Failed recovery retains the
   quarantine and historical evidence.
8. Verify restart, fork, nested content, repeated/concurrent failures, and
   interrupted preparation. Define auxiliary calls without live sessions
   explicitly rather than inventing provider-local recovery behavior.
9. Add the real loop/local HTTP-provider scenario and keyless runnable snapshot.
   Record the model-visible replacement and durable events. Regenerate owned
   artifacts, update both documentation languages, and close the proposal only
   when all acceptance evidence exists.

## Acceptance matrix

| Case | Required observation |
| --- | --- |
| Missing original object | One durable quarantine transition; useful remaining messages reach the provider. |
| Corrupt bytes or metadata | Integrity failure recorded; original reference and bytes preserved. |
| General read error twice | Exactly one retry, then retryable quarantine. |
| Successful retry | No quarantine; verified image reaches the request. |
| Cancellation before/during retry | No quarantine; owned work settles and dispatch does not start. |
| Unknown error | Error propagates; no false data-damage classification. |
| Repeated/concurrent reference | One effective transition; all occurrences project consistently. |
| Later text-only turn | No read of the quarantined object; request proceeds. |
| Restart and fork | Event replay reconstructs identical projected messages. |
| Recovery with incorrect bytes | No recovery event or image restoration. |
| Verified original restored | Recovery event commits and subsequent requests use the original reference. |
| Provider preparation race | Dispatch uses the verified prepared request; no stale preflight-only success. |

Run all owning session, attachment, loop and provider tests; typecheck, lint,
snapshots, complete changed-source coverage, and expanded mutation scope.
No source exclusion, assertion filtering, or lowered threshold closes a case.
The full-plan browser/native/CI obligations remain required where affected.

## Adjacent cancellation work

`tool-fs/src/read-image.ts` forwards its execution signal through attachment
admission. The service, base64 admission helper, local provider, compression
queue, normalization, and pre-publication storage accept cancellation. Queued
work is removed; active native work retains its slot until settlement; batches
join every preparation before rejecting. Atomic publication already started
finishes durably and earlier committed members remain stored.

Native Sharp/filesystem tests and an actual built Loader composition prove
cancelled preparation publishes nothing and later saves remain readable.
The complete owning replay passes 150 cases with one existing Windows skip;
a later native-reason regression passes all five limiter cases. Strict
changed-source coverage still fails on six storage locations. Full details are
in [admission cancellation evidence](attachment-admission-cancellation.md).
The subsequent shared-request lifecycle repair passes 158 owning tests and
the built Loader acceptance. Final cancellation joins owned native/cache work;
retained callers continue independently and queued requests receive cancellation.
Native cache read failures propagate. Complete attachment-package coverage
still fails on six storage and sixteen invariant-companion locations. See
[shared-request evidence](shared-request-cancellation.md).
These slices do not implement quarantine, prepared dispatch or recovery events.
