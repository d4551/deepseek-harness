# Team composition ownership and switching

Status: implemented in source; built Web and complete gate acceptance pending.

The initial real-Loader regression proves that mounting a Team plugin inside
one preset grants its eleven tools to an unrelated preset. Adding ancestry
admission exposes a second failure: switching between two Team compositions
leaves only ten tools because disposal notifications start the next installer
before the old contribution is fully removed. The original failures remain in
`/tmp/dsh-team-scoped-admission-before.log` and
`/tmp/dsh-team-scoped-admission-after.log`.

## Repair

- Team admission requires the plugin's owning scope in the Agent's ancestry.
- AgentPresets exposes an awaited `agent-preset/recompose` lifecycle around
  the parent relink. Team plugins finish removing their Agent contributions
  before that relink and install against the resulting composition afterwards.
- A rejected transition restores the retained composition's contributions.
  A plugin unloaded during a pending transition cannot reinstall afterwards.
- Cordis owns each Agent's tools, policy and asynchronous command teardown as
  one effect group. The manual installation catch clause and disposer array
  are removed. Plugin-wide teardown awaits every Agent and reports all failures.
- Web's host Team row is disabled. Standard, Cordis and PTC compositions each
  carry the Team row with their existing swarm settings. Minimal carries none;
  copied compositions preserve the actual plugin grant independently of id.
- The existing notification-failure contract remains intact. Its test exposed
  an intermediate regression, which was repaired without changing the assertion.

## Verified evidence

The final combined owning replay passes **231 tests across 21 files**, zero
failures or skips. Complete coverage of
`packages/subagent/tool-agent-team/src/index.ts` passes all unchanged per-file
thresholds: statements 123/123, branches 85/85, functions 34/34, lines 105/105.
The report and log are `/tmp/dsh-team-composition-lifecycle-policy-coverage/`
and `/tmp/dsh-team-composition-lifecycle-policy-coverage.log`.

The real-service cases cover copied compositions, concurrent independent
Agents, repeated switches, exact eleven-tool catalogs, one policy per admitted
Agent, swarm command cleanup, prepared execution revocation, rejected
transitions, unpublished scopes, plugin unload during a pending transition,
and all reported final policy-removal failures across two Agents followed by
successful plugin replacement. They do not establish every possible observer
failure's cleanup behavior; earlier teardown failures still require scrutiny.

All six shipped profile bundle declaration/packaging/patch-parse tests pass in
`/tmp/dsh-team-composition-profile-bundles.log`. Both updated README pairs are
reviewed, recorded and pass the named pairing check. Working-tree whitespace
passes. The tool catalog freshness check passes. Source and retained log hashes
are in `team-composition-lifecycle-evidence.json`.

Earlier failing test and coverage logs remain preserved; no thresholds,
suppression directives, test assertions or mutation inputs were relaxed.

## Subsequent built validation and cleanup repair

The previous status turn verified the live mutation process. This execution
turn resumed it to terminal exit 1: 96.79%, 178 reported kills, three timeouts
and six survivors. Its frozen source matches the current mount module; full
status-reason review remains open. No passing score is accepted.

Dependency reconciliation passes and changes only the declared scope peer in
`bun.lock`. Fresh product build passes in
`/tmp/dsh-team-composition-product-build.log`. All **35 built Web tests pass**
in `/tmp/dsh-team-composition-built-web.log`, closing the three earlier observed
catalog failures for that snapshot. The tests require all 34 standard tools,
including packaged search tools, and repeatedly switch a copied minimal
composition while checking executor denial, policy count, command visibility
and an independent standard session. No tool-name exclusion remains in that
catalog assertion. The Web chunk warning remains.

Canonical generators refresh the event matrix, config source link and Cordis
event catalog. All **1,183 documentation pairs pass** in
`/tmp/dsh-team-composition-all-pairing.log`.

Full typed lint found five issues in the new code. Explicit void control flow,
typed failure collection and a synchronous registry-removal notification repair
them without directives. Agent scope ownership performs contribution teardown;
the later disposal notification removes the tracking entry.

The additional real tools-change observer test then exposed ten retained Team
tools after the first removal failed. Original failure evidence is
`/tmp/dsh-team-early-disposal-before.log`. Cordis composite cleanup now drains
every disposer in reverse order and reports all failures after completion.
An initial implementation broke two synchronous lifecycle assertions; those
assertions remain unchanged, and the revised implementation preserves them.
The intermediate combined owning replay passes **253 tests across 23 files** in
`/tmp/dsh-composite-teardown-synchronous-owning.log`. An additional native-file
regression checks mixed synchronous and asynchronous failures, ordering, file
closure and an owner joining in-flight teardown. Final source preserves single-
disposer synchronous errors after the full diagnostic run exposed two callers.
The final canonical full suite reports **20,468 passed, two existing enforcement
failures and 42 skipped**, with all 67 accessibility audits executed. Final build
and typed lint pass. Final built Web replay passes all **35 tests**.
The complete Team entry module reaches 100% in all four coverage metrics in the
expanded 255-test replay; the aggregate fails on the coverage provider's raw
TypeScript parsing of the changed Cordis module. Full details and exact final
evidence are in [composite teardown](composite-teardown.md).

## Remaining work

Final documentation reports 30 passed, two protected-file failures and zero
skipped. Translation pairing and all generated catalogs pass.

1. Repair native coverage source capture and establish complete Cordis coverage.
2. Review every mount mutation detection reason and repair the six survivors.
3. Run mutation acceptance for Team and the expanded lifecycle boundary.
4. Continue the complete unchanged full-green plan and directive inventory.

No staging, commit or push was performed. Full-green acceptance remains open.
