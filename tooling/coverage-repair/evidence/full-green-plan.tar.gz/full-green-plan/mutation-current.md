# Historical storage mutation snapshot — validity withdrawn

**Do not use this score as current acceptance evidence.** A later audit found shared Vitest/Vite cache writes through sandbox `node_modules` symlinks; the command runner can classify startup failures as killed mutants. The retained report contains a dependency-optimizer ENOTEMPTY in mutant 362. All verdicts require a clean isolated-cache replay and failure-reason review.

Original recorded output, retained for comparison:

Five changed modules; 384 killed, 12 survived, 396 total: **96.97%**, exit 1.
No timeouts, runtime errors, or uncovered mutants. This does not establish
whole-repository mutation quality. The original report is
`/tmp/dsh-plan-storage-mutation.json`; log `/tmp/dsh-storage-mutation-expanded.log`.

- packages/storage/storage-json/src/atomic.ts: {"Killed":14,"Survived":5}
- packages/storage/storage-json/src/format.ts: {"Killed":105,"Survived":2}
- packages/storage/storage-json/src/index.ts: {"Killed":60}
- packages/storage/storage-json/src/per-record-unit.ts: {"Killed":181,"Survived":5}
- packages/storage/storage-json/src/unit-lifecycle.ts: {"Killed":24}

Every remaining mutant:

| File | ID | Line | Status | Mutator | Replacement |
| --- | --- | --- | --- | --- | --- |
| packages/storage/storage-json/src/atomic.ts | 5 | 31 | Survived | StringLiteral | "" |
| packages/storage/storage-json/src/atomic.ts | 8 | 38 | Survived | ObjectLiteral | {} |
| packages/storage/storage-json/src/atomic.ts | 9 | 38 | Survived | BooleanLiteral | false |
| packages/storage/storage-json/src/atomic.ts | 15 | 57 | Survived | BlockStatement | {} |
| packages/storage/storage-json/src/atomic.ts | 17 | 59 | Survived | BlockStatement | {} |
| packages/storage/storage-json/src/format.ts | 119 | 119 | Survived | BlockStatement | {} |
| packages/storage/storage-json/src/format.ts | 123 | 122 | Survived | ConditionalExpression | false |
| packages/storage/storage-json/src/per-record-unit.ts | 244 | 115 | Survived | StringLiteral | "" |
| packages/storage/storage-json/src/per-record-unit.ts | 251 | 123 | Survived | BlockStatement | {} |
| packages/storage/storage-json/src/per-record-unit.ts | 287 | 129 | Survived | ConditionalExpression | false |
| packages/storage/storage-json/src/per-record-unit.ts | 347 | 175 | Survived | StringLiteral | "" |
| packages/storage/storage-json/src/per-record-unit.ts | 348 | 176 | Survived | BlockStatement | {} |
