# Complete test-run failure inventory

The 2026-09-16 full normal run finished with exit 1: 13 failed files, 1,339 passed files, seven skipped files; 20 failed tests, 20,069 passed, 42 skipped. Duration 1,270.62 seconds. Source changed during execution, including external commits; this is diagnostic evidence, not final-state acceptance.

Raw output: /tmp/dsh-finish-complete-tests.log. Complete failure section: /tmp/dsh-finish-complete-tests-failures.log. Neither report was rewritten. No failure or skip is accepted as final green.

## 1. process-bound scripts/lint-scope-corpus.spec.ts > repository lint directory discovery > discovers every probe through the unchanged root configuration and exclusions

OPEN: unchanged root lint child exceeded 90 seconds during full load. A later full lint snapshot passes; the timeout has not been repaired or explained by final evidence.

## 2. thread-safe scripts/gen-client-catalog.spec.ts > the real workspace surface > collects every declared slot with a teachable contract

OPEN: workspace catalog test exceeded its unchanged 30-second test deadline. No timeout increase or discovery narrowing.

## 3. thread-safe scripts/suppression-justifications.spec.ts > live authored source > contains no diagnostic directives or catch clauses

OPEN: current complete scanner still reports 807 directives and 1,447 catch clauses. No exemption.

## 4. thread-safe packages/credentials/authorization/tests/invariant.spec.ts > authorization invariant companion > fails a settlement that left its key in flight

OPEN: settlement produced NOT_COMMITTED after cancellation/resolve. Five focused tests pass without a source repair; load-sensitive failure remains unresolved.

## 5. thread-safe packages/host/directory-picker-auto/tests/loader-composition.spec.ts > real Loader composition > mounts the native backend for an attended loopback host and unmounts it on disposal

REPAIRED IN FOCUSED REPLAY: Cordis retirement and disposal ordering; 36 tests across five files pass. Full final-state replay still due.

## 6. thread-safe packages/host/directory-picker-auto/tests/loader-composition.spec.ts > real Loader composition > tolerates the mounted entry being removed by the tree before the chooser unloads

REPAIRED IN FOCUSED REPLAY: Cordis retirement and disposal ordering; 36 tests across five files pass. Full final-state replay still due.

## 7. thread-safe packages/host/directory-picker-auto/tests/loader-composition.spec.ts > real Loader composition > reports a terminal debounced-write failure again to the teardown owner

REPAIRED IN FOCUSED REPLAY: terminal write error remains observable to teardown; same 36-test replay. Full final-state replay still due.

## 8. thread-safe packages/hooks/hook-protocol/tests/pwsh-shell.spec.ts > a hook run through a pwsh ctx.shell > carries a blocking exit code and its stderr reason back out of PowerShell

REPAIRED IN FOCUSED REPLAY: native PowerShell command propagates $LASTEXITCODE; all three tests pass with unchanged exit-code/stderr assertions.

## 9. thread-safe packages/llm/llm-deepseek/tests/adapter.spec.ts > DeepSeekAdapter against a mock server > classifies an aborted request as an aborted finish

REPAIRED IN FOCUSED REPLAY: cancellation yields canonical ABORTED; 365 owning tests pass with unchanged assertion.

## 10. thread-safe packages/client/ui-settings-models/tests/components.client.spec.tsx > ModelsSection > keeps the card usable when the write rejects instead of answering

TEST REPAIRED: await actual enabled Apply, retry the rejected write and verify unchanged arguments/retained input. 91 model tests pass; isolated old test also passed, so original full-load race was not reproduced narrowly.

## 11. thread-safe packages/client/ui-settings-models/tests/onboarding-dialog.client.spec.tsx > DeepSeekOnboardingDialog > keeps the modal open and reports rejected and failed credential writes

TEST REPAIRED: await actual enabled Save, retry and retain dialog/key without completion or settings mutation; same 91-test replay.

## 12. thread-safe packages/session/session-checkpoint-policy/tests/replay-durability.spec.ts > does not start readiness or consume replay after predispatch cancellation, prepared=false

REPAIRED IN FOCUSED REPLAY: canonical predispatch cancellation, no readiness or replay consumption; 365 owning tests pass.

## 13. thread-safe packages/session/session-checkpoint-policy/tests/replay-durability.spec.ts > does not start readiness or consume replay after predispatch cancellation, prepared=true

REPAIRED IN FOCUSED REPLAY: canonical predispatch cancellation, no readiness or replay consumption; 365 owning tests pass.

## 14. thread-safe packages/session/session-checkpoint-policy/tests/replay-durability.spec.ts > owns every readiness listener through cancellation, prepared=false

REPAIRED IN FOCUSED REPLAY: retained readiness ownership through cancellation; 365 owning tests pass.

## 15. thread-safe packages/session/session-checkpoint-policy/tests/replay-durability.spec.ts > owns every readiness listener through cancellation, prepared=true

REPAIRED IN FOCUSED REPLAY: retained readiness ownership through cancellation; 365 owning tests pass.

## 16. thread-safe packages/subagent/subagent/tests/list-children.spec.ts > SubagentRuntime.listChildren > refuses a cached ancestor identity from the fork seed and lets preparation rule

REPAIRED IN FOCUSED REPLAY: the test suite now awaits every created Cordis root disposal before deleting native cache/session directories; deletion retries removed. All 63 owning tests and scoped typed lint pass. Full-load final aggregate replay remains required; the earlier 154-test passing replay was not itself a repair.

## 17. thread-safe packages/session/session-title/tests/provider.spec.ts > SessionTitleService Provider lifecycle > runs an all-messages revision when the next main request reuses its logged header

REPAIRED IN FOCUSED REPLAY: consume the stream to execute deferred request readiness; seven owning tests pass.

## 18. thread-safe packages/experimental/webworker-runtime/tests/node/sandbox-stack.spec.ts > Worker Landlock through the production sandbox stack > allows workspace and temp writes while classifying an outside write as denied

OPEN: actual confined sandbox backend unavailable on this execution. No unconfined substitution or new skip; native confined execution still required.

## 19. thread-safe packages/experimental/webworker-runtime/tests/node/sandbox-stack.spec.ts > Worker Landlock through the production sandbox stack > keeps read-only confined and danger-full-access unwrapped

OPEN: actual confined sandbox backend unavailable on this execution. No unconfined substitution or new skip; native confined execution still required.

## 20. thread-safe packages/experimental/webworker-runtime/tests/node/sandbox-stack.spec.ts > Worker Landlock through the production sandbox stack > does not leak a concurrent command policy into another process

OPEN: actual confined sandbox backend unavailable on this execution. No unconfined substitution or new skip; native confined execution still required.

