# Source-map loading integrity

The isolated converter now rejects unavailable or malformed referenced source
maps instead of measuring the generated code as if it were the authored source.
It decodes inline base64 as UTF-8 and reads percent-encoded data URLs, relative
map URLs, and absolute file URLs. No source-map parse assertion, suppression,
helper-name filter, or dependency override is added. The existing source-file
read catch and directive interpretation remain unresolved upstream debt.

## Implementation and verification

`src/location.ts` resolves the annotation against the generated file's URL,
loads its content, and passes the serialized map to the existing TraceMap
constructor. Read and parse failures propagate. Absence of an annotation remains
distinct from a present annotation that cannot be read. The change removes the
map-loading catch and its unchecked source-map type assertion.

`test/source-map-integrity.test.ts` adds ten cases across four parser projects.
Five representations preserve the exact Unicode source text and real Inspector
counts for one executed and one unexecuted function. Three malformed JSON cases,
a missing file, and an invalid data URL must reject conversion. No generated
coverage ranges or test substitutes are used in the successful execution cases.

The negative control restores the exact previous verified location module,
SHA-256 `1a66811da97c710a0ecad6124c024e7d953873f665028e11c6d4082fede8a246`,
inside the independent reconstruction. All **40 new cases fail**. The plain
base64 case separately exposes the corrupted `café` and emoji text; charset,
percent encoding and file URLs expose missing URL support. The control is
restored to the repaired source before final verification.

The complete frozen reconstruction passes **1,224 tests across 79 files**,
strict compilation, lint, formatting and publication checks. The source build
and reconstructed build are byte-identical:

| Artifact | SHA-256 |
| --- | --- |
| `dist/index.mjs` | `43cb6fe4bb1d4c15af29b96f5863b1e9ec90ffc3c5794e687503389f9bf59635` |
| `dist/index.d.mts` | `7e4de81c67aaa01f9202bb56242f85355e6a78bd327260294e8e26ada36f4b02` |
| `pnpm-lock.yaml` | `591cdd6dcf72e712529531bee5bea580a2f682130bf7ac4c3b67e0147e16ae81` |

The reconstruction starts from the same verified official archive as the prior
converter repair, records 21 source/dependency inputs and uses a fresh dependency
cache with frozen installation. Independent native Git patch application also
reproduces all 21 inputs without patch warnings. Neither dependencies nor the
lockfile change in this slice. The source and frozen build logs still contain
the builder's TypeScript API warning and declaration dependency-ownership hint;
their successful exits do not establish a warning-free toolchain.

Logs and reconstruction records use `/tmp/dsh-source-map-integrity-` prefixes.
The original 36-case control and intermediate 1,220-test run remain retained;
the final control has 40 cases and the final complete reconstruction has 1,224.
`vitest-source-map-integrity-evidence.json` fingerprints the final inputs,
artifacts and verification logs. The standalone patch is
`vitest-source-map-integrity-candidate.patch`; its binary dependency artifact
is separately fingerprinted in the input record.

## Generated CommonJS getters: producer evidence

The latest official npm metadata identifies esbuild 0.28.2 at commit
`609683d892977362a0f99026cb74b96263d728a9`. Its official source archive is
SHA-256 `04cb2d38fb6af093577aa8bf174add7286099b65ef7854480cbbb8ff061cef1f`.
An unmodified Go build drives eight real native module executions, spanning
ESM/CommonJS, whitespace minification and retained names. All four ESM cases
pass; all four CommonJS cases fail with the same extra authored function.

The probe retains generated code, maps, native V8 ranges, executed-source
identity checks, mapped arrow locations and final function counters in eight
`/tmp/dsh-esbuild-export-map-{format}-{minify}-{names}.json` records. Every
executed source exactly contains the compiler output, with wrapper length zero.
The two generated export getters map to original line 1, column 0; the other
runtime helpers have no original source location. The converter consequently
merges both getters into a false function at the original `export` token.

The producer's `createExportsForFile` constructs the getters and namespace
statements without authored locations, leaving Go's zero-valued locations.
`generateCodeForFileInChunkJS` includes that namespace prefix in the same mapped
statement list as authored code. This identifies the next implementation
surface: correct the producer's representation/emission of generated locations
while preserving all authored mappings. No producer source is modified yet.
Consumer helper-name exclusions would conceal this provenance defect and are
not accepted. The initial probe's noncanonical temporary paths and CommonJS
namespace access errors are retained separately; only the corrected native
probe's four-pass/four-fail result supports this finding.

The [official esbuild architecture](https://github.com/evanw/esbuild/blob/main/docs/architecture.md)
describes map generation during printing. The
[ECMA-426 scope proposal](https://github.com/tc39/ecma426/blob/main/proposals/scopes.md)
explains that point mappings alone cannot generally reconstruct original
scopes. These references guide the investigation; actual producer bytes and
native execution establish the failure above.

## Remaining acceptance

The converter remains unpromoted. Generated getter attribution, exact child
transport, runner integration, complete unsuppressed coverage and mutation,
platform/CI acceptance and the full repository plan remain open. The converter's
own aggregate coverage still omits executed AST/evaluation modules and is not
accepted as complete measurement. No root file, index entry or commit changes
in this slice. Root is clean at `105a97ef9c776a2856118ee02609dc61a0fb9617`;
the latest root inventory still has 633 directives. The native Node build is
still running in session 83623 and has not passed runtime acceptance.
