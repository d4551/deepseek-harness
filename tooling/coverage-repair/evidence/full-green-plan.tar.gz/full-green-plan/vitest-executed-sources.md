# Executed-source collection candidate

The isolated Vitest source candidate now captures native Inspector sources and
source maps during execution. It is **not promoted or accepted**. The latest
native regression file reports **nine passed, one failed, zero skipped**;
the complete expanded native compiler still fails on two Node API calls.
The repository's 643 directives remain unchanged.

## Implementation

`packages/coverage-v8/src/executed-sources.ts` owns generated source captures
for one Inspector session. It listens before enabling the Debugger domain and
requests the exact script text when each parsed-script notification arrives.
External source maps and missing embedded original texts are read during that
notification, before the workload can remove those files. Inline maps support
base64 and URL-encoded contents. Map decoding errors remain recorded failures
and are rethrown when the corresponding executed record is requested.

Artifacts contain session ID, script ID, URL, executed JavaScript, the resolved
map and original texts, and a SHA-256 identity. Capture checks the Inspector
source length. Before conversion, the provider verifies identity and UTF-16
range bounds against the corresponding V8 record.

The Node collector attaches artifacts to native records that have no Vite
execution metadata. Vite wrapper normalization is still outstanding. Native
subprocess records without artifacts now fail explicitly; the candidate cannot
complete automatic child coverage until its runtime transport supplies them.

The provider remaps each record independently before merging Istanbul results.
It no longer combines raw offset ranges solely by URL, nor drops converted
files merely because the disk path has been removed. The unused raw merger
dependency and its associated declaration directive are removed. The direct
map decoder dependency is declared through normal pnpm installation.

Collector shutdown removes its Debugger listener, joins pending captures,
disables the Debugger domain, and releases the capture map. Its enabled state
resets after shutdown, allowing a subsequent session to start correctly.

## Verified behavior

The complete native test file is
`/tmp/dsh-vitest-5.0.1-source/test/coverage-source-integrity.test.mjs`.
Its final log is `/tmp/dsh-vitest-executed-sources-final.log`.

Passing cases prove:

- Invalid native input, failed transforms and absent subprocess artifacts fail.
- Valid unexecuted source retains its function and statement inventory.
- Two actual VM executions at one URL with different generated bodies retain
  both functions and the correct two hit/two unhit branch outcomes.
- An external map and its original Unicode/CRLF source can both be deleted
  before collection; the recorded original line hits remain correct.
- Malformed executed maps and altered serialized source identities reject.
- A stopped isolated collector releases its listener and a new non-isolated
  session collects fresh actual execution.

The previous four failure-propagation tests remain in the file. The missing
source case now asserts the stronger explicit missing-artifact error rather
than allowing reporting to reach a disk-read failure.

## Remaining failing assertion

The deleted-source case loads ESM syntax through the actual tsx registration.
Inspection proves that the loader executes generated CommonJS, including
helper functions. The captured bytes, map and original source are retained
correctly, but the converter projects generated helpers onto the authored
`export` text. It reports an additional `(anonymous_0)` function where the
original source contains only `value` and `uncalled`.

The exact function-name and count assertions remain unchanged and failing.
The byte assertion now correctly distinguishes generated JavaScript from the
original text and separately checks the captured original source. This follows
the executed-source requirement rather than assuming the loader ran disk bytes.
No helper-name filter or source exclusion is added.

`/tmp/dsh-vitest-executed-source-deletion-proof.json` preserves the actual V8
ranges, generated code, original map and incorrect remapped locations. The
converter's authored source was initially extracted at
`/tmp/dsh-ast-v8-1.0.6-source`, official commit
`48f88c789411ce6e96137b16ec348d06ae6c2f6e`. The subsequent
[source-map conformance candidate](vitest-source-map-conformance.md) changes
its position lookup and adds regression cases. That change remains unaccepted:
the loader case is still red and twelve framework coverage assertions fail.

## Validation and outstanding scope

The complete expanded strict compile retains only the existing two removed
Node transform-mode diagnostics in
`/tmp/dsh-vitest-executed-sources-types-final.log`; exit status remains 1.
Every new capture source is included, with strict library checking unchanged.
Normal dependency operations finish successfully in
`/tmp/dsh-vitest-executed-source-dependency.log` and
`/tmp/dsh-vitest-executed-source-remove-merger.log`.

`vitest-executed-sources-inventory.json` records all input fingerprints.
`vitest-executed-sources-candidate.patch` preserves the complete candidate
source/config/lock changes against the official Vitest archive. This includes
earlier dependency repairs and is not an isolated patch for publication.

Remaining requirements include correct generated-helper attribution; exact
Vite wrapper normalization; automatic child/worker/grandchild transport without
changing exact environments; parameter-property and multi-process acceptance;
abrupt exit and startup-failure completeness; report rendering after deletion;
the full Node/browser/platform matrix; strict build and reproducible artifacts;
root integration; and final unsuppressed coverage and mutation measurements.
No repository-wide acceptance claim follows from this candidate.

Primary interfaces: [Node Inspector](https://nodejs.org/api/inspector.html),
[Debugger source retrieval](https://chromedevtools.github.io/devtools-protocol/tot/Debugger/#method-getScriptSource).
