# Root installation of the source-built Stryker distribution

The root manifest and Bun lockfile now install the verified core archive and
the generated instrumenter/runner patches. Both obsolete emitted-only patches
are removed after tracing their root-manifest and notices consumers. The core
archive declares its own `jsonc-parser` dependency before dependency resolution.
Vitest, its browser provider, and coverage package resolve to 5.0.1; the workspace
declarations and enforced floor agree. Registry evidence is retained in
`/tmp/dsh-root-vitest-current-registry.json`.

`tooling/stryker/verify-installed.mjs` verifies the complete 1,006-file artifact
inventory, each file's SHA-256, archive and patch digests, core-owned parser,
shared API identity, runner/core identity and CLI entry point. Bun's two patch
markers are explicitly checked, including their empty contents and identifiers
derived from each patch. Nothing is removed from the installed file inventory.
The identifier algorithm was verified against Bun 1.4.2's official source:
https://github.com/oven-sh/bun/blob/bun-v1.4.2/src/install/patch_install.rs

Ordinary script test discovery includes installed-file verification and five
native mutation-accounting cases. The native cases resolve the instrumenter
through core's dependency edge in both root and isolated installations.

The third-party notices generator now discloses every repository-local package
declaration across all four dependency sections, validates its path and checks
that its payload exists. The generated notice links the core archive and both
package patches. The English and Chinese maintenance instructions agree.

## Verification

All commands use Node 26.8.2 and Bun 1.4.2 where applicable.

| Check | Result | Raw evidence |
| --- | --- | --- |
| Normal root install, lifecycle enabled | Passed | `/tmp/dsh-stryker-root-install.log` |
| Normal Vitest family install, lifecycle enabled | Passed | `/tmp/dsh-stryker-root-vitest-install.log` |
| Installed source artifact and ownership check | Passed, 1,006 files | `/tmp/dsh-stryker-root-ownership.log` |
| Notices, dependency floor and distribution tests | 91 passed | `/tmp/dsh-stryker-root-tests.log` |
| Local-declaration helper strict coverage | 10 tests; statements 14/14, branches 14/14, functions 2/2, lines 12/12 | `/tmp/dsh-stryker-root-manifest-coverage.log` |
| Complete product build | Passed; oversized JS chunk warning remains | `/tmp/dsh-stryker-root-build.log` |
| Complete typed lint | Passed | `/tmp/dsh-stryker-root-lint.log` |
| Workspace constraints | Passed | `/tmp/dsh-stryker-root-constraints.log` |
| Complete documentation aggregate | 30 passed, 2 failed, 0 skipped | `/tmp/dsh-stryker-root-doc-sync.log` |
| Full HEAD/worktree whitespace | Passed | `/tmp/dsh-stryker-root-head-whitespace.log` |
| Staged whitespace | Failed on older staged patch bytes | `/tmp/dsh-stryker-root-index-whitespace.log` |

The clean root installation copied 10,057 authored files into
`/tmp/dsh-root-frozen-i156_qa4`, without Git metadata or installed dependencies.
Its fresh-cache `bun install --frozen-lockfile` installed 1,109 packages with
normal lifecycle execution, exit zero, in 71.19 seconds. The lockfile remains
byte-identical to the root lockfile. The complete installed inventory and all
five native accounting tests pass in that copy. Evidence:
`/tmp/dsh-root-frozen-copy.json`, `/tmp/dsh-root-frozen-install.log`,
`/tmp/dsh-root-frozen-ownership.log`, `/tmp/dsh-root-frozen-accounting.log`.

Complete normal test execution finishes with 20,407 passed, three failed and
42 skipped in `/tmp/dsh-stryker-root-full-tests.log`; all 67 accessibility audit
tests execute. `full-run-root-integration-failures.md` lists every failure and
subsequent resolution. An SDK image-admission call assertion
still expected the pre-cancellation signature. The owning replay reproduces
the sole difference as an explicit second `undefined` argument. Its repair
retains exact image bytes/content and additionally requires exactly one
admission and one delivery. The original failed replay is retained in
`/tmp/dsh-sdk-image-admission-before.log`; subsequent evidence belongs in
`/tmp/dsh-sdk-image-admission-after.log` (40 passed) and
`/tmp/dsh-sdk-image-admission-lint.log` (exit zero). The full-suite execution
had already exercised the older SDK assertion before this correction, so its
SDK failure is retained as historical evidence and resolved by the owning replay.

## Remaining acceptance

Root integration is verified; repository-wide acceptance is not. The complete
source scan at 2026-09-16T15:00:04.271Z finds 651 directives across 4,049 files:
533 coverage and 118 lint. All remain violations. Exact comparison with the
903-site baseline confirms 252 removals and zero additions across 26 files.
See `source-20260916150004271.json` and
`suppression-inventory-diff-145309.md`.

The source-prohibition gate, coverage collection and remapping defects,
remaining runner lifecycle work, 217 empty invariant installers, protected
AGENTS documentation failures, full platform CI and repository-wide mutation
acceptance remain open. No index reconciliation, commit, push or publication
was performed. The working root's earlier failed marker check is superseded
by explicit marker validation, not by excluding installer files.
