# Source-directive inventory difference

Comparison: preserved 903-site `source-latest.json` versus the 703-site
`source-20260916110911278.json`. Identity uses path, kind and directive text;
line movement does not count as removal. This measures source directives,
not completed behavioral repair or full coverage acceptance.

- Removed directive occurrences: 200.
- Added directive occurrences: 0.
- Net decrease: 200.

| File | Removed directives |
| --- | ---: |
| `packages/acp/acp/src/session.ts` | 17 |
| `packages/client/ui-primitives/src/markdown/mathCompatibility.ts` | 9 |
| `packages/client/ui-slots/tests/core.client.spec.ts` | 3 |
| `packages/core/agent-loop/src/agent.ts` | 5 |
| `packages/core/agent-loop/src/index.ts` | 5 |
| `packages/core/agent-loop/src/tool-calls.ts` | 6 |
| `packages/core/tools/tests/execution-signal-types.spec.ts` | 21 |
| `packages/core/tools/tests/schema.spec.ts` | 5 |
| `packages/credentials/credentials-local/src/index.ts` | 7 |
| `packages/extensions/cordis-client-runner/src/client/timer.ts` | 6 |
| `packages/fs/fs-local/src/fsio.ts` | 26 |
| `packages/fs/fs-observation-policy/src/index.ts` | 1 |
| `packages/llm/llm-retry/src/history.ts` | 1 |
| `packages/session/session-persistence-jsonl/src/index.ts` | 20 |
| `packages/session/session-persistence/src/coordinator.ts` | 9 |
| `packages/skill/skill-filesystem/src/index.ts` | 24 |
| `packages/spill/spill-local/src/cleanup.ts` | 35 |
