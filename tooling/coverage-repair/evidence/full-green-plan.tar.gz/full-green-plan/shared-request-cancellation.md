# Shared image-request cancellation — 2026-09-16

Status: implemented repair; complete-green acceptance remains open.

## Confirmed defects and repair

The original provider uses a regular abort listener. A caller's earlier
`stopImmediatePropagation()` listener prevents it from observing cancellation;
the native request completes successfully despite the aborted signal. A second
native regression makes the cache entry a directory. The original code hides
the read failure, performs an unnecessary transform and fails later during
rename, losing the original operation's error.

Both regressions fail in `/tmp/dsh-request-cancellation-before.log` and pass
after repair. The provider uses Node's supported `addAbortListener`. Independent
waiters retain their own exact cancellation reasons, including primitive
reasons. The final cancelling waiter joins the shared operation before returning.
Its shared signal removes queued compression work and reaches active encoding
candidates and cache writes. Cache cleanup completes before final settlement.

`SharedRequest` moves from the provider entry into a focused internal module.
It retains one operation controller and counts its live waiters. Five tests
exercise real promise settlement, cancellation with another retained caller,
native reason identity, failure propagation and listener disposal. No runtime
method is replaced by these tests. Three existing request-image tests replace
spies with actual Sharp/filesystem work and direct shared-result identity.

Cache reads regenerate only absent entries or malformed image data. Other
filesystem errors propagate. The unsafe error-code cast is removed. Cache
encoding and staging receive the signal; a rename already in progress settles
before the final caller returns. Durable original objects remain untouched.

## Evidence

| Check | Result | Log |
| --- | --- | --- |
| Two native regressions before repair | Both fail | `/tmp/dsh-request-cancellation-before.log` |
| Native regressions plus lifetime tests | Seven pass | `/tmp/dsh-request-cancellation-after.log` |
| Request-image owning tests | 20 pass | `/tmp/dsh-shared-request-owning.log` |
| Complete product build | Pass; existing oversized chunk warning remains | `/tmp/dsh-shared-request-build.log` |
| Complete typed lint | Pass | `/tmp/dsh-shared-request-full-lint.log` |
| Complete attachment-package coverage plus read_image | 158 pass, one existing Windows skip; coverage exit 1 | `/tmp/dsh-shared-request-complete-coverage.log` |
| Built Loader acceptance | Pass within complete attachment replay; admission and request cancellation preserve later successful use | Same complete coverage log |
| Configuration catalog | Canonical generation changes one source pointer; complete-byte comparison proves both languages change only line 55 to 56 | `/tmp/dsh-shared-request-config-catalog.log` |
| First quick documentation aggregate | 12 pass, three fail; generated catalog pairing was still pending | `/tmp/dsh-shared-request-doc-quick.log` |
| Final quick documentation aggregate | 13 pass, two protected-file failures, zero skips | `/tmp/dsh-shared-request-doc-quick-final.log` |
| Initial complete documentation aggregate | 29 pass, three fail: two protected-file checks and two missing property descriptions | `/tmp/dsh-shared-request-doc-sync.log` |
| Final complete documentation aggregate | 30 pass, two protected-file failures, zero skips; property descriptions repaired | `/tmp/dsh-shared-request-doc-sync-final.log` |
| Complete diff whitespace | Exit 2 on existing toolchain patch payloads; scoped attachment/doc diff passes | `/tmp/dsh-shared-request-whitespace.log` |

Coverage includes every source in both attachment packages and the changed
read_image consumer. The new lifecycle module, request-image, provider entry
and all other measured sources except the three below reach all four 100%
metrics. The whole measured scope has 480/495 statements, 305/308 branches,
90/94 functions and 445/455 lines. These are coverage values, not a mutation
or accessibility result.

All 22 uncovered locations remain visible:

- Attachment-local storage: six statement/branch locations, retaining the
  filesystem-root guard, non-EEXIST publication error propagation and
  pre-publication cancellation cleanup check.
- Attachment-local invariant companion: eight locations, zero measured
  statements/functions/lines.
- Attachment seam invariant companion: eight locations, zero measured
  statements/functions/lines.

The two invariant companions contain empty installers. Their current package
registration does not establish meaningful invariant enforcement. Do not
introduce empty-call coverage tests or exclude them to make this package run
green; their production contract and actual Loader ownership need repair.
The existing simulated Windows tests remain test debt, not native evidence.

Admission callers still needing cancellation-owner tracing include SDK server
`admitEncodedImages`, session-controller command image admission, the command
service, ACP content and MCP image results. No claim is made that a transport
owns a usable signal before its real lifecycle has been read. B4 quarantine,
retained prepared bytes and session/token-meter/compaction migration remain
open independently.

## Complete inventory

`source-20260916132434142.{json,md}` records 4,043 source files, 2,460 findings,
658 directives (540 coverage and 118 lint), 1,445 catch clauses and 357 static
catch-handler accesses. Corpus SHA-256:
`c4e7930f28a04596d13d95c8364ca7281e1fa3ae72dea79f2c03979d5bc52603`.
The directive count is unchanged from the previous repair. All 658 remain
violations; no suppression, test skip, retry, deadline change or source
exclusion is added by this repair. Source-owned catch and invariant debt remain.

HEAD remains `8f8780a13e40205c50518fa34b8cf11e3a6d141c`; external staging
continues. Root does not stage, commit, push or alter the index. Complete
coverage, valid mutation acceptance, protected-document checks, native matrices
and remote CI remain unresolved.
