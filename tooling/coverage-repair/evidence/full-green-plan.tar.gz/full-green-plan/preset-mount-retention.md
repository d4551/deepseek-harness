# Preset mount ownership and inspection repair

Current HEAD: `ee24359f10f99c47b05ff75cb40426e7ea860505`.
The preceding status-only turn made no implementation progress. This slice
resumes the full plan without changing its acceptance criteria.

## Confirmed defect

The native regression mounts a real Loader composition with a file-owning
plugin, disposes the runtime, verifies file cleanup, and forces garbage
collection without another registry read or mount. The old implementation
retains the record: `/tmp/dsh-preset-retention-boolean-before.log` fails its
release assertion. The earlier failure log invoked a Cordis getter while
formatting the retained object; asserting the boolean release condition
exposes the real failure without inspecting that object.

Successful validation now registers the record through the subtree's effect
lifecycle. Unload removes it without a later observation. Reads still exclude
disposed fibers before asynchronous cleanup settles. The unchanged native
regression passes. Real service tests verify immediate exclusion and denial
when an agent has no standing composition. Both languages of the README and
owning decision record are updated and their pair records regenerated.

## Mutation diagnostics

New Loader tests detect original survivor ids 70, 80, 82, 83 and 84 through
wrong-name service reads, invalid released-entry reads, and lost diagnostics.
Logs: `/tmp/dsh-preset-inspection-mutant-<id>.log`. The matching unmutated
control passes 194 tests in
`/tmp/dsh-preset-inspection-instrumented-control.log`.

The additional absent-composition test detects survivor 63 through an invalid
fiber access. Its log is `/tmp/dsh-preset-inspection-mutant-63.log`; the matching
expanded control passes 197 tests in
`/tmp/dsh-preset-inspection-final-instrumented-control.log`.

Together with earlier repairs, sixteen of the original 23 survivors are
detected; seven remain in that historical replay: 39, 52, 55, 67, 107, 153,
169. Original instrumented source and test inputs are preserved. These ids
predate the lifecycle source change and do not establish its mutation score.

## Current verification

- Owning suite: 193 passed, 16 files, zero skips;
  `/tmp/dsh-preset-retention-final-owning.log`.
- Product build: passed; `/tmp/dsh-preset-retention-build.log`.
  Its oversized Web chunk warning remains open.
- Full typed lint using the fresh build: passed;
  `/tmp/dsh-preset-retention-lint.log`.
- Full mount coverage: failed; statements 114/116 (98.27%), branches 33/60
  (55%), functions 18/20 (90%), lines 91/93 (97.84%);
  `/tmp/dsh-preset-retention-coverage.log`. All 192 tests pass. This run
  precedes only the final absent-composition test.
- Quick docs: 13 passed, two protected-file failures, zero skipped;
  `/tmp/dsh-preset-retention-doc-quick.log`.
- Full docs: the initial run reports 29 passed and three failures, including
  a stale event matrix. Canonical generation restores the committed Team
  listener edge, and its Chinese counterpart and pair record are synchronized.
  The final aggregate reports 30 passed, two protected-file failures and zero
  skips in `/tmp/dsh-preset-retention-doc-sync-final.log`.
- Freshly built Web composition: 31 passed, the same three catalog failures;
  `/tmp/dsh-preset-retention-built-web.log`. Original exact assertions remain.
- Full mount mutation: completed with exit 1 after 31 minutes, reporting
  96.79% against the unchanged 99 threshold: 178 killed, three timeouts,
  six survivors across 187 candidates. It started after all build and
  documentation writers finished, using
  `/tmp/dsh-preset-retention-stryker.config.mjs`. Raw log:
  `/tmp/dsh-preset-retention-mutation.log`; report:
  `/tmp/dsh-preset-retention-mutation.json`. The break threshold remains 99.
  The report source matches the current module's SHA-256,
  `7cf3cc9de1b2e000712e81ae04f2b7913ba84ddfd976836d7d7615b7c4100e23`.
  Complete status-reason review remains open; this is a failed checkpoint,
  not accepted mutation evidence. Survivors are 37, 50, 53, 65, 105 and 170;
  timeouts are 24, 30 and 31. The initial command-runner control passed.
  Native execution handle `34786` is terminal. Preserved sandbox:
  `/private/tmp/dsh-preset-retention-mutation-sandboxes/sandbox-2jtTqx`.
  Both new inspection/retention test files are present in the captured inputs.
- Working-tree whitespace passes at the inspected source snapshot.

No suppression, reduced threshold, test skip, retry, test double or mutation
exclusion is added. The runtime live-record predicate does not alter test or
measurement scope. No commit, staging or push is performed. The 633-directive
inventory and copied-minimal product defect remain unresolved.

Local source and native execution were checked against the current primary
[Cordis lifecycle documentation](https://deepseek-harness.github.io/deepseek-harness/en/develop/cordis-tutorial/02-lifecycle-and-effects).
Full-green acceptance remains open.
