# Native converter fixture and strict compilation

The isolated converter now passes its complete configured typecheck with
`skipLibCheck: false`. Its large function fixture uses actual subprocess V8
coverage from the exact emitted JavaScript. All 1,000 function counts, 7,000
statement counts and 10,000 branch outcomes are asserted directly. Complete
tests remain red: 1,119 pass and 13 fail, with no compiler errors. The candidate
is not promoted to the runner or root application.

## Verified fixture defect

The upstream fixture paired `functions.json` with unrelated emitted code.
The saved record spans 1,039,023 UTF-16 units; TypeScript 6.0.3, the compiler
in the upstream lockfile, emits 333,930 units. There are 240 saved ranges beyond
the emitted file. The saved native records identify five executed methods,
but the old conversion snapshot claims 273 covered functions and 1,899 covered
statements. Both converter builds reproduce that inflated result.

The historical compiler was downloaded into an isolated control directory and
its archive checked against the registry SHA-512. It is not installed into the
candidate; the candidate remains on TypeScript 7.0.2. The twelve historical and
current emitter/converter comparisons are recorded in
`/tmp/dsh-emitter-probe/compare.json` and `compare-imports.log`.

The current Amaro 1.2.0 emitter produces valid JavaScript and source maps.
The fixture runs in a separate native Node process. Inspector supplies the
script source and precise coverage. The collector checks exact source identity,
integer offsets within the emitted source, all 1,000 method names, and each
native invocation count before returning the complete function record. Native
resources and temporary files have explicit disposal ownership.

Five calls, `method1(1)` through `method5(5)`, each return zero. Independent
execution of Istanbul-instrumented JavaScript agrees with native conversion:

| Metric | Covered | Total |
| --- | --- | --- |
| Functions | 5 | 1,000 |
| Statements | 20 | 7,000 |
| Lines | 20 | 7,000 |
| Branch outcomes | 15 | 10,000 |

The function snapshot now records those verified values. The test also checks
every function name and every function, statement and branch counter from the
known calls and nested conditions. The original saved JSON remains available
to the separate range-normalization tests; the conversion fixture no longer
uses it as execution evidence. No original test is deleted.

The native/Istanbul comparison is `/tmp/dsh-emitter-probe/native.mjs`, with
complete maps in `native-evidence.json` and the passing output in
`native-realpath.log`. Initial probe failures remain in their original logs:
the first comparison passed a path instead of a file URL; the first native
probe did not canonicalize macOS's `/tmp` symlink. The final proof verifies
the exact canonical URL, source bytes and counters.

## Dependency and compiler changes

The [instrumentation declaration repair](vitest-instrumentation-declarations.md)
resolves both dependency diagnostics. Replacing the removed TypeScript
`transpileModule` API with Amaro resolves the other four diagnostics. Emission
uses source maps, ordinary type-only import removal and mutable enum handling.
Missing maps fail explicitly. TraceMap supplies the typed map object; the
old source-map assertion and empty-map alternative are removed.

The existing self-dependency override and stale release-age exceptions are
removed. Package resolution and supply-chain verification run normally.
Library checking is enabled in `tsconfig.json`, including the normal
`pnpm run typecheck` command. Test selection, coverage selection, framework
assertions and thresholds are unchanged. Existing broader upstream test and
configuration debt remains outside this completed slice.

The first frozen reconstruction exposed a nonportable dependency path. Its
failure is retained in `/tmp/dsh-converter-native-frozen-install.log`.
The converter now contains the verified instrumenter archive under `artifacts/`
and declares it through a relative file dependency. A new reconstruction uses
the official converter source archive plus the recorded fourteen changed or
added files, a fresh cache and a frozen lockfile. Its location is recorded in
`/tmp/dsh-converter-portable-frozen-location.json`.

## Final verification

All commands use verified official Node 26.9.0 and TypeScript 7.0.2.

| Check | Result | Complete output |
| --- | --- | --- |
| Ordinary configured typecheck | Pass, including library declarations | `/tmp/dsh-converter-portable-typecheck.log` |
| Authored build | Pass; experimental compiler API warning remains | `/tmp/dsh-converter-portable-build.log` |
| Complete lint, formatting and package validation | Pass | `/tmp/dsh-converter-portable-lint.log` |
| Complete suite | 1,119 pass, 13 fail, no compiler errors | `/tmp/dsh-converter-portable-tests.log` |
| Fresh-cache frozen installation | Pass with normal lifecycle scripts | `/tmp/dsh-converter-portable-frozen-install.log` |
| Independent configured typecheck | Pass | `/tmp/dsh-converter-portable-frozen-types.log` |
| Independent build | Executable and declaration files identical | `/tmp/dsh-converter-portable-frozen-build.log` |
| Independent complete suite | Same 1,119 passes and 13 failures | `/tmp/dsh-converter-portable-frozen-tests.log` |

The independent executable SHA-256 is
`c5a2ff2a2b1cc95d9e7e25bd02948024cce0dda270dbe746e2b5a1fff7151649`.
The independent declaration SHA-256 is
`7e4de81c67aaa01f9202bb56242f85355e6a78bd327260294e8e26ada36f4b02`.
Both remain identical to the earlier source-range repair. The frozen lockfile
is unchanged, SHA-256
`591cdd6dcf72e712529531bee5bea580a2f682130bf7ac4c3b67e0147e16ae81`.

## Remaining attribution work

The checker fixture and twelve Svelte/Vue cases across four parsers still fail.
Their existing expected values are unchanged. The independent checker oracle
in `/tmp/dsh-emitter-probe/checker-oracle.json` shows that simply updating the
checker snapshot would conceal unresolved attribution differences:

| Current checker emission | Converter | Independent Istanbul remapping |
| --- | --- | --- |
| Functions | 3,249 | 3,284 |
| Statements | 23,859 | 23,895 |
| Lines | 23,003 | 23,026 |
| Branch outcomes | 27,766 | 27,890 |

The historical TypeScript emission also disagrees with Istanbul. Both full
maps and the summary log are retained. The next repair must establish correct
authored locations and counters across these compiler-generated constructs;
changing a total alone is insufficient evidence.

The isolated runner still needs its Node transformation API repair, CommonJS
helper attribution, Vite wrapper normalization and subprocess source transport.
Final runner reconstruction and root integration remain open. The root's
633 directive inventory, complete 100% coverage, accepted global 99% mutation,
product debt, documentation and platform/CI obligations are unchanged.

The root worktree is clean at observed commit
`105a97ef9c776a2856118ee02609dc61a0fb9617`, which contains the earlier 41-file
Team composition and teardown change. This tooling slice did not stage, commit,
push or modify root files. All listed verification processes are terminal.

Current API grounding: [Amaro](https://github.com/nodejs/amaro),
[Node Inspector](https://nodejs.org/api/inspector.html),
[disposable temporary directories](https://nodejs.org/api/fs.html#fspromisesmkdtempdisposableprefix-options),
and [package-managed local dependencies](https://pnpm.io/cli/add).
