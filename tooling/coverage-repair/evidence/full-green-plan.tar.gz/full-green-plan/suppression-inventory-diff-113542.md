# Source-directive comparison through native HTTP repair

Preserved 903-site snapshot: `source-latest.json`. New 699-site snapshot:
`source-20260916113542547.json`. Identity is path, kind, and directive text;
line movement does not count as removal. This measures directive occurrences,
not completed behavioral or coverage acceptance.

- Removed: 204.
- Added: 0.

| File | Removed directives |
| --- | ---: |
| `packages/acp/acp/src/session.ts` | 17 |
| `packages/client/ui-primitives/src/markdown/mathCompatibility.ts` | 9 |
| `packages/client/ui-slots/tests/core.client.spec.ts` | 3 |
| `packages/core/agent-loop/src/agent.ts` | 5 |
| `packages/core/agent-loop/src/index.ts` | 5 |
| `packages/core/agent-loop/src/tool-calls.ts` | 6 |
| `packages/core/tools/tests/execution-signal-types.spec.ts` | 21 |
| `packages/core/tools/tests/schema.spec.ts` | 5 |
| `packages/credentials/credentials-local/src/index.ts` | 7 |
| `packages/extensions/cordis-client-runner/src/client/timer.ts` | 6 |
| `packages/fs/fs-local/src/fsio.ts` | 26 |
| `packages/fs/fs-observation-policy/src/index.ts` | 1 |
| `packages/llm/llm-retry/src/history.ts` | 1 |
| `packages/session/session-persistence-jsonl/src/index.ts` | 20 |
| `packages/session/session-persistence/src/coordinator.ts` | 9 |
| `packages/skill/skill-filesystem/src/index.ts` | 24 |
| `packages/spill/spill-local/src/cleanup.ts` | 35 |
| `packages/web/web-fetch-http/src/provider.ts` | 4 |
