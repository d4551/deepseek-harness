# Native Worker sandbox acceptance

Status: implemented; scoped validation complete. The unchanged three-case host replay is recorded in
`/tmp/dsh-worker-sandbox-host-before.log`.

The prior spec substitutes `node:child_process` and `process.kill` while
retaining the host platform. The production Worker installs its own process
global and selects Linux; on macOS the spec instead selects Seatbelt. A passing
platform spy would not prove the deployment's confinement.

Retain all three scenarios and their original filesystem and sandbox assertions.
Run them in an actual browser Worker, loading the built provider packages through
the production image packer and module loader. Child commands must execute in
actual nested Workers using the production worker entry. Assert child creation,
capture browser errors, and release workers, browser, server, and scratch files.
Do not replace sandbox probes, process operations, policies, or filesystem results.

Affected files: the existing sandbox stack spec and its native Worker fixtures.
Validation: unchanged failing replay; native three-case replay; related Worker
process tests; typed lint; packed module verification. Build prerequisites must
fail when missing, with no skip. No new exclusions or suppressions are permitted.

Current documentation consulted: Vite's Web Workers feature documentation and
Playwright's Worker API. Context7's previously established quota failure remains;
the primary vendor sources provide the current API evidence.

## Verified repairs

The existing spec now builds a native Worker entry that imports the production
worker, installs production process globals, mounts the canonical packed image,
and runs the original three command scenarios through its module loader.
No process, platform, policy, probe, or filesystem result is substituted. The
original sandbox and filesystem assertions remain exact comparisons. Each case
also requires at least three observed Workers and no browser warning or error.
Native rejection events report the failure to the parent without cancellation.
All resource cleanup failures remain test failures. No custom retry or timeout
setting remains in the suite.

The first native replay passes all three scenarios. The unchanged host replay
fails all three. The migrated suite plus child-process and shell-process suites
passes 33 tests in `/tmp/dsh-worker-sandbox-native-owning.log`. The complete
runtime package passes 911 tests across 35 files in
`/tmp/dsh-worker-runtime-native-full.log`. That initial run included a custom
setup deadline. Removing it exposed a default hook timeout, retained in
`/tmp/dsh-worker-runtime-final-native-full.log` (908 passed, three unrun).
Setup now executes inside the first scenario's existing 30-second deadline.
After the host and website build writers finished, the final complete runtime
replay passed 911 tests across 35 files with zero skips in 27.04 seconds:
`/tmp/dsh-worker-runtime-timed-native-full.log`. Setup and its first scenario
completed in 8.052 seconds. Native rejection reporting and resource cleanup
are included in this final run; no custom timeout or retry remains.

CI graph regressions expose four missing prerequisite relationships in
`/tmp/dsh-coverage-build-order-before.log`. The corrected graphs pass all
79 owning tests in `/tmp/dsh-coverage-build-order-after.log`. Standalone coverage
now owns its complete build; primary and Windows aggregates depend on their
existing build. Complete local tests wait for application and web writers.
Windows workflow build preparation moves into that shared aggregate; the
macOS sandbox full-suite step gains browser provisioning and an application
build. All 20 workflow tests pass in `/tmp/dsh-worker-ci-workflows.log`.

Complete typed lint passes in `/tmp/dsh-worker-ci-order-full-lint.log` before
the final native-event fixture refinement; its scoped lint also passes.
The final scoped lint passes in `/tmp/dsh-worker-runtime-timed-lint.log`.
Documentation validation finishes with 30 passed, two failed and zero skipped
in `/tmp/dsh-worker-ci-order-doc-sync.log`. The failures are protected root/client
AGENTS wrapping and the protected root AGENTS word budget. The quality-policy and
two CI ownership note pairs are updated; all remain useful active records.

The real-browser behavior run does not provide native platform or complete
source-coverage acceptance. No gate threshold, source include/exclude, policy
verdict, skip, or suppression is added.

Primary API references: https://vite.dev/guide/features#web-workers and
https://playwright.dev/docs/api/class-worker.
