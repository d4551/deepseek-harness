# Accessibility execution evidence repair

## Implemented contract

Root and standalone browser runs retain their existing selectors, default reporter, and strict thresholds. The additional native reporter requires every selected source-owned audit definition to register a test and finish successfully with that test's own native axe result validated at 100. The browser setup uses native `onTestFinished` task attribution captured before axe starts. The generic audit helper has no ambient Vitest dependency. Weak result identity tracking prevents caller-created numeric results from earning a receipt. Canonical original failure strings are retained privately before completion publishes native identity; rewriting returned objects cannot erase failures. Cross-test result reuse fails explicitly.

Candidate declarations remain static ownership evidence only. Skipped and unreachable declarations remain obligations. Public `globTestSpecifications()` reconciles candidate discovery against configured test discovery before selected-file execution: full runs cannot turn config omissions into focused success. Explicit project or CLI exclusion selection is recognized from public invocation options; selected subsets, names, shards, related/changed sources and tags report partial evidence. Native line and column positions distinguish definitions on the same line. The shared Vitest metadata contract is an owner-package declaration module, `packages/test-support/client-a11y/tests/task-meta.d.ts`, accepted by both host and client composite programs without broadening file selection.

## Verified defects and evidence

- Original static checker accepted both dead audit bodies and skipped tests: `/tmp/dsh-full-green-plan/a11y-config-presence-probe.log`. The saved original checker is `/tmp/dsh-a11y-execution-before/client-a11y-coverage.ts`.
- Native regression also exposed line-only attribution accepting an unregistered same-line sibling. `/tmp/dsh-a11y-same-line-before.log` records one actual test falsely counted as two verified tests and exit 0. Exact column matching repairs this.
- All seven real Chromium reporter regressions passed in `/tmp/dsh-a11y-execution-final-owning.log`: genuine per-instance audits; unreachable, skipped, unregistered, same-line unregistered, caller-created, and borrowed-result failures. That run also passed four existing static checks. Its three source-location unit failures were incorrect expected column numbers, retained in the log and corrected against the complete source strings. All three corrected source-location tests pass in `/tmp/dsh-a11y-execution-candidate-columns-native.log`.
- A real unnamed button result could be rewritten to a perfect result and earn a receipt before the integrity fix: `/tmp/dsh-a11y-native-mutation-before.log`. Immutable original failure capture rejects it after repair.
- Full CLI, `startVitest`, and `createVitest().start()` runs all falsely accepted an omitted candidate before configured-discovery reconciliation: three failed regressions in `/tmp/dsh-a11y-config-omission-before.log`.
- Final owning replay passes **49 tests in eight files**, including all 14 native reporter regressions: `/tmp/dsh-a11y-integrity-selection-owning.log`. Native ordering assertions prove acquisition publishes completion without a validation receipt; explicit caller validation at 100 publishes the receipt. Lower-floor calls preserve utility behavior and publish no receipt. Explicit file-focused CLI and both public APIs pass while reporting partial evidence.
- Final complete browser lane: **73 files, 698 tests passed; 67 audit tests verified** after integrity and configured-discovery repair. `/tmp/dsh-a11y-integrity-full-browser.log`, exit 0.
- Host and client noEmit aggregates both pass: `/tmp/dsh-a11y-integrity-host-types.log` and `/tmp/dsh-a11y-integrity-client-types.log`. Earlier TS6307 ownership failures are retained separately.
- Typed lint passes: `/tmp/dsh-a11y-integrity-selection-lint-fixed.log` plus unchanged-file validation in `/tmp/dsh-a11y-execution-lint-final-declaration.log`.
- Export JSDoc, bilingual pairing, and relative links pass: `/tmp/dsh-a11y-integrity-export-jsdoc.log`, `/tmp/dsh-a11y-integrity-pairing-check.log`, `/tmp/dsh-a11y-execution-links.log`.
- Markdown wrapping fails only protected `AGENTS.md:3` and `packages/client/AGENTS.md:3`: `/tmp/dsh-a11y-execution-wrap.log`. These files were not edited.

## Initial strict coverage evidence

`/tmp/dsh-a11y-integrity-coverage.log` records 28 owning tests passing, then exit 1 from unchanged per-file 100 thresholds. The JSON report includes **all four** source files, including the new `execution.ts` and existing `invariant.ts`; the text reporter omits full-coverage rows only from display.

- `execution.ts`: 16/16 statements, 7/7 functions, 4/4 branches; all lines covered.
- `index.ts`: 56/57 statements, 22/23 functions, 21/24 branches; unresolved formatting branches at lines 154–155.
- `invariant.ts`: 6/6 statements, 2/2 functions; no branches.
- `popup-review.ts`: 33/37 statements, 3/3 functions, 36/42 branches; uncovered branches at lines 21, 25, 26, 27, and 32.

The Vite dependency dynamic-import warning remains visible in browser logs. This initial run did not establish a warning-free build or package-wide strict coverage pass.

## Native coverage completion

After the parent released the full-suite write hold, only `packages/test-support/client-a11y/tests/popup-review.browser.spec.ts` was added. No production source, axe rules, tag selection, safety guards, discovery configuration or thresholds changed in this follow-up.

Nine real Chromium cases cover missing controls/haspopup/expanded metadata, a non-popup ARIA review, repeated ID references, the native true/menu value, retained axe results after trigger removal, mixed completed/unresolved popup reviews, and the documented v2 result format. The v2 case restores v1 in owned `finally` cleanup and verifies a subsequent native audit includes failure summaries. Original axe result objects and DOM references are retained; no NodeResult objects were fabricated.

The complete owning suite passes **37 tests in six files**, and all four source files meet unchanged per-file 100% thresholds: **116/116 statements, 70/70 branches, 35/35 functions, 84/84 lines**. Log: `/tmp/dsh-a11y-native-popup-coverage.log`, exit 0. JSON: `/tmp/dsh-a11y-native-popup-coverage/coverage-final.json`.

- `execution.ts`: 16/16 statements, 7/7 functions, 4/4 branches.
- `index.ts`: 57/57 statements, 23/23 functions, 24/24 branches.
- `invariant.ts`: 6/6 statements, 2/2 functions; no branches.
- `popup-review.ts`: 37/37 statements, 3/3 functions, 42/42 branches.

Typed lint and the full client noEmit aggregate pass: `/tmp/dsh-a11y-native-popup-lint.log` and `/tmp/dsh-a11y-native-popup-types.log`. The Vite dependency warning remains unresolved; no global repository pass or mutation score is claimed. The new test file is untracked; this agent performed no staging or commits.

## Remaining limits

Source candidate discovery retains its import/render/assertion syntax boundary. The AST attribution follows named Vitest imports and direct, local, or named relative helper calls. Namespace imports, re-export chains, generated factories, and complete component/state/journey discovery are not proven. Registered source candidates with no attributable definition fail, but the static qualification stage can miss unsupported spellings. The execution ledger does not prove exhaustive UI coverage or replace keyboard, screen-reader, and content review. README pairs describe these limits.

No product UI, coverage thresholds, discovery selectors, or accessibility rules were weakened. No source suppression was added. Existing invariant companion behavior is unchanged; its comment was corrected because the helper now owns a test execution ledger. No staging or commits were performed by this agent; another work source staged several files during the task.

## Edited paths

- `packages/test-support/client-a11y/src/{index,execution,invariant}.ts`
- `packages/test-support/client-a11y/tests/browser-setup.client.ts`
- `packages/test-support/client-a11y/tests/audit-surface.browser.spec.ts`
- `packages/test-support/client-a11y/tests/popup-review.browser.spec.ts`
- `packages/test-support/client-a11y/tests/task-meta.d.ts`
- `packages/test-support/client-a11y/README.{md,zh.md,i18n.yaml}`
- `scripts/client-a11y-coverage.ts`
- `scripts/client-a11y-candidates.ts` and `.spec.ts`
- `scripts/client-a11y-reporter.ts` and `.spec.ts`
- `vitest.config.ts`
- `vitest.client-browser.config.ts`

Obsolete intermediate `scripts/client-a11y-task-meta.ts` and owner `task-meta.client.ts` were removed in favor of the native declaration module.

Native API references: https://vitest.dev/guide/advanced/ and https://vitest.dev/api/advanced/vitest. Local Vitest 5 source confirms `start(filters)` stores filename filters in a private field, so the reporter does not read that field or assume the declared `config.filters` is populated. It uses the supported discovery API and native selected specifications.
