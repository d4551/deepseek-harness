# Every documented README limitation section

These include both unresolved work and intentional product boundaries. Classification is mandatory; this inventory does not authorize inventing features or erasing supported constraints.

## [packages/acp/acp/README.md:162](/Users/brandon/Downloads/deepseek-harness/packages/acp/acp/README.md:162)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this package is a poor fit or needs special operational care. They are current package constraints, not a protocol comparison or a task backlog.

- **One primary workspace** — additional directories remain unsupported.
- **Raster prompt images only** — PNG, JPEG, WebP, and GIF require a durable attachment store and an exact image-capable route.
- **MCP tools only** — MCP resources and prompts have no DSH consumer.
- **No transcript replay or interactive extensions** — session deletion, fork, `session/load`, modes, commands, plans, terminals, client filesystem operations, and elicitation remain outside this automation surface.

<a id="dev-note"></a>
```

## [packages/api/gateway/README.md:61](/Users/brandon/Downloads/deepseek-harness/packages/api/gateway/README.md:61)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- The Connection adapter maps ordinary dispatch failures and business exceptions to the RPC `internal` code with empty details; lookup-policy errors carried by `TypertLookupFailure` are returned unchanged. Structured `TypertGatewayError` categories remain available only to same-process callers.
- SRC mode supports unique identifier parameters without destructuring, defaults, or rest parameters. It validates JSON safety rather than generated business types and never infers optional fields.
- Only strict generated contributions can mount on the Client face. SRC markers have no Client codec or type projection.
- `$stream()` supervises carrier replacement but does not infer replay semantics; each domain owns its resume cursor or replacement-baseline validation and normal-end classification. Connection generations reopen the internal `$events` stream; one-way notifications are not replayed, while pending scoped waterfalls retain their event id across replay.
- Lookup resolvers are configured per key; an individual Remote parameter or endpoint cannot currently select a live-only policy under the same `agent`/`session` key.
- Forwarded events reach `$on` without business-payload projection or redaction. Ordinary notifications are not replayed after reconnect; Agent-scoped waterfalls project only the top-level Agent identity needed to select the Client Context and carry their own pending lifetime.
- WebSocket heartbeats keep idle intermediaries active but do not require a timely Pong or terminate an unresponsive peer. Half-open carriers remain subject to TCP or intermediary failure detection before the Client reconnects.


<a id="dev-note"></a>
```

## [packages/api/remotes/README.md:65](/Users/brandon/Downloads/deepseek-harness/packages/api/remotes/README.md:65)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- The capability set is fixed by explicit build-time value imports; the Client does not discover the Host's active Services or Remote definitions at runtime.
- Additional capabilities require an explicit `/remote` value import and mount in this assembly.
- Pending scoped waterfalls replay to a replacement Client generation. Ordinary forwarded events are not replayed; state that requires reliable recovery needs an owner-provided query, cursor, or opening baseline.


<a id="dev-note"></a>
```

## [packages/api/session-controller/README.md:59](/Users/brandon/Downloads/deepseek-harness/packages/api/session-controller/README.md:59)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- Control baselines represent process-local state and therefore cannot reconstruct jobs after a Host restart.
- A failed follow resumption remains visible to the caller instead of retrying indefinitely.
- File-reference completion uses the shared Agent lookup and can resume a cold Session; the `skills/list` catalog is the non-activating alternative for skill metadata.


<a id="dev-note"></a>
```

## [packages/api/settings-controller/README.md:56](/Users/brandon/Downloads/deepseek-harness/packages/api/settings-controller/README.md:56)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- The batch bound is fixed at 64 references and is not a deployment-configurable field.

<a id="dev-note"></a>
```

## [packages/api/workspace-controller/README.md:40](/Users/brandon/Downloads/deepseek-harness/packages/api/workspace-controller/README.md:40)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- `follow()` replaces the whole projection after reconnect and has no durable cursor or incremental catch-up protocol.
- Process-local deletion markers prevent delayed data from reviving a removed Workspace only for the lifetime of the Client model.


<a id="dev-note"></a>
```

## [packages/attachment/attachment-local/README.md:126](/Users/brandon/Downloads/deepseek-harness/packages/attachment/attachment-local/README.md:126)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what this storage can and cannot do; they are current package constraints.

- **Images are kept forever** — stored images are never deleted automatically, and nothing collects unreferenced objects.
- **Local to this machine** — images live on the machine that runs the harness; other hosts cannot read them.
- **Animated GIF becomes static** — normalization retains only the first frame; animation is outside the version-one image contract.
- **Encoder output is versioned** — the installed Sharp/libvips build pins normalization and request bytes; an encoder or transform-version upgrade re-addresses future variants while existing objects remain valid.

<a id="dev-note"></a>
```

## [packages/attachment/attachment/README.md:107](/Users/brandon/Downloads/deepseek-harness/packages/attachment/attachment/README.md:107)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what image attachments can and cannot do; they are current package constraints, not a task backlog.

- **Raster images only** — PNG, JPEG, WebP, and GIF are accepted; generic files, audio, and video are not supported yet.
- **Images are never deleted** — stored images are retained indefinitely; nothing removes them automatically.
- **Unsent drafts are not saved** — a composer draft stays in the browser until you submit the message.

<a id="dev-note"></a>
```

## [packages/boot/app-boot/README.md:129](/Users/brandon/Downloads/deepseek-harness/packages/boot/app-boot/README.md:129)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe when this boot library is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **Bare package specifiers depend on Loader internals** — production bins need Loader's optional native helper; an in-process caller without it must use resolvable relative/file specifiers or provide its own module-resolution hook.
- **Snapshot replay swapping is basename-specific** — only a config ending in `cordis.yml` or `cordis.yaml` maps to the sibling `cordis.snapshot.yml`; custom config names require caller-managed selection.
- **Environment discovery is launch-scoped** — `loadLayeredEnv` reads only the invocation directory and Harness home once; it does not search parents or follow a workspace selected later. `loadEnv` remains the one-directory helper for non-product bins.
- **A user patch replaces the whole matched config** — an id-targeted patch does not deep-merge, so a profile override restates the bundle fields it keeps.

<a id="dev-note"></a>
```

## [packages/boot/cmdline/README.md:128](/Users/brandon/Downloads/deepseek-harness/packages/boot/cmdline/README.md:128)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe where app-owned command lines are a poor fit or need special care. They are current package constraints, not a task backlog.

- **Launcher flags must precede app arguments** — the split is positional: the first token the launcher does not recognize starts the inner arguments, so `--patch` placed after an app flag belongs to the app. The launcher's parser consumes one `--`, so an app argument that must survive as a literal `--` needs `-- --`.
- **An app-owned service has no statically declared provider** — consumer rows name it through ordinary injection; a bundle that omits its provider fails at settlement with pending entries naming the service rather than at load.
- **A user patch that replaces a row's whole `config` drops its expressions** — a flag beats the value written beside it, not a literal a user wrote in place of the expression; keeping the expression is what keeps the flag winning.

<a id="dev-note"></a>
```

## [packages/bundle/acp-app/README.md:57](/Users/brandon/Downloads/deepseek-harness/packages/bundle/acp-app/README.md:57)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **A profile can omit the ACP bridge** — a custom ACP launch profile must retain this bundle or another `dsh-acp` row; otherwise no peer answers the client.
- **User plugins can violate stdout purity** — profile and per-launch patches are trusted application composition. The shipped bundle writes no non-protocol stdout, but it cannot contain an arbitrary inserted plugin.
- **Configuration changes require restart** — the shipped `acp` profile uses `patchReload: startup` so one stdio connection never observes a replacement bridge or Agent dependency.


<a id="dev-note"></a>
```

## [packages/bundle/base/README.md:129](/Users/brandon/Downloads/deepseek-harness/packages/bundle/base/README.md:129)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits tell you when the core needs extra care or where an override must go. They are current package constraints, not a general comparison or a task backlog.

- **Overrides replace whole settings blocks** — a patch entry replaces the target's entire configuration, so your override must restate every setting you want to keep; nothing merges automatically.
- **Per-surface settings belong to the surface's bundle** — a default that differs between the web GUI and headless mode lives in that surface's bundle, not in the shared core.
- **Windows temp grants are private per-session subdirectories** — `workspace-write` confines writes to the workspace plus the session's own temp subdirectory (`<temp>\dsh-<hash>`, TMP/TEMP rewritten for confined children); `read-only` grants nothing. See `@deepseek-ai/dsh-sandbox-windows-acl`.
- **Adding the plain filesystem provider on top of the sandboxed one fails the profile** — the two register the same service, so the profile refuses to load; use one or the other.
- **Browser installation is required** — default search and fetch use Playwright Chromium. Without its browser download, both fail with `WEB_PROVIDER_CONFIGURED_UNAVAILABLE`; choose another provider explicitly if Chromium cannot run on the host.

<a id="dev-note"></a>
```

## [packages/bundle/headless/README.md:115](/Users/brandon/Downloads/deepseek-harness/packages/bundle/headless/README.md:115)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits tell you when headless does not fit and what it needs from the `dsh` launcher. They are current package constraints, not a general CLI comparison or a task backlog.

- **One task per run** — after the task is answered the process exits; there is no interactive follow-up, so split multi-step work into separate runs.
- **Runs through the `dsh` launcher** — starting the headless profile another way fails at startup, because only the launcher can request the process exit.
- **No pre-token heartbeat** — stderr stays silent until the provider emits a non-empty reasoning delta; a delayed first token exposes no earlier progress signal.
- **Reasoning enters stderr logs** — redirection and supervisors may retain substantially more and potentially sensitive model output; route stderr to a controlled sink when needed.
- **Only reasoning and the final answer are printed** — a run without an assistant message prints an empty stdout line and exits 1; intermediate tool output is not printed.

<a id="dev-note"></a>
```

## [packages/bundle/hosted-drive/README.md:76](/Users/brandon/Downloads/deepseek-harness/packages/bundle/hosted-drive/README.md:76)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **One drive per deployment.** The layer configures a single collection from environment variables; a deployment serving several users from one process would need per-session drive selection, which the patch layer has no place to express.
- **The drive arbitrates concurrency, and only if it serves versions.** Two harnesses on one collection interleave writes; a guarded write reports the conflict when the server serves an ETag and cannot guard at all when it does not.
- **Authentication is password-only here.** The WebDAV provider also supports digest and bearer tokens, but this patch wires the password form, so a token-authenticated collection needs its own overlay row.

<a id="dev-note"></a>
```

## [packages/bundle/sdk-app/README.md:53](/Users/brandon/Downloads/deepseek-harness/packages/bundle/sdk-app/README.md:53)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **A profile can omit the SDK server** — a custom profile selected by the TypeScript client must retain this bundle or another `dsh-sdk-jsonrpc-server` row; client initialization fails when no peer answers.
- **User plugins can violate stdout purity** — profile and per-launch patches are trusted application composition. The shipped bundle writes no non-protocol stdout, but it cannot contain an arbitrary inserted plugin.
- **Configuration changes require restart** — the shipped `sdk` profile uses `patchReload: startup` so one stdio connection never observes a replacement server or Agent dependency.


<a id="dev-note"></a>
```

## [packages/bundle/sdk-minimal/README.md:90](/Users/brandon/Downloads/deepseek-harness/packages/bundle/sdk-minimal/README.md:90)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **The composition intentionally omits shared product services** — select `dsh --profile sdk` when settings, managed credentials, policy presets, telemetry, Web tools, or the full default tool roster are required.
- **User patches can expand the tree and corrupt stdout** — profile customization is trusted application composition; a plugin that writes ordinary text to stdout can break JSON-RPC framing.

<a id="dev-note"></a>
```

## [packages/bundle/web-app/README.md:137](/Users/brandon/Downloads/deepseek-harness/packages/bundle/web-app/README.md:137)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits tell you what to expect in unusual setups — a source checkout, SSH sessions, or strict networks. They are current package constraints, not a general browser comparison or a task backlog.

- **The frontend must be built** — a source checkout needs `bun run build` first; startup stops with a build hint when the dist is missing, and there is no source-serving fallback.
- **LAN addresses are sampled once at startup** — interface changes after boot are not re-advertised; the printed LAN URL always matches what was sampled.
- **Only the handoff start is observable** — the GUI reports that the browser was asked to open, not that it actually opened; a later browser exit is never reported, and the printed URL is your manual fallback.
- **SSH sessions keep the URL but skip the browser handoff** — the printed URL names the remote host's loopback endpoint; the SSH client or editor must expose and open the local forwarded address.
- **`BROWSER` overrides only come from the environment** — a discovered `.env` cannot set `BROWSER`; only an inherited value can choose the executable for the automatic handoff.
- **Binding all network interfaces is not supported** — `--host 0.0.0.0` is rejected at startup for safety; use the default loopback host.

<a id="dev-note"></a>
```

## [packages/client/connection/README.md:59](/Users/brandon/Downloads/deepseek-harness/packages/client/connection/README.md:59)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **The `/api` bridge buffers each request body in memory** — `maxRequestBodyBytes` (default 300 MiB, sized for the default 200 MiB aggregate image limit after base64 expansion plus envelope headroom) is therefore also the per-request resident bound; a streaming body path would be needed to lower it without shrinking the image limits.
- **The browser cookie is not marked `Secure`** — loopback HTTP is the shipped transport, so exposing the same authority over plaintext networking can expose the bearer cookie in transit.
- **There is no logout operation** — clearing the browser cookie ends one browser session; deleting the owner credential record and restarting `dsh` revokes every session.


<a id="dev-note"></a>
```

## [packages/client/hmr/README.md:109](/Users/brandon/Downloads/deepseek-harness/packages/client/hmr/README.md:109)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the reload driver does not preserve or restore. They are current package constraints, not a task backlog.

- **Reload is coarse by design** — a fresh fiber and fresh components; React state inside the reloaded plugin is lost while the data layer (connection/runtime fibers, Session objects) is untouched. react-refresh-grade state preservation conflicts with re-executing the bundle and is deliberately out.
- **No failure rollback** — a reload that fails leaves the entry FAILED and visible in the loader status projection; the previous bundle is not restored automatically.
- **Rebuilt frames do not replace the boot graph** — each frame carries the plugin-artifact revision needed for its one-resource combo reload; a page reload receives the recomposed startup graph.

<a id="dev-note"></a>
```

## [packages/client/locale/README.md:122](/Users/brandon/Downloads/deepseek-harness/packages/client/locale/README.md:122)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where localization is incomplete or frozen at registration time. They are current package constraints, not a task backlog.

- **Registry-held text reads its translation once** — copy captured at registration time outside the slot render path (e.g. the `/model` command description in the command registry) keeps the language it was registered under until re-registration; slot-rendered copy follows switches live.
- **Language packs own language-specific behavior** — the registry supplies selection, persistence, browser matching, key fallback, and `<html lang>`; it does not add plural rules or bidirectional layout.

<a id="dev-note"></a>
```

## [packages/client/modules/README.md:108](/Users/brandon/Downloads/deepseek-harness/packages/client/modules/README.md:108)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the module system does not do. They are current package constraints, not a task backlog.

- **Flat module graph by design** — every bundle is one module node whose edges point only at table leaves; the interface (`loadCache`/`edges`/`invalidate`) already supports a general module graph, so the externalization granularity can change without an interface change.
- **No unload bookkeeping of its own** — style removal and fiber teardown ordering live with the HMR driver (`@deepseek-ai/dsh-client-hmr`); the loader only inventories owned style tag ids per record.
- **Snapshot delivery retains artifact bytes** — the Host holds each bundle, optional source map, generated one-resource response, and current startup combo responses in memory; HMR additionally retains one prior startup generation. Memory scales as several copies of the composed client artifacts in exchange for immutable responses and one-generation race tolerance.

<a id="dev-note"></a>
```

## [packages/client/store/README.md:30](/Users/brandon/Downloads/deepseek-harness/packages/client/store/README.md:30)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Persistence is browser-local** — persisted stores use JSON in `localStorage`; non-browser runtimes disable persistence, and the package provides no cross-device synchronization.


<a id="dev-note"></a>
```

## [packages/client/ui-agent-preset/README.md:73](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-agent-preset/README.md:73)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current preset surfaces. They are current package constraints, not a general composition comparison or a task backlog.

- **A preset without metadata is listed by id** — display text is optional, and a copy given no name deliberately falls back to its directory name rather than presenting itself identically to its source.
- **A revealed path is display text, not a link** — where the host has no desktop opener the row shows the directory to copy by hand; the browser cannot open a host filesystem location itself.
- **Composition edits are invisible to the page** — the files are edited outside the browser and nothing on the wire announces a file change, so the roster re-reads on its own actions, `settings/changed`, and `connection/reset`, not on every disk edit.

<a id="dev-note"></a>
```

## [packages/client/ui-agent-team/README.md:97](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-agent-team/README.md:97)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Ordinary child continuation** — a human message sent after navigation uses the stable addressed-subagent prompt path, not the Team peer mailbox.
- **No lifecycle or workspace controls** — the panel cannot spawn, rename, delete, or interrupt teammates, and write scopes remain advisory metadata.

<a id="dev-note"></a>
```

## [packages/client/ui-approval/README.md:30](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-approval/README.md:30)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **The panel exposes transient decisions only** — it supports allow-once and reject; persistent permission policy remains owned by Host-side approval packages.


<a id="dev-note"></a>
```

## [packages/client/ui-attachment/README.md:85](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-attachment/README.md:85)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current attachment surface. They are package constraints, not a general image-viewer comparison or a task backlog.

- **Images only** — non-image files have no rail card or history renderer yet; DeepSeek Chat-style file cards and upload progress wait until the composer accepts non-image attachments.
- **No zoom or download in the lightbox** — the preview renders the original at fit-to-viewport size only.
- **The lightbox does not trap focus** — it sets `aria-modal` and restores focus on close, but Tab can reach the page behind it.

<a id="dev-note"></a>
```

## [packages/client/ui-brand-official/README.md:72](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-brand-official/README.md:72)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define how brand presentation is supplied. They are current package constraints, not a brand-design comparison or a task backlog.

- **One occupant set** — alternative presentation belongs in another Cordis package occupying the same slots.
- **The browser title is independent** — `DSH_CLIENT_TITLE` selects title text at build time rather than through a UI slot.

<a id="dev-note"></a>
```

## [packages/client/ui-chat/README.md:54](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-chat/README.md:54)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **The view reflects the loaded Session window** — older transcript nodes become available only after Session Controller loads the preceding event page. Turn navigation lists loaded Turns in the shared Menu primitive, with each entry named by its Turn, loaded prompt, and response. Loading an earlier page preserves existing entries. Arrow keys, Home, and End move between entries; Enter navigates and Escape returns focus to the menu button. The menu remains available in narrow layouts.


<a id="dev-note"></a>
```

## [packages/client/ui-commands/README.md:74](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-commands/README.md:74)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current command surface. They are current package constraints, not a general command-line comparison or a task backlog.

- **Detached-result notices fall back to the console off-session** — the fire-and-forget paths route results to the triggering session's composer via `SessionInput.notify`; after session teardown the console line is the only remaining surface.

<a id="dev-note"></a>
```

## [packages/client/ui-conversation/README.md:104](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-conversation/README.md:104)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Only registered targets can render** — the shell deliberately has no implicit fallback target beyond the registered `chat` preference.


<a id="dev-note"></a>
```

## [packages/client/ui-deliverables/README.md:81](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-deliverables/README.md:81)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current deliverables vocabulary. They are current package constraints, not a general file-linking comparison or a task backlog.

- **Mention matching is exact path or unique basename only** — a suffix mention stays inert; widening the matcher is deferred until a real closing-message shape needs it.
- **Files created indirectly by terminal commands remain outside the matching vocabulary** — naming such a file in inline code does not make it clickable unless a successful mutation location also records that path.
- **Native folder handoff targets the Host desktop** — a browser reached through a non-loopback authority omits the action, as does a deployment reporting no native opener; SSH forwarding that makes a remote Host look loopback-local must set the Session Controller's `nativeOpen: false`.

<a id="dev-note"></a>
```

## [packages/client/ui-directory-picker-browse/README.md:69](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-directory-picker-browse/README.md:69)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current browse surface. They are current package constraints, not a general file-browser comparison or a task backlog.

- **No search, no multi-select, and no rename or delete** — the dialog lists and creates directories; a target is reached by navigating, editing the path, or filtering the last pane by prefix.
- **Hidden-entry filtering is client-side** — the Host always lists hidden entries and flags them, so the toggle changes only what the dialog renders.

<a id="dev-note"></a>
```

## [packages/client/ui-directory-picker-native/README.md:69](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-directory-picker-native/README.md:69)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the native chooser fits. They are current package constraints, not a general picker comparison or a task backlog.

- **No cancellation of an open chooser** — the wire has no per-request abort, so a chooser already on the host display cannot be closed from the browser; a discarded settlement is ignored.
- **Local Host carriers only** — an OS dialog opens on the machine running the Host, so in-process and remote-browser deployments need the `-browse` composition instead. Platform failures surface through the owner's retryable folder dialog.

<a id="dev-note"></a>
```

## [packages/client/ui-goal/README.md:72](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-goal/README.md:72)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current goal surface. They are current package constraints, not a goal-domain comparison or a task backlog.

- **Durable phase only** — the projection omits process-local activation, so the strip cannot distinguish an active-but-disarmed goal from an armed one; resume re-arms through the RPC side. There is no host-live activation channel.
- **Preset-independent host state** — switching an active session to `minimal` leaves its host-owned goal intact. `/goal` and goal tools disappear, while this strip can still edit, pause, resume, or clear the goal.

<a id="dev-note"></a>
```

## [packages/client/ui-input-trigger/README.md:71](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-input-trigger/README.md:71)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current trigger pipeline. They are current package constraints, not a general menu comparison or a task backlog.

- **Global source layer only** — session-scope source registration (per-session shadowing) is designed but not enabled; the ledger tracks the trigger condition, a real per-session source need.
- **`InputTriggerCandidate.icon` renders as text** — `MenuView` drops the string into the icon slot verbatim; wiring to the design-system icon enum lands when that enum ships.
- **Overlay SlotMap merge home is split from slot ownership** — the sole `conversation.input.overlay` merge lives here, while ui-conversation owns its anchor, children declaration, and lifecycle because the dependency direction is ui-conversation → ui-input-trigger.

<a id="dev-note"></a>
```

## [packages/client/ui-jobs/README.md:69](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-jobs/README.md:69)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current job list. They are current package constraints, not a general job-management comparison or a task backlog.

- **Rows are read-only** — a job's streamed output and a human-initiated cancellation are separate phases. Cancellation additionally owes a model-facing decision the seam does not answer: `kill()` marks terminal delivery reported, so an interrupt written against the current contract would leave the model believing its job is still running.
- **The list is not the registry's own set** — it shows what one session can see through the wire view, so a job owned by another session never appears here, and a process restart empties the list while the transcript keeps the `run_in_background` cards that started those jobs. An unowned job (one started without a live `Agent`) reaches every session's list, matching what `list(caller)` reports to every caller.

<a id="dev-note"></a>
```

## [packages/client/ui-layout/README.md:69](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-layout/README.md:69)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current layout behavior. They are current package constraints, not a general window-manager comparison or a task backlog.

- **Panel geometry is transient** — reload restores the sidebar default and details closed; switching between distinct Session ids also closes details and forgets its dragged width, while unselected surfaces render details at zero width without modifying geometry.
- **Concession-chain auto-close derives a zero width without touching the preferred width** — the panel restores itself when the window widens; consumers must not read the stored details width as the rendered truth.
- **No scroll anchoring during squeeze reflow** — layout changes may move the reader's viewport.

<a id="dev-note"></a>
```

## [packages/client/ui-message-feedback/README.md:68](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-message-feedback/README.md:68)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current feedback surface. They are current package constraints, not a general rating comparison or a task backlog.

- **Note size is a Host policy** — the deployment configures `maxNoteBytes` (8192 in the Web bundle) and the Host rejects an oversized note with `note-too-large`. The editor does not pre-check the limit, so an oversized note fails on save rather than while typing.
- **No cross-tab push** — a second tab's rating becomes visible on reconnect or on the next conflict reply, not immediately; the sidecar publishes no live frames.
- **Chat view only** — the trajectory and waterfall views render no feedback controls even though their assistant nodes carry the same `messageId`.

<a id="dev-note"></a>
```

## [packages/client/ui-model-selection/README.md:75](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-model-selection/README.md:75)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current model surface. They are current package constraints, not a general model-router comparison or a task backlog.

- **No create-time or addressed-subagent selection** — both entries require an existing ordinary session's Agent; there is no draft-phase model choice to fold into session creation, and subagent continuation deliberately exposes no independent model-selection contract.
- **Directory names are presentation-only** — selection and persistence use provider/model/effort ids; a provider whose catalog or exact-model metadata lookup fails lists as an unselectable failure row until reload.
- **No arbitrary effort input** — the composer offers only the exact model's adapter-advertised levels; an adapter without reasoning metadata leaves the Effort row absent.

<a id="dev-note"></a>
```

## [packages/client/ui-permission-presets/README.md:73](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-permission-presets/README.md:73)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current permission surfaces. They are current package constraints, not a general policy comparison or a task backlog.

- **The Settings row is Web-only** — non-Web clients may still switch the current session through `/permission`, but do not receive this browser contribution.
- **Preset descriptions come from the host** — localized built-in labels may therefore appear beside a description written in another language.

<a id="dev-note"></a>
```

## [packages/client/ui-plan/README.md:73](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-plan/README.md:73)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the current plan chip. They are current package constraints, not a plan-mode comparison or a task backlog.

- **Plan mode is guidance, not an execution sandbox** — deployments that require enforced read-only planning must compose the independent sandbox and approval policies.
- **The chip belongs to the default composer** — a pending whole-composer interaction such as plan review temporarily replaces the InputBar and its chip.
- **No inactive plan control** — entry uses the shared Command source; a session with the capability but inactive mode shows no plan affordance in the tool row.

<a id="dev-note"></a>
```

## [packages/client/ui-primitives/README.md:114](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-primitives/README.md:114)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define how the atoms behave at the edges; they are current package constraints, not a component roadmap.

- **Streaming defers cross-boundary reference resolution** — a reference-style link or footnote whose definition sits on the other side of the incremental freeze boundary renders as literal text while the reply streams; the settled full parse at finalize resolves it.
- **Glyph-level icons are redrawn approximations** — the fish logo and the sparkle mark come from font glyphs whose vector geometry is not exportable from the local design data; hand-authored recreations stand in until an exact export path exists.
- **`Pill` and `Input` have no design source** — both atoms are self-defined; the sidebar search field and view-tab strip that resemble them are consumer-owned compositions, not these atoms.
- **No `Active` `StateDot` variant** — the supported states are done, warning, ongoing, and error.
- **User-facing copy is required at the render site** — the atoms are zero-Cordis and cannot reach `ctx.locale`; each feature must supply complete localized labels through the primitive's typed props ([decision](../../../.agents/notes/implemented/architecture/2026-08-23-locale-owned-client-ui-copy.md)).
- **`TerminalBlock` is not a terminal emulator** — it renders settled or still-running command output, not an interactive session: SGR colors, carriage return, backspace, erase-in-line, tab stops, and character width are honored; absolute cursor positioning, screen clearing, and alternate-screen sequences are stripped.

<a id="dev-note"></a>
```

## [packages/client/ui-projection/README.md:34](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-projection/README.md:34)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **The Conversation record types stay in `ui-conversation`** — the folds here produce `AssistantBlock`, `RunningToolCall`, and their siblings, but those declarations remain with the merge-extensible `ConversationTurnDataMap` / `ConversationStepDataMap` maps that other rows augment. Moving them would relocate every `declare module` target, so this package type-imports them and the type graph points from the shared layer at the row rather than the other way round.
- **Adding an export is a shell change** — a new name here is only reachable once `PLATFORM_MODULES` and `packages/client/web/src/seed.ts` carry the package, so a consumer cannot pick it up from a package-local build alone.

<a id="dev-note"></a>
```

## [packages/client/ui-reference/README.md:83](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-reference/README.md:83)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the reference source cannot help; they are current package constraints.

- **Candidate failure is intentionally quiet** — one unavailable or failed Remote discovery call yields no rows for that domain. A session-reference preparation failure occurs after prompt acceptance and terminates that agent turn.
- **No browser-side file scan** — Web completion requires a mounted Host `ctx.fileReferences` provider; the browser cannot fall back to its own filesystem.
- **Session search remains metadata-only** — discovery filters session id, cwd, and the latest log-backed title through `ctx.sessionReferenceResolver`; message bodies and full transcripts are not searched.

<a id="dev-note"></a>
```

## [packages/client/ui-renderer/README.md:86](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-renderer/README.md:86)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the application frame appears and how far per-region readiness goes; they are current package constraints.

- **The first application frame waits for every client entry** — the boot kernel hands over the mount point only after the loader roster settles; per-region readiness remains deferred.
- **Slot rendering has no Suspense integration or per-entry lazy loading** — the complete plugin roster settles before the renderer mounts the root.

<a id="dev-note"></a>
```

## [packages/client/ui-session/README.md:30](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-session/README.md:30)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Pending interactions are process-local projections** — the owning Remote waterfall must replay an outstanding request after a browser reconnect.


<a id="dev-note"></a>
```

## [packages/client/ui-settings-general/README.md:92](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-settings-general/README.md:92)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the shell itself provides versus what features must supply; they are current package constraints.

- **The General section has no built-in rows** — each row appears only when its owning feature plugin is mounted; the shell cannot fill the section alone.

<a id="dev-note"></a>
```

## [packages/client/ui-settings-models/README.md:98](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-settings-models/README.md:98)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the editor's field coverage and the page's reach; they are current package constraints, not a settings roadmap.

- **Only the API key and curated fold fields are editable on the card** — the hand-written editor traded schema-generic field coverage for the mockup layout. Retry policy, timeouts, DeepSeek model descriptions, and other advanced fields remain in `settings.yaml`; existing model fields the editor does not show are preserved.
- **Credential cleanup is intentionally narrow** — deleting a row removes the configured, writable credential only when its reference is the exact `<ROUTE>_API_KEY` target this page derives. Custom references, environment credentials, and unidentifiable targets are retained because the row cannot prove ownership of them.
- **Only pi-ai routes can be hand-declared** — the custom-provider card writes into `llm-pi-ai`, the one namespace whose profiles describe a whole provider. A `llm-deepseek` route is a composition fact, not something this page can create.
- **Interrogation covers OpenAI-compatible endpoints** — the adapter reads only that model-list response format, so a gateway speaking another protocol reports that it cannot be asked and its models are entered by hand.
- **Undeclared live routes render nowhere** — a route registered without a configurable-provider declaration has no settings address; it stays visible in pickers but not on this page's rows.

<a id="dev-note"></a>
```

## [packages/client/ui-settings-plugin-inventory/README.md:81](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-settings-plugin-inventory/README.md:81)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the freshness and reach of the inventory view; they are current package constraints.

- **One snapshot per Settings mount or retry** — the tab does not subscribe to Loader changes or automatically refetch after reconnect; switching tabs preserves the current snapshot, while reopening Settings obtains a new one.
- **Read-only Loader view** — local search does not add provenance, current-browser activation diagnosis, grouping by source, or plugin mutation controls.

<a id="dev-note"></a>
```

## [packages/client/ui-settings-plugins/README.md:92](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-settings-plugins/README.md:92)

```markdown
These boundaries define which plugins appear and how fresh the list is; they are current package contracts.

- **Only host-plane plugins appear** — a plugin an agent preset mounts carries its configuration inline in that preset's `agent.cordis.yml` and cannot register a settings namespace at all, so this section lists nothing for it. Editing those values remains the preset editor's job.
- **A card still needs a browser bundle** — the browser half must be a `dsh.client` package built in the client module system's lazy-CJS factory format, and the `clientBundle` preset that emits it lives in `../../../packages/client/tsdown.client.ts` rather than a published package, so a plugin outside this repository has to reproduce that build itself.
- **The served namespaces re-read on two signals only** — the wire announces settings-document commits and connection resets, not registrations, so a namespace whose owner registers after the tab's read joins the list on the next document commit or reconnect.
- **The shell card follows the composed executor** — the POSIX and PowerShell executor families share the `bash` namespace because a host composes exactly one of them, so the served schema differs by platform (PowerShell adds `pwshPath`) even though the card edits the same two fields on both.

<a id="dev-note"></a>
```

## [packages/client/ui-settings/README.md:90](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-settings/README.md:90)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the settings transport cannot reach; they are current package constraints.

- **Non-loopback pages get no durable settings** — this Client keeps Host persistence disabled there, so a scope starts `unavailable` and never crosses the wire; every row it backs is inert even though Connection authentication covers the API.

<a id="dev-note"></a>
```

## [packages/client/ui-sidebar/README.md:82](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-sidebar/README.md:82)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the shell owns versus what its occupants own; they are current package constraints.

- **Session state-dot rendering is owned by ui-workspace** — no done/error notification sources are available to this shell.
- **Workspace browser behavior is composition-owned** — grouping, ordering, search, and row state belong to ui-workspace, not this shell.
- **"New task completed" unread marking is local viewing state** — completion-time > last-seen never reaches the host.

<a id="dev-note"></a>
```

## [packages/client/ui-skill/README.md:89](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-skill/README.md:89)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the reference and the row fall back to generic behavior; they are current package constraints.

- **Result-only history pages use the generic row** — keyed dispatch needs the paired call in the runtime window; pagination that leaves the call outside has no tool identity. This client presentation feature does not extend the history wire contract to recover it.
- **Text is the truth** — the reference is plain draft text; a hand-typed identical token is the same reference, and the host gesture boundary judges the sent text, not the menu interaction. Chip visuals derive from the lexicon scan; no occurrence identity, position tracking, or structured reference payload exists on the prompt wire.
- **A menu opened before the prewarm settles** shows no skill candidates for that keystroke; the next keystroke re-polls the settled cache.

<a id="dev-note"></a>
```

## [packages/client/ui-slots/README.md:85](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-slots/README.md:85)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the registry's scaling behavior and accepted type noise; they are current package constraints.

- **`isLive` scans all records linearly** — fine at UI-plugin registration counts (tens); revisit with an entry→record backref if ledgers ever grow hot.
- **The `__renders` phantom anchor is visible on `PropsRenderSlots`** — the same accepted noise as the type-chain design's `__accepts`: generic method signatures compare loosely across key unions, so the contravariant marker is what enforces "component key set ⊆ children declaration".

<a id="dev-note"></a>
```

## [packages/client/ui-subagent/README.md:98](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-subagent/README.md:98)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the catalog can show and what `@` references mean; they are current package constraints.

- **The catalog has no durable outcome** — activity and timing do not distinguish completion, failure, or cancellation, and the UI exposes no Activation identity; stopping is limited to the composer's current-turn Stop for a running continuable child.
- **`@` references remain display-title text** — duplicate or renamed labels are ambiguous, so they intentionally do not acquire continuation semantics.

<a id="dev-note"></a>
```

## [packages/client/ui-theme/README.md:92](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-theme/README.md:92)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the theme extension surface and the color authority; they are current package constraints.

- **Third-party themes are an extension point, not a product** — registering one means overriding same-named alias variables; no validation exists that an override set is complete.
- **The token sheets are the sole color authority** — values absent from the design system are deliberately not appended; the nearest semantic token wins, and design-owner-approved additions enter as a static step plus a semantic alias in the same change.

<a id="dev-note"></a>
```

## [packages/client/ui-tool/README.md:92](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-tool/README.md:92)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the dispatch depth and the view ownership; they are current package constraints.

- **The Host excludes `run_code` from PTC mode program bindings** — production events produce one dispatch level; the recursive Runtime/UI contract supports nesting.
- **First-party Tool views are colocated here** — they can move to their owning business packages independently through the keyed slot.
- **Tool copy reuses the `ui-conversation` locale namespace** — tool titles, row chrome, and Cordis-free primitive labels use that dictionary; presenter models retain locale keys or data rather than rendered wording.

<a id="dev-note"></a>
```

## [packages/client/ui-trajectory/README.md:81](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-trajectory/README.md:81)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the view can show while work is in flight; they are current package constraints.

- **In-flight Time stays blank** — `partial` and `runningCalls` rows show their running state without a fabricated duration, so the Overview renders a start marker rather than inventing a live span. Record and timeline selection are local to Trajectory, with no anchor deep links.

<a id="dev-note"></a>
```

## [packages/client/ui-user-questions/README.md:85](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-user-questions/README.md:85)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define draft durability and composer ownership; they are current package constraints.

- **Unsubmitted drafts have page-and-Session lifetime** — Session navigation preserves them while that Session scope remains in the page, but a full page reload, Session pruning, or a newly delivered pending-request identity starts with an empty draft. The store never writes them to the Host, `localStorage`, or disk.
- **One request owns the composer at a time** — later pending requests remain in the session snapshot and become visible after the earlier request resolves.

<a id="dev-note"></a>
```

## [packages/client/ui-workflow-run/README.md:81](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-workflow-run/README.md:81)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define which runs produce records and what the node exposes; they are current package constraints.

- **Only top-level calls through `dsh-tool-workflow` produce these records** — nested PTC mode calls and direct `WorkflowEngine` consumers do not.
- **Navigation is intentionally live-only** — terminal members remain visible for review but never expose a cold-session opener from this node.
- **The node shows run, phase, member identity, and status only** — scripts, outputs, errors, logs, usage, static topology, and controls remain outside this surface.

<a id="dev-note"></a>
```

## [packages/client/ui-workspace-roots/README.md:87](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-workspace-roots/README.md:87)

```markdown
<a id="known-limitations-and-deferred-work"></a>

These limits define the current panel. They are current package constraints, not a general multi-root comparison or a task backlog.

- **The primary root is fixed** — the session's `cwd` is immutable by the session contract, so the panel can add and remove additional roots but never re-point the primary one. Working in a different primary root is a new session.
- **Paths are typed or chosen, never browsed in place** — the panel has no in-app directory tree. A deployment whose composed picker serves the browse capability rather than a native chooser answers Browse with a refusal, and the typed field remains the way to add a folder there.
- **Roots are recorded as supplied** — the host deduplicates by exact spelling and drops the primary root's spelling, and performs no filesystem access. Two spellings of one directory therefore both appear in the list; canonicalization belongs to the enforcement layer that resolves them.
- **The origin is per deployment, not per root** — the harness composes one filesystem provider, so the origin tag sits on the primary root and describes every path the session reaches. A composition with no filesystem provider shows no tag rather than claiming local disk.

<a id="dev-note"></a>
```

## [packages/client/ui-workspace/README.md:101](/Users/brandon/Downloads/deepseek-harness/packages/client/ui-workspace/README.md:101)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the search depth, the archive surface, and the picking carrier; they are current package constraints.

- **No fuzzy content search or event deep links** — the content backend uses literal token/phrase matching, and selecting a result opens the Session rather than the matching event.
- **No Session deletion or unarchive control** — sessions can be archived, but archived sessions have no viewing or unarchive surface, and Workspace registration deletion does not delete Sessions.
- **Pending user interaction is not aggregated into collapsed groups** — a waiting row inside a collapsed group lights no group-header indicator and becomes visible only after that group is expanded.
- **No row outside the range can start one** — a row no range reaches — the Ungrouped bucket header, a provisional blank draft, a folded group's **Show N more** row — moves the focus under Shift and carries nothing, because it is not in the account a range spans. Shift *across* such a row carries as it always did, and the additive modifier with A takes the whole account from any row that is in it.
- **Type-ahead reads only keys the browser names with one character** — an IME composes its text without emitting such a key, so composing a Chinese or Japanese session name does not search the list; the arrows and Home/End reach every row regardless.
- **Native folder selection depends on the local Host carrier** — under the `-native` composition, in-process or remote browser deployments cannot open a local operating-system dialog; remote-capable picking is the `-browse` composition's in-app flow.

<a id="dev-note"></a>
```

## [packages/client/web/README.md:105](/Users/brandon/Downloads/deepseek-harness/packages/client/web/README.md:105)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the boot kernel does not support. They are current package constraints, not a task backlog.

- **The application waits for the full roster** — one failed entry keeps the framework-free boot page visible with a per-entry report; partial UI availability is not supported.

<a id="dev-note"></a>
```

## [packages/code-runtime/code-runtime-python/README.md:103](/Users/brandon/Downloads/deepseek-harness/packages/code-runtime/code-runtime-python/README.md:103)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the package does and does not cover; they are current package constraints, not a task backlog.

- **The cross-language guard covers the executed surfaces and the frame field shapes, not the field types** — the mirror e2e compares required/optional field sets, not that `cpuSeconds` is an `int` on both sides; comparing type declarations across TypeScript and Python has no mechanical equivalent here, so a type-level drift is caught by review plus the backend's real-subprocess suite.
- **`src/index.ts` exports the protocol vocabulary only** — the package carries no subprocess execution path and no Python-side JSON codec, so nothing here spawns `python3` outside the mirror test.

<a id="dev-note"></a>
```

## [packages/code-runtime/code-runtime-worker-thread/README.md:135](/Users/brandon/Downloads/deepseek-harness/packages/code-runtime/code-runtime-worker-thread/README.md:135)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the backend is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **OS processes a program spawns survive termination** — `worker.terminate()` ends the thread only, weaker than bash-local's process-group kill; orphan cleanup is a deployment concern until a container backend exists.
- **Type-strip rides Node's experimental `stripTypeScriptTypes` API** — amaro or sucrase are the named drop-in replacements if the relied-on behavior shifts.
- **`computeMs` expiry can overshoot by up to one poll interval** — busy time is sampled every 25 ms (an internal constant, deliberately not config).
- **Programs get a five-method `console` shim** (`log`/`info`/`warn`/`error`/`debug`) — deliberately not Node's full console API.
- **Intermediate binding values have no byte cap** — a program can exhaust process or worker memory with a value that never becomes outer output.
- **The default 64 MiB cap is a rejection boundary, not recoverable storage** — outer spill can save only the bounded logs and diagnostic returned after `output-limit`; bytes rejected beyond the runtime cap never reach the spill layer.

<a id="dev-note"></a>
```

## [packages/code-runtime/code-runtime/README.md:116](/Users/brandon/Downloads/deepseek-harness/packages/code-runtime/code-runtime/README.md:116)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the seam cannot do; they are current package constraints, not a task backlog.

- **`run()` is one-shot** — `logs` arrive only on the resolved `CodeRunResult`; the seam exposes no streaming-log or progress API for a live program's output.
- **No state survives between runs** — every request runs against a fresh world; a persistent REPL-style kernel is deferred until a backend brings its own logging story.
- **Only the worker-thread backend ships** — `'process'` and `'container'` are declared well-known `isolation` values with no implementation; a hard security boundary awaits a container backend.
- **Intermediate binding values have no byte cap** — implementations remain subject to structured-clone cost and process memory, while a provider may already impose its own acquisition bound.

<a id="dev-note"></a>
```

## [packages/compaction/command-compact/README.md:134](/Users/brandon/Downloads/deepseek-harness/packages/compaction/command-compact/README.md:134)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the command is a poor fit; they are the current package constraints.

- **Idle-only** — `/compact` reports that condensation is unavailable when a turn or already accepted waking prompt has right of way; the command itself is not queued.
- **No range or policy arguments** — the argument-free form keeps behavior stable across command adapters. Explicit ranges remain the programmatic `compactRegion()` path.
- **Command adapters only** — surfaces without `ctx.commands` cannot invoke it and rely on automatic pressure compaction.

<a id="dev-note"></a>
```

## [packages/compaction/compaction-basic/README.md:241](/Users/brandon/Downloads/deepseek-harness/packages/compaction/compaction-basic/README.md:241)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when automatic condensation is a poor fit or needs special care; they are the current package constraints.

- **Meter accuracy follows the fixed heuristic** — missing reusable provider usage falls back to character count plus structural overhead rather than exact tokenization; image occurrences carry provider-exact visual tokens only on routes whose adapter declares request-image pricing.
- **Overflow classification is adapter-maintained** — provider wording can change; both DeepSeek adapters normalize recognized context-limit failures to `CONTEXT_WINDOW_EXCEEDED`.
- **Some indivisible-unit and envelope-only overflow remains outside surface compaction** — recovery cannot shrink system/tools/prefix, split an indivisible non-tool node, or repair a tool unit whose non-prunable remainder still exceeds the window. The optional pruner can shrink text-bearing tool-result bulk inside an otherwise indivisible pair.
- **`compactRegion` requires an open turn** — a manual call on a fully-closed session throws ("no open turn") rather than compacting.
- **Summarization failure preserves the latest durable surface** — before any replacement, the auto path logs a warning and proceeds with full over-budget history. A summary that does not shrink its shadowed span is retried as a consolidation pass within the configured retry budget before that warning. If pruning already landed, a later summarization failure proceeds from that durable pruned surface. Summarization truncation at `maxTokens`, which hidden reasoning tokens can consume, follows the same rule.

<a id="dev-note"></a>
```

## [packages/compaction/compaction-tool-result-pruner/README.md:127](/Users/brandon/Downloads/deepseek-harness/packages/compaction/compaction-tool-result-pruner/README.md:127)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when trimming is a poor fit or needs special care; they are the current package constraints.

- **Character budgets are not token budgets** — provider token density varies, so `ctx.tokenMeter` remains the authority for deciding whether trimming relieved request pressure.
- **Pruning is syntactic** — it retains the beginning and end without interpreting which middle lines are semantically important.
- **Grapheme clusters can split** — code-point slicing protects surrogate pairs but does not perform locale-aware grapheme segmentation.

<a id="dev-note"></a>
```

## [packages/compaction/compaction/README.md:151](/Users/brandon/Downloads/deepseek-harness/packages/compaction/compaction/README.md:151)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what condensation cannot do, regardless of which backend is loaded; they are the current package constraints.

- **Human command, not a model tool** — condensation is triggered by the `/compact` command and by automatic pressure; no model-facing compaction tool is registered.
- **Some single-unit overflow is out of contract** — balanced summary compaction cannot split one indivisible unit. The optional pruning companion can still repair a closed tool pair when text-bearing tool-result bulk is removable; a large non-tool node or a tool unit whose non-prunable remainder is oversized cannot be compacted.
- **An envelope that alone approaches the window is not surface-compaction work** — compaction shrinks derived history, never the system prompt, tools, or session prefix.

<a id="dev-note"></a>
```

## [packages/context/agent-instructions/README.md:209](/Users/brandon/Downloads/deepseek-harness/packages/context/agent-instructions/README.md:209)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when instruction loading is a poor fit or needs operational awareness. They are current package constraints, not a task backlog.

- **Discovery follows structured fs tools, not shell navigation** — a `bash` command that changes directories does not trigger nested instruction discovery because shell syntax and per-call shell state are not a reliable filesystem seam.
- **Refresh is touch-driven** — there is no watcher; external edits become visible on the next successful first-party `read`, `write`, or `edit`, when resume reconciles a visible baseline, or when an entering pre-step restores a shadowed baseline.
- **Candidate semantics stay intentionally small** — lowercase names, `.claude/rules/`, and `@path` imports are not interpreted; project scopes load `AGENTS.local.md`/`CLAUDE.local.md` overlays by default, but the user-global `$DSH_HOME` scope has no local overlay and other custom names require explicit candidate configuration.
- **Per-directory dedup is content-based** — sibling candidates collapse only when byte-identical after trimming leading and trailing whitespace; a `CLAUDE.md` that symlinks its sibling `AGENTS.md` resolves to the same content and collapses like any duplicate, while a distinct real copy that has drifted from `AGENTS.md` loads in full alongside it.
- **Symlinked instruction files are followed across the trust boundary** — a candidate whose final component is a symlink is resolved and its target loaded, so a cloned repository can surface off-tree file content as lower-authority workspace guidance (it never overrides system, developer, or direct user instructions). Confine `ctx.fs` with the filesystem policy gate or an OS sandbox when loading untrusted repositories.
- **Instruction content is bounded, not summarized** — over-budget broad files are omitted and the most-specific file may be truncated; the plugin never asks a model to compress instruction prose.

<a id="dev-note"></a>
```

## [packages/context/file-reference-local/README.md:121](/Users/brandon/Downloads/deepseek-harness/packages/context/file-reference-local/README.md:121)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit. They are current package constraints.

- **Host-local namespace** — the provider scans the Harness host filesystem, so remote or virtual `read` implementations require a provider whose namespace matches the tool.
- **Bounded advisory index** — very large workspaces may omit paths after `maxEntries`, and excluded or unreadable directories do not appear. The default exclusions name only build outputs no ecosystem also uses for sources; `lib` is deliberately absent, so a workspace that builds into it adds that name through `excludedDirectories`.
- **One invalidation of staleness** — a bare query answered right after a tool result reflects the tree as of the previous traversal; the following query sees the rebuild.
- **One entry budget for all roots** — `maxEntries` bounds the whole index, not each root, so many or large roots reach the cap sooner. The traversal is breadth-first across roots, so the budget is spent on every root's shallow paths before any root's deep ones.
- **A shared path belongs to one root** — a directory two roots both reach is indexed once, under whichever root's traversal reached it first, and rendered in that root's form. A root nested inside another therefore offers its files as absolute paths.
- **Any unreadable root fails the traversal** — one root that cannot be read leaves the index without that root's entries, so the whole rebuild is discarded and the previous entries keep answering until the root returns.
- **No ignore-file semantics** — `.gitignore` and other project ignore files do not influence discovery; only configured directory basenames are excluded.

<a id="dev-note"></a>
```

## [packages/context/file-reference/README.md:94](/Users/brandon/Downloads/deepseek-harness/packages/context/file-reference/README.md:94)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the seam is a poor fit. They are current package constraints.

- **Path candidates are advisory** — the seam does not prove that a later model-facing filesystem tool can access the same namespace; deployments must align the provider with the effective `read` implementation.
- **No file-content reference object** — selected files remain ordinary prompt text and require an explicit model tool call before their contents become model-visible.

<a id="dev-note"></a>
```

## [packages/context/session-reference/README.md:116](/Users/brandon/Downloads/deepseek-harness/packages/context/session-reference/README.md:116)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when cross-session references are a poor fit. They are current package constraints.

- **No body discovery** — candidate queries inspect titles but do not search message bodies.
- **Labels come from projections alone** — an attached session is labeled from its live projection cut, a cold one from its durable checkpoint, and a session neither answers for is labeled by its id and cannot be found by its title. Discovery never reads a log: folding one title costs a whole log, and this runs under every completion keystroke. A session persisted before the projection cache was composed regains its title the first time it is opened, which checkpoints it.
- **Trusted caller boundary** — the service assumes its host is authorized to read every session exposed by `ctx.sessionQuery`; it is not a model-facing search tool.
- **Text projection only** — non-text user and assistant blocks are not propagated across sessions.
- **No live link** — references are snapshots, not forks, resumes, subscriptions, or source-session mutations.

<a id="dev-note"></a>
```

## [packages/context/time-context/README.md:131](/Users/brandon/Downloads/deepseek-harness/packages/context/time-context/README.md:131)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when clock context is a poor fit. They are current package constraints.

- **Prompt provenance only** — browser-zone context guides natural-language interpretation but does not silently supply another tool's required zone field.
- **Mixed turns ask** — if one open turn contains prompts from different browser zones, the model is told to clarify rather than guess which one owns an unqualified time.
- **Fallback is not user authority** — the configured or process zone formats the clock when browser provenance is missing or mixed, but the model-facing policy still says to clarify.
- **Whole-second display** — timestamps and durations omit sub-second precision even though durable event times retain milliseconds.
- **History cost between compactions** — omission or `0` retains one reading for every eligible attempt; a positive interval reduces but does not eliminate this cost and may leave a later request without fresh browser-zone guidance.

<a id="dev-note"></a>
```

## [packages/context/tmux-context/README.md:120](/Users/brandon/Downloads/deepseek-harness/packages/context/tmux-context/README.md:120)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when tmux location context is a poor fit. They are current package constraints.

- **First step only** — a pane moved or resized mid-turn is reflected on the next turn, not between steps.
- **Own location only** — the plugin never captures the visible text of sibling panes.
- **Layout, not size** — pane/window pixel dimensions are omitted; only the layout tree and active flags are reported.
- **Tab-delimited fields** — a tmux window name containing the literal two-character sequence `\t` would mis-split the reading and be skipped as malformed; ordinary names are unaffected.
- **tty-based pane detection** — the process is considered "in tmux" only when its controlling terminal matches `$TMUX_PANE`'s `#{pane_tty}`. This deliberately excludes terminals that inherited `$TMUX`/`$TMUX_PANE` from a tmux ancestor (e.g. a VS Code integrated terminal). `ps -o tty=` is POSIX; the check is a no-op wherever it or `#{pane_tty}` is unavailable.

<a id="dev-note"></a>
```

## [packages/core/agent-default-model/README.md:109](/Users/brandon/Downloads/deepseek-harness/packages/core/agent-default-model/README.md:109)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the service's scope. They are current package constraints, not a task backlog.

- **One process-wide default** — the service owns a single default; per-session model selection remains the entry point's responsibility.
- **No retention without a settings provider** — `saveSelection()` cannot keep a selection for a later agent when no settings provider is mounted.

<a id="dev-note"></a>
```

## [packages/core/agent-loop/README.md:181](/Users/brandon/Downloads/deepseek-harness/packages/core/agent-loop/README.md:181)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the loop needs special care. They are current package constraints, not a task backlog.

- **Classification is unary** — calls whose safety depends on comparing siblings or resources must remain exclusive ([rationale](../../../.agents/notes/implemented/feature/2026-07-10-parallel-tool-call-execution.md)).
- **Config labels are fresh by default** — omitting `sessionId` creates a fresh `${id}-session-<uuid>` on every startup; exact resume-or-create behavior requires an explicit stable `sessionId`, while `resumeSessionId` requires existing persisted history.
- **Config agents have no per-agent persona field or setup hook** — they use the deployment persona; scoped persona and tool composition are available only through the programmatic `ctx.agents.create()` / `resume()` factory options.
- **No built-in turn budget** — tool calls or steering continue the current turn; a policy that bounds runaway turns must cancel from an existing lifecycle extension point such as `agent/turn-stopping`.

<a id="dev-note"></a>
```

## [packages/core/agent-tool-presentation/README.md:103](/Users/brandon/Downloads/deepseek-harness/packages/core/agent-tool-presentation/README.md:103)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this row needs special care. They are current package constraints, not a task backlog.

- **The runtime stays host-plane** — a preset can select PTC mode but cannot supply the TypeScript runtime it needs; a deployment that composes none can compose no ptc preset.

<a id="dev-note"></a>
```

## [packages/core/agent/README.md:162](/Users/brandon/Downloads/deepseek-harness/packages/core/agent/README.md:162)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this package needs special care. They are current package constraints, not a task backlog.

- **Initiator scope is process-local** — workers, child processes, HTTP, durable queues, and restarts must materialize any required identity explicitly.
- **Ambient identity may outlive liveness** — consumers still check `agent.status`, cancellation, and the owning capability contract before lifecycle-sensitive work.
- **`agent/session-start` cannot gate startup** — it remains a synchronous, veto-less notification; async composition that must finish before publication belongs in the factory's `setup(agentCtx)` transaction instead.
- **`cancel()` clears the inbox by default** — it aborts the in-flight turn plus queued and steering work; `cancel(cause, { keepInbox: true })` aborts only the turn and preserves pending items, and there is no step-only abort that keeps the turn running.
- **Each additional `UserMessage` carries exactly one `MessageSource`** — contributions from several plugins merged onto one message collapse under one source, so the message cannot name several producers.

<a id="dev-note"></a>
```

## [packages/core/scope/README.md:96](/Users/brandon/Downloads/deepseek-harness/packages/core/scope/README.md:96)

```markdown
<a id="known-limitations-and-deferred-work"></a>

These limits define when the primitive needs special care. They are current package constraints, not a task backlog.

- **Only scope-aware APIs isolate state** — registries must file by `scopeOf()` and events must dispatch through `scopeTarget()`; an arbitrary Cordis service remains context-global merely because it is called through a scoped context.
- **A context carries one nearest scope key** — the hierarchy lives in the key-level parent relation, not in context tags; nested scope contexts still shadow to a single tag, and multi-membership policy sets remain unsupported.
- **Service reachability comes from the scope minter** — handing out `Scope.ctx` also hands out the minting plugin's injected services, so a broader minter cannot later be narrowed by the holder.

<a id="dev-note"></a>
```

## [packages/core/session/README.md:171](/Users/brandon/Downloads/deepseek-harness/packages/core/session/README.md:171)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the session store needs special care. They are current package constraints, not a task backlog.

- **`fork()` cuts only at stable boundaries of live sessions** — the selected prefix must end outside an open turn and the source must be in the store; forking a persisted-but-unloaded session is excluded from the [fork API](../../../.agents/notes/implemented/feature/2026-06-30-session-store-fork-api.md).
- **`SESSION_FORMAT_VERSION` stays pinned at `0`** — pre-release, no broad compatibility implied: `Session` accepts only current seed shapes, a backend refuses any other version, and every unknown event type refuses reconstruction ([mechanism](../../../.agents/notes/implemented/simplification/2026-08-25-fail-closed-session-event-vocabulary.md)).
- **`TurnEndReasonMap` omits the ACP-named `refusal` / `max_turn_requests` variants** — producer-gated: they land when an adapter or the loop first emits them.
- **No session tree beyond fork** — a pi-style entry tree over branched sessions is deferred unless a consumer needs more than boundary-based forking.

<a id="dev-note"></a>
```

## [packages/core/system-prompt/README.md:164](/Users/brandon/Downloads/deepseek-harness/packages/core/system-prompt/README.md:164)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when prompt assembly needs special care. They are current package constraints, not a task backlog.

- **Deployment-authored prompt text is config/composition only** — this plugin owns the global persona default, creator plugins may register agent-scoped shadows, and other sections come from the plugin that owns the fact; there is no end-user prompt-editing API.
- **No escape syntax for literal `{{…}}` braces** — every complete group is interpolated against registered variables; an escape is deferred until a real prompt needs one.
- **`toolOrder` misconfiguration surfaces at prompt assembly (the first turn), not at boot** — only shape violations throw at config load.


<a id="dev-note"></a>
```

## [packages/core/tools/README.md:221](/Users/brandon/Downloads/deepseek-harness/packages/core/tools/README.md:221)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the registry needs special care. They are current package constraints, not a task backlog.

- **Concurrency policy is not an event gate** — `executionMode()` reads the resolved tool definition directly; plugins can only declare a classifier on definitions they own.
- **`tools/pre-execute` deliberately cannot rewrite `exec.arguments`** — logged and rendered args would desync from what ran; the rewrite design is [a proposed Agent Note](../../../.agents/notes/proposed/feature/2026-06-30-pre-tool-input-rewrite.md).
- **Caller-defined subagent and workflow structured outputs remain object-rooted** — this is a consumer-level guard; the shared schema vocabulary and tool outputs support every JSON root.
- **`timeoutMs` on a definition is declarative only** — the registry never enforces deadlines; enforcement requires the `@deepseek-ai/dsh-tool-call-timeout-policy` wrapper.
- **PTC mode's SDK language follows the one loaded runtime, and a presentation is per agent rather than per tool** — `mode: ptc`/`both` rejects prompt assembly unless `ctx.codeRuntime.language` has a registered SDK renderer; within one agent no tool can be native-only while another is ptc-only.
- **PTC mode intermediate values are execution-local and unbounded by bytes** — they cannot be reconstructed from session replay and may exhaust process or worker memory; only the outer `run_code` output has the worker's configurable hard cap.
- **`run_code` state is fresh per run** — a persistent REPL-style kernel is rejected for the MVP, because cross-call state would be invisible to the log.

<a id="dev-note"></a>
```

## [packages/credentials/authorization/README.md:142](/Users/brandon/Downloads/deepseek-harness/packages/credentials/authorization/README.md:142)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this package is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **No flow is resumable** — an attempt lives in the process that started it, so a browser reload during a login abandons it and the human starts over; durable attempts need a store this seam does not have.
- **Nothing revokes** — signing out is `ctx.credentials.deleteRecord(key)`, which forgets the local record without telling the issuer; a provider that needs a server-side revoke has no place to declare it.
- **A key with no flow is inert** — the seam reports what is registered, so a record left by an uninstalled plugin can be deleted but not re-authorized; recognizing that orphan is the caller's job, as it is for `listRecords()`.

<a id="dev-note"></a>
```

## [packages/credentials/credentials-local/README.md:192](/Users/brandon/Downloads/deepseek-harness/packages/credentials/credentials-local/README.md:192)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Same-reference concurrent writes are last-write-wins** — the writer lock and the read-modify-write keep concurrent writers from dropping each other's entries, but two writers editing one reference still resolve to the later write; there is no revision check.
- **A same-UID process can read the document** — the file-effect sandbox modes do not deny reads, and an OS-keychain provider is deferred.
- **Environment changes are invisible** — the snapshot is frozen at launch, so a variable exported after startup reaches neither resolution nor `describe`; changing an environment-sourced credential takes a restart.
- **Atomic, not crash-durable** — inherited from `dsh-atomic-write`; the store re-reads on boot.
- **Windows creation is not owner-only** — the `0600` file and `0700` directory modes the writer asks for do not exist on Windows, so a new document inherits the access-control list of the directory it lands in. The access-control audit refuses an exposed document at the next load or write rather than at creation, so keep the harness home under a directory only your account can reach.

<a id="dev-note"></a>
```

## [packages/credentials/credentials/README.md:169](/Users/brandon/Downloads/deepseek-harness/packages/credentials/credentials/README.md:169)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this package is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **References have no enumeration** — the seam answers questions about references it is given; configuration surfaces learn them from settings schemas, so a `list()` over that half has no current consumer. Records do enumerate, because they have no schema to be discovered from.
- **References are environment-variable-shaped** — one flat POSIX-identifier namespace, because a reference doubles as the environment name it resolves through. Records carry the richer `<owner>/<id>` addressing.
- **Process-environment changes are invisible** — no notification can fire for a variable changed in the launching shell; a UI only re-reads `describe()` on its own navigation.
- **A record's owner is its scope, and nothing verifies the scope is mounted** — the seam stores what it is given and reports what it stores; recognizing an orphan is the caller's join between `listRecords()` and whatever registry owns that scope, and the seam has no registry of its own to check against.

<a id="dev-note"></a>
```

## [packages/e2b/e2b/README.md:121](/Users/brandon/Downloads/deepseek-harness/packages/e2b/e2b/README.md:121)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the E2B family is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Not a whole-harness runtime** — Cordis services, agent/session state, session logs, LLM requests, skills, and SDK-side buffers stay in the host process.
- **Sandbox state is ephemeral** — disposal and timeout delete the sandbox; reconnect, pause/leave retention, templates, volumes, and snapshots are outside this POC.
- **No deployment platform is configured** — network policy, host-workspace synchronization, and sandbox discovery are outside this POC.
- **`cwd` is a resolution convention, not containment** — adapters and commands can address other sandbox paths; E2B network access retains the base image's policy.

<a id="dev-note"></a>
```

## [packages/e2b/fs-e2b/README.md:117](/Users/brandon/Downloads/deepseek-harness/packages/e2b/fs-e2b/README.md:117)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **No host synchronization** — an empty E2B cwd stays empty until a tool, command, or external process populates it; local files are neither uploaded nor reflected back.
- **Mutation coordination is host-process-local** — `createIfAbsent` preserves a remote creator racing publication, but another harness connection or command can still race replacement; version guards detect only metadata changes represented by E2B.
- **Reads reopen canonical targets by path** — a concurrent remote path replacement between resolution and stream opening is not fenced by a stable file handle; no observed product defect justifies a provider-specific bounded-read protocol in this POC.
- **Whole-file mutation costs remain** — overwrite diffs and literal edits read complete files into host memory, and every operation incurs E2B controller latency.
- **The POC targets E2B's default Linux image** — it relies on GNU `realpath`/`base64`/`chmod`, same-filesystem rename, streaming reads, and metadata extended attributes; custom templates are outside this POC.

<a id="dev-note"></a>
```

## [packages/e2b/subprocess-e2b/README.md:137](/Users/brandon/Downloads/deepseek-harness/packages/e2b/subprocess-e2b/README.md:137)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **The SDK still retains complete command output in host memory** — E2B `CommandHandle.stdout` and `.stderr` accumulate the base64 transport even when this adapter exposes bounded raw-byte tails, so the subprocess seam's normal host-memory bound is not achieved and transport retention is larger than the source stream.
- **Synchronous-PID consumers are unsupported** — `pid` remains `-1` during remote startup; consumers that require a positive PID immediately, including the ACP child backend, cannot use this provider unchanged.
- **Private state lives for the sandbox lifetime** — process directories and valid spill files remain under `.dsh-e2b` until the owner deletes the sandbox; this POC supplies no in-sandbox sweep.
- **Control state shares the sandbox user's UID** — E2B runs every command as the same default user, so `0700`/`0600` modes cannot isolate `.dsh-e2b` control files from concurrently running sandbox processes; real isolation needs an E2B per-command user or an out-of-band control channel.
- **Numeric process identities are not reuse-fenced** — E2B exposes numeric PID/PGID input, signalling, and cleanup operations but no atomic identity-bound alternative; replacement is deferred until E2B adds an identity primitive or a failure demonstrates a narrower protocol.
- **The initial environment probe inherits sandbox defaults** — E2B merges command overrides with default environment entries, so the probe cannot blank unknown credential-shaped names before enumerating them; this POC therefore does not support secrets in sandbox-default environment variables.
- **E2B exposes no signal fact** — an adapter-requested `SIGTERM` or `SIGKILL` is reported only when no wrapper-published direct exit code wins; every unrequested SDK exit remains an exit code, including values equal to `128 + signal`.
- **Exact terminal stdin-wait inspection is unavailable** — E2B exposes the foreground process group but not the syscall evidence needed to prove it is waiting on fd 0, so the generic PTY backend falls back to controlled prompt markers and bounded silence.
- **Linux utility and E2B transport semantics are assumed** — there is no Windows, escaped-session recovery, or network-partition fidelity layer.

<a id="dev-note"></a>
```

## [packages/examples/agent-spine-demo/README.md:170](/Users/brandon/Downloads/deepseek-harness/packages/examples/agent-spine-demo/README.md:170)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the bundle is a poor fit or needs special operational care. They are current package constraints, not a comparison with other composition approaches or a task backlog.

- **Most of the spine set is fixed in code** — `apply()` always mounts the core services; config can omit bundled goals, skills, bash, and task-control tools, but swapping the loop or dropping another spine member means composing a different bundle.
- **The invariant service and companions remain fixed members** — `invariants.enabled: false` or package filters suppress checks but do not remove the service or companion registrations; Session's always-on validation and freezing are separate.
- **Retry can duplicate provider billing** — each provider attempt may incur billing, and `always` mode has no attempt limit; usage accounting stays with the entry point.

<a id="dev-note"></a>
```

## [packages/experimental/inspector/README.md:134](/Users/brandon/Downloads/deepseek-harness/packages/experimental/inspector/README.md:134)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Client active debugging is unsupported** — Console events, Runtime evaluation, RemoteObject access, and read-only `lib/client.js` Sources work. Client-script debugger requests return explicit unsupported errors; target-wide pause and resume control the Host only.
- **Client Sources expose the Inspector bundle only** — other page scripts are not cataloged by this package.
- **Client evaluation uses page JavaScript** — page Content Security Policy can block dynamic evaluation, and the synthetic context does not provide DevTools command-line helpers or native REPL declaration semantics.
- **Client identity arbitration requires Web Locks** — browsers without that API retain reconnect and refresh identity through `sessionStorage`, but cannot distinguish two simultaneously live tabs copied from the same storage state.
- **Fetch interception covers `globalThis.fetch`** — direct Undici APIs and fetch references retained before activation are not observed.
- **Body cloning has cost** — full capture tees request and response streams up to the configured limits and can increase memory and I/O pressure. The retained-body limit does not include buffering inside the stream tee, including an oversized source chunk or data queued for a slower application reader.
- **No automatic Worker restart** — an unexpected Worker exit fails the current Inspector instance; lifecycle recovery belongs to a later change.

<a id="dev-note"></a>
```

## [packages/experimental/webworker-packer/README.md:47](/Users/brandon/Downloads/deepseek-harness/packages/experimental/webworker-packer/README.md:47)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **The rule tables are judgement calls** (`rules.ts`: exclude globs, page-asset patterns, entry seeds) pinned by `tests/`; a new asset class the worker must reach needs a table row, not a scanner change.
- **Reachability infers only exact request forms** — computed `import` and `require` arguments, stored `createRequire` results, CommonJS-obtained `createRequire`, and bases other than `import.meta.url` resolve only at runtime and fail loud if the target was otherwise pruned; a target reachable only through those forms needs an explicit image entry seed.
- **Vendored package sources (`src/*.ts`) are excluded** — nothing resolves them at runtime; a future in-worker source-inspection feature would need a dedicated include rule.
- **The packer assumes built `lib/` artifacts are current**: it never compiles, so a stale workspace build packs stale bytes. Run the repository build first.


<a id="dev-note"></a>
```

## [packages/experimental/webworker-runtime/README.md:46](/Users/brandon/Downloads/deepseek-harness/packages/experimental/webworker-runtime/README.md:46)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **The worker composition writes plaintext session logs** (`compression: 'none'` boot patch): it carries no Zstandard codec, so exported logs are `.jsonl`, never `.jsonl.zstd`.
- **`node:dns/promises`, `node:vm`, `node:net`, `node:sqlite`, `node:worker_threads` are structural stubs**: every call reports its refusal on the console and throws. Rows needing native DNS, a real process, or realm isolation cannot run here.
- **Filesystem watchers observe only the mounted VFS**: image seeding is silent and the VFS has no symlinks or external writers. `persistent`, `ref()`, and `unref()` preserve the Node API but cannot control a dedicated Worker's lifetime because browsers expose no ref-counted event loop.
- **Worker confinement is a VFS boundary, not kernel Landlock**: `read-only` and `workspace-write` run the unchanged `@deepseek-ai/node-addon-landlock-run` JavaScript and launcher argv, but the process layer implements the logical `landlock-run` executable and enforces its grants on every shell filesystem request. `full` therefore covers the Worker command table and mounted VFS only; it does not claim arbitrary native-process execution or Linux kernel isolation.
- **The worker bundle pins a path inside `@yarnpkg/parsers`** — the build resolves the package's own `lib/shell.js` instead of its root, whose barrel also re-exports the Syml parser and so drags js-yaml into a bundle that never parses that format (around 175 kB, plus its module body at worker start). The path is derived from the package manifest, so a layout change fails the build rather than reinstating the barrel; upgrading the dependency means re-checking that the shell parser still lives there.
- **The shell is not bash**: no loops, functions, `case`, job control, or process substitution — the grammar stops at pipelines, `&&`/`||`, subshells, groups, redirections, and expansion. `&` runs its command to completion in place, `sed` accepts only substitution scripts, patterns are JavaScript regular expressions, and the command table holds coreutils only (no `git`, no network tools).
- **A shell process has no synchronous filesystem**: it reads and writes the host's VFS by message, because blocking on a reply would need `SharedArrayBuffer`, which requires a cross-origin isolation GitHub Pages cannot grant. Directory-walking commands therefore cost one round trip per entry, and two concurrent commands can interleave their writes.
- **Transport, worker-host, and page-half coverage needs a browser-grade harness** — the per-file coverage gate is unmet for those modules; unit specs cover storage, ALS, the transform, and the stub contracts.


<a id="dev-note"></a>
```

## [packages/extensions/cordis-client-runner/README.md:122](/Users/brandon/Downloads/deepseek-harness/packages/extensions/cordis-client-runner/README.md:122)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the browser half needs special care. They are current package constraints, not a task backlog.

- **A refused resolution is not retried** — the acknowledgement of `resolveRequestRun` is not read, so when the host declines a stale success (`accepted: false`, because the definition's revision moved on while this page was loading) the page keeps what it loaded and does not orchestrate again. The request stays answerable — another page's answer or the caller's cancellation settles it — and the stop that bumped the revision retracts the stale load.
- **The plugin stays parked until the host namespace exists** — it declares `remote.dynamicCordisRunner`, so it loads no browser half whose host half it could never reach.
- **Slot admission has no carrier** — the dispatched row declares services, not target slots, so per-deployment allow or deny lists for slot admission have nowhere to ride.
- **Guard whitelists are hand-mirrored twins** — the browser guard replicates the host-side sandbox facade; sharing one specification is deferred.

<a id="dev-note"></a>
```

## [packages/extensions/cordis-host-runner/README.md:124](/Users/brandon/Downloads/deepseek-harness/packages/extensions/cordis-host-runner/README.md:124)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the runner needs special care. They are current package constraints, not a task backlog.

- **A successful run does not mean the UI rendered** — `run` returns once the answering page has loaded the browser half; React renders afterwards, so a component that throws cannot appear in the run receipt. The failure surfaces through steering and `cordis_inspect_self` diagnostics.
- **A browser-half package suspends where no page is connected** — headless and ACP deployments hold the run until the asking turn is cancelled; host-only packages are unaffected.
- **A suspended run request has no timeout** — it waits for a person until the asking turn is cancelled, so unattended automation cannot use packages with a browser half.
- **`vmTimeoutMs` bounds only synchronous evaluation** — an async host-half body escapes it, matching the toolset's cooperative trust stance.
- **A stale-success refusal leaves the request suspended** — when the answering page names a revision the registry has moved past, the resolution is refused (`accepted: false`) and the request stays answerable until another page answers or the caller cancels; the browser half does not read the acknowledgement.
- **The run announcement carries no service declarations** — a browser half's declared `inject` is read from the plugin it returns in the page, so `cordis/request-run` carries metadata only, never code or service lists.
- **`zod` is a runtime dependency of the generated Typert faces, not of `src`** — `./typert` and `./remote` resolve to unbundled `lib` files with a bare `import { z } from 'zod'`, so the package declares it and `knip.json` ignores it for this workspace; nothing in `src` imports zod.

<a id="dev-note"></a>
```

## [packages/extensions/tool-cordis/README.md:175](/Users/brandon/Downloads/deepseek-harness/packages/extensions/tool-cordis/README.md:175)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the toolset is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **The sandbox is containment for honest code, not a security boundary** — host-realm helpers on the sandbox global are reachable, so package code can reach Node; load this plugin as deliberately as you would grant a bash tool.
- **Plain JavaScript only** — dynamic package code is not transformed: no TypeScript, JSX, or imports, and the sandbox withholds Node globals such as `require`, `setTimeout`, and `fetch`, redirecting filesystem, network, and process work to Cordis services.
- **The vm and approval bounds belong to the runner** — see its [Known Limitations](../cordis-host-runner/README.md#known-limitations-and-deferred-work); an async host-half body escapes `vmTimeoutMs`.

<a id="dev-note"></a>
```

## [packages/extensions/ui-cordis/README.md:105](/Users/brandon/Downloads/deepseek-harness/packages/extensions/ui-cordis/README.md:105)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the surfaces need special care. They are current package constraints, not a task backlog.

- **An open panel does not see registry changes that announce nothing** — `cordis_define`, and an undefine of a definition that was not running, change the registry without a dispatch announcement, so a panel left open across one of them keeps its rows until it is closed and opened again. A run request is the exception: it blocks the model, so it both renders its own row and triggers a read.
- **A request-only row is answerable but not operable** — it offers approve and decline only, because the run and stop controls need the registry row the read has yet to deliver.
- **A row can disappear for the width of one read** — the activity's orchestrating arm carries the session but deliberately no label, so an approved request whose registry read has not landed leaves no row until it does; in practice the read is triggered when the request arrives.
- **A render failure is this page's own reading, and it arrives too late for the run receipt** — the panel shows the last crash the runner saw here, so a package that renders fine in this tab shows nothing even while it crashes in another, and the model learns about it by asking (`cordis_inspect_self`) rather than from the call it already made.
- **A second page's load failure is invisible to the others** — the host settles a dispatch on the first load report, so a page whose browser half failed after another page acknowledged keeps reading as running on the other pages.
- **Any page may answer any request** — approvals are frame-wide by design, so a person in one tab can approve a run the model asked for while another tab is in front of the defining session; narrowing who may answer is deferred.
- **A card whose call head left the event window loses its labels** — the define card derives name and purpose from the call arguments, so a session long enough to truncate them leaves the card naming its call id; the panel is unaffected because the host inventory carries the labels.

<a id="dev-note"></a>
```

## [packages/feedback/command-feedback/README.md:125](/Users/brandon/Downloads/deepseek-harness/packages/feedback/command-feedback/README.md:125)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where `/feedback` is a poor fit or behaves differently than a user might expect. They are current package constraints, not a task backlog.

- **No feedback retrieval or management surface** — the optional OTel plugin uses the event only as a sharing trigger. There is no retrieval, aggregation, categorization, or model-facing tool for `feedback/record`.
- **No structured fields** — an entry is one free-text string with no category, severity, or referenced-event link, so feedback cannot be filtered by subject without re-reading its text.
- **No amend or withdraw** — the session log is append-only and this package adds no tombstone, so a mistaken entry stays recorded and can only be superseded by a later one.
- **No explicit durability barrier** — the acknowledgement follows the append, not a flush, so an entry recorded immediately before a crash can be lost with any other unflushed tail. A consumer that needs a barrier awaits `ctx.sessions.flush(session)`.
- **No visible acknowledgement on a fresh session** — the web transcript renders command rows only once a session is active, so `/feedback` on a still-blank session records the event but shows no acknowledgement row. Recording feedback after the first message renders normally.
- **Web only among the shipped entry points** — headless mode, ACP automation, and JSON-RPC provide no command adapter, so `/feedback` is unavailable there.

<a id="dev-note"></a>
```

## [packages/feedback/message-feedback/README.md:136](/Users/brandon/Downloads/deepseek-harness/packages/feedback/message-feedback/README.md:136)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the service is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Compare-and-set is single-process** — the per-Session queue serializes one service instance only; storage-domain has no cross-process conditional write, so multiple Host processes writing one storage root can still lose updates.
- **No durable Session deletion cascade** — Session persistence has no deletion API, and `session/disposed`/`api-session/removed` mean detach rather than durable deletion. The service therefore retains empty rows and may leave orphan rows after out-of-band log removal instead of deleting valid feedback on detach.
- **Detach/catalog retirement window** — a request in the narrow interval after live detach but before the persistence catalog materializes the header can receive `session-not-found`; callers retry after retirement materialization.
- **Header identity is not a content fingerprint** — `{createdAt, cwd}` detects reuse only when those fields differ; a cloned log retaining the same header identity is indistinguishable.
- **Trusted caller boundary** — `list`/`put`/`delete` carry no authenticated actor or audit identity. A deployment must expose the Host gateway only through its trusted or separately authenticated boundary until authorization and attribution are added.
- **Catalog and row bounds** — a cold request scans the complete Session snapshot catalog because persistence has no lookup-by-id metadata operation. `maxNoteBytes` bounds one note, but the item count and aggregate retained bytes of one Session row are not capped; an indexed metadata read and deployment-owned row bound remain deferred until a concrete consumer defines their policy.

<a id="dev-note"></a>
```

## [packages/fs/fs-local/README.md:122](/Users/brandon/Downloads/deepseek-harness/packages/fs/fs-local/README.md:122)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the local backend is a poor fit or needs special operational care. They are current package constraints, not a general filesystem comparison or a task backlog.

- **`config.cwd` is not a sandbox** — it is a resolution default, not containment: absolute paths and `..` escape it. Enforce containment with a stricter `ctx.fs` backend or a permission plugin on the `tools/execute` waterfall ([capability-seam note](../../../.agents/notes/implemented/architecture/2026-06-17-filesystem-capability-seam.md)).
- **Version tokens depend on filesystem metadata** — they combine device, inode, size, nanosecond mtime, and nanosecond ctime; a storage layer that cannot update any of those facts for a rewrite can still defeat the stale guard.
- **`editText` holds the whole file (plus the edited copy) in memory** — streaming exists only on the read path.
- **A sub-limit overwrite still buffers a contextual basis** — `writeText` may retain up to just below `config.diffBasisMaxBytes` of prior text in addition to the caller-owned replacement; the bound does not cap the returned `after` value or the whole-file presentation fallback.
- **Binary detection is asymmetric** — reads NUL-sample only the first 8192 bytes while edits scan the whole buffer, so a file with a late NUL reads fine but rejects edits.
- **The per-target mutation lock is in-process only** — guarded creation still uses an atomic no-replace publication across processes, but replacement writers in another process are caught only when the optional version guard observes their metadata change; they are never serialized.
- **Guarded creation requires hard-link support** — filesystems or mounts that reject hard-link publication cannot serve `createIfAbsent`; the backend preserves the missing target and reports `FS_IO_ERROR`.
- **Post-commit cleanup is best effort** — a successful publication remains successful if removal of its owner-only staging directory fails, leaving private residue for later operator cleanup.

<a id="dev-note"></a>
```

## [packages/fs/fs-network-drive/README.md:53](/Users/brandon/Downloads/deepseek-harness/packages/fs/fs-network-drive/README.md:53)

```markdown
- **Path checks are not atomic with local I/O.** Native path resolution detects existing symlink escapes, but another process can rename directories between a check and a subsequent filesystem operation. Hostile concurrent writers require operating-system confinement; this provider does not implement descriptor-relative atomic traversal.

- **One writer per drive subtree.** A second harness pointed at the same remote root can publish between this one's version check and its write. Every drive serves a version — the WebDAV provider falls back to modification time and size when a collection omits ETags — so the compare-and-set check always runs; what a missing ETag costs is the *atomic* remote guard (`If-Match`), leaving a window between the check and the `PUT` rather than removing the check.
- **A shell `rm` or `mv` in the workspace does not reach the drive.** The `ctx.fs` seam has no unlink or rename, so deletions and renames happen through the shell against the materialization root. The drive still holds the file, and the next hydration brings it back. Closing this needs the drive seam's `remove` and `move`, which exist for it and have no consumer yet.
- **The materialization root is not garbage collected.** A hydrated file stays until the root is removed, so a long session over a large drive grows toward the size of what it touched. Eviction needs a policy — age, size, or pinning — that no consumer has yet stated.
- **A drive-side edit is invisible until something restats.** There is no watch in the Definition, so a file changed on the drive after hydration is served from the local copy until an operation revalidates it.
- **A working file the drive does not hold costs its own size to identify, and is unreadable above `maxFileBytes`.** Nothing has published it, so its version is the digest of its content: `stat`, `read`, and `write` stream the whole file to derive one, and a file over the ceiling is refused rather than served. A drive file is identified by the revision the drive already reported, which costs no read at all.

<a id="dev-note"></a>
```

## [packages/fs/fs-observation-policy/README.md:119](/Users/brandon/Downloads/deepseek-harness/packages/fs/fs-observation-policy/README.md:119)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the policy is a poor fit or needs special operational care. They are current package constraints, not a general filesystem comparison or a task backlog.

- **Observed state does not survive a session resume** — persistence of the record is deferred, so a resumed session must re-read files before guarded writes and edits.
- **Actors without an agent session can never satisfy the policy** — their edits throw `FS_NOT_OBSERVED` and their writes always resolve `createIfAbsent`, so a non-agent caller cannot overwrite an existing file through the gate.
- **Direct `ctx.fs` reads emit no `fs/observed`** — a file read outside the `read` tool stays unobserved, and a later guarded edit rejects with `FS_NOT_OBSERVED` until the tool reads it.
- **Authorization is version freshness, not view completeness** — any windowed read authorizes a full-file overwrite of an unchanged file, deliberately weaker than a full-view rule ([seam-split note](../../../.agents/notes/implemented/simplification/2026-06-26-fsspec-style-fs-seam.md)).

<a id="dev-note"></a>
```

## [packages/fs/fs-sandbox/README.md:116](/Users/brandon/Downloads/deepseek-harness/packages/fs/fs-sandbox/README.md:116)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the sandbox backend is a poor fit or needs special operational care. They are current package constraints, not a general sandbox comparison or a task backlog.

- **A policy fence, not a kernel boundary** — the check is trusted code over a model-controlled path, so the residual resolve-to-syscall TOCTOU is narrowed (by the in-place re-canonicalization) but not eliminated; adversarial host processes are out of scope. Kernel-grade isolation of untrusted code stays `ctx.shell`'s.
- **Fence-vs-runner parity is derived from one owner** — the writable set comes from `writableRoots`, shared with the Seatbelt profile; a runner profile that defines its writable set elsewhere would drift.
- **Requires `ctx.sandboxPolicy`** — tools use it to resolve each session policy and the backend uses it for agentless-call fallbacks; the backend does not confine without it composed.

<a id="dev-note"></a>
```

## [packages/fs/fs/README.md:105](/Users/brandon/Downloads/deepseek-harness/packages/fs/fs/README.md:105)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the contract is a poor fit or needs special operational care. They are current package constraints, not a general filesystem comparison or a task backlog.

- **Text-only mutations by contract** — text reads and both mutations reject binary or non-UTF-8 content with `FS_NOT_TEXT`; `readBytes` is the single raw-byte primitive, and binary-safe mutations remain deferred ([tool-schemas Agent Note](../../../.agents/notes/implemented/feature/2026-06-17-filesystem-tool-schemas.md)).
- **Thirteen primitives only** — no delete, rename, copy, or watch; `listDir` lists a single level, with recursion, globbing, pagination, and search out of scope ([directory-listing note](../../../.agents/notes/archived/architecture/2026-07-03-filesystem-directory-listing-seam.md)).
- **No I/O deadline** — the seam arms no timeout; cancellation is a best-effort optional `AbortSignal` per primitive ([fs family stance](../README.md)).
- **Resolve-then-operate costs a remote backend two round-trips per tool call** — folding or caching resolution is left to such a backend.

<a id="dev-note"></a>
```

## [packages/fs/network-drive-webdav/README.md:61](/Users/brandon/Downloads/deepseek-harness/packages/fs/network-drive-webdav/README.md:61)

```markdown
- **No locking.** WebDAV's `LOCK`/`UNLOCK` are not used, so two harnesses pointed at one collection can interleave writes to a file. The guarded-write intent narrows the window to the gap between a version check and its `PUT`, and closing it fully requires the lock verbs and the lock-token lifetime that goes with them.
- **Versions are whatever the server returns.** A collection that serves no ETag makes every guarded write unguarded, because the provider has nothing to compare. That is a property of the server, and the provider reports it rather than substituting a digest it would have to read the whole file to compute.
- **No range write.** The Definition has none, and WebDAV's `PATCH` byte-range extension is not widely served, so a one-byte edit re-uploads the file.

<a id="dev-note"></a>
```

## [packages/fs/network-drive/README.md:59](/Users/brandon/Downloads/deepseek-harness/packages/fs/network-drive/README.md:59)

```markdown
- **No watch, and no change notification.** A consumer that must notice a drive-side edit polls `stat`. The seam carries no subscription because the shipped consumer materializes on demand and revalidates by version, and a subscription that no provider could implement uniformly would be a promise the seam cannot keep.
- **No partial write.** `write` replaces a whole file; there is no append or byte-range write, so a consumer editing a large file transfers it whole in both directions. `read` takes a range, so the asymmetry is deliberate: ranged reads are universally available over HTTP, ranged writes are not.
- **No atomic multi-path operation.** `move` is the only two-path operation and providers implement it as the transport allows; there is no transaction spanning several paths, so a consumer needing one builds it from guarded writes and its own recovery.

<a id="dev-note"></a>
```

## [packages/fs/tool-fs-search/README.md:207](/Users/brandon/Downloads/deepseek-harness/packages/fs/tool-fs-search/README.md:207)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the search tools are a poor fit or need special operational care. They are current package constraints, not a general search comparison or a task backlog.

- **Search and file access have no shared-workspace proof** — returned paths are follow-up-readable only when the workdir and filesystem root denote the same workspace; the package performs no runtime cross-service validation.
- **The packaged binary is fixed at dependency version** — Node deployments use the version selected by `@vscode/ripgrep`; Python single-file runtimes copy that target-native version into the required `-rg` sidecar. An unsupported platform or a corrupted installation fails with `SEARCH_FAILED`, while the Python runtime package rejects a missing sidecar before launch. Remote or virtual filesystems need a co-located workspace or another search consumer.
- **The schemas expose one bounded page** — offset pagination, case-mode switches, alternate output modes, and provider-backed discovery remain outside this package; capped complete output requires a spill backend.
- **Sampling, when enabled, groups by first path segment beneath the search root only** — an over-cap `glob` page balances across those top-level entries, so a result concentrated deeper is still shown unevenly below that level; recursive balancing is deferred.

<a id="dev-note"></a>
```

## [packages/fs/tool-fs/README.md:232](/Users/brandon/Downloads/deepseek-harness/packages/fs/tool-fs/README.md:232)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the tool suite is a poor fit or needs special operational care. They are current package constraints, not a general filesystem comparison or a task backlog.

- **No model-facing directory listing ships** — `ctx.fs.listDir` serves provider code such as skill discovery, while the sibling `dsh-tool-fs-search` package supplies ripgrep-backed `glob` and `grep` rather than extending the filesystem seam.
- **`read` handles UTF-8 text files only** — images use the separate extension-routed `read_image` tool; PDF, audio, and video remain deferred. A directory target is `FS_NOT_REGULAR_FILE`.
- **Extension-declared media type** — the extension selects the declared type and the attachment store's magic-byte validation stays authoritative; a correctly formatted image under a wrong extension is refused with the rename remedy rather than sniffed.
- **No inline image preview on the tool-result card** — UI surfaces render the image result generically (the durable reference, not pixels); inline rendering is deferred to the UI packages.
- **No attachment-region tool** — an agent may crop an image through another available tool when it has a filesystem path; a pasted or dragged image without a path cannot be re-read at higher resolution.
- **No timeout surface** — `read`/`write`/`edit` take no timeout argument and declare no timeout budget; cancellation rides `exec.signal` only ([provider rationale](../README.md)).

<a id="dev-note"></a>
```

## [packages/fs/tool-str-replace-editor/README.md:128](/Users/brandon/Downloads/deepseek-harness/packages/fs/tool-str-replace-editor/README.md:128)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the editor tool is a poor fit or needs special operational care. They are current package constraints, not a general editor comparison or a task backlog.

- **Operations target UTF-8 text** — binary files are unsupported.
- **`str_replace` intentionally rejects zero or multiple matches** — it has no `replace_all` argument.
- **Every mutation goes through the mounted policy and sandbox** — `fs/write-intent` or `fs/edit-intent` resolves the current session sandbox policy and delegates enforcement to the mounted filesystem and policy plugins, so a deployment without them gets unconditional mutations.

<a id="dev-note"></a>
```

## [packages/goal/command-goal/README.md:121](/Users/brandon/Downloads/deepseek-harness/packages/goal/command-goal/README.md:121)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the command is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **Plain-text interaction only** — the generic command registry has no modal edit form or replacement-confirmation callback; inline edit and explicit clear keep destructive intent deterministic across adapters.
- **No per-command round-cap argument** — `defaultMaxGoalRounds` remains deployment config, while a direct human request may ask the model to edit `max_goal_rounds` through the separately authorized goal tool.
- **No continuous status widget** — bare `/goal` is the portable observation API; no adapter-specific badges or reconnectable command output are provided.
- **Web command adapter only in the shipped apps** — headless, ACP automation, and JSON-RPC adapters do not consume `ctx.commands`. Ordinary prompts can still authorize model-facing goal tools when those are composed.

<a id="dev-note"></a>
```

## [packages/goal/goal-round-driver/README.md:120](/Users/brandon/Downloads/deepseek-harness/packages/goal/goal-round-driver/README.md:120)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the driver is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **No independent evaluator** — the model-facing goal policy decides when evidence is sufficient for completion and whether a blocker is semantically unchanged; evaluator-backed certification remains deferred.
- **Same-session execution only** — this package deliberately does not spawn a fresh agent, fork a session prefix, or implement Ralph-style independent attempts; that workflow belongs to its own plugin layer.
- **Accepted-queue unload race** — Cordis plugin unload is asynchronous. A goal prompt already accepted by the agent inbox can begin and consume its round before unload starts; teardown then cancels the request, disarms the goal, and awaits quiescence. No later round starts.
- **Round cap, not resource budget** — token, currency, time, and provider quota policies remain independent. Their session events are not attributed to the goal message or mapped into goal blocker codes.
- **No abnormal auto-retry** — transient provider and persistence failures require a later human-authorized resume rather than an implicit retry policy.

<a id="dev-note"></a>
```

## [packages/goal/goal/README.md:147](/Users/brandon/Downloads/deepseek-harness/packages/goal/goal/README.md:147)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the goal service is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **State, not scheduling** — this package does not decide when an armed goal continues, retry abnormal failures, or cancel an active turn; those policies belong to consumer packages such as `dsh-goal-round-driver`.
- **Round-count budget only** — `maxGoalRounds` does not meter tokens, currency, wall time, or provider quotas.
- **No independent evaluator** — the caller that records completion or blocking is authoritative; evaluator-backed certification is deferred to a separate policy layer.
- **One current goal** — parallel objectives and a separate goal database are intentionally absent; history remains available in the session log after replacement or clear.
- **Trusted in-process producers** — a plugin with direct `Session` access can append counterfeit `goal/change` data. Strict replay detects malformed or inconsistent records and leaves goal access failed at that record until the log is repaired; this is integrity detection, not plugin isolation.

<a id="dev-note"></a>
```

## [packages/goal/tool-goal/README.md:142](/Users/brandon/Downloads/deepseek-harness/packages/goal/tool-goal/README.md:142)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the goal tools are a poor fit or need special care. They are current package constraints, not a task backlog.

- **Semantic intent remains model judgment** — execution can prove that the current turn contains a direct human message, not whether the request is substantial enough to merit a goal.
- **Same-condition blocking remains model judgment** — the runtime enforces distinct admitted-round count, not semantic equivalence of obstacles; an independent evaluator is deferred.
- **No scheduling or direct human rendering** — these tools mutate state only; the same-session driver and `dsh-command-goal` are independent consumers of the same domain.
- **Goal-round authority requires a driver** — the autonomous `complete`/`blocked` path is dormant unless a continuation driver admits goal-sourced user turns; mounting this tool package alone does not create them.
- **Prompt registration is independent of filtering** — a scope may hide the tools while retaining their guidance unless the deployment scopes both registrations together.

<a id="dev-note"></a>
```

## [packages/guard/approval-adversary/README.md:116](/Users/brandon/Downloads/deepseek-harness/packages/guard/approval-adversary/README.md:116)

```markdown
<a id="known-limitations-and-deferred-work"></a>

Automatic review has these operating limits.

- **Model judgment:** the reviewer cannot inspect workspace files or prove that a claimed check actually ran. Prompt-injection resistance still depends on the selected model's judgment.
- **Text evidence:** non-text human messages and delegated sessions without human instruction history cannot receive automatic approval.
- **One user-owned policy:** the enabled state, route, bounds, and deployment restrictions apply to all sessions.
- **Route selection:** the settings form accepts provider and model identifiers as text.

<a id="dev-note"></a>
```

## [packages/guard/approval-assessor/README.md:77](/Users/brandon/Downloads/deepseek-harness/packages/guard/approval-assessor/README.md:77)

```markdown
<a id="known-limitations-and-deferred-work"></a>

These limits define when the audit is a poor fit. They are current package constraints, not a task backlog.

- **Rule matching only** — a paraphrased evasion that matches neither a built-in rule nor an `extraPhrases` entry passes screening. Enable the [adversarial reviewer](../approval-adversary/README.md) for model-based authorization review after this stage.
- **Built-in rules are English** — other languages require deployment-specific entries in `extraPhrases`.
- **One user-owned policy** — the Host settings namespace applies one enabled state and phrase list to every approval request; it does not select policy by tool or session.

<a id="dev-note"></a>
```

## [packages/guard/repeat-tool-reminder/README.md:162](/Users/brandon/Downloads/deepseek-harness/packages/guard/repeat-tool-reminder/README.md:162)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the guard is a poor fit. They are current package constraints, not a task backlog.

- **Exact-match detection only** — canonicalization is a deep key-sort, so near-identical variants (a tweaked path, extra whitespace inside a value) evade the chain; fuzzy matching is rejected pending evidence of need.
- **Compaction does not reset chains** — a chain spanning a compaction checkpoint keeps counting.
- **Advisory only** — escalating to a blocking form at a high threshold is not implemented, though `PostToolDecision` already supports blocking.
- **No subagent chain-sharing** — chains stay isolated per agent; a parent and its subagent repeating the same call never combine.
- **Legitimate idempotent polling still draws nudges** past the thresholds — the pressure valves are the `thresholds`/`exclude` config.
- **Past the highest threshold a chain goes silent** — reminders fire only at exact configured counts, never beyond them.

<a id="dev-note"></a>
```

## [packages/guard/timeout-policy/README.md:115](/Users/brandon/Downloads/deepseek-harness/packages/guard/timeout-policy/README.md:115)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the policy is a poor fit. They are current package constraints, not a task backlog.

- **Cooperative, never a hard kill** — the deadline only notifies via `exec.signal`; a tool that ignores the signal does not stop on timeout, the wrapper remains inside `await next()`, and the model receives no timeout result until downstream settles.
- **No blanket budget** — only tools that declare `timeoutMs` on their `ToolDefinition` get a deadline; undeclared tools (the shipped `bash`, `read`, `write`, and `edit` declare none) have no registry-wide default.

<a id="dev-note"></a>
```

## [packages/hooks/hook-protocol/README.md:120](/Users/brandon/Downloads/deepseek-harness/packages/hooks/hook-protocol/README.md:120)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what hooks cannot do through the shared engine yet. They are current package constraints, not a task backlog.

- **`HookOutput.updatedInput` is parsed but not honored** — input rewrite is a deferred consistency-design problem ([the pre-tool-input-rewrite Agent Note](../../../.agents/notes/proposed/feature/2026-06-30-pre-tool-input-rewrite.md)); a bridge logs and warns when a hook sets it.
- **Only the command-hook shape runs** — the protocol executes `{ type: 'command', command, timeout? }`; a bridge parses-and-skips the other shapes its dialect defines (`http`, `mcp_tool`, `prompt`, `agent`).

<a id="dev-note"></a>
```

## [packages/hooks/hooks-claude-code/README.md:167](/Users/brandon/Downloads/deepseek-harness/packages/hooks/hooks-claude-code/README.md:167)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what your Claude Code hooks cannot do through this bridge yet, and where behavior differs from the reference tool. They are current package constraints, not a task backlog.

- **Unsupported hook events (23 of Claude Code's current 30)** — `Setup`, `InstructionsLoaded`, `UserPromptExpansion`, `MessageDisplay`, `PermissionRequest`, `PostToolUseFailure`, `PostToolBatch`, `PermissionDenied`, `Notification`, `TaskCreated`, `TaskCompleted`, `StopFailure`, `TeammateIdle`, `ConfigChange`, `CwdChanged`, `FileChanged`, `WorktreeCreate`, `WorktreeRemove`, `PreCompact`, `PostCompact`, `SessionEnd`, `Elicitation`, and `ElicitationResult`. Config for these events is ignored before group parsing, so an unsupported event cannot invalidate or register hooks. The comparison baseline is Claude Code's [official hook-event reference](https://code.claude.com/docs/en/hooks#hook-events).
- **`SessionStart` is partial** — JSON `additionalContext` is consumed, but plain stdout context, `initialUserMessage`, `sessionTitle`, `watchPaths`, `reloadSkills`, and `CLAUDE_ENV_FILE` are unsupported. The hook runs detached, but the first step waits for it and carries its context, so a slow hook delays the first request instead of missing it; `continue: false` on this point is recorded only, and the payload omits optional fields such as `model`, `agent_type`, and `session_title`.
- **`UserPromptSubmit` is partial** — blocking and JSON `additionalContext` work, but plain stdout context, `sessionTitle`, and `suppressOriginalPrompt` are unsupported. Unless overridden, the bridge also uses its 600-second default instead of Claude Code's event-specific 30-second command timeout.
- **`PreToolUse` is partial** — `deny` and `ask` decisions work; `allow` does not pre-approve, `defer` is unsupported, `additionalContext` is ignored, and `updatedInput` is logged + warned but not honored ([the pre-tool-input-rewrite Agent Note](../../../.agents/notes/proposed/feature/2026-06-30-pre-tool-input-rewrite.md)).
- **`PostToolUse` is partial** — blocking feedback and JSON `additionalContext` work, but `updatedToolOutput` and `updatedMCPToolOutput` are unsupported and `tool_response` is flattened to text.
- **`SubagentStart` and `SubagentStop` are partial** — both report a constant `agent_type` of `general-purpose` and use the child session id where Claude Code reports the parent session. Start context is best-effort and can only reach a live in-process child; stop is observe-only and cannot block the subagent or feed it context. Start omits `transcript_path`; stop also omits `agent_transcript_path`, `last_assistant_message`, `background_tasks`, and `session_crons` and always reports `stop_hook_active: false`.
- **`Stop` is partial** — blocking forces another model turn, `stop_hook_active` is `true` from the second run in one turn, and eight consecutive blocks in a turn are overridden with a warning, as in Claude Code; `last_assistant_message`, `background_tasks`, and `session_crons` are omitted.
- **Common payload and output fields are partial** — mapped event payloads omit `prompt_id`, `transcript_path`, `permission_mode`, and `effort` where Claude Code would provide them. `{"continue": false}` halts `PreToolUse` and `UserPromptSubmit`, stops a `Stop` hook's continuation, and has no effect on `PostToolUse`, as in Claude Code; `stopReason` reaches the model on its next request; `suppressOutput` and `terminalSequence` are not applied.
- **Handler and config support is partial** — only shell-form command handlers run. `http`, `mcp_tool`, `prompt`, and `agent` handlers are skipped; command-handler options such as `args`, `async`, `asyncRewake`, `shell`, `if`, `once`, and `statusMessage` are not honored. Matching handlers run serially and are not deduplicated, whereas Claude Code runs them in parallel and deduplicates identical handlers. One process-level `configPath` is parsed once at load; Claude Code's layered project, user, plugin, and policy discovery and live reload are not implemented.

<a id="dev-note"></a>
```

## [packages/hooks/hooks-codex/README.md:163](/Users/brandon/Downloads/deepseek-harness/packages/hooks/hooks-codex/README.md:163)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what your Codex hooks cannot do through this bridge yet, and where behavior differs from the reference tool. They are current package constraints, not a task backlog.

- **Unsupported hook events (5 of Codex's current 10)** — `PermissionRequest`, `PreCompact`, `PostCompact`, `SubagentStart`, and `SubagentStop`. Config for these events is silently dropped during parsing. The comparison baseline is Codex's [official hook reference](https://learn.chatgpt.com/docs/hooks).
- **`SessionStart` is partial** — plain stdout and JSON `additionalContext` work, and the first step waits for the detached run so its context reaches the first request; `continue: false` on this point is recorded only, since no turn is open to end.
- **`UserPromptSubmit` is partial** — blocking, plain-stdout or JSON context, and `{"continue": false}` work, but the common `systemMessage` control is not surfaced.
- **`PreToolUse` is partial** — blocking works, but `additionalContext`, `permissionDecision: "allow"`, and `updatedInput` are ignored, and `{"continue": false}` is warned about while the call proceeds, as Codex does not accept it here. Every tool is represented as `tool_input: { command }`, so non-shell tool arguments are not faithfully exposed to the hook.
- **`PostToolUse` is partial** — blocking feedback, JSON `additionalContext`, and `{"continue": false}` (the stop text replaces the tool result and the turn continues) work, but non-shell tool arguments are reduced to `{ command }` and structured tool output is flattened to text in `tool_response`.
- **`Stop` is partial** — blocking forces another model turn, `stop_hook_active` is `true` from the second run in one turn, `{"continue": false}` outranks a block, and eight consecutive blocks in a turn are overridden with a warning, a cap Codex does not document; `last_assistant_message` is always `null`.
- **Common payload and output fields are partial** — every mapped event reports the statically configured `model` and `permission_mode: "default"` instead of current Codex runtime values. `systemMessage` is logged + warned but not surfaced; `{"continue": false}` follows Codex on `UserPromptSubmit`, `PostToolUse`, and `Stop`, and `stopReason` is recorded on the turn's end rather than shown to the model.
- **Config loading and execution are partial** — one process-level `configPath` is parsed at load; Codex's active user, project, session, system/managed, and plugin layers, trust controls, and inline `config.toml` hook form are not implemented. Only synchronous `command` handlers run, current metadata such as `statusMessage` and `commandWindows` is ignored, and matching handlers run serially rather than with Codex's concurrent launch semantics.

<a id="dev-note"></a>
```

## [packages/host/directory-picker-auto/README.md:101](/Users/brandon/Downloads/deepseek-harness/packages/host/directory-picker-auto/README.md:101)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the boot-time sample can misjudge the host. They are current package constraints, not a task backlog.

- **Detection infers operator location from launch context, which no launch-side signal can prove** — a tmux session detached from its SSH launch loses the `SSH_*` markers; a Darwin process outside an Aqua session still counts as displayed; and a workstation-local launch later reached through `ssh -L` arrives from `127.0.0.1`, resolves `native`, and opens the chooser on the unattended workstation. A wrong `native` choice degrades to the backend's existing retryable failure dialog, and composing `-browse` directly selects the safe interaction for such deployments.
- **The Linux chooser probe reads `PATH` only** — a zenity/kdialog reachable some other way (shell alias, non-PATH install) still resolves `browse`; installing either binary on `PATH` restores `native` eligibility at the next boot.
- **Boot-time only** — one resolution serves every client of the boot; per-connection adaptivity (native for a local browser, browse for a remote one, same server) would need a per-client capability and the wire advertisement the seam does not carry, and waits for a deployment that serves both at once.

<a id="dev-note"></a>
```

## [packages/host/directory-picker-browse/README.md:103](/Users/brandon/Downloads/deepseek-harness/packages/host/directory-picker-browse/README.md:103)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the browse interaction is incomplete or intentionally unscoped. They are current package constraints, not a task backlog.

- **Windows hidden attribute is not read** — Node dirents do not expose `FILE_ATTRIBUTE_HIDDEN`, so `hidden` means dot-prefixed on every platform until a native probe is worth its cost.
- **No drive-root enumeration** — on Windows the ancestry stops at the drive root; crossing drives waits for the browser UI's path-entry affordance rather than an enumeration primitive here.
- **Whole-filesystem scope** — there is no per-deployment browse-root restriction; `workspace.create` accepts arbitrary paths, so a root here would be UX scoping rather than a security boundary.

<a id="dev-note"></a>
```

## [packages/host/directory-picker-native/README.md:92](/Users/brandon/Downloads/deepseek-harness/packages/host/directory-picker-native/README.md:92)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the native interaction is unavailable or fragile. They are current package constraints, not a task backlog.

- **Linux requires desktop tooling** — with neither Zenity nor KDialog installed, `pick` rejects with an actionable error; it does not fall back to a typed-path prompt (the browse backend is that fallback at the composition level).
- **Windows has no mechanism fallback** — the child-process picker through packaged koffi is the only native tier, so a COM refusal or dialog crash surfaces the failure; the browse backend remains the fallback at the composition level.

<a id="dev-note"></a>
```

## [packages/host/directory-picker/README.md:94](/Users/brandon/Downloads/deepseek-harness/packages/host/directory-picker/README.md:94)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the seam contract leaves a decision to a future consumer. They are current package constraints, not a task backlog.

- **No multi-root support** — the browse contract exposes one ancestry chain per listing; per-deployment root scoping (and Windows drive-root enumeration above a drive) waits for a consumer that needs it, per the DirectoryPicker Agent Note.

<a id="dev-note"></a>
```

## [packages/host/frontend-static/README.md:97](/Users/brandon/Downloads/deepseek-harness/packages/host/frontend-static/README.md:97)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when a served asset class is not yet covered. They are current package constraints, not a task backlog.

- **The starter MIME table is minimal** — it covers the Vite-emitted asset set plus the shipped PWA manifest; other extensions fall back to `application/octet-stream` until an asset class ships.
- **Pathname routing is explicit** — the current client enters through the root or configured index path and has no History API pathname routes. Adding one requires an explicit server rule and real-composition coverage rather than a broad fallback for every miss.

<a id="dev-note"></a>
```

## [packages/host/plugin-inventory/README.md:88](/Users/brandon/Downloads/deepseek-harness/packages/host/plugin-inventory/README.md:88)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what a point-in-time inventory cannot tell a client. They are current package constraints, not a task backlog.

- **Point-in-time state only** — the result contains no durable failure history or subscription; a missing root Fiber is reported as `null`, regardless of why no live root exists.
- **No provenance or mutation** — the service does not identify which bundle, profile, or override introduced an entry, and it cannot enable, disable, add, or remove plugins.

<a id="dev-note"></a>
```

## [packages/host/webserver/README.md:105](/Users/brandon/Downloads/deepseek-harness/packages/host/webserver/README.md:105)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the server is intentionally minimal. They are current package constraints, not a task backlog.

- **No server-wide TLS, authentication, or origin policy** — route owners such as `dsh-client-connection` enforce their own request policy. Binding a non-loopback address still exposes unprotected routes and static assets to that network.
- **Socket options are fixed** — config selects the bind host and port, while backlog and other socket settings remain internal until a deployment needs them.

<a id="dev-note"></a>
```

## [packages/identity/anonymous-user-id/README.md:115](/Users/brandon/Downloads/deepseek-harness/packages/identity/anonymous-user-id/README.md:115)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe when the id is a poor fit or needs special attention. They are current package constraints, not a general comparison of anonymity approaches or a task backlog.

- **No recovery after deletion** — losing the file mints a new anonymous identity by design; recovery would require stable derivation material that weakens anonymity.
- **Best-effort concurrency** — a reader landing in the narrow interval between a concurrent process's exclusive create and completed write can use a different in-memory UUID for that run; later launches converge on the persisted value.
- **No cross-home identity** — different `$DSH_HOME` values cannot be correlated.
- **Configured DeepSeek gateways receive the id** — `dsh-llm-deepseek` sends the stable header to its resolved `baseURL`, including deployment overrides, independently of telemetry sharing mode.
- **Deleting the file does not reset the current process** — memoization keeps the run's id until the next launch.

<a id="dev-note"></a>
```

## [packages/interaction/commands/README.md:132](/Users/brandon/Downloads/deepseek-harness/packages/interaction/commands/README.md:132)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the registry does not offer. They are current package constraints, not a UI backlog.

- **Only unstructured text input** — forms, completion schemas, and typed arguments remain command-owned parsing concerns.
- **Cooperative side-effect cancellation** — dispatch stops awaiting on abort; handlers must honor the signal to stop work that has already escaped into external systems.

<a id="dev-note"></a>
```

## [packages/interaction/permission-presets/README.md:125](/Users/brandon/Downloads/deepseek-harness/packages/interaction/permission-presets/README.md:125)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the preset service does not offer. They are current package constraints, not a permission-system comparison.

- **Only two mechanism knobs are bundled** — presets select sandbox mode and approval policy; an agent/profile choice is not part of `PresetSpec` yet.
- **`custom` is derived-only** — callers can switch away from an unmatched knob combination but cannot target or persist a named custom preset through this service.
- **The preset table is process-level** — configuration is fixed for the plugin lifetime; changing available presets requires reloading the plugin.
- **Stored defaults must remain in the preset table** — removing the referenced preset makes Permission settings registration fail until the `permission` section in `settings.yaml` is updated or reset.

<a id="dev-note"></a>
```

## [packages/interaction/tool-ask-user/README.md:134](/Users/brandon/Downloads/deepseek-harness/packages/interaction/tool-ask-user/README.md:134)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the tool is a poor fit. They are current package constraints, not a UI backlog.

- **A pending question blocks the tool call until the human answers** — the tool declares no `timeout-policy` budget; cancellation rides the turn's `exec.signal` only.
- **Runtime-owned subagents cannot ask the user** — `ask_user_question` rejects a live child owned by another agent with `DELEGATED_CALLER`; the child must include the unresolved question or decision in its final result. Durable lineage does not decide this boundary, so a lineage-bearing session resumed as a runtime root may ask normally.
- **Native answers render as JSON text** — the canonical value remains structured, but the model-facing result uses compact JSON rather than a richer content-block vocabulary.

<a id="dev-note"></a>
```

## [packages/interaction/user-approval/README.md:147](/Users/brandon/Downloads/deepseek-harness/packages/interaction/user-approval/README.md:147)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the seam is a poor fit or needs special composition care. They are current package constraints, not a general permission comparison.

- **Requests are valid only inside an open turn** — an idle or between-turn caller throws before auditing; a durable out-of-turn approval workflow is deferred.
- **Only one-shot grants exist** — the outcome vocabulary has `allowed-once` but no `allow-always`, remembered rule, revocation, or grant store; session policy is only `ask` / `never`.
- **The request carries no tool arguments** — an answerer sees the tool name, reason, and optional call id; the ACP machine channel requires a call id and delegates requests without one.
- **No built-in answerer** — headless or incompletely composed deployments resolve `unavailable` and fail closed; the service itself never prompts a human.

<a id="dev-note"></a>
```

## [packages/interaction/user-questions/README.md:61](/Users/brandon/Downloads/deepseek-harness/packages/interaction/user-questions/README.md:61)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Agent-scoped Web answering** — Remote Events route the shipped Web answerer only when the request carries a live Agent scope; agentless callers need an unscoped local waterfall listener.
- **The vocabulary is the question-form shape only** — selectable options plus optional custom text; richer interaction shapes (file pickers, diff-preview confirmations) have no seam vocabulary yet.


<a id="dev-note"></a>
```

## [packages/jobs/jobs-local/README.md:124](/Users/brandon/Downloads/deepseek-harness/packages/jobs/jobs-local/README.md:124)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the registry is a poor fit. They are current package constraints, not a task backlog.

- **Jobs are process-local** — records die with the harness process; durable or cross-restart execution needs a separate backend implementing the seam.
- **A silently ineffective cancel can stall teardown and hold capacity** — if `cancel` returns without settling `done`, the registry cannot distinguish it from a slow stop; the job keeps one bucket slot for the rest of the service lifetime, and only an explicit throw can be force-failed safely.

<a id="dev-note"></a>
```

## [packages/jobs/jobs/README.md:113](/Users/brandon/Downloads/deepseek-harness/packages/jobs/jobs/README.md:113)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the contract is a poor fit. They are current package constraints, not a task backlog.

- **The contract is in-process** — `JobStart.run()` passes callbacks and exact `Agent` objects; a durable or cross-process backend must reshape identity, restart, ownership, and observation semantics before it can implement this seam.
- **Stream output has one consuming cursor** — independent observers need a cursor or snapshot API.
- **Foreground work cannot be promoted** — producers choose foreground or background before starting.

<a id="dev-note"></a>
```

## [packages/jobs/tool-jobs/README.md:166](/Users/brandon/Downloads/deepseek-harness/packages/jobs/tool-jobs/README.md:166)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the tools are a poor fit. They are current package constraints, not a task backlog.

- **A settlement inside the driver's retirement window still strands its notice** — between the turn loop's last inbox check and the driver committing its idle phase the owner still reads as busy, so the notice is injected and nothing wakes. Steering has the same hole; closing it belongs to `agent-loop`.
- **A spent wake budget is not restored by time** — only user-authored input refills it, so an unattended agent whose budget ran out collects its remaining notices on the next turn something else opens.
- **A notice pending on an idle owner does not survive that owner's disposal** — the disposal cancel clears the unclaimed inbox, and the log keeps the insert/cancel pair as the record.
- **Stream reads are single-consumer** — independent observers need another runtime API.
- **Unowned jobs have no session fence** — external callers must supply policy or avoid them.

<a id="dev-note"></a>
```

## [packages/llm/deepseek-llm-api-extensions/README.md:43](/Users/brandon/Downloads/deepseek-harness/packages/llm/deepseek-llm-api-extensions/README.md:43)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Official DeepSeek requests only** — the registry intentionally has no provider-neutral routing or pi-ai adapter integration.
- **No field ordering contract** — JSON object member order follows registration preparation but receivers address fields by name.


<a id="dev-note"></a>
```

## [packages/llm/llm-deepseek/README.md:179](/Users/brandon/Downloads/deepseek-harness/packages/llm/llm-deepseek/README.md:179)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the adapter stops and future work begins. They are current package constraints, not a general DeepSeek comparison or a task backlog.

- **A settings `models` list replaces the composition list wholesale** — settings-layer merging is per-field, and arrays are one field; per-entry catalog merging would need a keyed shape.
- **`tool_choice` is not mapped** — not part of the core vocabulary (shared with the pi-ai twin).
- **Requests use raw `fetch`, not `@cordisjs/plugin-http`** — no shared proxy or interception configuration.
- **Plugin-added content block types are skipped** — core text and supported image blocks are serialized, and empty tool output crosses the wire as the literal `(no output)`.
- **Images are input-only durable attachments** — direct external URLs and assistant image output are not supported; DeepSeek input normally uses the Files API and uses inline base64 only for per-request recovery.

<a id="dev-note"></a>
```

## [packages/llm/llm-litert/README.md:132](/Users/brandon/Downloads/deepseek-harness/packages/llm/llm-litert/README.md:132)

```markdown
<a id="known-limitations-and-deferred-work"></a>

These limits define what the route does not attempt; they are current package contracts.

- **One route per plugin instance** — a composition serving several LiteRT-LM endpoints mounts the plugin once per route, because `provider`, `models`, and the endpoint resolve together.
- **The supervised server is not restarted** — the plugin starts the process once and stops it on dispose; a server that exits later leaves the route registered and its requests fail through pi-ai until the fiber is reloaded.
- **Imports are load-time only** — models are imported while the plugin applies, so adding a model means changing configuration and reloading, not calling the running server.
- **The endpoint is unauthenticated** — LiteRT-LM's HTTP API has no credential of its own, so a remote route must reach a server that is private or fronted by an authenticating proxy.

-----

<a id="dev-note"></a>
```

## [packages/llm/llm-pi-ai/README.md:201](/Users/brandon/Downloads/deepseek-harness/packages/llm/llm-pi-ai/README.md:201)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the adapter stops and future work begins. They are current package constraints, not a general pi-ai comparison or a task backlog.

- **`maxRequestImageBytes` counts base64 image payload only** — text, tools, descriptors, and JSON structure ride outside the bound, so it must sit below the gateway's request-body cap with headroom. Offload is a deterministic request projection and is not recorded as a session event.
- **A sign-in lives only in the process that started it** — an authorization attempt is not durable, so reloading the page mid-login abandons it and the human starts over. Signing out is `deleteRecord` on the stored record, which forgets it locally without telling the issuer.
- **Provider-native discovery answers through this plugin's ambient context** — a route naming no credential defers to the catalog provider's own resolution, which asks for environment values (`AZURE_OPENAI_API_KEY`, `AWS_PROFILE`, and each provider's own set) and for local credential files. Both questions are answered here: the credential seam is consulted before the process environment, and file existence is checked against the host process's filesystem with `~` expanded. What it cannot do is *read* a credential file's contents — a provider that parses `~/.aws/credentials` itself does so directly, outside the seam.
- **Settings can add or override routes, not remove composition routes** — the user layer merges over the composition base, so deleting a `cordis.yml`-provided provider is a composition change.
- **The layered merge has no delete for dict keys** — a `reasoningEfforts` level, `modelOverrides` entry, or `compat` field the base declares can be overridden but not removed by the user layer.
- **`headers` can carry a credential the redactor never sees** — the profile's `headers` dict is plain strings; store credentials as `apiKeyEnv` references.
- **A route's catalog never refreshes itself** — the catalog is whatever `settings.yaml` says; nothing here queries a provider for the models it serves.
- **One wire protocol per route** — a mixed-protocol catalog route cannot host a model of the other protocol; splitting the provider across two route keys is the workaround.
- **A modality declaration is not verified** — a model declaring `image` its gateway does not serve is refused by the provider after prompt admission. The durable image remains in history and the same misdeclared model can fail again; switching to a text-only model remains possible because the shared LLM runtime projects image references into stable text for that request.
- **An unauthenticated route depends on its protocol** — a route naming no credential resolves as configured-but-keyless, but pi-ai's OpenAI-compatible implementation still requires an API key or an `Authorization` header, so a keyless local server needs a placeholder credential referenced by `apiKeyEnv` or an `Authorization` entry in `headers`.
- **`GenerateOptions.stop` is unsupported** — pi-ai's common stream options cannot guarantee stop-sequence behavior across providers.
- **In-history `system` messages use pi-ai's common context conversion** — provider-specific placement follows pi-ai rather than a harness-owned wire override.
- **Provider HTTP status is unavailable** — pi-ai error events do not expose a stable HTTP status across providers.
- **Retry policy is provider-owned, not an SDK retry** — pi-ai SDK retries stay disabled so durable agent steps and `llm/retry` events own every visible attempt, and direct `ctx.llm.stream()` calls remain single-attempt.

<a id="dev-note"></a>
```

## [packages/llm/llm-retry/README.md:125](/Users/brandon/Downloads/deepseek-harness/packages/llm/llm-retry/README.md:125)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the executor stops and future work begins. They are current package constraints, not a general retry comparison or a task backlog.

- **Agent turns are the only retry boundary** — direct `ctx.llm.stream()` consumers remain single-attempt because a raw stream cannot separate already-emitted chunks durably.
- **Always mode retries permanent failures** — authentication, quota, invalid-request, protocol, and unrecoverable context errors continue until success, cancellation, or disposal; deployments own provider-specific cost and latency controls.
- **Finite plugin budgets add** — normal mode counts only its configured codes and exact provider policy, while context-overflow compaction owns a separate budget. Any overlapping policy must define registration-order behavior.
- **Recovery policies compose by waterfall order** — always mode accepts a downstream retry before applying its fallback. A later policy that ignores cancellation and never settles also prevents fallback, turn quiescence, and plugin disposal from completing.
- **`llm/retry` records scheduling, not completion** — later step and turn events establish success, exhaustion, or cancellation.

<a id="dev-note"></a>
```

## [packages/llm/llm/README.md:141](/Users/brandon/Downloads/deepseek-harness/packages/llm/llm/README.md:141)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where this service stops and other packages or future work begin. They are current package constraints, not a task backlog.

- **No retry execution, caching, or rate limiting ships in this service** — provider registration stores the retry policy, but a stream remains a single provider attempt; `@deepseek-ai/dsh-llm-retry` executes the policy at durable agent-step boundaries.
- **`GenerateOptions` sampling is `temperature`/`maxTokens`/`stop` only** — no `tool_choice`, `top_p`, or penalty fields; the vocabulary grows when a producer lands ([dropped inert knobs](../../../.agents/notes/archived/simplification/2026-07-04-drop-inert-request-knobs.md)).
- **Producer-gated variants stay out until produced** — `prefill`, per-tool `strict`, block `cache` hints, and the `agent` message-source variant have no producer ([Agent Note](../../../.agents/notes/archived/simplification/2026-07-04-prune-producerless-vocabulary-variants.md)).
- **`BlockAssembler` handles core block kinds only** — a plugin-added block type whose stream is never closed by `block-end` makes `blocks()` throw.
- **`GenerateOptions.sessionId` is a locally-declared brand** — importing dsh-session's `SessionId` would create a dependency cycle.

<a id="dev-note"></a>
```

## [packages/llm/plugin-package-inventory-deepseek/README.md:59](/Users/brandon/Downloads/deepseek-harness/packages/llm/plugin-package-inventory-deepseek/README.md:59)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Loader package provenance only** — programmatic child fibers and in-memory dynamic plugins do not have authoritative npm name/version provenance and remain outside this inventory.
- **Loose modules are omitted** — a relative file without a named and versioned owning manifest is a plugin module, not a plugin package.
- **In-place package replacement requires restart** — manifest identities are cached for the process lifetime. Loader enable, disable, mount, unmount, and ordinary source HMR still refresh the active entry set, but replacing a mounted package's manifest with another version in the same process is not a supported upgrade path.


<a id="dev-note"></a>
```

## [packages/llm/token-meter/README.md:127](/Users/brandon/Downloads/deepseek-harness/packages/llm/token-meter/README.md:127)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the measurement stops and future work begins. They are current package constraints, not a general token-accounting comparison or a task backlog.

- **The fixed heuristic is approximate** — text without reusable provider usage is priced by character count plus structural overhead, not an exact provider tokenizer or request serializer; only image occurrences on routes with declared pricing carry provider-exact visual tokens.
- **Every measurement clones the current surface** — coherent immutable snapshots make reads O(surface), including below-threshold pressure checks.
- **Provider usage is only reusable for an identical canonical envelope** — prompt, prefix, tools, provider, model, or call-config changes deliberately fall back to full heuristic estimation.
- **Missing legacy source seqs are handled conservatively** — assistant messages without `sourceEventSeqs` cannot distinguish provider output from listener rewrites, so the fold avoids claiming a known empty or exact chunk stream.

<a id="dev-note"></a>
```

## [packages/lsp/lsp-stdio/README.md:141](/Users/brandon/Downloads/deepseek-harness/packages/lsp/lsp-stdio/README.md:141)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **No confinement policy** — this package trusts the configured server and does not sandbox its process; a restricted deployment must supply appropriate process and filesystem providers or a same-world sandbox wrapper.
- **Transient-open compatibility floor** — servers whose synchronization omits open/close (or advertises `None`) are unsupported even if closed-document queries would work; the pinned TypeScript e2e establishes one compatibility floor, not a cross-language claim.
- **Per-server and per-workspace serialization latency** — parallel agents sharing one server and workspace queue behind one process; long-lived workspace processes consume memory until disposal.
- **A hard-killed harness orphans language servers** — `initialize.processId: null` removes server-side client-PID monitoring, so servers are cleaned only by graceful service disposal; a SIGKILL'd harness leaves them running until they exit on their own.

<a id="dev-note"></a>
```

## [packages/lsp/lsp/README.md:122](/Users/brandon/Downloads/deepseek-harness/packages/lsp/lsp/README.md:122)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the seam's current scope. They are package constraints, not a task backlog.

- **Exclusive extension ownership within one runtime** — two providers cannot both claim `.ts`, even with different language ids; overlaps fail registration. A deployment-configured selector above registrations is the intended extension, which can relax exclusive reservation without adding provider choice to model input ([seam Agent Note](../../../.agents/notes/implemented/architecture/2026-07-15-lsp-capability-seam.md)).
- **Four read-only operations only** — symbols and call hierarchy are deferred because they need different schemas; diagnostics need separate freshness and accumulation rules; mutations (rename, code actions, formatting) require separate tools with preview, permission, and write-policy integration.
- **No observation API** — availability is observed only by running `query()` and routing the thrown `LspError` codes; there is no provider-change event or capability-status query.

<a id="dev-note"></a>
```

## [packages/lsp/tool-lsp/README.md:162](/Users/brandon/Downloads/deepseek-harness/packages/lsp/tool-lsp/README.md:162)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the tool is a poor fit. They are current package constraints, not a task backlog.

- **UTF-16 cursor coordinates** — columns are exact for the protocol but hard for a model to count around non-BMP characters; an off-symbol position may return empty results, so the prompt explains the convention without encouraging broad LSP use ([seam Agent Note](../../../.agents/notes/implemented/architecture/2026-07-15-lsp-capability-seam.md)).
- **No cross-server completeness promise** — supported servers may return empty or partial results depending on indexing readiness; the tool promises no completeness across languages or servers.

<a id="dev-note"></a>
```

## [packages/mcp/mcp-client/README.md:184](/Users/brandon/Downloads/deepseek-harness/packages/mcp/mcp-client/README.md:184)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what you cannot do with this plugin and when it needs operational attention. They are current package constraints, not a comparison with other MCP clients or a task backlog.

- **Tools are the only bridged MCP capability** — Resources and Prompts have no harness consumer mechanism and are deferred.
- **Startup and discovery timeouts are inherited from the MCP SDK** — the plugin exposes no connection or discovery timeout; each `initialize` and paginated `tools/list` request uses the SDK's 60-second request default, so an unresponsive server or cursor chain can delay both activation and teardown while the initial synchronization settles.
- **Reconnect triggers on transport close** — a crashed stdio child fires it; Streamable HTTP failures surface per request through the SDK transport's own recovery, so an unreachable HTTP server is retried per call rather than respawned by the supervisor.
- **Image is the only durable rich-result bridge** — PNG, JPEG, WebP, and GIF enter Native context after exact capability proof. Audio and embedded-resource payloads remain execution-local with explicit diagnostics, while resource links preserve only their name and URI as text.
- **Unsupported MCP output schemas are not enforced** — `structuredContent` falls back to `JsonValue` when the advertised schema uses vocabulary outside the harness subset.
- **Task-required MCP tools are rejected at call time** — a tool that requires the task-based execution extension throws instead of bridging; the extension is not implemented.

<a id="dev-note"></a>
```

## [packages/plan/plan-mode/README.md:176](/Users/brandon/Downloads/deepseek-harness/packages/plan/plan-mode/README.md:176)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe when plan mode does not behave as you might expect or needs extra care. They are current package constraints, not a roadmap.

- **Guidance, not enforcement** — plan mode restrains through text only; deployments that need enforced restrictions configure sandbox mode and approval policy independently.
- **Pending selections are process-local** — a selection made after the turn's final accepted pre-step is lost if the process exits before another accepted in-turn pre-step; the UI must reapply it.
- **No creation-time plan option** — forked agents inherit logged plan state, while newly spawned agents begin inactive.
- **Live children cannot open the review** — a child owned by another live agent fails the `exit_plan_mode` call and is told to include the unresolved decision in its final result; durable fork lineage alone does not prevent a session resumed as a runtime root from opening the review.
- **One specialized review renderer** — only the Web UI has a `plan-review` presentation; another interaction provider presents the same request through its generic option flow.

<a id="dev-note"></a>
```

## [packages/preset/agent-presets/README.md:164](/Users/brandon/Downloads/deepseek-harness/packages/preset/agent-presets/README.md:164)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the roster is a poor fit or needs special operational care. They are current package constraints, not a general composition comparison or a task backlog.

- **A preset outside the writable root is discoverable but not deletable** — `remove()` refuses anything that does not live under the first `user` root, so a deployment that configures its own writable root while leaving `includeUserRoot` on lists the harness-home presets, mounts them, and answers "it does not live under the writable preset root" for every delete. A deployment that wants only its own presets sets `includeUserRoot: false`.
- **A session cannot change preset once it has produced anything** — switching re-links a blank session's parent scope to another standing mount, and only a blank one: swapping tools mid-conversation would strand tools the model has called.
- **A generation is keyed on the composition file alone** — the stamp check notices `agent.cordis.yml` changing, not an edit to a skill file or asset beside it; those reach new sessions only once the composition file itself moves or the process restarts.
- **A superseded generation lives as long as its last session** — sessions already joined keep the generation they run on, so an edit-then-create cycle holds two generations, each with its own `dsh-skill-filesystem` watcher set, until every session on the older one is disposed; only then, or at once when no session ever joined it, is the retired subtree released.
- **A copy is never mounted to validate** — it is byte-identical to its source, so a source broken on disk yields a copy exactly as broken as the source; discovery's health check marks both rows on the next roster read rather than deferring the failure to a session start.
- **Health asks what is installed, not what would import** — discovery proves the composition parses in the loader dialect, holds named rows, and that each row it can prove will start names a package present above the harness base or a file that exists; it never imports one, so a package whose own entry file is missing, a plugin that throws on apply, and one waiting forever for a service all still fail at the first session. `disabled` is the one entry field the Loader interpolates, so a row carrying an expression there is left unchecked rather than judged from the file.
- **A copy is a snapshot that drifts** — upgrading the deployment does not update copies of shipped presets, and there is no patch semantics at this layer to express "standard plus one change"; the shipped set itself accepts the same cost — `cordis` and `code` each duplicate `standard`'s full assembly and then edit it — so the whole assembly stays readable in one file.
- **Root scans are not watched** — every read hits the filesystem instead, which keeps the roster fresh but puts one `readdir` per root on each `list()`.

<a id="dev-note"></a>
```

## [packages/preset/persona/README.md:109](/Users/brandon/Downloads/deepseek-harness/packages/preset/persona/README.md:109)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the row is a poor fit. They are current package constraints, not a task backlog.

- **No global mount** — the prompt registry owns the unscoped persona slot, so this row is usable only from a scoped composition. A deployment-wide persona change belongs in the `system-prompt` row's own config.
- **Runtime-context suppression is all-or-nothing** — `includeRuntimeContext: false` turns off every context contribution for the scope, including sandbox policy, approval policy, and delegation; there is no per-provider filter.

<a id="dev-note"></a>
```

## [packages/preset/swarm-profile/README.md:109](/Users/brandon/Downloads/deepseek-harness/packages/preset/swarm-profile/README.md:109)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Shared checkout** — every teammate observes the same working directory; write scopes exclude two tasks from being in progress on the same paths, but they are not filesystem locks, and this bundle adds no worktree isolation.
- **Base profile required** — the patch depends on row ids and Subagent providers supplied by `dsh-base`; it is not a standalone profile.
- **One ceiling per deployment** — `maxConcurrentRuns` bounds the whole process, with no per-Team or per-member sub-quota.

<a id="dev-note"></a>
```

## [packages/runtime-diagnostics/invariants/README.md:146](/Users/brandon/Downloads/deepseek-harness/packages/runtime-diagnostics/invariants/README.md:146)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the registry is a poor fit or needs operational care. They are current package constraints, not a task backlog.

- **Filters are fixed for the service lifetime** — `enabled`, `package_allowlist`, and `package_blocklist` are compiled once at startup; changing them requires a Cordis plugin reload.
- **Live-only companions miss pre-reload operations** — a companion that only observes live operations cannot reconstruct operations that began before its own reload; session-backed companions rebuild their baseline from durable events.
- **Request reconstruction covers loop-built requests only** — the `dsh-agent-loop` companion reconstructs requests explicitly built by the loop; direct one-shot LLM calls remain outside that contract even when callers freeze them or attach a session id.
- **No checks without a companion** — the registry ships no product checks; a composition that mounts the service alone observes nothing.

<a id="dev-note"></a>
```

## [packages/sandbox/sandbox-local/README.md:121](/Users/brandon/Downloads/deepseek-harness/packages/sandbox/sandbox-local/README.md:121)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a general platform comparison or a task backlog.

- **Windows ACL enforcement is partial** — the restricted token must retain Everyone for process initialization, so external objects granting Everyone write access remain writable; NTFS hard links also alias one file object across workspace and external paths. The provider reports `enforcement: 'partial'` rather than overstating that boundary as full.
- **Landlock may be partial** — older supported kernel ABIs confine only the access classes they expose, reported as `enforcement: 'partial'` rather than overstated as full.
- **Seatbelt depends on deprecated `sandbox-exec`** — macOS still ships it, but this provider cannot replace or probe that private policy engine if Apple removes it.
- **Runner selection is cached for the provider lifetime** — installing, removing, or repairing a runner requires reloading the plugin before selection changes.
- **`runnerCommand` is an operator assertion** — a configured custom runner skips functional probes and is assumed to implement the bwrap-compatible profile honestly; if it is itself a Bash script, its interpreter startup runs before that script applies confinement.

<a id="dev-note"></a>
```

## [packages/sandbox/sandbox-policy/README.md:142](/Users/brandon/Downloads/deepseek-harness/packages/sandbox/sandbox-policy/README.md:142)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the policy surface this package provides. They are current package constraints, not a general sandbox comparison or a task backlog.

- **One primary workspace root per session** — policy resolves `SessionHeader.cwd`; extra writable roots are not part of `SandboxExecutionPolicy`.
- **File-effect modes only** — `SandboxMode` governs file effects; network and process policy are outside its vocabulary, so no knob here restricts them.
- **Temporary areas are deliberately summarized** — enforcing backends grant different platform temporary areas, which are selected after policy resolution and therefore cannot be enumerated truthfully in the current context.

<a id="dev-note"></a>
```

## [packages/sandbox/sandbox-windows-acl/README.md:160](/Users/brandon/Downloads/deepseek-harness/packages/sandbox/sandbox-windows-acl/README.md:160)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the backend is a poor fit or needs special operational care. They are current package constraints, not a general Windows comparison or a task backlog.

- **One write allowlist per workspace** — the write SID is the unit of the allowlist and IS the workspace identity; reusing one sandbox instance across two workspaces widens both grants to both roots. Create one instance per workspace root — the seam does exactly this, keyed by the workspace path.
- **Cleanup is best-effort by design** — `dispose()` attempts every temp revocation and aggregates failures into an `AggregateError`; a cleanup failure can leave the random directory and its temp-SID-only ACE behind. Once the process exits no future token carries that SID, so the residue is inert until OS temp hygiene or manual removal reclaims it.
- **Standing workspace ACEs are invisible residue** — renaming a workspace derives a new SID; the old ACEs on the old path stay (inert, write-SID-only), and a future cleanup command may reap them.
- **NULL-DACL directories are not identity-preserving under grant+revoke** — a directory with a NULL DACL means "everyone full control"; `grantWrite` builds the new ACL from that null, and the revoke round-trip leaves an empty (deny-all) DACL rather than the original NULL DACL. Real workspace and temp directories carry real DACLs, so this stays a documented edge.
- **Piped stdio capture is impossible for confined grandchildren** — libuv's pipe stdio uses named pipes, whose client-end open requests write access no restricting SID is granted (the Win32 layer's default SD template, not the token default DACL), so `spawn(..., { stdio: 'pipe' })` inside a confined process fails with EPERM; inherited and ignored stdio spawns work, and anonymous pipes (PowerShell pipelines) work because the restricted token's default DACL carries a full-access restricting-SID ACE.
- **Grant materialization is an eager full-tree propagation** — `SetNamedSecurityInfoW` on a directory with inheritable ACEs walks every descendant immediately (tens of seconds on large workspace trees); the per-workspace identity pays it once per workspace per machine, and the exact-ACE skip makes every later provision cheap.
- **Read-side confinement and network policy are out of scope** — `WRITE_RESTRICTED` intersects write accesses only; pair this backend with a read-side policy for stronger confinement.
- **Wide-directory and FAT-volume warnings are deferred; FAT-class targets stay writable** — the UI-side warnings are not implemented, a FAT volume as a grant root fails loudly, and a FAT-class target outside the granted roots has no security descriptors so it stays writable under both confined modes; FAT is treated as legacy residue.
- **PowerShell language mode differs by confined mode** — under `read-only`, PowerShell cannot create its AppLocker probe files in temp and conservatively starts in ConstrainedLanguage (`Add-Type`, non-core .NET static calls, COM, and reflection fail); the shipped `workspace-write` path lets the probe complete, so pwsh stays in FullLanguage unless host-wide WDAC/AppLocker policy says otherwise, while a direct `AclSandbox` with `tempDir: null` has no such guarantee. This split is PowerShell startup behavior, not part of the ACL write boundary.

<a id="dev-note"></a>
```

## [packages/sandbox/sandbox/README.md:160](/Users/brandon/Downloads/deepseek-harness/packages/sandbox/sandbox/README.md:160)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the seam is a poor fit or needs special operational care. They are current package constraints, not a general sandbox comparison or a task backlog.

- **File effects are the whole policy vocabulary** — the seam expresses no network, process, syscall, device, or credential restrictions.
- **Same-world confinement only** — containers, microVMs, and remote execution require replacing capability implementations rather than adding a provider here.
- **Denial reporting is a stderr dialect** — the seam returns backend signatures instead of a typed runtime denial channel, so consumers that need classification infer it from the child process's output.
- **Runner diagnostics are in-band** — exit status plus stderr evidence cannot prove which process wrote a matching line, so a confined child that deliberately mimics its runner can cause a false availability or diagnostic attribution; this cannot bypass confinement, and an out-of-band runner-status channel is deferred.
- **One provider per context** — composing different sandbox mechanisms simultaneously requires a provider-level ladder or separate Cordis contexts; callers choose policy per call, not backend identity.

<a id="dev-note"></a>
```

## [packages/schedule/schedule/README.md:197](/Users/brandon/Downloads/deepseek-harness/packages/schedule/schedule/README.md:197)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe when Schedule does not fit your use case or needs special operational care. They are current package constraints, not a general reminder-service comparison or a task backlog.

- **Session-local delivery only** — a reminder runs on time only while its original Session is live; a cold Session receives no external notification and processes an overdue record only after resume.
- **Activity-driven retry** — a rejected due preflight or contained framing/enqueue failure leaves the record active but starts no private retry timer; later Agent activity or a successful Schedule preflight triggers recomputation.
- **Explicit local zone** — `at` never imports browser context; callers must translate natural language into either an offset-bearing RFC 3339 string or a local object with `time_zone`.
- **Fixed intervals, not calendar rules** — `every_seconds` is creation-anchor-aligned and cannot run more often than every five minutes; calendar or Cron expressions are not part of the protocol.
- **Latest-only catch-up** — an overdue Every record contributes only its latest due occurrence, so Schedule never replays a missed backlog.
- **Narrow crash duplicate window** — a crash after synchronous follow-up admission but before the dispatch checkpoint can repeat the reminder; the package does not claim model completion, user acknowledgement, or exactly-once effects.
- **Load-order boundary** — the plugin does not scan or adopt Agents that were already live when it loaded.

<a id="dev-note"></a>
```

## [packages/sdk/client/README.md:115](/Users/brandon/Downloads/deepseek-harness/packages/sdk/client/README.md:115)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the client is a poor fit or needs special care. They are current package constraints, not a comparison with other SDK clients or a task backlog.

- **No bundled-runtime resolution** — the client resolves the same-version `@deepseek-ai/dsh` package (or a caller-provided `dshBin`); packaged-executable discovery stays Python-side until a TypeScript distribution consumer exists.
- **No mid-turn cancel** — the wire has no prompt-cancel method; abandoning a turn means closing the runtime (see the [protocol limitations](../protocol/README.md#known-limitations-and-deferred-work)).
- **No per-prompt result** — low-level `prompt()` returns only an enqueue receipt; high-level `run()` owns receipt-to-idle collection, and abandoning it means closing the runtime.
- **Client→server notifications and server→client requests are unimplemented** on both wire ends; the transport carries them for future approval flows.

<a id="dev-note"></a>
```

## [packages/sdk/protocol/README.md:109](/Users/brandon/Downloads/deepseek-harness/packages/sdk/protocol/README.md:109)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the protocol does not cover or promise. They are current package constraints, not a comparison with other wire formats or a task backlog.

- **No protocol-version negotiation** — the handshake carries only `serverInfo.version` (`0.0.1`, unvalidated by clients); pre-release stance, no compatibility promise.
- **No cancel or session-close methods** — a client abandons a turn by closing the runtime process; see the [JSON-RPC serving plugin](../server/README.md).
- **Server→client requests are a dead capability** — the transport supports them, but the server never sends one; the Python SDK's responder surface exists for future approval flows.

<a id="dev-note"></a>
```

## [packages/sdk/server/README.md:118](/Users/brandon/Downloads/deepseek-harness/packages/sdk/server/README.md:118)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the plugin needs special operational care. They are current package constraints, not a comparison with other serving approaches or a task backlog.

- **The wire has no per-session close or prompt-cancel method** — SDK-created agents remain live until process shutdown.
- **There is no per-prompt result** — `MessageId` identifies inbox admission only; clients that own an automation interval must define and observe that interval themselves.
- **stdout purity is deployment-enforced** — a surrounding config can still load a stdout logger and corrupt the JSON-RPC channel; this plugin does not inspect or veto sibling loggers.
- **Automatic adapter mounting is DeepSeek-specific** — `initialize` can reuse any pre-registered model adapter, but its only fallback mounts the DeepSeek adapter.

<a id="dev-note"></a>
```

## [packages/session-query/session-log-export/README.md:117](/Users/brandon/Downloads/deepseek-harness/packages/session-query/session-log-export/README.md:117)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this package is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Requires a per-session raw artifact backend** — the download endpoint needs a persistence backend with a per-session raw artifact; the shipped JSONL backend supports plaintext and zstd, and SQLite export is not supported.
- **Browser download, not a Host-path writer** — the browser chooses the local destination; no Host path or native folder action is returned.
- **Preflight reports only pre-stream failures** — a descendant or attachment failure after the browser accepts the GET is reported by the browser download manager, not by the dialog.

<a id="dev-note"></a>
```

## [packages/session-query/session-query-sqlite/README.md:136](/Users/brandon/Downloads/deepseek-harness/packages/session-query/session-query-sqlite/README.md:136)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this package is a poor fit or needs special operational care. They are current package constraints, not a general SQLite comparison or a task backlog.

- **No caller authorization** — this is a trusted context-wide service; a model tool or UI must enforce its own access policy.
- **Synchronous query execution** — `DatabaseSync` blocks the JavaScript thread during MATCH execution and cannot interrupt a statement already running.
- **Token recall, not arbitrary substrings** — the `unicode61` tokenizer does not match substrings inside a larger token; use `filterEvents()` for literal scans.
- **Single-owner derived index** — one service in one process must own each index path; external writers and multi-process sharing are unsupported.

<a id="dev-note"></a>
```

## [packages/session-query/session-query/README.md:134](/Users/brandon/Downloads/deepseek-harness/packages/session-query/session-query/README.md:134)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this package is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **No caller authorization** — this is trusted context-wide infrastructure; a model tool or UI must constrain which sessions its caller may inspect.
- **No provider coordinator or fallback** — the service is abstract over search, so a composition must mount a concrete backend; there is no search-provider registry or fallback implementation.
- **Exact reads replay whole logs** — `readSession`, `readSurface`, `filterEvents`, and event traces load and validate the complete logical log, so very large histories pay full inspection per call; `listSessions` stays lightweight.
- **Literal text scan, not full-text search** — the `text` filter scans extracted documents with a regular expression and does not rank; ranked search requires the mounted backend.

<a id="dev-note"></a>
```

## [packages/session-query/tool-session-query/README.md:163](/Users/brandon/Downloads/deepseek-harness/packages/session-query/tool-session-query/README.md:163)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this package is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Search caps without continuation** — search returns at most the deployment cap and asks the model to narrow its query when more matches exist; there is no continuation token.
- **Conservative workspace identity** — workspace identity is exact-string `cwd` equality, so symlink-equivalent paths do not share authority.
- **Inline payloads without the spill policy** — custom compositions without the generic spill policy accept complete trace and event payloads inline.

<a id="dev-note"></a>
```

## [packages/session/session-checkpoint-policy/README.md:108](/Users/brandon/Downloads/deepseek-harness/packages/session/session-checkpoint-policy/README.md:108)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the policy's durability guarantee stops. They are current package constraints, not a task backlog.

- **Durable execution intent, not exactly-once effects** — the policy records that a call was dispatched, not that its external effect completed. Side-effecting tools should forward `exec.callId` as an idempotency key when their provider supports one.
- **No per-chunk checkpoint for streaming** — `assistant/chunk` events rely on bounded background batches; a hard crash may lose the current in-memory batch or outstanding write.
- **Unknown outcome, not automatic retry** — a persisted call without a result cannot prove whether its external effect completed, so recovery records an unknown outcome instead of retrying.

<a id="dev-note"></a>
```

## [packages/session/session-log-deepseek/README.md:65](/Users/brandon/Downloads/deepseek-harness/packages/session/session-log-deepseek/README.md:65)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Crash-window duplicates** — a 2xx followed by process loss before the acceptance watermark persists causes conservative replay on resume.
- **No live Session means no field** — direct or stale-session calls have no canonical log to snapshot; explicit absence semantics remain deferred.
- **No independent request-size cap** — complete delivery is fail-closed; provider rejection leaves the cursor unchanged instead of truncating the log.


<a id="dev-note"></a>
```

## [packages/session/session-persistence-jsonl/README.md:138](/Users/brandon/Downloads/deepseek-harness/packages/session/session-persistence-jsonl/README.md:138)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this backend is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Only the configured encoding and current `SESSION_FORMAT_VERSION` (v0) load** — changing compression requires a separate or fresh root, or selecting raw mode; the pre-release format has no migration.
- **The flat-file storage layout does not load** — use a separate root or move pre-release artifacts into the project/session directory layout before loading.
- **Compressed files are not directly line-readable** — use the backend to load them, or select `compression: 'none'` before writing a fresh root when external line readers are required.
- **Nothing deletes session files** — logs accumulate under `root` until removed externally; the seam has no deletion API.
- **One live writer per session** — append and repair are coordinated only inside the owning backend instance; another instance or process must not write the same session until that owner reaches quiescent disposal.
- **POSIX materialization requires hard-link support** — first append uses `link()` so same-id races fail instead of overwriting a committed log; Windows uses write-through rename without replacement.

<a id="dev-note"></a>
```

## [packages/session/session-persistence-sqlite/README.md:169](/Users/brandon/Downloads/deepseek-harness/packages/session/session-persistence-sqlite/README.md:169)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a general SQLite comparison or a task backlog.

- **Pre-release design with no migration** — schema 19 is an interim SQLite-only design; neither schema stability nor migration support is guaranteed.
- **Packing depends on batch boundaries** — a compatible run split by the write-behind window or an explicit flush stays split across physical rows; this avoids rewriting prior rows at the cost of a timing-dependent packing ratio.
- **Synchronous SQLite and compression** — Node's SQLite driver and Zstandard calls block the JavaScript thread.
- **Busy waits block the event loop** — SQLite waits inside synchronous calls; a competing writer can stall the thread for up to the configured `busyTimeoutMs`.
- **External SQL readers must decode physical rows** — a packed `events.type` (`text-chunks`, `reasoning-chunks`, `tool-call-chunks`) is not a logical event type; supported consumers read through this provider.
- **No deletion or historical compaction** — normal appends are insert-only and nothing removes old rows.

<a id="dev-note"></a>
```

## [packages/session/session-persistence/README.md:130](/Users/brandon/Downloads/deepseek-harness/packages/session/session-persistence/README.md:130)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the seam's guarantees stop. They are current package constraints, not a task backlog.

- **No deletion or retention API** — pruning stored sessions is out-of-band backend maintenance.
- **`list()` is unpaginated and unfiltered** — it returns every stored session's header; fine for local stores, unindexed at scale.
- **Synthetic closers are the only crash story** — a backend must synthesize `tool/result`/`step/end`/`turn/end` closers on load; there is no partial-turn resume that continues an interrupted turn instead of closing it.

<a id="dev-note"></a>
```

## [packages/session/session-projection-cache/README.md:119](/Users/brandon/Downloads/deepseek-harness/packages/session/session-projection-cache/README.md:119)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the cache needs operational care. They are current package constraints, not a task backlog.

- **No eviction or retention surface** — records accumulate per session; pruning stored checkpoints is out-of-band maintenance, same stance as session persistence itself.
- **Interval throttle is per-session coarse** — the timer arms at the first dirty event after a clean write; a steady sub-threshold trickle writes once per interval, not a sliding window.
- **No cache-side cold refold** — the cache serves and refreshes its rows but never reads the session log (it does not depend on the persistence layer); a consumer that needs a guaranteed cold snapshot refolds from the log itself.

<a id="dev-note"></a>
```

## [packages/session/session-projection/README.md:121](/Users/brandon/Downloads/deepseek-harness/packages/session/session-projection/README.md:121)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the projection registry needs care at scale. They are current package constraints, not a task backlog.

- **Every tail page carries every client-visible key** — there is no per-key opt-out or lazy-key request shape yet; acceptable while values are UI-scale whole states, revisit if a domain's value grows large.
- **The unit table is process-wide, so key presence is not a per-session capability signal** — a key registered by any agent preset appears in every session's snapshot; a client must read the value rather than treat an absent key as absence of the feature.
- **Eager drive touches every unit per event** — cheap by construction (whole-value rule, same-reference gate), but a hot path would justify per-unit event-type prefilters.
- **Registry cells live in memory only** — a restart rebuilds by folding the log on first touch; compositions that mount `dsh-session-projection-cache` seed that fold from persisted rows instead.
- **Synchronous unit discipline is only partially mechanical** — `wire.viewSchema.parse` rejects a Promise-returning view, but an `apply` that blocks or reads torn non-session state is a review concern.

<a id="dev-note"></a>
```

## [packages/session/session-stats/README.md:112](/Users/brandon/Downloads/deepseek-harness/packages/session/session-stats/README.md:112)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the figures describe and when the unit is absent. They are current package constraints.

- **Steps count work attempted, not visible output** — a step that failed before producing visible content still closes with `step/end` and counts; a step interrupted by a crash counts after the session reloads, when crash recovery appends its synthetic `step/end`.
- **A cancelled step is counted but untimed** — no assistant message assembles, so its partial stream time enters no wall-time figure; a max-tokens usage-host message conversely contributes model time the surface does not show.
- **Counts are log-scoped, not surface-scoped** — steps whose messages were later compacted away stay counted; the figures describe the whole session, not the current model-visible surface.
- **Mounted only where the projection registry is composed** — other assemblies serve no `sessionStats` key, and their consumers fall back to window-scoped counting.

<a id="dev-note"></a>
```

## [packages/session/session-telemetry-otel/README.md:127](/Users/brandon/Downloads/deepseek-harness/packages/session/session-telemetry-otel/README.md:127)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where SDK behavior governs and where export guarantees end. They are current package constraints.

- **Upstream experimental tree** — `@opentelemetry/sdk-logs` is published from the upstream experimental tree; SDK API churn lands here and only here, while the seam contract does not move.
- **Live-collector behavior belongs to the SDK exporter** — authentication, TLS, throttling, and other real OTLP deployment behavior follow the upstream SDK rather than a package-owned compatibility layer.
- **Feedback-time snapshot** — `FEEDBACK_ONLY` retains no telemetry-owned copy before feedback; it reads and redacts the current canonical log when feedback is recorded, so a crash before feedback uploads nothing and policy changes before feedback affect what that replay exports.

<a id="dev-note"></a>
```

## [packages/session/session-telemetry/README.md:108](/Users/brandon/Downloads/deepseek-harness/packages/session/session-telemetry/README.md:108)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the delivery and data-protection guarantees a deployment gets. They are current package constraints.

- **Best-effort delivery** — the cursor marks handed-off, not delivered; a session torn down inside a reload window cannot be re-adopted, and whatever sits in a backend queue at crash time is lost. A durable outbox (spool, per-sink cursors, at-least-once) is deferred until a deployment states a crash-loss requirement.
- **No built-in redaction rules** — with no `sessionTelemetry/record` listener mounted, records leave the process exactly as captured, including any credentials embedded in file contents or command output; a deployment exporting to a shared collector owns its rule set.
- **On-demand redaction uses current state** — uncaptured events exist only in the canonical session log; a later `captureSession()` deep-copies and redacts their current values with the policy mounted at that time, and there is no capture-time telemetry snapshot or durable pre-capture spool.

<a id="dev-note"></a>
```

## [packages/session/session-title-all-prompts-llm/README.md:99](/Users/brandon/Downloads/deepseek-harness/packages/session/session-title-all-prompts-llm/README.md:99)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define how the provider treats long and heterogeneous sessions. They are current package constraints.

- **No summarization-of-summaries** — input overflow retains the prior title; this provider has no summarization-of-summaries or retention policy for very long sessions.
- **Messages are treated equally** — it treats all eligible human messages alike and offers no weighting, filtering, or manual-title precedence.

<a id="dev-note"></a>
```

## [packages/session/session-title-first-prompt-llm/README.md:99](/Users/brandon/Downloads/deepseek-harness/packages/session/session-title-first-prompt-llm/README.md:99)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this provider stops representing the session. They are current package constraints.

- **First message may go stale** — the first message alone may cease to represent a long-running session; use the all-messages provider when later prompts should retitle it.
- **Forks never retitle automatically** — a fork keeps its inherited title and never runs this provider automatically, even when its seeded first message came from the parent.

<a id="dev-note"></a>
```

## [packages/session/session-title-llm/README.md:111](/Users/brandon/Downloads/deepseek-harness/packages/session/session-title-llm/README.md:111)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the accepted generation shapes. They are current package constraints.

- **Text output only** — the helper accepts text output and rejects tool calls; structured-output adapters and provider-specific prompt variants are not exposed.
- **Whole-prompt byte ceiling** — it enforces a byte ceiling for the whole framed user prompt rather than clipping individual messages or applying a retention policy.

<a id="dev-note"></a>
```

## [packages/session/session-title/README.md:131](/Users/brandon/Downloads/deepseek-harness/packages/session/session-title/README.md:131)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the title service does not provide. They are current package constraints.

- **No title deletion, search, or list indexing** — unpinning back to automatic titles without an explicit `refresh`, search, and list indexing are outside this service.
- **At most one provider** — the registry deliberately accepts a single implementation, so a deployment cannot compose competing title strategies without writing one provider that owns their precedence.

<a id="dev-note"></a>
```

## [packages/settings/settings-file/README.md:130](/Users/brandon/Downloads/deepseek-harness/packages/settings/settings-file/README.md:130)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Same-namespace conflicts stay last-write-wins** — the writer lock and read-modify-write keep concurrent writers from dropping each other's namespaces, but two writers editing one namespace still resolve to the later write; there is no per-value merge or revision check.
- **A missed watcher event stays unseen until the next signal** — reads never re-stat the file, so a change the watcher fails to report is only folded in by the next event, the next write, or a restart.
- **Comment preservation is YAML-only and map-shaped** — JSON documents re-serialize without comments, and comments inside a changed array, or attached inline to a changed scalar value, go with the value they described.
- **No value indirection** — sections hold literal values; `${env:VAR}`-style references for secrets are a deferred seam-level feature.

<a id="dev-note"></a>
```

## [packages/settings/settings/README.md:150](/Users/brandon/Downloads/deepseek-harness/packages/settings/settings/README.md:150)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the service is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **Single user layer** — resolution knows schema defaults, one composition `base`, and one user document; it does not record which layer supplied each resolved value.
- **The serialized schema carries a secret's default** — `redactSecrets` maps `object`, `dict`, `array`, `tuple`, `union`, and `intersect` onto the value position by position and removes any subtree whose node kind it cannot map, so a `role('secret')` value does not ride a response. The envelope is separate: `schema.toJSON()` carries a secret field's `.default(...)` to every client, and a write rejection returns schema text that can quote the submitted value.
- **Cross-process concurrency is provider-defined** — the service serializes writes per namespace in-process only; concurrent processes converge by provider behavior (the file provider read-modify-writes under a writer lock, so namespaces survive concurrent writers and same-namespace conflicts resolve last-write-wins).

<a id="dev-note"></a>
```

## [packages/shell/bash-local/README.md:131](/Users/brandon/Downloads/deepseek-harness/packages/shell/bash-local/README.md:131)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this executor is a poor fit. They are current package constraints, not a roadmap.

- **Unconfined by itself** — commands run with the harness process's authority; deployments needing confinement compose `dsh-bash-sandbox`, while per-call allow/deny/ask policy belongs on the tools' `pre-execute` waterfall.
- **No persistent shell or PTY** — every call starts a fresh non-login `bash -c`; cwd-only persistence and interactive terminal sessions remain deferred until a real workflow requires them.
- **POSIX-only** — the `bash` binary is hardcoded and the underlying service's group semantics are POSIX; Windows is unsupported.
- **A background spawn-failure note is single-delivery** — the subprocess service buffers no output for a process that never ran, so the executor injects `spawn failed: …` into exactly one `readOutput()` delta; a reader that discards that delta cannot recover it.

<a id="dev-note"></a>
```

## [packages/shell/bash-sandbox/README.md:165](/Users/brandon/Downloads/deepseek-harness/packages/shell/bash-sandbox/README.md:165)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this executor is not a general security boundary. They are current package constraints, not a roadmap.

- **Confinement covers file effects only** — network restriction and a uniform process-visibility guarantee are absent, so the modes are not a general-purpose security sandbox.
- **Denials are inferred from failed-command stderr** — backend signatures make the inference portable, but a matching application error can be classified as a denial and a denial omitted from the retained tail can be missed.
- **An asynchronously observed background runner failure has no immediate error channel** — it is recorded on the settled process and surfaces when the caller reads the generic task with `job_output`; a synchronous subprocess throw that names the runner path instead fails `start()` immediately.
- **`danger-full-access` deliberately bypasses `ctx.sandbox`** — it is an explicit unconfined mode, not a wider sandbox profile.

<a id="dev-note"></a>
```

## [packages/shell/pwsh-local/README.md:137](/Users/brandon/Downloads/deepseek-harness/packages/shell/pwsh-local/README.md:137)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this executor is a poor fit. They are current package constraints, not a roadmap.

- **Unconfined by itself** — commands run with the harness process's authority; deployments needing confinement compose a sandboxing executor or policy instead.
- **No persistent shell or PTY** — every call starts a fresh `pwsh -Command`.
- **The command string is PowerShell text** — the `-Command` domain has no shell-quoting layer, but a model-facing command is parsed by PowerShell itself, so PowerShell syntax errors are command failures, not launch failures.
- **A background spawn-failure note is single-delivery** — the subprocess service buffers no output for a process that never ran, so the executor injects `spawn failed: …` into exactly one `readOutput()` delta; a reader that discards that delta cannot recover it.
- **Windows termination reports no signal** — a force-killed process settles as exit 1 with `signal: null`, so signal-based status classification does not apply on Windows; `kill()`-initiated stops still stamp `killed` directly.
- **The encoding preamble precedes the command** — PowerShell requires `param(...)`, `#requires`, and `using` statements at the very top of a script, so a command whose first statement is one of those cannot run under the UTF-8 output preamble; wrap a `param(...)` script in `& { … }`, and run `using`/`#requires` scripts from a file instead.
- **Non-ASCII stdin under Windows PowerShell 5.1 may be mis-decoded** — the preamble pins output encoding only; `[Console]::InputEncoding` stays at the host default because setting it under redirected stdin throws; pwsh 7 defaults to UTF-8 and is unaffected.

<a id="dev-note"></a>
```

## [packages/shell/pwsh-sandbox/README.md:135](/Users/brandon/Downloads/deepseek-harness/packages/shell/pwsh-sandbox/README.md:135)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this executor is only a partial boundary on Windows. They are current package constraints, not a roadmap.

- **Reads are unrestricted on Windows** — the ACL runner restricts writes only; the read boundary is documented in `@deepseek-ai/dsh-sandbox-windows-acl`.
- **Windows workspace-write temp authority is private** — per live session/workspace pair; agentless calls receive a fresh private directory per invocation; the ambient temp root is never granted, and the runner rewrites `TMP`/`TEMP` to the private directory before spawning.
- **Windows read-only grants no explicit writable root but remains partial** — the restricted token must retain Everyone; objects whose DACL grants Everyone write access — including compatible opens of the NUL device — remain ambient authority, while PowerShell's `> $null` redirection still works without opening NUL.

<a id="dev-note"></a>
```

## [packages/shell/shell-env/README.md:122](/Users/brandon/Downloads/deepseek-harness/packages/shell/shell-env/README.md:122)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the registry is a poor fit or needs care. They are current package constraints, not a task backlog.

- **`list()` enumerates plugin-contributed variables only** — registry-owned built-ins (`DSH_HOME`, `DSH_SHELL`, `DSH_SESSION_ID`) are not included, so diagnostics, prompt, or UI code must not treat `list()` as an exhaustive environment catalog.
- **`DSH_SESSION_JSONL` is a location hint, not a guarantee** — the file may not exist before the first flush and may not contain the current buffered turn, and the value is not an authorization credential.

<a id="dev-note"></a>
```

## [packages/shell/shell/README.md:128](/Users/brandon/Downloads/deepseek-harness/packages/shell/shell/README.md:128)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the seam does not provide. They are current package constraints, not a roadmap.

- **No interactive-input vocabulary** — `stdin` is written once at spawn and closed; the seam has no channel to feed a running task and no PTY session concept.
- **Foreground timeouts are always executor-owned** — a caller-owned-deadline mode on the seam is explicitly deferred by the [tool-call timeout-policy note](../../../.agents/notes/implemented/architecture/2026-07-07-tool-call-timeout-policy.md).

<a id="dev-note"></a>
```

## [packages/shell/tool-shell-persistent/README.md:151](/Users/brandon/Downloads/deepseek-harness/packages/shell/tool-shell-persistent/README.md:151)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the tool is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **The tool requires an owning Agent and a real PTY backend whose shell matches the dialect** — agent-less calls, a dialect-mismatched backend, and backends that cannot start an interactive shell fail.
- **The pwsh dialect cannot suppress input echo** — PowerShell's PSReadLine renders submitted input back into the terminal stream and has no `stty -echo` equivalent. The marker-anchored extraction excludes the echo in complete results, and the wrapper-source strip covers fallback paths, but a wrapper that wraps across the terminal width may leave a partial echo in partial-output results, bounded by `maxOutputChars`.
- **Raw ESC characters inside pwsh commands are unsupported** — PSReadLine consumes them before execution. The wrapper escapes the control bytes it needs (`[char]27`-built OSC markers, backtick escapes for the body).
- **A model redefinition of the pwsh `prompt` function removes the readiness marker** — the shell then settles on the silence tier instead of the marker fast path.
- **SIGTSTP/SIGHUP are unavailable on Windows** (backend-rejected); SIGINT is delivered as a console-wide Ctrl-C input write, which at a prompt cancels the pending line instead of signalling a process.
- **An interactive foreground child returns early with partial output only where the subprocess provider proves its stdin wait** — elsewhere the call runs to `timeoutMs`.
- **Explicit `exit` and timeout discard shell state** — cancellation also resets and discards the result, even when a complete status marker is already observable; the next call starts a fresh shell.
- **Environment facts such as network access and package mirrors belong in the configured `description`** — not this package's default.

<a id="dev-note"></a>
```

## [packages/shell/tool-shell/README.md:228](/Users/brandon/Downloads/deepseek-harness/packages/shell/tool-shell/README.md:228)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the tool is a poor fit or needs special care. They are current package constraints, not a task backlog.

- **Replay exit pills parse from result text** — output whose final line happens to be exactly `[exit code: N]` / `[killed by signal: …]` shows a wrong pill on session replay and loses that line from the card body, because the parse treats it as the marker it consumes; a display-only known residual.
- **The tool opts out of `timeout-policy` budgets** — it keeps the executor-owned `BASH_TIMEOUT` path, per [the tool-call timeout-policy Agent Note](../../../.agents/notes/implemented/architecture/2026-07-07-tool-call-timeout-policy.md).
- **Background processes have no executor timeout** — callers must use `job_kill`, or rely on owner/service disposal, when work no longer matters.
- **The pwsh dialect gates its Windows sandbox paragraphs on confinement, not on the platform** — the ConstrainedLanguage and named-pipe contracts are Windows-restricted-token behavior, but the description adds them whenever any confining executor is mounted. Every shipped pwsh-plus-confinement composition is win32-only, so the gate is equivalent today; a POSIX `dsh-pwsh-sandbox` composition would need a platform gate instead.
- **No persistent shell** — every call starts a fresh process; the persistent-shell counterpart is [`@deepseek-ai/dsh-tool-shell-persistent`](../tool-shell-persistent/README.md), which keeps one owner-scoped shell alive across calls.
- **No dialect translation** — the model must write commands in the mounted dialect's language; the tool never rewrites bash into PowerShell or the reverse.

<a id="dev-note"></a>
```

## [packages/skill/skill-badge/README.md:100](/Users/brandon/Downloads/deepseek-harness/packages/skill/skill-badge/README.md:100)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the bundled provider does not do. They are current package constraints, not a task backlog.

- **One fixed skill, no runtime customization** — the provider contributes exactly the `dsh-badge` skill; deployments that need another badge variant author their own skill instead.
- **Remote Markdown relies on Shields.io** — the remote badge markup embeds a Shields.io image; use the packaged PNG when the target cannot fetch remote images reliably.

<a id="dev-note"></a>
```

## [packages/skill/skill-filesystem/README.md:139](/Users/brandon/Downloads/deepseek-harness/packages/skill/skill-filesystem/README.md:139)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Discovery is one level deep** — only `<root>/<name>/SKILL.md` and `<root>/<name>.md` are recognized; nested skill trees and package manifests are ignored.
- **Project scope is the nearest `.git` ancestor** — workspaces without that marker fall back to the supplied cwd, with no alternate project-root marker or monorepo subproject selection.
- **Malformed entries disappear with a warning** — the model catalog receives no per-skill diagnostic and cannot distinguish an absent skill from an invalid one; unexpected I/O failures preserve the last-good catalog instead.
- **Missing-root observation polls one path segment** — roots absent at startup use `fs.watchFile` at `watchPollIntervalMs` until Chokidar can attach, trading bounded detection latency for reliable creation detection across IDE, Git, and shell workflows.
- **No body revision protocol** — a loaded body is ordinary retained tool history; later file edits affect later calls but neither rewrite old results nor announce that the body changed.

<a id="dev-note"></a>
```

## [packages/skill/skill/README.md:129](/Users/brandon/Downloads/deepseek-harness/packages/skill/skill/README.md:129)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the registry is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Invalidation is provider-driven** — the registry has no TTL and cannot infer that an arbitrary remote source changed; each mutable provider must retain and call its registration-scoped `invalidate()` capability from its own observation mechanism.
- **Providers are queried sequentially** — one slow provider delays every provider registered after it; cancellation stops the caller's wait but cannot terminate work an uncooperative provider keeps running.
- **Incomplete observations are not retained** — rejected providers are omitted and explicitly supplied candidates remain available only to the current lookup; the registry owns neither a last-good catalog nor per-provider diagnostics.
- **Duplicate resolution is first-wins** — later lower-priority candidates within a layer are logged and hidden, and a nearer layer shadows a farther one silently; there is no API to inspect all shadowed definitions.

<a id="dev-note"></a>
```

## [packages/skill/tool-skill/README.md:238](/Users/brandon/Downloads/deepseek-harness/packages/skill/tool-skill/README.md:238)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the catalog or the loader is a poor fit. They are current package constraints, not a task backlog.

- **The catalog omits `whenToUse`, source, and provider metadata** — routing is based only on name and a capped description; `whenToUse` remains provider metadata and is not rendered by the loaded wrapper either.
- **Loaded instruction bodies have no size cap** — a provider can return a skill large enough to consume substantial next-step context; only catalog descriptions are truncated.
- **Resources are guidance, not attachments** — the tool reports a base directory/URL/opaque hint but neither enumerates nor fetches referenced files for the model.
- **Loading is one-shot text** — there is no partial, streaming, or cached-content handle when a remote provider is slow or a skill body is large.
- **Catalog replacement is whole-list** — one changed name or description appends every visible summary; this keeps stale-name retirement explicit but costs tokens proportional to the catalog.
- **Bodies are not versioned** — body-only edits do not change the catalog digest or notify the model; a later tool call reads the current provider content while earlier tool results remain historical facts.

<a id="dev-note"></a>
```

## [packages/spill/spill-local/README.md:120](/Users/brandon/Downloads/deepseek-harness/packages/spill/spill-local/README.md:120)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the local backend is a poor fit or needs operational care. They are current package constraints.

- **A long-lived deployment is not swept until restart** — the one-shot sweep runs only after activation, so files that cross the age cutoff during a run are reclaimed on the next start.
- **Locators require a co-located filesystem consumer** — a remote or virtual deployment needs another `SpillStore` backend whose locator and retrieval hint are meaningful there.
- **Windows creation is not owner-only** — the `0700` root and `0600` file modes do not exist on Windows, so both inherit the access-control list of the directory they land in. Only the cleanup sweep audits an access-control list, and it audits the roots it sweeps rather than the files this backend writes; set `root` to a directory only your account can reach whenever the ambient temp directory is not one.

<a id="dev-note"></a>
```

## [packages/spill/spill-policy/README.md:135](/Users/brandon/Downloads/deepseek-harness/packages/spill/spill-policy/README.md:135)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the policy cannot help. They are current package constraints.

- **Only final plain-text results are spillable** — mixed-content results, blocked feedback, and `read` pass through; provider truncation or tool-owned retention that happened earlier cannot be recovered here.
- **A notice that cannot fit disables replacement for that call** — a tiny cap or long locator leaves the oversized original inline after the backend has already saved an unreferenced spill.

<a id="dev-note"></a>
```

## [packages/spill/spill/README.md:129](/Users/brandon/Downloads/deepseek-harness/packages/spill/spill/README.md:129)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the spill storage service is incomplete on its own. They are current package constraints.

- **No retrieval or deletion API** — consumers can only render the backend's locator and guidance; lifecycle and access semantics remain backend-specific.
- **Storage is not access control** — the owner session namespaces writes but does not authorize reads of a locator; each backend and retrieval consumer must enforce its own boundary.

<a id="dev-note"></a>
```

## [packages/storage/storage-domain/README.md:144](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-domain/README.md:144)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the domain layer is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Single-process change visibility** — `domain/changed` is an in-process event; a second host process or a reconnecting GUI observes no changes until the cross-process revision pattern lands ([Agent Note](../../../.agents/notes/proposed/architecture/2026-07-24-domain-kv-storage-and-workspace.md)).
- **No cross-table transactions, secondary indexes, or multi-segment keys** — each write touches one record; these extensions are deferred in the Agent Note's out-of-scope list.
- **No data migration** — a domain whose stored version differs from its spec rejects at open (`version-mismatch`); changing a schema requires migrating the stored data by hand.

<a id="dev-note"></a>
```

## [packages/storage/storage-json/README.md:135](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/README.md:135)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this backend is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **`single` rewrites the whole unit** — each write republishes the complete unit file; use `per-record` or route the domain to SQLite when this cost is too high.
- **No cross-process write locking** — two processes writing the same unit can interleave replacements; writes to the same file use last-completion wins.
- **Windows rename without explicit write-through** — durability relies on libuv's `rename()` (`MoveFileExW` with replacement); the stricter Win32 write-through publish helper from the session-log backend is planned to move down here when the `log` facet lands.

<a id="dev-note"></a>
```

## [packages/storage/storage-sqlite/README.md:122](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-sqlite/README.md:122)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this backend is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Synchronous driver blocks the event loop** — each write is a synchronous `DatabaseSync` call; the block lasts a single statement, which is acceptable at domain-data scale.
- **No busy-wait or retry policy** — a competing connection holding a write lock rejects the operation immediately instead of waiting; the domain layer's write chain serializes writes within one process, and cross-process coordination is out of scope.
- **Only the current physical layout version opens** — any other stamped `user_version` is rejected rather than migrated (pre-release stance).
- **Open sequence duplicated from the session packages** — `openDatabase` mirrors the session-persistence SQLite open sequence; extraction into a shared medium layer is deferred to the planned session-backend migration.

<a id="dev-note"></a>
```

## [packages/storage/storage/README.md:124](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage/README.md:124)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the hub cannot do. They are current package constraints, not a task backlog.

- **`kv` is the only data shape** — a backend implements one facet; the `log` facet for session event logs is deferred to the session-backend migration ([Agent Note](../../../.agents/notes/proposed/architecture/2026-07-24-domain-kv-storage-and-workspace.md)).
- **Forms resolve lazily** — reading `ctx.storage.domain` before the domain plugin mounts throws `form-not-mounted`; assemblies order plugins accordingly rather than silently deferring.

<a id="dev-note"></a>
```

## [packages/subagent/agent-team/README.md:200](/Users/brandon/Downloads/deepseek-harness/packages/subagent/agent-team/README.md:200)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what a team cannot do yet or what needs special operational care. They are current package constraints, not a comparison with other coordination mechanisms.

- **Prerelease with no stability promise** — the package publishes at `0.x` alpha and its contracts still change freely.
- **One process and one shared checkout** — members share cwd and observe edits immediately; this package provides no worktree, remote member, merge, or filesystem lock.
- **Write scopes exclude tasks, not writers** — the board refuses two in-progress tasks on overlapping prefixes, but Bash, formatters, code generators, and direct external writers can still write anywhere and bypass filesystem version checks; Leads must review the final diff.
- **Flat immutable roster** — only the Lead creates direct teammates; there is no nested Team, rename, deletion, or name reuse.
- **No automatic ownership release** — idle, interruption, process exit, and failed work do not release a task owner.
- **Mailbox is not cross-process exactly-once** — concurrent harness processes over one Team are unsupported.

<a id="dev-note"></a>
```

## [packages/subagent/subagent-acp/README.md:152](/Users/brandon/Downloads/deepseek-harness/packages/subagent/subagent-acp/README.md:152)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this backend is a poor fit or needs special operational care. They are current package constraints, not a general ACP comparison or a task backlog.

- **A fresh process per run** — there is no process pooling; each delegation pays the full spawn and ACP handshake cost.
- **Local workspaces only** — the resolved working directory is a local path handed to a child on the same machine; remote workspace mapping is not designed.
- **No optional start-time capabilities** — this provider cannot apply `agentOptions`, `outputSchema`, a depth cap, a tool filter, or a persona inside the remote process, so the seam rejects requests that require them.
- **Only committed `agent_message_chunk` text is collected** — the automation server keeps reasoning, tool activity, plans, and other trace data in the child session log rather than emitting them on ACP.
- **Permission prompts are auto-answered** (`permission: allow | reject`) — no human is surfaced a child's `session/request_permission`.

<a id="dev-note"></a>
```

## [packages/subagent/subagent-claude-code/README.md:167](/Users/brandon/Downloads/deepseek-harness/packages/subagent/subagent-claude-code/README.md:167)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this provider is a poor fit or needs special operational care. They are current package constraints, not a general Claude Code comparison or a task backlog.

- **One fresh query and process per run** — there is no continuation, resume, pooling, progress stream, or product-session persistence.
- **Static instance selection** — Profile rows fix provider names, optional models, and tool bindings; calls cannot choose or change either a provider or model dynamically, and every exposed tool needs a unique `toolName`.
- **Host settings are intentionally authoritative** — when `model` is omitted, project and user settings choose it; native settings always retain the remaining tools and behavior, and the provider does not provide a filtered or hermetic production mode.
- **Authentication and account state remain native** — the Bundle supplies the CLI but does not create an account, log in, or rewrite Claude settings; configuration and authentication failures surface with their lifecycle stage and the safe `unknown` fallback rather than a separate public classification.
- **The SDK platform payload is required at delegation time** — installs that omit optional dependencies, unsupported platforms, and missing or damaged payloads fail at the first query; there is no host-CLI fallback.
- **No human interaction path** — `AskUserQuestion` is disabled, permission prompts are denied, MCP elicitation is declined, and blocking dialogs fail closed instead of suspending.
- **Assistant payload is final text only** — reasoning, intermediate messages, tool traffic, usage, stderr, and workspace diffs remain product-local.
- **No optional shared capabilities** — `agentOptions`, output schemas, child personas, tool filtering, and harness depth enforcement are rejected by the shared service for this provider.
- **No wall-clock timeout or side-effect rollback** — the caller cancels long work, and files or external systems changed before cancellation are not restored.

<a id="dev-note"></a>
```

## [packages/subagent/subagent-codex/README.md:165](/Users/brandon/Downloads/deepseek-harness/packages/subagent/subagent-codex/README.md:165)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this provider is a poor fit or needs special operational care. They are current package constraints, not a general Codex comparison or a task backlog.

- **One fresh process, thread, and turn per run** — there is no continuation, resume, pooling, progress stream, or product-session persistence.
- **Static instance selection** — Profile rows fix provider names, optional models, and tool bindings; calls cannot choose or change either a provider or model dynamically, and every exposed tool needs a unique `toolName`.
- **Authentication and account state remain native** — the Bundle supplies the CLI but does not create an account, log in, trust a project, or rewrite Codex settings; configuration and authentication failures surface with their lifecycle stage and the safe `unknown` fallback rather than a separate public taxonomy.
- **The native platform payload is required at delegation time** — installs that omit optional dependencies, unsupported platforms, and missing or damaged payloads fail at the first run; there is no host-CLI fallback.
- **Compatibility is pinned by development evidence** — upgrading from the verified 0.149.1 protocol baseline requires regenerating upstream schema evidence and rerunning handshake, answer-selection, approval, cancellation, keyless real-product, and credentialed DeepSeek nonce tests.
- **No human approval path** — known unattended approval requests are denied and unknown server requests fail closed; the three Profile modes never create a DSH interaction channel or per-call allow policy.
- **Assistant payload is final text only** — a failed run may additionally expose the separate safe diagnostic; reasoning, commentary, intermediate messages, tool traffic, usage, raw stderr, and workspace diffs remain outside the parent Session, while generic Job ids, notices, and status come from the shared job runtime.
- **No optional shared capabilities** — `agentOptions`, output schemas, child personas, tool filtering, and harness depth enforcement are rejected by the shared service for this provider.
- **No wall-clock timeout or side-effect rollback** — the caller cancels long work, and files or external systems changed before cancellation are not restored.

<a id="dev-note"></a>
```

## [packages/subagent/subagent-dsh-sdk/README.md:165](/Users/brandon/Downloads/deepseek-harness/packages/subagent/subagent-dsh-sdk/README.md:165)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this backend is a poor fit or needs special operational care. They are current package constraints, not a general SDK comparison or a task backlog.

- **A fresh runtime process per run** — no pooling; a harness runtime boots a full plugin tree, so per-run spawn cost is higher than the ACP backend's typical child.
- **No non-route start-time capabilities** — the parent can select the child agent route but cannot enforce `outputSchema`, depth, tool filters, or persona inside the child process; configure the selected child profile and its ordered patches instead.
- **The child's transcript stays in the child's own session root** — the parent log records only the delegation tool call and result; the streamed `session.event` channel is consumed for output extraction, not bridged into the parent log.
- **Local child processes only** — the resolved working directory is a local path; a remote runtime would need its own backend.

<a id="dev-note"></a>
```

## [packages/subagent/subagent-fork-in-process/README.md:138](/Users/brandon/Downloads/deepseek-harness/packages/subagent/subagent-fork-in-process/README.md:138)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the backend is the wrong choice; they are current package constraints.

- **The seed is a one-time snapshot** — the child sees the parent's completed turns as of the fork and nothing the parent logs afterwards; there is no live context sharing.
- **Fork lifecycle policy differs by composition** — the base bundle and ACP/headless examples use one-shot fork to preserve prefix reuse, while the CLI presets use continuable fork and accept the child-scoped [`report` return channel](../tool-subagent-report/README.md) invalidating that prefix. Making continuable fork cache-preserving requires the child system prompt and tool schemas to match the parent's byte for byte. Rationale and the reintroduction condition: the [cache-preserving fork Agent Note](../../../.agents/notes/implemented/architecture/2026-08-10-fork-children-stay-one-shot.md).
- **Shipped fork tools do not expose child LLM route selection** — they inherit the parent's provider and model so the copied history remains eligible for KV Cache reuse. Route selection stays disabled until a change can preserve reuse or expose a bounded recomputation cost; the [model-selected route Agent Note](../../../.agents/notes/implemented/feature/2026-08-18-model-selected-subagent-routes.md) owns that restriction.

<a id="dev-note"></a>
```

## [packages/subagent/subagent-in-process-driver/README.md:159](/Users/brandon/Downloads/deepseek-harness/packages/subagent/subagent-in-process-driver/README.md:159)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what an in-process one-shot run cannot do; they are current package constraints.

- **Runs expose no `sendMessage`/`resume`** — the optional runtime capabilities are absent on in-process one-shot runs.
- **Structured capture accepts the `defineTool` schema subset only** — unsupported JSON Schema constructs fail before the child is created; a provider needing a broader schema vocabulary requires a different runtime.

<a id="dev-note"></a>
```

## [packages/subagent/subagent-spawn-in-process/README.md:133](/Users/brandon/Downloads/deepseek-harness/packages/subagent/subagent-spawn-in-process/README.md:133)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the backend is the wrong choice; they are current package constraints.

- **Fresh means no parent transcript** — the child inherits cwd, lineage, provider, model, reasoning effort, output-token limit, and explicitly configured persona or tool restrictions, but none of the parent's conversation; use the fork backend when completed-turn context is required.

<a id="dev-note"></a>
```

## [packages/subagent/subagent/README.md:157](/Users/brandon/Downloads/deepseek-harness/packages/subagent/subagent/README.md:157)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the seam is a poor fit or needs special operational care. They are current package constraints, not a general delegation comparison or a task backlog.

- **ACP children remain one-shot and are not trace-enumerable** — an ACP run has no local child session in the parent's session corpus, and remote providers need an Activation ownership contract before they can support continuable children.
- **No host-user continuation** — `followup()` requires the exact live direct parent; only `interrupt()` accepts a durable human parent address.
- **Continuation messages never steer** — parent-to-child follow-ups enqueue later turns; they never redirect the child's current turn.
- **Wake gap during cancellation convergence** — a follow-up accepted after an interrupt signal but before the driver becomes idle stays queued until another waking send.
- **Process-local residency** — the Activation inbox and ownership graph do not coordinate two harness processes; concurrent access to one persistence store needs a durable mailbox and cross-process lease protocol.
- **No replay of accepted-but-unlogged messages** — a crash can lose an accepted prompt that never reached the child's session log; the lost message is not replayed automatically.
- **No durable report mailbox** — reports require a live direct parent and provide acceptance identity rather than exactly-once delivery.
- **Lifecycle events are observe-only** — a run-affecting `subagent/end` continuation or decision API waits for a concrete consumer.

<a id="dev-note"></a>
```

## [packages/subagent/tool-agent-team/README.md:147](/Users/brandon/Downloads/deepseek-harness/packages/subagent/tool-agent-team/README.md:147)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits describe what the policy and tools cannot guarantee for a team. They are current package constraints, not a comparison with other collaboration surfaces.

- **Prompt policy is coordination, not confinement** — it cannot stop Bash or external processes from writing overlapping files.
- **Delegation follows the configured policy** — `delegated` requires an explicit team request; `swarm` instructs the Lead to create tasks and teammates for parallel work.
- **No Web controls** — browser roster and task-board presentation is outside this runtime package.
- **Prerelease with no stability promise** — the package publishes at `0.x` alpha and its schemas still change freely.

<a id="dev-note"></a>
```

## [packages/subagent/tool-subagent-control/README.md:164](/Users/brandon/Downloads/deepseek-harness/packages/subagent/tool-subagent-control/README.md:164)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the control tools cannot observe or steer; they are current package constraints.

- **A queued message has no independent result** — acceptance returns only its inbox `messageId`; the child's work lands in the durable child Session and is never collected through this tool. A child granted `report` may send selected content back separately, but that message is not this call's result.
- **No steering of the current turn** — every message opens a later FIFO turn, so a message sent while the child is working runs only after its current turn finishes and cannot redirect it.
- **Listing is a snapshot, not a delivery promise** — it may race publication, disposal, or a later message, and another process may activate a child this process reports as `ready`; cross-process accuracy requires a shared lease. `interrupt_agent` performs the authoritative live-lineage check itself, so discovery staleness cannot grant authority.
- **No pagination or deletion** — the complete stably ordered set is returned, and persisted children remain listed for as long as their sessions remain in persistence; a service-level bound or delete operation is a later product decision.

<a id="dev-note"></a>
```

## [packages/subagent/tool-subagent-report/README.md:153](/Users/brandon/Downloads/deepseek-harness/packages/subagent/tool-subagent-report/README.md:153)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what an accepted report does and does not guarantee; they are current package constraints.

- **A parent whose host-owned disposal already started can still accept** — `AgentHandle.dispose()` cancels, awaits quiescence, and only then unwinds the scope and leaves the registry; it exposes no signal for "disposal started." A report accepted in that window is appended to the parent's transcript, but that parent will not act on it in this process. A continuation-manager-owned parent rejects forest teardown through the manager's admission boundary.
- **Acceptance is weaker than durable delivery** — there is no durable mailbox, idempotency key, delivery receipt, retry protocol, or exactly-once claim. A process failure after one side recorded acceptance leaves the outcome ambiguous, and an external retry may duplicate the report.
- **A staged quiet report is not immediately reconstructable** — acceptance returns its stable `MessageId`, but the parent Session reconstructs the framed content only after pending context reaches its ordinary log boundary.
- **Granting waits for the next Activation; revocation is immediate** — installing this package after a child becomes resident grants `report` and its guidance only on that child's next Activation, while removing the package revokes both from resident children immediately.
- **Nested reporting reaches exactly one edge upward** — a grandchild reports to its direct child parent, never to the top-level coordinator, which must explicitly report a derived update later.
- **No rate limiting** — the default `next-step` mode can amplify model work when nested children report frequently, although reports waiting together share one step; a deployment that accepts unread reports over that amplification selects `quiet`.

<a id="dev-note"></a>
```

## [packages/subagent/tool-subagent/README.md:206](/Users/brandon/Downloads/deepseek-harness/packages/subagent/tool-subagent/README.md:206)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what this tool does not return or enforce; they are current package constraints.

- **Background runs expose no result through this tool** — a one-shot task's final output is collected through the generic task surface, and a continuable child's output stays in its own session, read by its subagent id. The settlement notice states how that child ended and carries any final assistant message, but it is not this call's return value and cannot be awaited here.
- **Duplicate names across waiting one-shot instances are detected late** (`TODO(subagent-dup-toolname)`) — continuable instances reserve their prompt-section name during plugin application, but preventing provider-registration rollback for waiting one-shot instances requires a registry of intended names.
- **Shipped fork tools cannot select a child LLM route** — they inherit the parent's provider and model to keep the copied conversation prefix eligible for KV Cache reuse. Re-enable selection only when route changes preserve reuse or expose a bounded recomputation cost.
- **Non-routing child policy is fixed per instance** — another persona, tool filter, or depth cap requires another distinctly named tool. LLM selection requires an enabled per-Session preference and a provider that advertises `agentOptions`; both in-process providers and DSH SDK advertise it, while ACP, Codex, and Claude Code reject it rather than ignore it.

<a id="dev-note"></a>
```

## [packages/subprocess/subprocess-local/README.md:121](/Users/brandon/Downloads/deepseek-harness/packages/subprocess/subprocess-local/README.md:121)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit or needs special operational care. They are current package constraints, not a general platform comparison or a task backlog.

- **Windows tree support is best-effort** — termination routes through `taskkill /PID <pid> /T /F` with all outcomes contained (absent tree, races, missing binary), and liveness falls back to the direct-child boundary.
- **Windows terminal signalling is console-wide** — SIGINT is delivered as a `\x03` Ctrl-C input write that conhost turns into a console-wide CTRL_C event; SIGTSTP and SIGHUP are rejected as unavailable; a `taskkill` without `/F` does not terminate console processes, so the teardown TERM tier is a grace wait before the `/F` escalation.
- **A daemonized terminal descendant can still escape the observable boundary** — on macOS, a child that reparents before any foreground-inspection snapshot is no longer discoverable from the PTY root; on Linux, a `setsid` child leaves both the tree and the owned terminal session; the provider adds no continuous process-table monitor.
- **In-process cleanup requires a JavaScript-observable exit** — direct `process.exit()`, default uncaught exceptions, and default unhandled rejections emit Node's synchronous `exit` event; an unhandled `SIGTERM`, `SIGINT`, or `SIGHUP`, `SIGKILL`, fatal OOM, `process.abort()`, native crashes, and power loss require an external supervisor, container init, or equivalent OS owner.
- **The credential scrub is a name heuristic** — `*KEY*`/`*PASSWORD*`/`*SECRET*`/`*TOKEN*` only; differently named secrets (for example `*PASSPHRASE*`) pass through, and a whitelist for over-scrubbed variables is noted future work.
- **Completed spill files are not deleted** — bounded full-output recovery files (and the private per-process spill directory) accumulate under the OS tmpdir until something external cleans them.

<a id="dev-note"></a>
```

## [packages/subprocess/subprocess/README.md:137](/Users/brandon/Downloads/deepseek-harness/packages/subprocess/subprocess/README.md:137)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the seam is a poor fit or leaves work to its consumers. They are current package constraints, not a comparison or a backlog.

- **SDK-managed spawns remain outside** — a transport that owns its internal spawn (the SDK client, MCP) cannot route that call through this service; it can still import `scrubbedParentEnv` so environment policy stays single-sourced.
- **Teardown ladders are consumer-owned** — the seam ships signalling verbs and the whole-tree wait, not a canned quiesce sequence; each out-of-process consumer encodes its child's cooperation shape itself (the ACP backend's stdin-EOF-first ladder is the in-repo template).
- **Observability is provider-specific** — a daemonized child that leaves its tree or session can outlive termination; providers document their substrate limits, and the seam adds no continuous process-table monitor.

<a id="dev-note"></a>
```

## [packages/subprocess/win32-process/README.md:65](/Users/brandon/Downloads/deepseek-harness/packages/subprocess/win32-process/README.md:65)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Windows-only native loading** — importing the generic types is portable, but resolving the binding table loads Windows DLLs and fails on other hosts. Cross-platform tests inject a binding table instead of loading native APIs.
- **No public process service** — the package intentionally does not wrap its primitives in Cordis or Node streams. A consumer must own its policy, async scheduling, output limits, cancellation, and final handle closure.
- **Inherited environment only** — process creation passes a null environment block. The sandbox establishes changes through `SetEnvironmentVariableW` first because passing an explicit block through Koffi makes `CreateProcessAsUserW` fail with `ERROR_INVALID_PARAMETER`. Other callers that need environment changes must establish them before invoking the primitive or use their own runner process.
- **Restricted-token consumer only** — ordinary `CreateProcessW`, exact `applicationName`, parent-stdio release, and whole-Job settlement are absent until an ordinary process consumer requires them.
- **Create-to-assignment interruption** — the target starts suspended and cannot execute before Job assignment, but an external termination of the runner in the narrow interval between process creation and assignment can leave the suspended target behind. The package does not claim atomic Job attachment.
- **Header evidence is architecture-specific** — the committed ABI probe and layout constants cover the repository's current 64-bit Windows targets. A new pointer width or incompatible Windows ABI requires updating the probe before support is claimed.


<a id="dev-note"></a>
```

## [packages/terminal/terminal-bash/README.md:158](/Users/brandon/Downloads/deepseek-harness/packages/terminal/terminal-bash/README.md:158)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the backend is a poor fit or needs special operational care. They are current package constraints, not a general shell comparison or a task backlog.

- **Line-oriented output only** — a headless xterm maintains control-sequence state only for terminal-protocol replies. Returned output remains normalized to lines, and full-screen alternate-buffer interaction is unsupported.
- **Readiness is heuristic without an exact tier** — exact stdin-wait detection depends on the mounted subprocess provider; providers that cannot prove it (macOS, Windows) settle on prompt-marker and silence/timeout readiness.
- **pwsh bootstrap in a constrained sandbox** — the prompt function and UTF-8 pin write through `[Console]::`, which the Windows ACL sandbox's read-only mode may deny. When that prevents marker readiness, startup rejects at `timeoutMs` instead of publishing an incomplete shell.
- **Cleanup guarantees belong to the provider** — process-tree teardown is the `SubprocessTerminalHandle` contract, not this backend's.
- **Sessions do not survive process exit** — a harness restart destroys every session.

<a id="dev-note"></a>
```

## [packages/terminal/terminal/README.md:128](/Users/brandon/Downloads/deepseek-harness/packages/terminal/terminal/README.md:128)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the service is a poor fit. They are current package constraints, not a task backlog.

- **Process-local sessions** — sessions and raw scrollback live only in this process and do not survive a harness restart; durable work must be committed to files or another persistent system.
- **No cross-agent sharing** — sessions are intentionally single-owner, with no path to share or transfer a session.
- **No declarative auto-start** — sessions are created only during agent tool calls.

<a id="dev-note"></a>
```

## [packages/terminal/tool-terminal/README.md:166](/Users/brandon/Downloads/deepseek-harness/packages/terminal/tool-terminal/README.md:166)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define the model-facing surface that is absent. They are current package constraints, not a task backlog.

- **No TUI or key-sequence surface** — named key sequences, full-screen TUI interaction, BEL, resize, and auto-start are not exposed in any schema.
- **Background mode requires the jobs surface** — `run_in_background` needs both `@deepseek-ai/dsh-jobs` and its model-facing controller (`@deepseek-ai/dsh-tool-jobs`); without them the argument is rejected.

<a id="dev-note"></a>
```

## [packages/test-support/agent-loop-testkit/README.md:94](/Users/brandon/Downloads/deepseek-harness/packages/test-support/agent-loop-testkit/README.md:94)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the helper does not share. They are current package constraints, not a task backlog.

- **Only the mandatory prerequisite spine is shared** — adapters, optional plugins, `AgentLoop`, agents, and context teardown remain caller-owned so scenario-specific ordering stays visible.

<a id="dev-note"></a>
```

## [packages/test-support/client-a11y/README.md:98](/Users/brandon/Downloads/deepseek-harness/packages/test-support/client-a11y/README.md:98)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define how the auditing is consumed. They are current package constraints, not a task backlog.

- **Automated checks cover part of accessibility** — keyboard journeys, screen-reader behavior, and understandable content also require interaction review.
- **One surface at a time** — the module audits a DOM subtree a caller already rendered. It mounts nothing and knows nothing about slots, so a suite decides what a surface is and how to build it.

<a id="dev-note"></a>
```

## [packages/test-support/client-runtime/README.md:116](/Users/brandon/Downloads/deepseek-harness/packages/test-support/client-runtime/README.md:116)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define how the bench is consumed. They are current package constraints, not a task backlog.

- **Vitest and jsdom only** — every consumer is an in-repository browser-oriented Vitest suite. The package is not a product plugin or a general Node test harness.
- **Session, Conversation, and Chat fixtures stay separate** — `sessionSnapshot` contains only Session Controller state, `conversationSnapshot` contains target-neutral Conversation state, and `chatSnapshot` contains Chat target state. Assembly tests provide Session event entries instead of adding Conversation or Chat fields to `SessionSnapshot`.

<a id="dev-note"></a>
```

## [packages/test-support/llm-mock-server/README.md:151](/Users/brandon/Downloads/deepseek-harness/packages/test-support/llm-mock-server/README.md:151)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the server needs special care. They are current package constraints, not a task backlog.

- **Random weights model test pressure, not production incidence** — callers that want an environment-specific distribution must provide measured weights and record the emitted seed.
- **Request scripts are arrival-ordered** — concurrent callers share one cursor, so deterministic per-session fault assignment requires separate server instances.
- **True connection refusal is a listener lifecycle phase** — the CLI delay must overlap the client attempt; request-level random selection can only reset an accepted connection.

<a id="dev-note"></a>
```

## [packages/test-support/llm-replay/README.md:136](/Users/brandon/Downloads/deepseek-harness/packages/test-support/llm-replay/README.md:136)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when replay cannot stand in for a live model. They are current package constraints, not a task backlog.

- **First-call-order script binding assumes sequential delegation** — a cut that runs sibling subagents concurrently would bind live sessions to recorded scripts non-deterministically; a stronger keying is deferred until such a scenario exists.
- **Only ordinary loop chunks and marked local compaction outputs are derivable** — a pure pre-chunk throw, a cancel/hang, or an unmarked external summarizer call needs the `replay.override.json` sidecar; replacement and patch forms affect only the primary session, and child scripts still derive from their logs.

<a id="dev-note"></a>
```

## [packages/test-support/loader-smoke/README.md:107](/Users/brandon/Downloads/deepseek-harness/packages/test-support/loader-smoke/README.md:107)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the harness needs special care. They are current package constraints, not a task backlog.

- **Built mode requires a prior build** — the owning package manifest must also declare every package named by the config.
- **Captured stdout and stderr are bounded only by execa's default 100 MB `maxBuffer`** — a runaway child is terminated at that ceiling rather than at a smoke-chosen budget.
- **Timeout kills only the direct child** — a process tree spawned by a faulty fixture can outlive the smoke and needs external cleanup.

<a id="dev-note"></a>
```

## [packages/test-support/session-snapshot/README.md:150](/Users/brandon/Downloads/deepseek-harness/packages/test-support/session-snapshot/README.md:150)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the kit needs special care. They are current package constraints, not a task backlog.

- **Session harvest requires raw JSONL mode** — `runScenario` collects persisted `.jsonl` logs, so snapshot configs set the JSONL backend's `compression: 'none'`; compressed JSONL and SQLite compositions have no snapshot-harvest path.
- **Built mode requires current artifacts** — run `bun run build` before selecting `DSH_EXAMPLE_MODE=lib`; source mode remains the zero-build path.
- **ACP remains for protocol behavior** — cancellation and permission round trips whose stimulus is the ACP client stay on that adapter; assembled one-shot and persistent-control behavior uses headless and SDK adapters.

<a id="dev-note"></a>
```

## [packages/todo/tool-todo/README.md:154](/Users/brandon/Downloads/deepseek-harness/packages/todo/tool-todo/README.md:154)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the tool is a poor fit. They are current package constraints, not a task backlog.

- **Single-owner scope only** — the list belongs to the one calling agent session; subagent, shared, and swarm scopes are a deliberate cut, and a non-agent caller is rejected.
- **The item shape is deliberately minimal** — `content` plus three-state `status`; whole-list replacement needs no stable id, priority, or active-form fields.
- **Whole-list replacement is the only operation** — no partial updates, no read-back tool, and no per-item edits; the model must resend the entire list each call.

<a id="dev-note"></a>
```

## [packages/typert/generator/README.md:118](/Users/brandon/Downloads/deepseek-harness/packages/typert/generator/README.md:118)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the generator cannot model or emit; they are current package constraints, not a task backlog.

- **Package export patterns are skipped** — contributing packages need concrete export targets; wildcard export patterns are not analyzed.
- **Namespace re-exports across faces fail** — named and star re-exports produce links, but a namespace re-export cannot be represented until `TypeTargetModel` can model a module namespace without flattening it.
- **The Zod emitter supports a deliberate subset** — generic schema declarations and computed constructs such as conditional or mapped schema roots fail until a concrete schema-factory policy exists.
- **No generated schema imports across faces** — cross-face links are represented for analysis, but no generated schema requires a runtime cross-face Zod import.
- **Discovery covers concrete public exports only** — declarations neither exported nor imported by the reachable graph are intentionally outside the package model.

<a id="dev-note"></a>
```

## [packages/typert/loader/README.md:107](/Users/brandon/Downloads/deepseek-harness/packages/typert/loader/README.md:107)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the loader does not discover or register; they are current package constraints, not a task backlog.

- **Host face only** — discovery imports only the host `./typert` artifact; client runtimes need a separate composition owner before equivalent discovery is added.
- **Explicit entries for nested plugins** — Loader entries are discovered automatically, but plugins nested behind another entry, or not loaded by the Loader at all, need an explicit `packages` entry or direct `ctx.typert.register()` ownership.
- **Cached verdicts never expire** — a package that gains a `./typert` export mid-process needs a restart before the loader registers it.

<a id="dev-note"></a>
```

## [packages/typert/protocol/README.md:115](/Users/brandon/Downloads/deepseek-harness/packages/typert/protocol/README.md:115)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the declarations can represent; they are current package constraints, not a task backlog.

- **Decorator markers are minimal** — markers contain only the method name and the direct or Context invocation mode; parameter, result, lookup, and schema reflection require the Typert build pipeline.
- **Remote signatures are restricted** — decorators accept only public, non-static instance methods with string names, and source-mode execution cannot represent overloaded, destructured, defaulted, or rest-parameter signatures.

<a id="dev-note"></a>
```

## [packages/typert/registry/README.md:112](/Users/brandon/Downloads/deepseek-harness/packages/typert/registry/README.md:112)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the registry stores and rejects; they are current package constraints, not a task backlog.

- **No graph merging** — the registry stores generated reflection per face but does not merge host and client graphs or resolve TypeScript references; those are analyzer and emitter concerns.
- **Schema keys omit the face** — host and client run in separate contexts, so registering same-named schemas from both faces into one context is rejected as a duplicate.
- **JSON Schema projection is uncached** — `toJSONSchema()` returns a fresh document per call; consumers that project repeatedly own caching.

<a id="dev-note"></a>
```

## [packages/util/atomic-write/README.md:116](/Users/brandon/Downloads/deepseek-harness/packages/util/atomic-write/README.md:116)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define where the package is not the right tool. They are current package constraints, not a task backlog.

- **Atomic, not durable** — no `fsync` of the file or its directory, so after a crash the rename may be observed unwound. The file-backed stores here re-read and republish on boot, keeping durability the caller's policy.
- **String content only** — no `Buffer` or stream form until a consumer needs one.
- **Orphaned locks require operator recovery** — a process that exits while holding the lock leaves the sibling behind; later writers time out without deleting it.

<a id="dev-note"></a>
```

## [packages/util/browser-locale/README.md:105](/Users/brandon/Downloads/deepseek-harness/packages/util/browser-locale/README.md:105)

```markdown
- The shipped locale set is fixed at `en` and `zh`, matching the copy the product ships. A third locale changes this module's type and every dictionary that keys on it, so the set moves deliberately rather than by configuration.
- Only the language subtag decides. `zh-Hant` and `zh-Hans` both select the Simplified Chinese dictionary, because the product ships one Chinese copy set; a script-aware choice needs a second dictionary before it needs a rule here.
```

## [packages/util/capacity-gate/README.md:123](/Users/brandon/Downloads/deepseek-harness/packages/util/capacity-gate/README.md:123)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Admission only** — the gate delays a start and never stops admitted work; every holder still owns cancellation and cleanup for the operation it ran under the slot.
- **A free slot ignores the signal** — cancellation is checked only when the caller must wait, so a holder still needs its own pre-flight check for the unsaturated path.
- **One flat queue per gate** — there is no priority, fairness class, or per-owner sub-quota; a holder that needs those composes several gates.
- **The limit is fixed at construction** — a deployment that changes its bound rebuilds the holder rather than resizing a live gate.

<a id="dev-note"></a>
```

## [packages/util/crypto/README.md:53](/Users/brandon/Downloads/deepseek-harness/packages/util/crypto/README.md:53)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **v4 only** — no other UUID versions, namespaces, or parsing; consumers needing more should take a real UUID dependency.
- **Uniqueness is probabilistic** — 122 random bits, the same guarantee `crypto.randomUUID` gives; nothing here detects collisions.


<a id="dev-note"></a>
```

## [packages/util/diagnostic-text/README.md:82](/Users/brandon/Downloads/deepseek-harness/packages/util/diagnostic-text/README.md:82)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Only `text` and `messageChain` are read** — diagnostic category, code, and file position belong to the surface that reports them, which formats those alongside this sentence rather than inside it.
- **The separator is the caller's** — the walk joins with whatever string it is handed and neither indents nested levels nor trims the result, so a surface wanting the compiler's indented chain layout formats it itself.

<a id="dev-note"></a>
```

## [packages/util/document-queue/README.md:145](/Users/brandon/Downloads/deepseek-harness/packages/util/document-queue/README.md:145)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **One document per queue** — the chain is global to the queue, so an owner storing several documents constructs several queues and gets no cross-document ordering.
- **No cross-process serialization** — the chain orders this process's operations only; a writer that must exclude another process still takes the file lock from `dsh-atomic-write` inside its queued operation.
- **A missed watcher event stays unseen** — the queue reconciles on watcher events and at watcher ready, never on a timer, so a change the platform watcher fails to report is folded in only by the next event, the next queued operation, or a restart.
- **The reload policy is fixed** — `INVARIANT` propagates and everything else warns; an owner that needs a different split calls `reconcile` inside `enqueue` and applies its own.

<a id="dev-note"></a>
```

## [packages/util/home-paths/README.md:92](/Users/brandon/Downloads/deepseek-harness/packages/util/home-paths/README.md:92)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the helpers are not the right tool. They are current package constraints, not a task backlog.

- **Expansion is deliberately narrow** — only bare `~`, `~/...`, and `~\...` use the current operating-system home; named-user forms such as `~alice/...`, environment variables, and shell expressions remain unchanged.
- **Canonicalization reads but never mutates** — `canonicalizeWatchPath` performs `realpath` probes and propagates errors other than absence; callers still own directory creation, permissions, and trust policy for the resulting path.

<a id="dev-note"></a>
```

## [packages/util/keyed-lock/README.md:59](/Users/brandon/Downloads/deepseek-harness/packages/util/keyed-lock/README.md:59)

```markdown
- **Keys are strings compared exactly.** Two spellings of one path are two keys. Callers that need path identity canonicalize before locking; `dsh-fs` backends pass the branded `FsTargetKey` their own `resolve()` minted, which is already canonical.
- **No timeout, no cancellation, and no reentrancy.** A caller that never settles holds its key forever, and an operation that calls `run` again for the key it already holds deadlocks. Both are properties of the callers this serves, where each operation is a bounded filesystem write; a queue that needed to be abandoned would need a different primitive.
- **No fairness beyond arrival order.** There is no priority, and a key under continuous load serves callers in the order they arrived rather than by any weighting.

<a id="dev-note"></a>
```

## [packages/util/launch-environment/README.md:94](/Users/brandon/Downloads/deepseek-harness/packages/util/launch-environment/README.md:94)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the snapshot is not a security boundary. They are current package constraints, not a task backlog.

- **The snapshot is not a subprocess boundary** — every layer is also materialized into `process.env`, so ordinary project variables reach child processes under [`dsh-subprocess`](../../subprocess/subprocess/README.md)'s scrub; the product launcher's [`.env` contract](../../boot/app-boot/README.md) rejects bootstrap variables before materialization.
- **No per-workspace layer** — the project layer is the invoking directory, fixed at launch; a workspace selected later in the Web UI contributes nothing, deliberately, because following it would let a model's own workspace change the harness environment mid-session.

<a id="dev-note"></a>
```

## [packages/util/native-command/README.md:98](/Users/brandon/Downloads/deepseek-harness/packages/util/native-command/README.md:98)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when this runner is not the right tool. They are current package constraints, not a task backlog.

- **No output bounding** — both streams buffer unbounded in memory; every current caller invokes small native tools whose output is a path or an error line. Adopt `dsh-output-retention` bounding before pointing this at commands with meaningful output volume.

<a id="dev-note"></a>
```

## [packages/util/output-retention/README.md:150](/Users/brandon/Downloads/deepseek-harness/packages/util/output-retention/README.md:150)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the retainers deliberately do not cover. They are current package constraints, not a task backlog.

- **Item retention supports `head` only** — tail, head/tail, pagination, grouping, and provider-completeness semantics remain tool-owned.
- **Text retention is byte-oriented** — line and character windows such as `read` pagination require a separate renderer, and a cut may discard partial UTF-8 boundary bytes to keep the returned text valid.

<a id="dev-note"></a>
```

## [packages/util/sqlite-connection/README.md:129](/Users/brandon/Downloads/deepseek-harness/packages/util/sqlite-connection/README.md:129)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Settings are connection-local** — none of them persist in the database file, so a connection some other code opens on the same file holds none of them; every opener applies them itself.
- **The requested journal mode is not judged** — the verification only proves the connection reports the mode the caller asked for; refusing a non-durable mode such as `memory` or `off` stays with each backend's validated configuration.
- **`readConnectionSettings` needs a file-backed connection** — an in-process database returns no `PRAGMA mmap_size` row, so callers reading an in-process connection query the settings they care about directly.
- **No path validation** — symlink and ownership checks belong to the backend; owner-only creation loses to a parent directory another principal can write, and a hardened connection to a file another principal can replace is still a file another principal can replace.

<a id="dev-note"></a>
```

## [packages/util/timeout/README.md:134](/Users/brandon/Downloads/deepseek-harness/packages/util/timeout/README.md:134)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the library deliberately does not do. They are current package constraints, not a task backlog.

- **Notification only** — a deadline cannot stop work that ignores its signal; every capability still needs its own socket, process, or task termination path.
- **`timeoutMs <= 0` is internal vocabulary** — it disables the local timer only after an owning backend has resolved policy, never as a public model- or plugin-facing knob.
- **The first abort reason wins classification** — when an upstream cancellation beats the local timer, this layer cannot later report that its own timeout would also have elapsed.
- **An idle watchdog is not a total deadline** — it rearms per outstanding iterator demand and deliberately excludes consumer think time.

<a id="dev-note"></a>
```

## [packages/util/workspace-path/README.md:21](/Users/brandon/Downloads/deepseek-harness/packages/util/workspace-path/README.md:21)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Resolution is lexical** — it recognizes POSIX absolute paths, Windows drive paths, and UNC paths but does not access a filesystem or canonicalize `.` and `..` segments.
- **Home abbreviation is POSIX-only** — Windows paths remain unchanged because a portable browser cannot infer Windows home-path equivalence safely.


<a id="dev-note"></a>
```

## [packages/web/tool-web/README.md:244](/Users/brandon/Downloads/deepseek-harness/packages/web/tool-web/README.md:244)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the tools are incomplete or need deployment cooperation. They are current package constraints.

- **There is no batch-wide native-search counter** — `searchMaxQueries` bounds `ctx.web.search` calls, but a provider may perform several native searches inside each call; for example a model-backed provider configured with `maxUses` can permit up to `searchMaxQueries × maxUses` native searches, and `searchMaxResults` limits only the combined sources returned to the caller. Deployments control cost through these independent consumer and provider settings because the service does not know provider-internal search units.
- **HTML→markdown conversion omits inputs it cannot safely represent** — [turndown](https://github.com/mixmark-io/turndown) converts at most `fetchMaxOutputChars` source characters through a real DOM. A 512-level nesting guard and conversion exceptions produce a fixed omission marker instead of raw HTML; table `colspan` remains unsupported because GFM has no spanning-cell representation ([archived dependency decision](../../../.agents/notes/archived/simplification/2026-07-26-turndown-for-tool-web-html-markdown.md)).
- **The model-facing API is minimal by design, with promotions deferred** — `max_results` stays a config bound (not a model argument), and `web_fetch` takes only `url` (no `format`/`prompt`/LLM-summarization mode); both are named later steps in [the seam Agent Note](../../../.agents/notes/implemented/architecture/2026-06-24-web-capability-seam.md).
- **Public fetches do not request approval** — the shipped `cordis`, `code`, and `standard` presets expose `web_fetch` in every sandbox and approval mode. The HTTP provider blocks non-public destinations, but a model can send data to a public URL. Deployments that need per-call confirmation must add a `tools/pre-execute` policy or disable fetch.

<a id="dev-note"></a>
```

## [packages/web/web-fetch-http/README.md:128](/Users/brandon/Downloads/deepseek-harness/packages/web/web-fetch-http/README.md:128)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is unsafe or a poor fit. They are current package constraints.

- **Only textual content decodes** — html/xhtml and `text/*` plus JSON/XML families; a missing `Content-Type` or any binary type throws `WEB_UNSUPPORTED_CONTENT_TYPE`, and text-extractable PDF decoding is named deferred work.
- **Charset comes only from the `Content-Type` header** (UTF-8 default) — an HTML `<meta charset>` declaration is ignored, and a declared-but-unrecognized charset label throws rather than falling back.

<a id="dev-note"></a>
```

## [packages/web/web-fetch-playwright/README.md:178](/Users/brandon/Downloads/deepseek-harness/packages/web/web-fetch-playwright/README.md:178)

```markdown
<a id="known-limitations-and-deferred-work"></a>

These are the destination-policy gaps a deployment inherits and the maintainer constraints behind them. They are current package limits, not defects to route around.

- **Admission is not address pinning** — the policy decides a hostname and Chromium resolves it again when it connects, so a name that answers with a public address at admission and a private one at connection time reaches the private address. Playwright exposes no connection-level address hook to pin against, so closing this needs either a browser-level proxy that resolves and pins for Chromium or an upstream pinning API; a deployment that needs pinning today states `fetchProvider: http`.
- **A refused redirect hop is refused after the request, not before it** — Chromium follows a redirect inside its own network stack and does not re-enter `context.route` for the hop; it reports the hop on the context's `request` observer, which is where this provider decides it. The decision therefore lands after the browser has already issued that request, so a refused hop stops the content reaching the caller — the fetch fails with `WEB_BLOCKED_URL` before the document is read — but does not stop the request itself, leaving a blind request to the refused address. Preventing the request needs following redirects by hand through `route.fetch` and fulfilling the final response, which moves every request a page issues off Chromium's own network stack and changes what `page.url()` reports; `fetchProvider: http` prevents it today by resolving and pinning each hop before it connects.
- **A dedicated worker's WebSocket is not routed** — Playwright routes the WebSockets a page or frame opens, and neither `browserContext.routeWebSocket` nor `page.routeWebSocket` sees one a `new Worker(...)` script opens; `tests/chromium.spec.ts` pins that against a live Chromium so a Playwright release that closes it turns the test red. HTTP requests from the same worker are intercepted, so this reaches WebSocket servers on private addresses only — a non-WebSocket service never completes the handshake and returns no data to the page. Closing it needs an upstream routing fix, or an injected `Content-Security-Policy` that this provider does not rewrite responses to add.
- **Only the transports Playwright routes are checked** — HTTP(S) requests and `ws:`/`wss:` connections pass the address policy. WebRTC data channels and WebTransport are not routed by Playwright, so a page's script could reach a destination over them; disabling those transports at launch is deferred work, and neither is reachable through the request or WebSocket interceptor today.
- **The install probe is a filesystem check** — it confirms that the executable a launch would run exists, not that it starts. A partial or broken installation still reports the provider as available, and the first fetch fails with the launch error and the install command instead.
- **The shipped route has no recorded-session lane** — the redirect refusal, the WebSocket refusal, the launcher, the probe, and the install command all run against a real Chromium in `tests/chromium.spec.ts`, including one end-to-end fetch that maps a fixture hostname to loopback so a whole render can run offline. A `snapshots/session/` scenario cannot do the same: the policy refuses loopback, so a fixture page it may fetch needs that launch-time host mapping, which a shipped profile has no place to state, and merely leaving the row mounted makes a scenario host-dependent, because the plugin warns at mount exactly when the host has no browser and that harness compares process stderr byte for byte. The recorded-session lane therefore runs the `http` route, and this route's evidence is the real-Chromium suite.
```

## [packages/web/web-search-deepseek/README.md:149](/Users/brandon/Downloads/deepseek-harness/packages/web/web-search-deepseek/README.md:149)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is expensive or incomplete. They are current package constraints.

- **One search costs a full Messages model turn** — latency plus generated tokens, with up to `maxUses` server-side searches; DeepSeek exposes no dedicated retrieval endpoint.
- **Dynamic credential availability resolves inside the operation** — the synchronous availability check can establish that a resolver exists but cannot query an asynchronous credential store, so a selected keyless provider fails the search with `WEB_PROVIDER_CREDENTIAL_MISSING`; the stable `web_search` schema stays registered.
- **Over-returned sources still cost tokens** — with no result-count knob on the wire, `maxResults` is enforced only post-hoc by service truncation.
- **Uncited results carry no `snippet`** — a source gains one only when a text-block citation (`cited_text`) matches its URL.

<a id="dev-note"></a>
```

## [packages/web/web-search-exa/README.md:122](/Users/brandon/Downloads/deepseek-harness/packages/web/web-search-exa/README.md:122)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit. They are current package constraints.

- **A result with no non-blank highlight is dropped entirely** — there is no portable snippet to map, so fewer sources than requested can return.
- **Only `searchType`/`numResults`/`highlightsPerResult` are exposed** — Exa's other controls (livecrawl, category, domain/date filters, full-text contents) wait on provider-neutral service fields ([seam Agent Note](../../../.agents/notes/implemented/architecture/2026-06-24-web-capability-seam.md)).
- **Abort classification is error-shape-based** — only a `DOMException` named `AbortError` maps to `WEB_ABORTED`; an abort carrying a custom reason (such as `dsh-timeout`'s `TimeoutReason`) surfaces as `WEB_PROVIDER_ERROR`.

<a id="dev-note"></a>
```

## [packages/web/web-search-perplexity/README.md:142](/Users/brandon/Downloads/deepseek-harness/packages/web/web-search-perplexity/README.md:142)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the provider is a poor fit. They are current package constraints.

- **Citation-fallback sources are URL-only** — when Perplexity omits structured `search_results[]`, sources carry no `title`/`snippet`/`publishedAt`, so the tool renders bare hostname labels.
- **Over-returned sources still cost tokens and latency** — with no result-count control on the wire, `maxResults` is enforced only post-hoc by service truncation.
- **Only `model`/`maxTokens`/`searchRecency` are exposed** — Perplexity's other search controls (domain filters, `web_search_options` context size, images) wait on provider-neutral service fields ([seam Agent Note](../../../.agents/notes/implemented/architecture/2026-06-24-web-capability-seam.md)).
- **Abort classification is error-shape-based** — only a `DOMException` named `AbortError` maps to `WEB_ABORTED`; an abort carrying a custom reason (such as `dsh-timeout`'s `TimeoutReason`) surfaces as `WEB_PROVIDER_ERROR`.

<a id="dev-note"></a>
```

## [packages/web/web/README.md:145](/Users/brandon/Downloads/deepseek-harness/packages/web/web/README.md:145)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the service is incomplete on its own. They are current package constraints.

- **No observation surface** — there is no provider-change event and no capability-status query; availability is observable only by running a search or fetch and routing the thrown code, and the no-provider failure is the generic `WEB_PROVIDER_UNAVAILABLE` with no per-provider reason enumeration ([Agent Note](../../../.agents/notes/archived/simplification/2026-07-04-drop-unconsumed-web-observation-surface.md)).
- **Search requests carry only `query` and `maxResults`** — provider-neutral controls (recency, domain filters, regional hints, search depth) are deferred until the backends can honor them ([seam Agent Note](../../../.agents/notes/implemented/architecture/2026-06-24-web-capability-seam.md)).
- **`WebFetchBody` has no `pdf` arm** — text-extractable PDF support is named deferred work; the closed union makes adding it a compile-enforced change across the web packages.
- **Provider-backed page extraction is out of scope of `fetch()`** — a Firecrawl/Tavily-style `web_extract` capability is deferred rather than widening the fetch operation.

<a id="dev-note"></a>
```

## [packages/webhook/webhook-github/README.md:68](/Users/brandon/Downloads/deepseek-harness/packages/webhook/webhook-github/README.md:68)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **No TLS** — the injected development WebServer is normally loopback-only behind a TLS reverse proxy or tunnel.
- **Generic payload validation only** — rules own validation of the GitHub event fields they consume.
- **No provider acknowledgement of downstream work** — `202` precedes arbitrary rule calls and Session creation.
- **No form encoding** — GitHub must send `application/json`; `application/x-www-form-urlencoded` is rejected.


<a id="dev-note"></a>
```

## [packages/webhook/webhook/README.md:67](/Users/brandon/Downloads/deepseek-harness/packages/webhook/webhook/README.md:67)

```markdown
<a id="known-limitations-and-deferred-work"></a>

- **Process-local fire-and-forget only** — a crash loses rule calls that have not admitted a prompt; there is no queue, replay, or retry.
- **No built-in deduplication** — repeated provider deliveries may create repeated Sessions; rules that need idempotency own it.
- **No completion result** — HTTP acceptance and rule settlement do not report Agent success, idle, or output.
- **Trusted callbacks must cooperate with cancellation** — runtime teardown aborts and awaits them but cannot terminate arbitrary same-process code.
- **Workspace creation may outlive a failed Session attempt** — an empty Workspace is retained because another concurrent caller may already use it.


<a id="dev-note"></a>
```

## [packages/workflow/tool-ralph/README.md:155](/Users/brandon/Downloads/deepseek-harness/packages/workflow/tool-ralph/README.md:155)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the tool does not yet support. They are current constraints, not a task backlog.

- **Completion is worker self-declaration** — there is no independent evaluator or verifier deciding whether the objective is complete; evaluator policy and evaluator-driven continuation are deferred.
- **Foreground only** — there is no job id, background collection, process-resume checkpoint, scheduler, or wall-clock start policy.
- **The workspace is the only cross-round long-term memory** — one bounded report is the explicit handoff, and uncommitted conversational reasoning disappears with each child.
- **One round is one fresh child** — there is no within-round fan-out, model or provider switching, fork context, or model-call-selected provider.
- **Ordinary child failure is terminal for the run** — the fixed script reports the failed round and last successful handoff but does not retry; fatal workflow infrastructure failures can end before that state is returned.
- **Only round count bounds aggregate effort** — token, price, and elapsed-time budgets are deferred.

<a id="dev-note"></a>
```

## [packages/workflow/tool-workflow/README.md:152](/Users/brandon/Downloads/deepseek-harness/packages/workflow/tool-workflow/README.md:152)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the tool does not yet support. They are current constraints, not a task backlog.

- **The parent turn blocks until the whole workflow settles** — there is no background start/poll API, and cancellation discards partial output as an error.
- **`args` must be an object and Native result text is bounded** — callers wrap top-level arrays and scalars in a field; the canonical workflow result stays complete, while JSON beyond `maxResultChars` is truncated in the model-facing projection rather than stored behind a retrieval handle.
- **Workflow policy is fixed per tool registration** — provider selection, caps, and tool name are deployment config, not model-call arguments.
- **Durable records are top-level and observational** — nested PTC mode dispatches are not recorded, and a recording failure intentionally degrades to an incomplete prefix rather than changing execution.

<a id="dev-note"></a>
```

## [packages/workflow/workflow-worker-thread/README.md:160](/Users/brandon/Downloads/deepseek-harness/packages/workflow/workflow-worker-thread/README.md:160)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the engine is a poor fit or needs special operational care. They are current constraints, not a task backlog.

- **The worker and vm are not a security boundary** — model-written code can escape `node:vm` and reach the worker's process authority; a hostile-code deployment needs a separate-process or container engine.
- **One worker thread is paid per run** — there is no pool, warm runtime, or cross-run script cache.
- **No ambient timers, filesystem, or network are injected, but escaped code can still reach Node** — the missing globals are a portability API, not containment.
- **Termination can only report host-observed starts** — `agentsStarted` excludes worker-side calls still queued behind concurrency when a forced termination makes them unknowable.
- **Cross-realm errors fail `instanceof Error` inside scripts** — workflow authors must branch on stable fields such as `name` and `code`.

<a id="dev-note"></a>
```

## [packages/workflow/workflow/README.md:120](/Users/brandon/Downloads/deepseek-harness/packages/workflow/workflow/README.md:120)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define what the capability does not yet support. They are current constraints, not a task backlog.

- **Foreground collection only** — the caller owns one live run and awaits it; background start/poll, spill handles, and detached collection are deferred.
- **No journaling or resume** — scripts, child progress, and intermediate values are not checkpointed, so a process restart cannot continue a run.
- **No saved or nested workflows** — the capability starts caller-supplied scripts only, and a workflow script receives no `workflow()` hook for recursive orchestration.
- **No token-budget vocabulary** — engines cap concurrency, items, and children, but neither the request nor the result accounts for model tokens across children.
- **Runs are holder-owned, not service-tracked** — unloading the engine does not discover independent live handles; every consumer must dispose the run it started.

<a id="dev-note"></a>
```

## [packages/workspace/workspace/README.md:153](/Users/brandon/Downloads/deepseek-harness/packages/workspace/workspace/README.md:153)

```markdown
<a id="known-limitations-and-deferred-work"></a>


These limits define when the project list is a poor fit or needs special operational care. They are current package constraints, not a task backlog.

- **Removal never deletes data** — removing a project leaves its folder, files, and session histories in place; those sessions become ungrouped, and session deletion or folder removal are separate, absent capabilities ([decision](../../../.agents/notes/implemented/feature/2026-07-27-workspace-registration-deletion.md)).
- **A session joins only with a recorded directory** — a session belongs to a project only when its record carries a directory that resolves to the project's path; sessions without one stay ungrouped, and a session from another directory cannot be moved in.
- **External changes are seen late** — if another process deletes or damages a directory, the project reflects it only at the next refresh or restart.
- **Archiving is one-way** — a hidden session keeps its history and its place, but no unarchive action exists yet; the archive set is a durable display filter.
- **Re-adding a directory starts fresh** — after removal, adding the same directory again creates a new project with an empty session list; the old sessions do not come back automatically.

<a id="dev-note"></a>
```
