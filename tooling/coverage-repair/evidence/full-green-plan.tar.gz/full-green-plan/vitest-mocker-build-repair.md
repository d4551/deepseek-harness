# Module-analysis build and native package lookup

The isolated `@vitest/mocker` package builds all eight JavaScript and declaration
entries. Complete package-source compilation and a packed consumer's public
declaration imports pass with TypeScript 7 and library checking enabled. A fresh
frozen reconstruction reproduces all 28 generated files byte for byte.

Runtime acceptance remains red. The real packed export-analysis test exposes a
Node 26.9.0 package lookup defect. A source-level Node repair is prepared and its
native build is running; its corrected runtime behavior is not yet verified.
Neither candidate is promoted to the product repository.

## Build implementation and verification

`packages/mocker/package.json` uses `tsdown@0.23.0` for build and watch commands.
`packages/mocker/tsdown.config.ts` enumerates the same eight source entries and
retains `.js` and `.d.ts` output names. It uses the package's declaration contract
and enables library checking. The declared dependency ownership list specifies
which development dependencies belong inside the bundle. Runtime and peer
dependencies remain external. No peer override or compiler downgrade is added.

The old package Rollup configuration remains present pending runtime acceptance;
the active build script uses tsdown. Other packages still use the shared Rollup
declaration helper, so this package repair does not establish a complete runner
build. The `auto-register` export also retains its existing mapping to the
`register` output; that source/distribution discrepancy still needs an actual
browser regression and repair.

Verification outputs:

- `/tmp/dsh-mocker-modern-build-first.log`: retained failed output-extension API
  configuration attempt.
- `/tmp/dsh-mocker-modern-build-final.log`: complete package build passes.
- `/tmp/dsh-mocker-source-strict-types.log`: complete package-source compilation
  passes with `--skipLibCheck false`.
- `/tmp/dsh-mocker-modern-pack.log`: normal package archive creation passes.
- `/tmp/dsh-mocker-consumer-install.log`: retained initial installation failure
  because the MSW lifecycle script had not been reviewed.
- `/tmp/dsh-mocker-consumer-install-reviewed.log`: frozen installation passes
  after inspecting the script and permitting the exact `msw@2.15.0` script.
  Lifecycle scripts and strict build approval enforcement remain enabled.
- `/tmp/dsh-mocker-consumer-types.log`: all eight public declaration imports pass
  under strict TypeScript 7 without workspace source conditions.
- `/tmp/dsh-mocker-consumer-invalid-types.log`: incorrect format and accessor
  arguments are rejected with TS2345 and TS2322; no diagnostic directive is used.
- `/tmp/dsh-mocker-consumer-runtime.log`: one pass, one failure. Declared runtime
  and declaration entries exist and Amaro is owned by the packed manifest.
  Actual TypeScript export analysis fails in native package metadata lookup.
  The following syntax-error assertion is subsequently strengthened to require
  Amaro's `InvalidSyntax` code; this stronger test awaits the repaired runtime.
- `/tmp/dsh-mocker-full-types.log`: complete upstream typecheck still has 89
  diagnostics; this requirement is not satisfied by the package-only checks.

The archive is `/tmp/dsh-mocker-modern-artifact/vitest-mocker-5.0.1.tgz`.
The consumer is `/tmp/dsh-mocker-modern-consumer`; it supplies the actual Vite
and MSW peers and imports only packed exports. Its regression reads a real
TypeScript file containing an enum and a parameter property, checks the exact
discovered export names, and requires malformed TypeScript to fail.

## Independent reconstruction

`/tmp/dsh-mocker-reconstruct.py` compares every original source archive file
against the candidate, records all 18 changed original files and seven added
inputs, and generates `vitest-mocker-build-candidate.patch`. It extracts the
official archive into a fresh directory and applies that complete input patch
with Git, checking every changed input hash.

The official source archive SHA-256 is
`956950edf0f0ef8e08ce0e18b20136eb4142995eadc8dfa7e8af6cb4ff65119e`.
The reconstructed location and input hashes are in
`/tmp/dsh-mocker-frozen-location.json`. Fresh-cache frozen installation, complete
package build, and strict complete package compilation all pass:

- `/tmp/dsh-mocker-frozen-install.log`
- `/tmp/dsh-mocker-frozen-build.log`
- `/tmp/dsh-mocker-frozen-types.log`

`/tmp/dsh-mocker-build-byte-identity.json` records all 28 identical generated
file hashes and an unchanged lockfile. This reconstructs the existing candidate;
its pre-existing absolute local artifact dependencies and upstream configuration
exceptions remain integration debt. Git also reports two whitespace findings
inside the candidate's existing nested dependency patches; none is excluded.

## Native package lookup defect

The current official Node API promises an absent result when no parent package
metadata exists. Its implementation instead returns the queried module filename
from a metadata record with `exists: false`. The packed consumer then attempts
to parse `export enum ...` as JSON. The same result reproduces using only the
official Node binary, real files, and the public `findPackageJSON` API.

Verified official source archive:
`/tmp/dsh-node26.9.0/node-v26.9.0.tar.xz`, SHA-256
`47b970d88511b429e587b740fa733176909d2a2005a29662f01b05205f58468b`.
The source is extracted to `/tmp/dsh-node26.9.0/node-v26.9.0`.

The source repair changes `findPackageJSON` to return a metadata path only when
the native record says it exists. Its return annotation includes `undefined`.
The new native test checks absolute paths, URL strings, URL objects, relative
specifiers, repeated and sibling lookups, directory lookup, existing metadata,
and malformed metadata. The original binary reports **two passes and five
failures**, with no skips, in `/tmp/dsh-node-package-json-before.log`.

`node-package-json-source.patch` records the implementation and regression.
There is no application workaround or runtime monkey patch. Configure passes
with the installed Xcode toolchain. The standard `make -j8` native build is
running in session `83623`, writing `/tmp/dsh-node-package-json-build.log`.
Its completion, all seven new tests, existing package-lookup and loader tests,
and the unchanged packed consumer must be checked before accepting the repair.

## Remaining acceptance

The Node build and runtime checks are pending. Browser package behavior,
the existing auto-registration export mismatch, old build-config removal,
complete runner build/lint/typecheck, generated-helper attribution, child
coverage transport, reproducible integration, native platform checks, and the
full plan remain open. Root source is unchanged at
`105a97ef9c776a2856118ee02609dc61a0fb9617`; the 633 directive findings remain.

Primary references: [tsdown declarations](https://tsdown.dev/options/dts),
[tsdown dependency ownership](https://tsdown.dev/options/dependencies),
[pnpm build approval](https://pnpm.io/settings/build#allowbuilds),
[Node package lookup contract](https://nodejs.org/api/module.html#modulefindpackagejsonspecifier-base),
and [Node build instructions](https://github.com/nodejs/node/blob/v26.9.0/BUILDING.md).
