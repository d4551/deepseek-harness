# Commit, push, CI, and delivery blockers

Updated 2026-09-16 from the current worktree, installed hooks, workflow source,
and read-only GitHub queries. This is part of the full-green plan, not a passing
verification report. Every discovered blocker remains in scope until repaired
and verified; an absent branch rule does not reduce the acceptance standard.

## 1. Establish the exact delivery target

The inspected checkout is `master`; the initial inspection had staged changes,
while a later read-only status check recorded an empty index and retained
working-tree edits. Neither snapshot establishes the intended future index;
reconcile it before delivery. `origin` is
`d4551/deepseek-harness`; `upstream` is `deepseek-ai/deepseek-harness`.
Read-only queries found no open PR for origin's `master` or upstream's
`d4551:master`. Therefore there is no verified PR head, merge base, remote check
run, or review state covering this dirty worktree.

The origin master rules endpoint returned an empty list and its classic
protection endpoint explicitly returned `Branch not protected`. Upstream's
rules endpoint also returned an empty list, but its classic protection endpoint
returned a generic 404; that does not establish whether protection is absent
or inaccessible. Repeat these checks for the actual destination before delivery.
Do not create or change branch rules to make a failing change appear acceptable.

Before publication, record the intended repository, base, head, merge base,
required contexts and their issuing apps, review requirements, unresolved review
threads, mergeability, and merge-queue requirements if present. Reconcile the
live configuration with the workflow graph. Until that reconciliation succeeds,
remote readiness is unverified. Use a `codex/` branch for new implementation
branching unless the user directs otherwise; preserve all existing edits.

## 2. Local commit blockers

The effective `core.hooksPath` is the repository's `.git/dsh-hooks`, whose
pre-commit and pre-push scripts invoke Lefthook. Do not infer active behavior
from the separate `.git/hooks` directory alone.

| Check from `lefthook.yml` | Trigger and exact obligation | Repair and acceptance |
| --- | --- | --- |
| Translation pairing | Staged `.i18n.yaml` records outside the frozen archive; `bun scripts/verify-translation-pairing.ts --cached {staged_files}` | Stage a coherent EN/ZH/sidecar set only when preparing the authorized commit. Verify the index content, not merely working files. Repair actual translated units and digests. |
| Archived notes | Staged archive changes; `bun scripts/verify-archived-agent-notes.ts` | Prove permitted archival movement against the trusted base and frozen manifest. Preserve complete triplets and frozen records. |
| Staged lint | TS/JS file selection defined in the hook; `run-oxlint.ts --config .oxlintrc.staged.json --fix --no-error-on-unmatched-pattern` | Repair findings without directives or casts. Inspect the actual hook diff because `stage_fixed: true` automatically stages changes. Hook scope is not whole-repository lint acceptance. |
| Third-party notices | Manifests, lockfile, vendor record, Python metadata, and generator inputs | The hook runs the canonical generator and stages `THIRD_PARTY_NOTICES.md`. Verify freshness before committing and inspect generated changes. Deleted manifests may not trigger the hook, so run the freshness check explicitly. |
| Staged whitespace | `git diff --cached --check` | Correct whitespace in the intended index snapshot. Also check the working tree. |
| Vendor manifest guard | `scripts/check-vendor-manifest.sh` | Vendored source/bin changes require the matching `vendor/README.md` modification in the same commit. Verify the modification record is accurate; a changed filename alone is insufficient. |

The pre-merge-commit hook additionally checks staged translation records and
archived notes. Preserve these checks during any merge. The pre-push hook runs
`bun run typecheck`, which builds host contracts and checks client contracts.
It must succeed naturally; do not use `--no-verify`, `LEFTHOOK=0`, alternate hook
paths, or environment changes to bypass enforcement.

Earlier index and working-tree whitespace checks passed; the current externally
staged patch payloads fail the index check as detailed below. No actual
commit-hook run or new commit was performed for this plan.
Before an eventual commit, review existing staged ownership and the complete
index diff. After hook-generated changes, invalidate and rerun affected checks.
The hook is a mutating operation, so do not run it casually during planning or
while mutation testing captures a source snapshot. Earlier read-only checks passed
notices freshness, all 528 frozen archive artifacts, the index vendor filename
guard and both whitespace checks at that checkpoint; logs are `/tmp/dsh-commit-notices-check.log`,
`/tmp/dsh-commit-archive-check.log` and `/tmp/dsh-commit-vendor-check.log`.
This does not establish hook completion, intended-index review or commit readiness.
The source-owned patch format repair makes `git diff HEAD --check` pass.
The externally staged older patch payloads still fail the index check; see
`/tmp/dsh-clean-stryker-patches-final-index-whitespace.log`. The complete
[patch repair evidence](stryker-patch-whitespace-repair.md) preserves earlier
failures and native Git/Bun application proof. Index reconciliation and actual
commit-hook completion remain outstanding.

## 3. Known blockers and their repair order

| Priority / ID | Present evidence | Concrete next repair | Exit evidence |
| --- | --- | --- | --- |
| P0 CI-01 | Complete expanded scanner has 2,445 findings across 4,054 files: 643 directives, 1,445 catch clauses and 357 static catch-handler accesses; complete typed lint passes after the AST source repair; separate source-prohibition gate fails | Repair every directive and exposed code/test contract without exemptions; complete source enforcement for dynamic and aliased access | Complete lint and source audit pass, with zero retained diagnostic directives or equivalent evasions |
| P0 CI-02 | Latest documentation aggregate: 30 pass, two fail, zero skipped; both generated catalogs and bilingual pairs are current, immutable AGENTS wrapping/root word budget remain red | Resolve protected-file ownership; replay the final aggregate after all source writers finish | Both protected-file checks and final `doc-sync` pass without exclusions or larger budgets |
| P0 CI-03 | Exact child environment fails under automatic V8 subprocess coverage | Implement a supported collection design that preserves exact process environments and real child execution evidence | Same run proves the exact environment and nonzero correct child coverage, including actual non-Node children |
| P0 CI-04 | Source-loaded TypeScript children execute but Vitest remapping excludes files or reads mismatched transforms; the native shutdown probe confirms the executed and remapped bytes differ | Correct evidence collection and transform identity: capture executed generated JS, retain the actual source map, and remap distinct transforms before merging Istanbul results | Real subprocess TypeScript, parameter properties, parent/child overlap, and malformed-map failure tests; no parse exclusion, warnings, custom filtering, or denominator loss |
| P0 CI-05 | Latest full normal run: three failures, 20,407 passing, 42 skipped; SDK assertion subsequently repaired in the 40-test owning replay, source-prohibition and provenance-word gate failures remain. All 67 accessibility audit tests execute; Worker failures do not recur. Historical complete coverage has 2,049 failed metrics; current fs-local and spill cleanup strict coverage fail | Reconcile every failure and skipped case against current discovery and native ownership; repair behavior and missing assertions | Current complete run passes; every required test executes on its target; every executable file reaches all four 100% metrics |
| P0 CI-06 | Prior storage command-runner scores withdrawn; six-module/440-mutant isolated-cache snapshot finished at 97.27%, predates new source and is not accepted final evidence. Source-owned runner/instrumenter reconstruction and clean frozen root integration pass. Shutdown detects all 36 candidates, including two restored deletions; all reasons are reviewed, establishing a scoped 100% result only. | Finish the remaining runner lifecycle repair, replay final source inventory and inspect every outcome | At least 99% overall and in high-risk files; all survivor/error/timeout/no-coverage statuses retained; no omitted executable candidates |
| P0 CI-07 | No current complete Linux/Windows/platform evidence | Provision the existing workflow prerequisites and execute the actual native jobs | Every matrix leg succeeds on the final content, including ACL, Landlock, shell and confidentiality behavior |
| P1 CI-08 | Dependency, vendor, export, snapshot and generated documentation changes are extensive | Immutable install in a disposable verification checkout; canonical build and generators; packed-install and consumer checks | Lockfile unchanged by install; artifacts and catalogs reproduce; shipped consumers pass |
| P1 CI-09 | No matching PR or verified remote head for this worktree | Determine the real delivery target, then observe all remote checks and review policy when publication is authorized | Exact published SHA and applicable merge result have current passing checks and satisfied reviews |
| P1 CI-10 | Bao authority and full UI state coverage remain unresolved | Locate real canonical archives/tooling, repair shared primitives, execute all inventoried browser states | Verified generated provenance, zero unresolved axe/Brutalise findings, manual accessibility and actual journeys |
| P0 CI-11 | Repaired package gate rejects 217 empty invariant installers; the former comment-based exemption is removed | Implement meaningful package-owned runtime checks and verify valid/invalid observations; retain publication and registration requirements | Complete package gate passes with no empty installers or synthetic presence assertions |

The latest complete source list is `source-20260916152350649.md`; all 643
directive sites also appear in `suppressions-outstanding.md`. Complete full-run
failure status is in `full-run-root-integration-failures.md`; the complete current
run exits 1 in `/tmp/dsh-stryker-root-full-tests.log`. The current complete
typed lint passes in `/tmp/dsh-typescript-ast-final-full-lint.log` (exit 0). Its result
does not override the failing separate source-prohibition gate.
The independent package-invariant gate also fails on the 217 files listed in
`empty-invariant-installers.md`. Its repaired checker passes 29 tests and all
four 100% coverage metrics; that proves checker execution, not the missing
product checks. `empty-invariant-gate-repair.md` records complete evidence.
The subsequent complete typed lint passes in
`/tmp/dsh-worker-ci-order-full-lint.log`; the final Worker fixture refinement
also passes scoped typed lint. The complete repository test run has not been
repeated after these repairs.
All eleven coverage directives in subprocess launch are removed. Ordinary
package tests pass 183 cases with two native-Windows skips; strict coverage
retains two exact-environment failures and a source-remapping parse failure.
`subprocess-unsuppressed.md` records the complete evidence. The source removal
does not resolve CI-03 or CI-04, and no source is newly excluded.

Attachment admission cancellation passes 150 tests with one existing native-
Windows skip, including an actual built Loader composition. All eight affected
sources reach 100% lines and functions; strict coverage remains red on six
statement/branch locations in storage. A final additional native primitive-
cancellation regression passes all five owning limiter cases. Complete build
and typed lint pass, with scoped lint covering that last test addition.
`attachment-admission-cancellation.md` lists exact logs and remaining obligations.
Complete documentation finishes with 30 passing gates, two protected-file
failures and zero skipped in `/tmp/dsh-admission-final-doc-sync.log`; the quick
aggregate reports 13 passing gates and the same two failures. Immutable root/
client AGENTS wrapping and root AGENTS word budget remain unresolved.
Earlier complete whitespace exits 2 on the toolchain patch payloads in
`/tmp/dsh-admission-final-whitespace.log`; attachment-specific whitespace passes.
The subsequent shared-request repair passes full build/lint and 158 owning tests
with one Windows skip. Broader complete attachment-package coverage exposes
six storage locations and sixteen uncovered invariant-companion locations;
the latter have empty installers requiring actual contract repair. No source
is excluded. `shared-request-cancellation.md` records the complete results.
Final complete docs pass 30 gates and fail the two protected-file checks, with
zero skipped, in `/tmp/dsh-shared-request-doc-sync-final.log`.
The externally staged toolchain payloads currently fail `git diff --cached --check`
on blank patch-context lines and endings. The generation format is repaired in
the working tree with native application proof and an added whitespace rejection
check; `/tmp/dsh-clean-stryker-patches-final-index-whitespace.log` records the
remaining staged findings. No patch-file exemption is added. Fresh complete
Stryker reconstruction passes in
`/tmp/dsh-clean-stryker-patches-rebuild-check.log`; root dependency integration
and repository mutation acceptance remain open.
The subsequent [native shutdown repair](process-shutdown-repair.md) fixes
zero-status exits after failed or expired disposal. Sixteen native controller
cases, 23 rebuilt CLI/PTY acceptance cases, complete build and full typed lint
pass. The owning CLI replay passes 59 cases; its one opt-in built-Web smoke also
passes when explicitly enabled against the build. Documentation retains the
same protected-file failures. Strict coverage stays red; the Inspector probe
establishes a generated-source identity failure under CI-04. The shutdown run
detects all 34 reported mutants. However, independent AST execution proves the
upstream instrumenter omits two diagnostic-call deletions; no unfiltered score
is accepted. `process-shutdown-mutation-review.json` retains the reviewed
assertions, and `process-shutdown-repair.md` specifies the dependency repair.
The subsequent source-owned instrumenter repair passes complete strict
compilation, frozen isolated runtime installation and independent artifact
reproduction. Five native accounting regressions pass; four fail against the
upstream package because the removal candidates are absent. The shutdown
rerun detects all 36 candidates with no survivors, timeouts or errors. Every
status reason contains reviewed behavioral assertions, and source identity
matches the complete current module. The scoped mutation result is accepted.
`instrumenter-accounting-repair.md` records the package provenance and exact
checks. Full typed lint passes; the two protected documentation failures and
externally staged whitespace failures remain. Root dependency integration
and complete repository acceptance still block CI-06.
Historical complete lists remain in `lint-current.md`, `source-audit.md`,
`coverage-threshold-failures.md`, `full-run-test-failures.md`,
`mutation-current.md`, and `additional-findings.md`. Historical counts are not
fresh verdicts. Refresh inventories after repairs; do not replace failing
baseline reports with a narrower passing subset.

Latest scoped evidence does not remove these blockers: all storage backends and
Cordis disposal integration pass 272 tests; strict materialization in both
providers passes 1,024 tests (one native-Windows skip), with all eight measured
source files at 100% in all four metrics. Mandatory replay/checkpoint readiness
passes 365 tests including the unchanged DeepSeek cancellation assertion. The
full normal test run finished with 20 failures. It overlaps repairs and external
HEAD movement, so it is diagnostic evidence rather than final-state acceptance.
B4 quarantine and the complete
prepared-request/replay lifecycle remain open in
`B4-attachment-recovery.md` and `/tmp/dsh-b4-replay-ordering.md`; they are not
implemented by the strict-materialization repair.

CI-06 has an additional dependency-ownership blocker: Bun applies the prepared
Stryker core patch bytes but does not resolve a dependency newly added only to
the patched package manifest. A fresh-cache frozen isolated installation lacks
`jsonc-parser`, and the actual patched preprocessor fails to import it. The root
workspace dependency masks this error. An artificial peer declaration would not
establish the correct internal dependency edge. Evidence and retained clean
installation probes: `/tmp/dsh-bun-core-dependency-findings.md`. The prepared
repair artifacts remain uninstalled; no valid final product score is claimed.
A source-built core tarball now passes independent fresh-cache normal and
frozen Bun installation probes: the parser is owned by core in the actual
lock graph and private module edge, and is absent from root dependencies.
The subsequent [root integration](stryker-root-integration.md) replaces the
root core dependency with the verified archive and installs the source-generated
instrumenter/runner patches. All 1,006 installed files match the inventory;
the complete-root fresh-cache frozen install passes with an unchanged lockfile,
normal lifecycle execution and all five native accounting cases. Complete build,
typed lint, workspace constraints and 91 owning tests pass. The new declaration
helper has 100% coverage in all four metrics. Documentation retains its two
protected-file failures. Root integration is resolved; the remaining runner
lifecycle, complete mutation evidence and other CI-06 obligations are open.

CI-04 has a useful read-only prototype: Inspector `Debugger.getScriptSource`
returned the actual child JavaScript, whose length and line boundaries matched
the V8 profile, and the existing converter remapped it successfully. A map-only
patch is insufficient because Node's source-map cache omits generated code and
Vitest merges different transformed offsets by URL. This establishes a repair
direction, not a completed supported integration. Evidence is
`/tmp/dsh-a3-inspector-remap.log`.

The CI-04 acceptance matrix must include subprocesses and workers, parameter
properties, covered and uncovered branches, one URL executed through distinct
parent/child transforms, Unicode, CRLF, inline/external maps, multiple children,
and abrupt termination. Assert original statement/function/branch locations,
not just aggregate percentages. Missing source, invalid maps and inconsistent
offsets must fail collection explicitly. A package-managed dependency patch
is a possible delivery mechanism only after the supported collector lifecycle
is proven; clean installation must reproduce the patch and its results, and
notices must be regenerated. This does not resolve CI-03's environment contract.

## 4. Required main CI graph

The [strict runner build work](vitest-strict-build-repairs.md) reduces the
candidate's native compile failures from 20 diagnostics to two with
`skipLibCheck: false`. Verified source-built dependency reconstruction,
packed-consumer tests and corrected browser declaration ownership resolve
the measured dependency failures. Calls to Node's removed transform mode still
fail compilation, and earlier Node mode behavior must remain covered. The
candidate is unpromoted; CI-04 and CI-06 remain open.

The [TypeScript AST repair](typescript-ast-contract-repair.md) removes eight
lint directives through source schema correction and complete strict API
reconstruction. Native clean frozen installation preserves the lockfile and
passes all installed compiler contract tests. All 426 owning tests, complete
build, full typed lint, workspace constraints and notices freshness pass.
Strict coverage still fails at 237 locations across the eight affected sources;
documentation retains its two protected-file failures. This resolves the new
compiler package's local provenance and installation checks under CI-08,
without resolving CI-01, CI-02, CI-05, CI-06 or native platform requirements.

`.github/workflows/ci.yml` requires these 11 groups through
`all-checks-passed`; matrix entries add executions beyond the group count.

| Group | Command / execution | Prerequisites and acceptance |
| --- | --- | --- |
| `node-24` | `bun run check:ci:static` | Full history and trusted PR base for archive verification; all static gates pass |
| `node-24-coverage` | `bun run check:ci:coverage` | Linux bubblewrap, Playwright Chromium/system dependencies, pinned WebDAV; complete tests and unsuppressed coverage |
| `node-24-consumers` | `bun run check:ci:consumers` | Build-owned artifacts, browser and sandbox dependencies; all snapshot/artifact consumers pass |
| `node-compat` | `bun run check:node-compat` on Node 22.19 and 26 | Both configured compatibility legs, official client build profile |
| `python-sdk` | `uv run --python 3.10 --group test --project python/sdk pytest` | Pinned workflow uv installation and complete keyless SDK suite |
| `python-runtime` | Reusable `build-exe-for-python-sdk.yml` with `ci: true` | Linux x64/arm64, macOS arm64, Windows x64; real wheels, clean installation, executable and keyless tests, applicable trusted real API tests |
| `windows` | `bash scripts/wine-windows-gates.sh` | Wine and verified Windows Node; Wine build/site result remains separate from kernel evidence |
| `windows-build` | `bun run check:ci:windows-blocking` | Native Windows Developer Mode, immutable dependencies; workspace and built-artifact behavior |
| `windows-coverage` | Build, network-drive preparation, `bun run check:ci:coverage` | Native Windows Chromium and WebDAV; complete native test/coverage result |
| `windows-native-tests` | Explicit native test lists in CI plus ACL E2E | Process exits, worker threads, SQLite, PowerShell, credential/spill confidentiality, restricted tokens, DACL grants and real confinement |
| `windows-observational` | `bun run check:ci:windows-observational` | Native static/docs/package/artifact checks; despite its name it is required by the aggregate |

The shared `ci-coverage` aggregate now owns a complete build before its unchanged
coverage invocation on both Linux and Windows. The complete primary graphs
reuse their existing build; local `check-all` tests wait for both application
and web writers. The macOS sandbox full-suite step provisions Chromium and a
complete build. These dependencies pass the 79 owning graph/scheduler tests
and 20 workflow tests; native remote execution remains unverified.

Keep the aggregate unconditional after dependencies and fail on every required
failure, cancellation, or skip. Audit that every blocking job remains in
`needs`, and test that omitted or malformed verdicts cannot yield green.
GitHub itself can accept skipped/neutral statuses, so its green UI alone is
insufficient evidence for the stricter repository contract.

The 77-command detailed mode mapping is in `gates.md`. Use the canonical mode
commands and their dependency ordering rather than manually reproducing a
smaller subset. Build/generator writers must finish before mutation snapshots.

## 5. CI/CD workflows outside the aggregate

The new `workflow-inventory.json` records all 19 workflow definitions, triggers,
jobs, matrices, dependencies and shell commands. Reconcile these independently
of the main CI aggregate:

- `release.yml`: verify DSH release metadata, official build, DSH/vendor/
  Landlock tarballs and clean packed installation. It runs on PRs as well as
  master. Packing and verification do not require registry publication.
- `release-vendor.yml`: verify vendor release metadata, host build, vendor
  tarballs and clean installation. The current vendor source changes make this
  directly relevant.
- `landlock-run.yml`: the current package manifest and lockfile edits match its
  path trigger. Include every dynamically generated native matrix entry and
  Darwin contract. Derive the matrix from its actual generator.
- `e2e.yml`: real provider suite has a mandatory credential preflight for
  eligible trusted runs. A credential-driven skip does not prove provider
  behavior. Record trusted/fork applicability and obtain valid execution for
  every affected provider journey without exposing credentials.
- `issue-policy.yml`: once its review condition applies, validate the actual
  same-repository Issue references, one allowed `kind/*`, at least one `area/*`,
  priority consistency and remaining policy checks. Run the policy unit suite
  locally; do not manufacture Issue references or manipulate review state to
  avoid enforcement. Lifecycle automation is a separate state-changing workflow.
- `build-preview-cloudflare.yml`: verify preview build and packaged VFS image,
  then any authorized deployment's real protected response. Deployment and PR
  comments are external side effects, not prerequisites for local lint. Do not
  manually publish or comment merely to test the workflow.
- `expected-filenames.yml`: inspect the actual outgoing paths against its
  trigger and run its validation if applicable; record applicability evidence.
- `ci-master.yml` and `sandbox.yml`: verify the relevant post-merge platform
  contracts before claiming platform completeness. Record master-only results
  separately from PR checks; do not merge simply to discover an avoidable red.
- `pi-ai-provider-e2e.yml`, `e2b-e2e.yml`: include their real integrations when
  the final source scope reaches them. Required credentials/environments remain
  explicit unresolved dependencies until the tests actually execute.
- `python-release.yml`, `landlock-run-release.yml`, release publication and
  docs deployment workflows: validate affected artifact construction, install,
  version and provenance contracts without publishing or deploying as a test.
  An eventual release additionally requires its existing environment approvals
  and trusted credentials; this plan does not authorize publication.

## 6. Execution and evidence sequence

1. Retain the finished cache-isolated six-module mutation snapshot and its
   complete report. Previous command-runner scores are withdrawn. Inspect every
   reported kill for genuine assertion failure; startup/infrastructure failure
   cannot count as detection. Refresh counts and the exact source fingerprint.
   Do not turn a partial run into a passing percentage. This snapshot predates
   shared-cache constants factoring across 11 standalone config entry points;
   it captured the same primary cache behavior, but final source/config
   reconciliation remains necessary. The broader 11-entry-point config lint
   passes; native runner error classification and full child activation must
   pass before a product score is accepted.
2. Resolve measurement defects and immutable-file conflicts early. In parallel
   where authorized, repair the highest-impact data, cancellation and attachment
   defects from Phase B, then exhaust the remaining documented work.
3. Run focused behavioral regressions for every repair and the affected lint,
   type, generated, snapshot and package contracts. Keep repaired ownership
   behavior and boundary denial assertions direct.
4. Complete all local required modes on a stable source state. Run native-only
   obligations on their actual platforms. Preserve all raw failures and reports.
5. Reconcile the intended index and working tree before commit. Verify frozen
   artifacts, vendor manifest and notices; let the normal hooks run when a
   commit is actually authorized. Inspect automatic changes and revalidate.
6. Before any authorized push, require current applicable local evidence. Let
   the normal typecheck hook run, then verify the exact remote SHA. Check the
   actual PR base and merge result rather than relying on an earlier SHA.
7. Observe every required and relevant independent workflow. For each failure,
   obtain job logs, reproduce the defect, repair it, and rerun affected jobs.
   A canceled superseded run is incomplete; an infrastructure retry is recorded
   honestly and does not replace investigation of repeatable test failures.
8. Confirm approvals, unresolved discussions, conflicts, branch currency and
   policy checks. If no checks appear, inspect mergeability and workflow trigger
   conditions before trying another push. Do not create empty commits or toggle
   PR state to conceal missing execution.
9. Freeze the final result table: source/index/commit identifiers, tool versions,
   platform, command, run URL or log, exit status, duration, report paths and
   applicability. Any required red, missing, canceled, or unverified entry keeps
   full green open. Re-run evidence invalidated by a subsequent correction.

## 7. Acceptance terminology

**Commit-ready:** the intended index is reviewed, hook obligations and affected
local verification pass, and automatic hook edits are accounted for.

**Push-ready:** commit content has current local evidence and the normal
pre-push typecheck passes. Native remote-only evidence may still be pending;
that status must be stated explicitly.

**Merge-ready / full green:** every task acceptance item, native matrix entry,
applicable CI/CD check, source audit, coverage requirement, mutation target,
browser audit and review requirement has final-state evidence. Commit-ready or
push-ready is not the full-green claim.

## References

- Local authority: `lefthook.yml`, `package.json`, `scripts/run-gates.ts`, all
  workflow sources and `scripts/check-vendor-manifest.sh`.
- [Lefthook stage_fixed](https://lefthook.dev/configuration/stage_fixed/)
  documents automatic staging by pre-commit.
- [GitHub required-check troubleshooting](https://docs.github.com/en/pull-requests/how-tos/merge-and-close-pull-requests/troubleshooting-required-status-checks)
  explains accepted statuses and latest-commit requirements.

## Latest read-only remote check

`gh pr view --json number,url,headRefOid,statusCheckRollup` on the inspected
`master` branch still reports no pull request for `d4551:master`.
`/tmp/dsh-finish-remote-ci-error.log` retains the result. There is no remote
check run covering the dirty local content, and no branch, commit, push,
PR, merge, publication, or deployment was created by this verification.
