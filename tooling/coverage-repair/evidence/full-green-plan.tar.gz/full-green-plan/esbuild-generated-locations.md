# Generated export source locations

The isolated esbuild 0.28.2 candidate emits unmapped source-map segments for
compiler-created namespace exports. Authored functions, including authored
getters, retain their real source locations and native execution counts. No
coverage callback, helper-name exclusion, source omission, or counter adjustment
is added. Root dependencies have not been changed.

## Source repair

`internal/linker/linker.go` assigns negative locations to the generated export
statements, getter bodies, references, property keys, and closing tokens.
Their previous zero-valued locations pointed to the first authored token.

`internal/sourcemap/sourcemap.go` emits the standard one-field segment for a
location without an original source. It retains the original-coordinate delta
state and ends mapped-line propagation at that boundary. The chunk records
whether an authored mapping exists independently of its current boundary state.
Chunk concatenation rebases source coordinates at the first mapped segment,
even when unmapped segments precede it. Original-name deltas remain independent.

The representation follows the [ECMA-426 mappings structure](https://tc39.es/ecma426/#sec-mappings-structure).
The generated code remains executable; only false authored provenance changes.

## Verification

| Check | Result |
| --- | --- |
| Eight native ESM/CommonJS, whitespace and retained-name cases | 8 passed; unchanged official compiler has 4 passed and 4 failed |
| Eight bundled native cases with two authored modules, authored getters, ES5/ESNext and full minification | 8 passed; unchanged official compiler fails all 8 |
| Same bundled cases using independently reconstructed compiler | 8 passed |
| Go boundary tests | Three top-level tests pass, including seven concatenation cases |
| Go boundary negative controls | Official source fails five concatenation cases and panics on the negative-location transition |
| Complete upstream Go tests | Passed in working source and fresh reconstruction |
| Complete Go static checks | `go vet ./...` passed |
| Unchanged upstream source-map suite | Passed after installing its original fixture manifest |
| Native Git patch check/application | Passed against the fresh official archive |
| Reconstructed executable | Byte-identical to the working source build |

The bundled native cases require exactly seven authored functions/accessors,
their exact source files and lines, and real executed/unexecuted counts. Both
modules' generated export getters are present in executed output. Inspector's
script source must equal the compiler output. Tests retain the raw code, source
maps, native coverage, independently queried mappings and converted coverage.

Reproducible builds use `go build -trimpath -buildvcs=false
'-ldflags=-s -w -buildid='`. Both executables have SHA-256
`3fbd95b2edaaddbe298d9d1c0bcee46e0e5e7821967c6099d76131946bd12300`.
`esbuild-generated-locations.patch` contains the two source changes and the
boundary test. The archive, patch, source inputs, binaries, logs and native
captures are fingerprinted in `native-toolchain-repair-evidence.json`.

The first boundary-test draft had incorrect hand-calculated VLQ expectations
and one incorrect name offset; its failure log remains. Corrected expectations
express negative original-coordinate deltas and agree with independent native
mapping checks. No production assertion is weakened.

The first full upstream mapping run lacked React and Fuse fixture packages;
all four complex fixture variants failed and that log remains. Installing the
unchanged upstream fixture manifest permits the complete suite to pass. Those
historical fixture dependencies report one high-severity npm audit finding;
they are not promoted into root dependencies or accepted as a modern toolchain.
The separate source-map 0.8.0 validation install is also isolated. Existing
upstream test catches and cleanup behavior remain unchanged.

## Remaining acceptance

This establishes the namespace-export producer correction, not complete source
mapping correctness for every transformation. Nested input-map gaps and other
generated AST locations still require review. Packaging for supported platforms,
runner/converter integration, exact child transport and the complete unsuppressed
coverage/mutation matrix remain open. No source-map exclusion is a substitute
for those requirements. The repository is not green.
