# Native CLI shutdown repair

The production shutdown controller previously exited zero without a diagnostic
when normal or SIGTERM disposal rejected, threw synchronously, or exceeded its
deadline. Native reproduction of the original HEAD source records all four
cases in `/tmp/dsh-process-shutdown-baseline.json`.

`apps/cli/src/process-shutdown.ts` now reports unsuccessful disposal and changes
a requested zero exit code to one. Explicit nonzero codes remain intact. Normal
success records `process.exitCode` and permits pending work to drain; interrupts
exit after successful disposal, and another interrupt forces immediate exit.
The disposer has one retained settlement promise. Failed settlement is reported
and terminates the process, rather than being silently consumed.

All exit-function and timer overrides were used only by tests; the sole
production consumer in `profile-boot.ts` supplied only its application disposer.
Those overrides and the associated redundant completion flags are removed.
The controller owns the production five-second deadline directly. Its coverage
directive is removed. No new directive, callback cast, rejection handler,
test-only implementation branch, or configurable test clock is introduced.

The nine former simulated tests are replaced by sixteen native child scenarios.
They verify natural completion and event-loop drainage, thrown/rejected cleanup,
nonzero failure reporting, the actual five-second deadline, first-interrupt
disposal, second-interrupt escalation, escalation of pending normal shutdown,
promise identity and first-code ownership, and interruption after natural
completion. Real child exit status, stdout event order, stderr diagnostics,
signals, and parent timeout results are asserted. The custom grace-period test
has no production consumer and is replaced by the production-deadline cases.
The fixture is `apps/cli/tests/fixtures/process-shutdown.mjs`; the suite remains
at `apps/cli/tests/process-shutdown.spec.ts` in the unchanged discovery graph.

The EN/ZH CLI behavior reference and its consistency sidecar describe the
verified failure codes. The existing SIGTERM source comment is corrected.

## Verification

- All 16 native shutdown tests pass in
  `/tmp/dsh-process-shutdown-native-coverage.log`.
- Strict coverage exits 1. It reports four missing branches and 60% branch
  coverage. This is not accepted coverage evidence: Inspector proves TSX
  executes different bytes from the collector's stripped-TypeScript transform.
  The first retained-promise return begins at generated offset 270 but at
  offset 1203 in the collector's substitute source. Details and SHA-256 hashes
  are in `/tmp/dsh-shutdown-transform-identity.json`; captured sources are
  `/tmp/dsh-shutdown-executed.js` and
  `/tmp/dsh-shutdown-coverage-transform.js`. Collection is not disabled or
  modified. CI-04 remains open.
- Complete product build passes in
  `/tmp/dsh-process-shutdown-product-build.log`. The existing oversized web
  bundle warning remains open.
- Rebuilt CLI acceptance and real PTY shutdown pass all 23 cases in
  `/tmp/dsh-process-shutdown-cli-e2e.log`.
- The complete owning CLI suite passes 59 cases with one existing opt-in smoke
  skipped in `/tmp/dsh-process-shutdown-cli-owning.log`. That built-Web smoke
  subsequently runs with `DSH_REQUIRE_BUILT_CLI_SMOKE=1` and passes in
  `/tmp/dsh-process-shutdown-built-web-smoke.log`; it boots the shipped web
  composition and shuts down through SIGTERM. This is macOS/Node 26 evidence,
  not proof of the separate Node 22 or native Windows lanes.
- Scoped and complete typed lint pass in
  `/tmp/dsh-process-shutdown-lint.log` and
  `/tmp/dsh-process-shutdown-full-lint.log`.
- Complete documentation reports 30 passed, two protected-file failures and
  zero skipped in `/tmp/dsh-process-shutdown-doc-sync.log`.
- Whole-worktree whitespace passes; the externally staged older Stryker patch
  payloads still fail index whitespace in
  `/tmp/dsh-process-shutdown-index-whitespace.log`.
- Complete source scan `source-20260916142530618.json` records 651 directives:
  533 coverage and 118 lint, all outstanding violations. The corpus is 4,044
  files; its hash is
  `db9a664b89718840aa80d2017558a7b26a2f3b6670e6407ccd587e5e95dae51d`.

## Mutation outcome and newly exposed instrumenter filter

The command-runner measurement exits zero and reports 34 killed, zero survived,
zero timeout, zero no-coverage and zero error mutants. Every command runs all
16 native tests. All 34 status reasons were inspected and contain actual
behavioral assertion failures, including production hangs detected by the
child timeout assertion. No startup/cache/import infrastructure failure was
accepted as a kill. Source bytes in the report equal the current full module.
Raw evidence is `/tmp/dsh-process-shutdown-mutation.json`,
`/tmp/dsh-process-shutdown-mutation.log` and
`/tmp/dsh-process-shutdown-mutation-events/`; the per-mutant review is
`process-shutdown-mutation-review.json`.

**The reported 100% is not accepted as unfiltered mutation evidence.** Installed
`@stryker-mutator/instrumenter@10.0.0` has a `CallExpression` mutator filter that
removes its candidate when another mutation exists in the same subtree. It
omits deletion of both diagnostic calls because each contains a string mutation.
The lost candidates correspond to IDs 9 and 20 between the reported IDs 0–35.
Running the installed mutators against the real source AST independently
reproduces both removals in `/tmp/dsh-shutdown-omitted-mutations.json`.

The relevant upstream implementation is
`src/mutators/empty-expression-mutator.ts` and the filter application in
`src/transformers/babel-transformer.ts`, both at upstream commit
`cb3bd8fe25d5215422c9b632357062d3a43fcf92`. Source-owned dependency repair must
retain those call-removal candidates, rebuild the package and its maps from
source, verify clean package-managed installation, add a regression that
retains both the outer call deletion and inner string mutation, and rerun the
complete affected mutation corpus. Do not restructure production diagnostics
to influence mutation selection or add a plugin that hides other candidates.

The initial scratch command-runner config carried an unused Vitest plugin
setting and emitted an unknown-option warning. The inapplicable setting is
removed. A separate dry run with the corrected configuration passes without
that warning in `/tmp/dsh-process-shutdown-mutation-dry.log`; its outputs do not
overwrite the raw mutation result. The strict 99 threshold, complete module
input, and ordinary test-discovery rules remain unchanged. Shared package
dependencies, source enforcement, and coverage options are unchanged. No
repository-wide mutation score or full-green result is established.

## Follow-up: complete candidate accounting

The source-owned instrumenter repair now passes canonical rebuild, independent
artifact reproduction and native candidate-execution regressions. The complete
shutdown rerun detects all 36 mutants, including formerly omitted IDs 9 and 20,
with zero survivors, timeouts, no-coverage outcomes or errors. All 36 reasons
are reviewed behavioral assertions; source bytes match the current full module.
This result is accepted for the scoped module; coverage and repository-wide
acceptance remain open. See `instrumenter-accounting-repair.md` and
`process-shutdown-unfiltered-review.json`. The earlier 34-candidate report
remains historical and unaccepted.

## References

- https://nodejs.org/api/process.html#processexitcode
- https://nodejs.org/api/timers.html
- https://stryker-mutator.io/docs/stryker-js/configuration/
- https://vitest.dev/config/coverage
