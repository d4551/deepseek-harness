# Complete normal tests after root toolchain integration

`bun run test` completed with exit 1 in 297.16 seconds, using Node 26.8.2 and
Vitest 5.0.1. Results: 1,374 passed files, three failed files, seven skipped
files; 20,407 passed tests, three failed tests, 42 skipped tests. All 67 actual
accessibility audit tests executed and passed the complete candidate inventory
check. Raw output: `/tmp/dsh-stryker-root-full-tests.log`.

## Every failure

1. `scripts/suppression-justifications.spec.ts`: the complete authored-source
   corpus contains 2,453 prohibited findings: 651 directives (533 coverage,
   118 lint), 1,445 catch clauses and 357 static catch-handler accesses.
   The assertion still requires an empty finding list. Unresolved.
2. `scripts/bun-conversion-residue.spec.ts`: official upstream metadata in
   `tooling/stryker/provenance/browser-peer-metadata.json` contains the upstream
   package-manager name. The existing word gate rejects it. The provenance
   remains truthful and unchanged; no gate exemption is added. Unresolved.
3. `packages/sdk/server/tests/server.spec.ts`: image-admission assertion
   expected one argument, while the cancellation-aware API receives image
   bytes plus an explicit second `undefined` argument. Reproduced independently
   in `/tmp/dsh-sdk-image-admission-before.log`. Corrected to assert the complete
   call and exactly one admission and delivery. All 40 SDK/admission tests pass
   in `/tmp/dsh-sdk-image-admission-after.log`, and owning typed lint passes in
   `/tmp/dsh-sdk-image-admission-lint.log`. Resolved in owning replay.

The full suite had executed the older SDK assertion before that test correction.
Its final code frame reads the newer file but its captured expectation and call
diff are from the earlier execution. No full-suite rerun after this correction
is claimed. The intentional nested `source.spec.ts` failure tests the runner's
failure propagation; it is not a fourth failing top-level test.

The earlier three Worker sandbox failures do not recur in this complete run.
The 42 skips still require their actual target environments; they are not passes.
This ordinary run does not measure strict coverage or repository mutation.
Warnings retained in the log also require their separate repair.

Final source snapshot: `source-20260916150004271.json`, 4,049 files,
SHA-256 `2d2450883b13a7f7b63b11ce435fb078191cfddb1070adf27eaca788a774a53c`.
HEAD remains `8f8780a13e40205c50518fa34b8cf11e3a6d141c`; the worktree is dirty.
