# Complete gate command inventory

Derived from all exported local/CI modes. This list does not replace workflow-only native Windows, Python, Wine, provider, sandbox, or deployment build checks. Passing evidence is scoped and is not a final green claim.

## runtime closure

```sh
bun run verify-runtime-closure
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## Cordis config

```sh
bun run verify-cordis-config
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## client domain graph

```sh
bun run verify-client-domain-graph
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all

## test

```sh
bun run test
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all

## Issue management policy

```sh
bun run test:issue-management
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## duplication

```sh
bun run duplication
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, ci-primary, ci-linux-primary, ci-lint-contracts-ready, ci-windows-complete, ci-windows-observational

## mutation score (util tier)

```sh
bun run mutation
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, ci-primary, ci-linux-primary

## test:snapshot

```sh
bun run test:snapshot
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, ci-primary, ci-linux-primary, ci-snapshot, ci-consumers

## test:expected

```sh
bun run test:expected
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, ci-consumers

## build

```sh
bun run build
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, ci-primary, ci-linux-primary, ci-snapshot, ci-artifacts, ci-consumers, ci-windows-blocking, ci-windows-complete, ci-windows-observational

## build:web

```sh
bun run build:web
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all

## vendor rescope

```sh
bun run rescope-vendor:check
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene

## knip

```sh
bun run knip
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## publint

```sh
bun run publint
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-artifacts, ci-consumers, ci-windows-complete, ci-windows-observational

## constraints

```sh
bun run constraints
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## application entrypoints

```sh
bun run verify-application-entrypoints
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## DSH package licenses

```sh
bun run verify-dsh-package-licenses
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## package invariants

```sh
bun run verify-package-invariants
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## built package invariants

```sh
bun run verify-built-package-invariants
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-artifacts, ci-consumers, ci-windows-complete, ci-windows-observational

## node-next types

```sh
bun run verify-node-next-types
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-artifacts, ci-consumers, ci-windows-complete, ci-windows-observational

## optional dependency imports

```sh
bun run verify-optional-dependency-imports
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## client packages

```sh
bun run verify-client-packages
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## client UI i18n

```sh
bun run verify-client-ui-i18n
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, hygiene, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## doc-typecheck:contracts-ready

```sh
bun run doc-typecheck:contracts-ready
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, ci-primary, ci-linux-primary, ci-consumers, ci-windows-complete, ci-windows-observational

## documentation build / production site

```sh
bun run docs:build
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-windows-blocking, ci-windows-complete

## doc graphs

```sh
bun run verify-doc-graphs
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## markdown links

```sh
bun run verify-md-links
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## type equivalence

```sh
bun run verify-type-equiv
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## cordis catalog

```sh
bun run verify-cordis-catalog
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## Cordis inspect catalog

```sh
bun run verify-cordis-inspect-catalog
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## verify-mermaid

```sh
bun run verify-mermaid
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## scoped events

```sh
bun run verify-scoped-events
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## translation pairing

```sh
bun run verify-translation-pairing
```

Whole-corpus recheck passed: 1,180 pairs, after concurrent pairing write completed.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## markdown wrap

```sh
bun run verify-md-wrap
```

FAILED: immutable AGENTS.md conflict.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## client catalog

```sh
bun run verify-client-catalog
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## export jsdoc

```sh
bun run verify-export-jsdoc
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## tool catalog

```sh
bun run verify-tool-catalog
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## config catalog

```sh
bun run verify-config-catalog
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## persistence catalog

```sh
bun run verify-persistence-catalog
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## public repository links

```sh
bun run verify-public-repository-links
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## doc refs

```sh
bun run verify-doc-refs
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## subsystem pages

```sh
bun run verify-subsystem-pages
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## package paths

```sh
bun run verify-package-paths
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## tsconfig paths

```sh
bun run verify-tsconfig-paths
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## config source ownership

```sh
bun run verify-config-source-ownership
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## package README model experience

```sh
bun run verify-package-readme-model-experience
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## agent note classification

```sh
bun run verify-agent-note-classification
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## agent note format

```sh
bun run verify-agent-note-format
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## archived agent notes

```sh
bun run verify-archived-agent-notes
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## skill invocation metadata

```sh
bun run verify-skill-invocation-metadata
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## translation prompt

```sh
bun run verify-translation-prompt
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## doc budgets

```sh
bun run verify-doc-budgets
```

FAILED: immutable AGENTS.md conflict.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## documentation standard tests

```sh
bun x vitest run scripts/doc-standard.spec.ts
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## documentation site checks

```sh
bun x vitest run scripts/project-doc-site.spec.ts scripts/verify-doc-site-fragments.spec.ts
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## package README limitations

```sh
bun run verify-package-readme-limitations
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: check-all, doc-sync, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## module graph

```sh
bun run verify-module-graph
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: check-all, ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## vendored links

```sh
bun run verify-vendored-links
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: hygiene

## doc-typecheck

```sh
bun run doc-typecheck
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: doc-sync

## toolchain floors

```sh
bun run verify-toolchain-floors
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, ci-static, ci-windows-complete, ci-windows-observational

## Typert contracts

```sh
bun run build:lib:host
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary

## typecheck:contracts-ready

```sh
bun run typecheck:contracts-ready
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary

## lint:contracts-ready

```sh
bun run lint:contracts-ready
```

FAILED: 385 errors in latest full lint.

Modes: ci-primary, ci-linux-primary, ci-lint-contracts-ready

## test:coverage

```sh
bun x vitest run --coverage
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, ci-coverage, ci-windows-complete

## source worker smoke

```sh
bun x vitest run packages/workflow/workflow-worker-thread/tests/source-worker.compat.spec.ts
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, node-compat

## JSONL Zstandard smoke

```sh
bun x vitest run packages/session/session-persistence-jsonl/tests/zstd.compat.spec.ts
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, node-compat

## dsh source-launch smoke

```sh
bun x vitest run apps/cli/tests/source-launch.compat.spec.ts
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, node-compat

## Vitest jsdom smoke

```sh
bun x vitest run scripts/vitest-environment.compat.spec.ts
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, node-compat

## duplicate exports

```sh
bun run verify-duplicate-exports
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary

## coverage debt markers

```sh
bun run verify-coverage-debt
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary

## built artifact suites

```sh
bun x vitest run packages/client/ui-trajectory/tests/client-bundle.client.spec.ts packages/session/session-persistence-sqlite/tests/built-package.spec.ts
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, ci-artifacts

## built image suites

```sh
bun x vitest run --config vitest.built.config.ts
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, ci-artifacts

## built-bin smoke

```sh
bun x vitest run --config vitest.e2e.config.ts apps/cli/tests/profiles/headless/tests/keyless-smoke.e2e.ts apps/cli/tests/built-bin.e2e.ts packages/host/directory-picker-native/tests/built-worker.e2e.ts packages/sdk/server/tests/built-scope-carrier.e2e.ts packages/subagent/subagent-codex/tests/loader-composition.e2e.ts packages/subagent/subagent-claude-code/tests/loader-composition.e2e.ts packages/api/remotes/tests/built-lib.e2e.ts packages/subagent/agent-team/tests/built-lib.e2e.ts packages/workflow/workflow-worker-thread/tests/built-worker.e2e.ts packages/code-runtime/code-runtime-worker-thread/tests/built-lib.e2e.ts packages/lsp/lsp-stdio/tests/built-lib.e2e.ts
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-primary, ci-linux-primary, ci-artifacts, ci-consumers, ci-windows-blocking, ci-windows-complete

## web browser snapshot

```sh
DSH_SNAPSHOT=replay bun run test:web:built
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-linux-primary, ci-consumers

## documentation build

```sh
bun run docs:build:mpa
```

Passed in latest documentation aggregate; final frozen-revision replay remains required.

Modes: ci-static, ci-windows-observational

## Node compatibility

```sh
bun run check:node-compat
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: ci-consumers

## lint and duplication

```sh
bun run check:ci:lint:contracts-ready
```

FAILED: 385 errors in latest full lint.

Modes: ci-consumers

## typecheck

```sh
bun run typecheck
```

No complete passing evidence for the final worktree in this inventory. Must execute or associate a verified log.

Modes: node-compat
