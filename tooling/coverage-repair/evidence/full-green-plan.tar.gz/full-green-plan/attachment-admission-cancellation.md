# Attachment admission cancellation — 2026-09-16

Status: implemented slice, incomplete strict acceptance. This does not close B4
quarantine, request preparation/replay, mutation acceptance, or complete green.

## Behavior

Admission methods and the encoded-image helper accept the caller's signal.
`read_image` forwards its execution signal. The local provider removes queued
compression work when cancelled and retains active slots until native work
settles. Every batch joins all preparation promises before returning failure;
native operation failures retain their original identity. Normalization checks
cancellation between owned operations and does not start later candidates.

Storage checks cancellation before staging/publication. Once the atomic
publication operation starts, durability finishes; cancellation does not mask
a later publication failure. Earlier committed batch objects remain stored.
Staging handles close through `finally`, so close errors are no longer discarded.
Cleanup uses native non-recursive removal of its uniquely named staging file;
an absent staging file is already clean, while other removal errors still fail.

Twelve storage coverage directives and one test lint directive are removed.
The old private non-Error conversion expectation is replaced by preservation
of a native filesystem error. A separate native AbortSignal regression proves
that primitive cancellation reasons propagate unchanged and release the slot,
without a suppression or an artificial rejection. Existing FIFO, synchronous
failure, storage, integrity and image assertions remain enforced.

## Verification

| Evidence | Result | Log |
| --- | --- | --- |
| Initial cancellation regressions | Failed against uncancellable admission; initial assertion scheduling also reported an unhandled rejection, corrected by immediate joint ownership | `/tmp/dsh-admission-cancellation-before.log` |
| Built Loader first attempt | Failed because its fixture imported an undeclared package; corrected to the actual repository-owned built boot entry | `/tmp/dsh-admission-cancellation-final-owning-native.log` |
| Built Loader acceptance | Pass: cancelled batch creates no objects; subsequent admission saves and reads identical bytes | `/tmp/dsh-admission-loader-after.log` |
| First strict owning replay | 149 pass, one native-Windows skip; 13 uncovered locations | `/tmp/dsh-admission-cancellation-strict-coverage.log` |
| Final strict owning replay | 150 pass, one native-Windows skip; six uncovered locations; exit 1 | `/tmp/dsh-admission-cancellation-final-coverage.log` |
| Additional primitive-reason regression | Five limiter tests pass; typed lint passes | `/tmp/dsh-admission-native-reason-test.log`, `/tmp/dsh-admission-native-reason-lint.log` |
| Complete product build | Pass, existing oversized-chunk warning remains | `/tmp/dsh-admission-cancellation-final-build.log` |
| Complete typed lint | Pass; final test addition separately passes typed lint | `/tmp/dsh-admission-final-full-lint.log` |
| Canonical API catalog | 97 artifacts computed, three updated, one pair record refreshed | `/tmp/dsh-admission-catalog.log` |
| README/owning-note bilingual records | Three reviewed pairs recorded; complete pairing gate passes | `/tmp/dsh-admission-pairing.log` |
| Quick documentation aggregate | 13 pass, two protected-file failures, zero skipped | `/tmp/dsh-admission-doc-quick.log` |
| Complete documentation aggregate | 30 pass, two protected-file failures, zero skipped; 208.20 seconds | `/tmp/dsh-admission-final-doc-sync.log` |
| Changed attachment whitespace | Pass | `/tmp/dsh-admission-scoped-whitespace.log` |
| Complete diff whitespace | Exit 2: existing toolchain patch payloads | `/tmp/dsh-admission-final-whitespace.log` |

The strict run selects every affected source: attachment-local compression
limiter, encoding, normalization, store and service; attachment service and
base64 admission; tool-fs read-image. Thresholds remain per-file 100% for every
metric. Totals: statements 371/374 (99.19%), branches 213/216 (98.61%), functions
70/70 and lines 343/343. Storage alone reports 97.5% statements and 95% branches.
All other selected files reach all four 100% metrics. These are coverage values,
not mutation or accessibility scores.

Remaining uncovered locations in `attachment-local/src/store.ts`:

- Line 179: filesystem-root guard, branch and statement.
- Line 205: non-EEXIST publication error propagation, branch and statement.
- Line 283: pre-publication cleanup cancellation check, branch and statement.

Existing simulated Windows tests remain test debt; this replay is not native
Windows durability evidence. Native fault coverage for cancellation during
staging and after atomic publication remains open. The new Loader acceptance
exercises the actual provider, but does not establish a complete real-agent
`read_image` cancellation journey. Remaining RPC callers and shared request
cancellation ownership require separate source tracing and verification.

## Inventory and delivery

Final complete snapshot: `source-20260916130633427.{json,md}`. It contains 4,040
files and 2,460 findings: 658 directives (540 coverage, 118 lint), 1,445 catch
clauses and 357 static catch-handler accesses. Corpus SHA-256:
`f8e9dc8c458c5460f9516da0903b8c8379241859133fb5949fed48e44e1a8107`.
`suppression-inventory-diff-130633.md` verifies 245 removals and zero additions
across 24 files against the 903-directive baseline. Every remaining directive
is a violation. Configuration enforcement debt is tracked separately.

HEAD remains `8f8780a13e40205c50518fa34b8cf11e3a6d141c`. An external actor
continues changing the index. This task has not staged, committed or pushed;
the index and remote CI do not establish acceptance for the dirty worktree.

The existing image-pipeline Agent Note is retained and updated because it owns
batch preparation, native compression capacity and immutable publication.
The Web ordering note remains independently useful; no note is archived or
superseded by this cancellation slice.
