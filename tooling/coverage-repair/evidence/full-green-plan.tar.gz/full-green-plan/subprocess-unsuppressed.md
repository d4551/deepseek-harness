# Subprocess launch coverage exclusions

The complete launch implementation and owning tests were read before
editing. All eleven coverage directives in
`packages/subprocess/subprocess-local/src/spawn.ts` are removed. Production
statements, process guards, tests, configuration and thresholds are unchanged.
This exposes the existing branches to measurement; it does not establish that
all branches execute or that the existing simulated-platform tests provide
native operating-system evidence.

The complete package coverage command runs all eleven test files with source
measurement focused on the only changed module:

```sh
bun x vitest run packages/subprocess/subprocess-local/tests --coverage --coverage.include='packages/subprocess/subprocess-local/src/spawn.ts' --coverage.reportsDirectory=/tmp/dsh-subprocess-unsuppressed-coverage
```

It exits 1: 181 tests pass, two fail and two native-Windows tests remain skipped
on this macOS host. Both failures assert the exact isolated child environment;
the collector injects `NODE_V8_COVERAGE` into the child's explicit environment.
The provider also attempts to parse source-loaded TypeScript as JavaScript,
reports that it excludes the executed source, and returns 0/263 statements,
0/175 branches, 0/45 functions and 0/224 lines. Those percentages are invalid
measurement, not a claim that the passing runtime tests executed no code.
Full evidence is `/tmp/dsh-subprocess-unsuppressed-coverage.log` and its report
directory. No collection option, environment assertion or failure was removed.

Typed lint passes in `/tmp/dsh-subprocess-unsuppressed-lint.log`; changed-file
whitespace also passes. The ordinary package replay is recorded separately in
`/tmp/dsh-subprocess-unsuppressed-tests.log`: all eleven files pass, 183 tests
pass and two native-Windows tests remain skipped; exit 0 in 31.66 seconds.
Ordinary execution cannot discharge
the strict coverage failures.

The exposed source still contains error-handling and type-assertion debt,
simulated-platform tests and platform-specific acceptance gaps. Repairing the
collector requires exact child-environment preservation and correct executed
JavaScript/source-map identity; the owning CI-03 and CI-04 entries retain the
complete acceptance matrix.

Current Node API reference consulted:
https://nodejs.org/api/child_process.html.
