# TypeScript AST contract repair

The worktree remains **not green**. This repair removes eight lint suppressions by correcting the source-owned TypeScript property-signature schema, retaining the existing missing-annotation checks, and rejecting unannotated slot declarations explicitly.

## Source and reconstruction

- Official TypeScript 7.0.2 commit: `2bd066d87f5bafd315be9f40889d0a60b9e58e0b`.
- Source archive SHA-256: `5ccb47dbb3f68cd0da58b71e6f445eee36a50bd3e9f9f330cc23a97b88500119`.
- Native parser permits missing property annotations and initializers. The published schema incorrectly marks both fields as required.
- `tooling/typescript/schema.patch` corrects those two schema fields. The upstream generator regenerates the declarations and factory parameter types; strict TS7 compilation rebuilds the complete JavaScript API.
- All 364 distribution files are inventoried. Every executable JavaScript file must match the published package byte for byte. Only two declaration files and 23 declaration maps differ.
- `tooling/typescript/rebuild.mjs` reconstructs the complete patch and inventory using verified archives, frozen build dependencies, and the recorded Node/Bun versions. Independent reconstruction checks artifact equality.
- Root `package.json` and the normally generated `bun.lock` install the package patch. Third-party notices and the bilingual owner records are current.

## Repaired consumers

Eight lint directives are removed from six files without removing their checks:

| File | Directives removed |
| --- | ---: |
| `packages/typert/generator/src/analyzer-maps.ts` | 2 |
| `packages/typert/generator/src/analyzer-collect.ts` | 2 |
| `scripts/cordis-walk.ts` | 1 |
| `scripts/gen-config-catalog-load.ts` | 1 |
| `scripts/gen-config-catalog-lookup.ts` | 1 |
| `scripts/gen-persistence-catalog-scan.ts` | 1 |

Corrected declarations exposed four unsafe reads in `scripts/slot-walk.ts` and `scripts/slot-walk-text.ts`. Ten real-parser cases reproduced the crashes before repair. Slot and standard-prop declarations now produce explicit annotation errors. An annotated optional-property case preserves the normal catalog output. Two additional config-catalog cases check documentation diagnostics and distinguish an absent nested annotation from a known missing key. Generator regressions reject unannotated lookup and context map entries.

## Verified results

All commands use Node 26.8.2 and Bun 1.4.2 on native macOS arm64.

| Check | Result | Evidence |
| --- | --- | --- |
| Absent-value compiler contract before correction | Failed with two TS2322 diagnostics | `/tmp/dsh-typescript-ast-contract-before.log` |
| Canonical source reconstruction | Passed; all 364 API files rebuilt | `/tmp/dsh-typescript-ast-rebuild.log` |
| Independent fresh reconstruction | Passed; exact artifact equality | `/tmp/dsh-typescript-ast-independent-check.log` |
| Missing slot annotation regressions before repair | Ten failed, one passed | `/tmp/dsh-slot-annotations-before.log` |
| Slot and client catalog regressions after repair | 36 passed | `/tmp/dsh-slot-annotations-after.log` |
| Complete affected owning suites, final run | 426 passed across 31 files; no skips | `/tmp/dsh-typescript-ast-final-owning-coverage.log` |
| Strict coverage over all eight affected source files | **Failed**: 237 uncovered locations; 88.77% statements, 81.15% branches, 95.48% functions, 94.41% lines | Same final owning log; unchanged per-file 100% thresholds |
| Full product build | Passed; existing large-chunk warning remains | `/tmp/dsh-typescript-ast-product-build-after.log` |
| Final full typed lint | Passed | `/tmp/dsh-typescript-ast-final-full-lint.log` |
| Reconstruction tooling lint | Passed | `/tmp/dsh-typescript-ast-tooling-lint.log` |
| Workspace constraints | Passed | `/tmp/dsh-typescript-ast-constraints.log` |
| Third-party notices freshness | Passed | `/tmp/dsh-typescript-ast-notices-check.log` |
| Complete documentation aggregate | **30 passed, two failed, zero skipped**: protected AGENTS wrapping and root word budget | `/tmp/dsh-typescript-ast-doc-sync.log` |
| Working-tree and HEAD whitespace | Passed | `git diff --check`; `git diff HEAD --check` |

The first coverage invocation omitted the existing config-catalog owning suite and produced 554 uncovered locations. Its log remains `/tmp/dsh-typescript-ast-strict-coverage.log`. Including that suite exposed 239 locations; the two new annotation cases reduced the final count to 237. All eight sources remain included throughout. No coverage threshold, gate, test filter, retry rule, or exclusion was changed.

## Clean installation

Copied 10,071 present tracked and non-ignored untracked files into `/tmp/dsh-typescript-root-frozen-lxmo1zku`, without copying the original dependency tree or Git metadata. Two tracked deleted old patch paths remained absent, matching the worktree. The later config annotation test addition does not change installation inputs.

`bun install --frozen-lockfile --cache-dir /tmp/dsh-typescript-root-frozen-lxmo1zku-cache` passed with normal lifecycle scripts and 1,109 packages. The lockfile remained SHA-256 `abf5dc053da026f7232568b09244016b33087a1c00924b9e46905e8a36e9011a`.

`bun x vitest run scripts/typescript-ast-contract.spec.ts` passed all three tests in that clean checkout: all installed API bytes and the complete file set match, generator resolution shares the same package, strict absent-value compilation succeeds, and the actual factory and native parser execute correctly.

Evidence: `/tmp/dsh-typescript-root-frozen-copy.json`, `/tmp/dsh-typescript-root-frozen-install.log`, `/tmp/dsh-typescript-root-frozen-contract.log`. This is native macOS evidence, not Linux/Windows evidence.

## Remaining acceptance

The final source scan at `2026-09-16T15:23:50.649Z` covers 4,054 files at HEAD `8f8780a13e40205c50518fa34b8cf11e3a6d141c` plus dirty changes. Corpus SHA-256: `49c66f1368f15c19d43e36b86c7d5a50dd3aa85f23e58d2733b06d302337bd9d`.

It reports **643 directive suppressions: 533 coverage and 110 lint**. All remain violations. It also reports 1,445 catch clauses and 357 static catch-handler accesses, totaling 2,445 source findings. Full listings are `source-20260916152350649.md` and `suppressions-outstanding.md`.

The exact 903-directive baseline comparison verifies 260 removals and zero additions across 32 files in `suppression-inventory-diff-152023.md`. That comparison precedes the final added test file, which contains no directives; suppression occurrences are unchanged.

Strict coverage, complete repository mutation at 99%, the source prohibition gate, 217 empty invariant installers, protected documentation checks, native platform obligations, source-remapping defects, provider catalog updates, B4 attachment recovery, and delivery/index verification remain open. No stage, commit, push, PR, merge, or publication was performed. This bounded repair does not establish full green.
