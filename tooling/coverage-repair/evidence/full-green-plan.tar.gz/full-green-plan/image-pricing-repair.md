# Current DeepSeek image-token pricing and suppression removal

The pricing module implements the official calculator's current V4.1 geometry.
All six of its coverage directives are removed, with zero new directives. The
complete owning suite passes 652 tests, but strict coverage remains red on five
failure-guard locations. Full-green acceptance remains open.

## Verified defect and repair

The module priced the retired experimental V4 layout: a 384-token cap, a
384×384 pixel floor, an 8:1 width clamp, even-row alignment, and worst-case
pad-to-four. Current official vision documentation specifies a 1,024-token cap
and a 544×544 pixel floor. The live calculator uses V4.1 geometry with neither
the old width clamp nor row/alignment padding. Official pricing documentation
states that the old Flash and experimental vision names route to V4.1 Flash.

The repair changes the provider-owned formula and reference expectations
together. It retains the provider's grid-budget and convergence failures;
invalid, nonfinite, fractional, nonpositive, and unsafe integer dimensions now
reject with RangeError. The request pricer still uses its configured upload
projection and byte/count offload rules. Its default 640,000-pixel upload budget
is unchanged and is documented as a harness budget, not the provider's native
image projection.

The old implementation disagrees with all 22 independently collected official
vectors. For 1920×1080, it reports 369 instead of the calculator's 968. At the
harness's default projected 1066×600 size, the correct estimate is 407. The
official calculator was also exercised through the browser and displayed 968
for 1920×1080. No paid API request or production credential was used.

The published JavaScript chunk is retained at
`/tmp/dsh-deepseek-calculator.js`, SHA-256
`68808d86315e5beb08c125f0b42f28b3ee66fe138baa1208322ca59884841b00`.
Its unchanged calculator class is extracted into
`/tmp/dsh-current-deepseek-reference.mjs` for independent comparison.
The repaired function matches it on 3,887,248 dimension pairs: a grid covering
both orientations across 1–8192 and 250,000 deterministic samples through
999,999. This is formula parity evidence, not a guarantee of exact billed usage.

## Evidence

| Check | Result | Log |
| --- | --- | --- |
| Native provider-reference comparison | 22/22 prior vectors differ; 3,887,248 repaired comparisons match | `/tmp/dsh-image-pricing-reference-parity.log` |
| Initial pricing coverage | Tests pass; ten uncovered locations | `/tmp/dsh-image-pricing-current-coverage.log` |
| Expanded DeepSeek/compaction replay | 541 tests pass; five uncovered locations | `/tmp/dsh-image-pricing-owning-coverage.log` |
| Separate actual token-meter directory | 109 tests pass | `/tmp/dsh-image-pricing-token-meter.log` |
| Final focused replay | 37 tests pass; eight locations remain because adapter-owned configuration branches need the broader suite | `/tmp/dsh-image-pricing-final-focused-coverage.log` |
| Final combined owning replay | 652 tests pass across 28 files; strict coverage exits 1 on five locations | `/tmp/dsh-image-pricing-final-owning-coverage.log` |
| Full product build | Exit 0; existing oversized web chunk warning remains | `/tmp/dsh-image-pricing-product-build.log` |
| Built public entry | Correct native estimates and invalid-dimension rejection | `/tmp/dsh-image-pricing-built-consumer.log` |
| Full typed lint | Exit 0; final additional vectors pass scoped typed lint | `/tmp/dsh-image-pricing-full-lint.log`, `/tmp/dsh-image-pricing-final-scoped-lint.log` |
| Quick documentation | 13 passed, two protected-file failures, zero skipped | `/tmp/dsh-image-pricing-doc-quick.log` |
| Full documentation | 30 passed, two protected-file failures, zero skipped | `/tmp/dsh-image-pricing-doc-sync.log` |
| Complete working-tree whitespace | `git diff HEAD --check` exits 0 | `/tmp/dsh-image-pricing-final-whitespace.log` |
| Staged whitespace | Exit 2 on older externally staged toolchain patches | `/tmp/dsh-image-pricing-final-index-whitespace.log` |

An initial command named the nonexistent `packages/context/token-meter/tests`
alongside the real DeepSeek and compaction directories; its result is not claimed
to include token-meter tests. The separate and final combined runs use the
actual `packages/llm/token-meter/tests` directory.

Remaining strict coverage locations in `image-tokens.ts` are lines 50 and 81
(failure branches plus their throw statements), and the line-125 convergence
failure. Request-pricing reaches all four 100% metrics in the combined owning
run. No injected arithmetic failures, patched globals, exposed private solver,
weaker threshold, retry, skip, source exclusion, or coverage directive is used.
No accepted mutation score is established by this work.

The package README and existing route-pricing Agent Note are updated in both
languages and their pairing records are current. The existing note remains
active because its route-neutral accounting and usage-anchor decisions still
govern production consumers; no new note or archive triplet is created.

## Complete remaining inventory

`source-20260916140008214.{json,md}` scans 4,043 files at
2026-09-16T14:00:08Z, HEAD `8f8780a13e40205c50518fa34b8cf11e3a6d141c`
with a dirty worktree. It records 2,454 findings: **652 directives** (534 coverage,
118 lint), 1,445 catch clauses and 357 static catch-handler accesses. Corpus
SHA-256: `ffe9de5df9405cf476e79be570b4db43dfec64ba35503669a93b8bd1574ed9d5`.
The [directive comparison](image-pricing-directive-diff.json) proves six removals
and zero additions against the preceding complete snapshot. All 652 retained
directives remain violations; 217 empty installers are a separate blocker.

Current provider documentation also exposes outdated default model catalog
names/capabilities in the adapter and its README. Those require coordinated
catalog, route, configuration, and consumer repair; this formula repair does
not establish that the entire provider integration is current.

## Primary references

- [Current calculator](https://api-docs.deepseek.com/quick_start/token_usage/)
- [Exact published calculator chunk](https://api-docs.deepseek.com/assets/js/1e0da2c4.9d2e6179.js)
- [Current vision limits](https://api-docs.deepseek.com/guides/vision/)
- [Model routing and pricing](https://api-docs.deepseek.com/quick_start/pricing/)

The complete plan, no-suppression requirement, ≥99 mutation requirement,
native-platform checks, protected-document conflicts, and remote CI acceptance
remain active. No index, commit, push, protected instructions, or gate budgets
were changed.
