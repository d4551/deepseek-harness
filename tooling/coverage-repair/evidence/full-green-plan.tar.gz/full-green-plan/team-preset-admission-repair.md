# Team preset admission repair

The Team tool plugin reads the Agent's actual joined composition when the preset
service exists. It reconciles scoped tools and policy when the tool registry
announces composition changes. A configured preset restriction denies an Agent
that has not joined a composition. Deployments without the preset service
continue to evaluate their recorded creation header.

The session header is immutable creation metadata. Checking it only once left
Team tools callable after switching from standard to minimal and failed to
restore them after the inverse switch. Two added shipped-composition executor
regressions fail on the built pre-repair plugin in
`/tmp/dsh-team-preset-switch-before.log`. Both failures are actual incorrect
`isError` results, not merely differences in displayed tool lists.

## Current source evidence

- The complete owning suite passes 32 tests across four files with no skips.
- Strict full-module coverage passes unchanged thresholds: statements 121/121,
  branches 80/80, functions 30/30, lines 106/106, all 100%.
  `/tmp/dsh-team-preset-final-coverage.log` and
  `/tmp/dsh-team-preset-final-coverage/index.html`.
- Tests mount the real preset service, durable session persistence, Agent
  registry, Team service and tool registry. They exercise absent or contradictory
  creation metadata, uncomposed admission, repeated switches, plugin replacement,
  disposal, and a prepared task-creation call paused at the real execution hook.
  Removing its composition's Team tools prevents that call from changing the board.
- Direct JavaScript-style calls exercise invalid coordination and missing Agent
  identity without type assertions or diagnostic directives.
- Final scoped typed lint passes in `/tmp/dsh-team-preset-final-scoped-lint.log`.
  Two test expression diagnostics were repaired without changing lint policy.
- README and existing profile decision note pairs are updated and recorded.
  No new note or archive is introduced; the existing profile-level ownership
  rationale remains relevant.

## Pending verification and remaining debt

The manifest declares the optional preset-service type dependency, its development
dependency and a project reference, plus the Loader development dependency used
by the new real-service tests. Lockfile reconciliation completed successfully in
`/tmp/dsh-team-preset-install.log`. Complete product build passed in
`/tmp/dsh-team-preset-build.log`, and full typed lint passed in
`/tmp/dsh-team-preset-full-lint.log`.

The rebuilt Web composition replay passes both executor switch regressions.
The test composition now gives session persistence its own directory, avoiding
collisions with the user's real session files. Its result is 31 passed and three
failed in `/tmp/dsh-team-preset-built-web-isolated.log`. The three remaining
failures below retain their original exact assertions.

Config catalog generation and freshness pass. The Chinese declaration and source
line were synchronized, and the pairing record was regenerated. All 25 staged
pairing records and all 1,183 documentation pairs passed on 2026-09-17. Staged
whitespace also passed. This clears the reported translation pre-commit blocker;
it does not clear the two protected-file documentation aggregate failures.

Scoped mutation has not established 99% for the Team module. The existing installation catch clause,
manual asynchronous command-disposal ownership, and empty invariant installer
remain debt; this patch does not claim the entire package is clean.

The broader Web suite's two renamed copies of the minimal composition need
separate policy reconciliation: the current configured exclusion names the
`minimal` id, while copied directories have different ids. Its standard exact
tool list also predates the documented default Team capability. No existing
assertion was removed or weakened to hide these failures.

The preset-mount mutation snapshot began before these independent Team edits and
finished unsuccessfully before the dependency installation and build. Its raw
87.63% report remains preserved.

The current committed HEAD is `ee24359f10f99c47b05ff75cb40426e7ea860505`.
The user committed the preceding repairs; this agent did not create that commit.

Repository-wide full-green acceptance remains open.
