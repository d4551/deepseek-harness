# Framework location and logical-expression traversal repair

The isolated converter passes all **1,184 tests across 75 files**, with no
compiler errors. Strict project compilation, lint, formatting, package checks,
and build pass. An independent reconstruction from the verified official
archive, using a fresh frozen dependency installation, also passes all 1,184
tests and strict compilation. Its JavaScript and declaration files match the
candidate byte for byte. This is progress on the coverage prerequisite, not
repository-wide full-green acceptance. The converter remains unpromoted.

## Repaired behavior

`src/location.ts` locates a generated function declaration through a mapped
token on the same declaration line, bounded by that function's end. A native
Inspector regression verifies named and arrow declarations; another assertion
rejects borrowing a location from the following function. This restores Svelte
function records without restoring unbounded forward mapping.

`src/evaluation.ts` identifies deferred function ranges. Statement-location
resolution does not borrow a callback or method body's mapped source while
creating its surrounding generated container. Native tests execute object
methods, arrow functions, and function expressions both with and without a
call. They assert every statement and line count. A computed method-key test
preserves the key's immediate evaluation and branch counts. All twelve prior
Svelte/Vue failures pass with their original assertions unchanged.

`src/ast.ts` tracks logical-expression branch grouping separately from traversal.
The previous grouping operation marked nested logical nodes for subtree
omission, dropping callbacks, their statements, and nested branches. The repair
visits their contents while emitting one branch group. Parenthesized nodes are
normalized for OXC's AST representation. Three real Inspector scenarios cover
`&&`, `||`, and `??`, asserting exact functions, statements, and branch counts
across all four parsers.

The compiled-artifact control executes the same code once and gives the native
measurement to both artifacts. The previous artifact reports function counts
`[1, 0]` and statement counts `[1, 1, 0]`. The repaired artifact reports the
required `[1, 1, 0]` and `[1, 1, 1, 0]`, including the executed callback. The
branch counts remain `[1, 1, 0]`. The control asserts the previous mismatch and
the repaired equality; it does not fabricate V8 records.

## Fixture expectations and independent comparison

The checker fixture uses the current Amaro emission established in the prior
native-fixture repair. After traversal repair, converter and independent
Istanbul instrumentation agree on 3,284 functions, 27,890 branch outcomes,
and 23,026 executable lines. The converter has 23,892 statements; Istanbul has
23,895. Every statement start appears in both maps. The three count differences
are at the TypeFacts, CheckMode, and SignatureCheckMode enum declarations:
Istanbul retains both a whole-enum and declaration-line range at each start,
while the converter's ranges resolve to the same declaration-line location and
are deduplicated. The full maps are retained for inspection.

The bundled JavaScript expectation gains two callback functions and their two
statements: 1,011 functions and 6,147 statements. Branch and line expectations
remain unchanged. Its cross-tool difference additionally includes four existing
`c8` fixture directives, which Istanbul does not interpret. Those directives
are unchanged; this comparison is not unsuppressed repository acceptance.
The checker and bundled snapshots were updated only after tracing these
differences. No framework assertion, threshold, exclusion, or retry was weakened.

## Reconstruction and evidence

The source archive is the official converter commit
`48f88c789411ce6e96137b16ec348d06ae6c2f6e`, SHA-256
`429aa1cb7add6728d9d0e0dc512e15e04cb34a7a9831a8d16b8ea7d33a221f4f`.
The reconstruction overlays 20 recorded source/config/dependency inputs,
including the previously verified instrumenter declaration archive. It checks
every other original source file against the official archive. No dependency
version, lock entry, override, or release-age exception changed in this repair.

The fresh reconstruction is recorded in
`/tmp/dsh-framework-logical-frozen-location.json`. Build identities:

- `dist/index.mjs`: `f7eeb2cc585e55b53a877d7b119704e834aa23a1e2198e07f510724b58b6eb7a`.
- `dist/index.d.mts`: `7e4de81c67aaa01f9202bb56242f85355e6a78bd327260294e8e26ada36f4b02`.
- `pnpm-lock.yaml`: `591cdd6dcf72e712529531bee5bea580a2f682130bf7ac4c3b67e0147e16ae81`.

Complete final logs use `/tmp/dsh-framework-logical-final-` and
`/tmp/dsh-framework-logical-frozen-` prefixes. Earlier failing logs, including
the twelve native logical-expression failures, remain unchanged.
`vitest-framework-logical-evidence.json` records paths and hashes.

## Remaining acceptance failures

Replaying the previously captured native CommonJS execution through this
rebuilt converter still produces an extra function at the authored `export`
token. The result has counts `[3, 1, 0]` instead of only the authored `value`
and `uncalled` functions. `/tmp/dsh-generated-helper-probe.json` preserves the
new result and decoded mappings; the original captured evidence is unchanged.
No helper-name filter, source exclusion, or weakened assertion is introduced.
This defect still blocks promotion and trustworthy native-source coverage.

The runner retains its two removed Node transform-mode API diagnostics. Vite
wrapper normalization, native child transport, complete artifact integration,
platform acceptance, and repository coverage/mutation remain open. The upstream
converter's own coverage summary reports 98.77% statements, 94.61% branches,
98.8% functions, and 99.44% lines; that report omits the AST and new evaluation
modules and is not accepted as complete coverage evidence. Existing upstream
lint exclusions and disabled rules also do not satisfy the root contract.

Root remains clean at `105a97ef9c776a2856118ee02609dc61a0fb9617`. No root files,
index entries, or commits were changed in this tooling slice. The 633 root
directives, two normal-suite enforcement failures, 42 skipped cases, protected
documentation failures, and the remaining full plan obligations are unresolved.

Primary references checked: [ECMA-426](https://tc39.es/ecma426/) and
[Amaro's official source](https://github.com/nodejs/amaro). Source maps establish
positions, not authored function ownership; the remaining helper attribution
must be repaired without treating these passing tests as proof of completion.
