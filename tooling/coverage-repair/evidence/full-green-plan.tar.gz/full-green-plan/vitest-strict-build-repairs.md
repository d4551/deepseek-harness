# Strict native Vitest build: dependency repairs

The source-owned runner candidate remains **unpromoted and not accepted**. The repository's 643 suppression sites and full-green blockers remain open. Work in this slice changes the isolated build sources and dependency graph, not the installed root distribution.

## Measured progress

The unchanged native compiler command is:

```sh
PATH=/tmp/dsh-node26.8.2/node-v26.8.2-darwin-arm64/bin:$PATH node node_modules/typescript/bin/tsc -p tsconfig.runtime-native.json --noEmit --pretty false
```

Run from `/tmp/dsh-vitest-5.0.1-source`. The configuration includes complete `packages/vitest/src/**/*.ts` and `packages/browser-playwright/src/**/*.ts`, follows their source imports, enables strict checking, and keeps `skipLibCheck: false`.

| Checkpoint | Diagnostics | Log |
| --- | ---: | --- |
| Current state before this slice | 20 | `/tmp/dsh-vitest-runtime-native-current.log` |
| Declaration source repairs and Node API type ownership | 14 | `/tmp/dsh-vitest-runtime-native-after-declarations.log` |
| Browser source identity unified in the build paths | 7 | `/tmp/dsh-vitest-runtime-native-browser-owner.log` |
| Snapshot declaration dependency owned by its package | **2, still failing** | `/tmp/dsh-vitest-runtime-native-metadata-owner.log` |

No compiler error was disabled. No source file was removed from compilation.

## Local package declaration repair

`local-pkg@1.2.1` publishes `loadPackageJSON` and `loadPackageJSONSync` declarations with an undeclared `Args` type. The official source is retained at `/tmp/dsh-local-pkg-source`, downloaded from `https://codeload.github.com/antfu-collective/local-pkg/tar.gz/refs/tags/v1.2.1`. Archive SHA-256: `5df896156e0389b38c4c45de9f1016932ac4301841ad888630d51fe53f4272e1`.

The source now explicitly types the defaulted `cwd` argument as `string`. Its previous declaration generator accesses TypeScript's removed `ts.sys` API and fails under TypeScript 7; the original failure is retained in `/tmp/dsh-local-pkg-rebuild.log`. The replacement build uses native TypeScript 7.0.2 to emit the complete declarations with strict library checking, and tsdown 0.23.0 plus the official Quansync generator for both runtime formats. Bundler warnings are fatal. No emitted declaration is edited by hand.

The dependency manifest declares the rebuilt runtime's Node floor and owns current `mlly@1.8.2`, `pkg-types@2.3.3`, and `quansync@1.0.0`. Normal Bun installation produces the build lockfile. `build.mjs`, `tsdown.config.ts`, `tsconfig.native.json`, and `tsconfig.declarations.json` contain the reproducible build. The obsolete build configuration is removed from the candidate.

Verified results:

- Complete source compilation passes: `/tmp/dsh-local-pkg-native-compile.log`.
- Canonical rebuild passes without warnings: `/tmp/dsh-local-pkg-final-build.log`.
- Upstream source test and complete CommonJS and ESM acceptance programs pass: `/tmp/dsh-local-pkg-final-tests.log`.
- Package archive: `/tmp/dsh-local-pkg-1.2.1-source-repair.tgz`, SHA-256 `02ee6422235b781197902fb20a49ac6a9897414bf2e6717b1b3623d5f4fac457`.
- Independent fresh source copy `/tmp/dsh-local-pkg-frozen-np7etmxy` passes fresh-cache frozen installation, the canonical build, and all upstream tests. Logs: `/tmp/dsh-local-pkg-frozen-install.log`, `/tmp/dsh-local-pkg-frozen-build.log`, `/tmp/dsh-local-pkg-frozen-tests.log`.
- All three output files reproduce byte for byte; the frozen lockfile remains unchanged. `vitest-build-dependency-inventory.json` records all build inputs and output hashes.
- A separate packed consumer `/tmp/dsh-local-pkg-consumer` passes strict declaration compilation and actual async/sync calls with omitted, explicit, and undefined cwd. Its owning package resolves Quansync 1.0.0 without a direct consumer declaration of that dependency. Logs: `/tmp/dsh-local-pkg-consumer-install.log`, `/tmp/dsh-local-pkg-consumer-compile.log`, `/tmp/dsh-local-pkg-consumer-runtime.log`.
- Both numeric cwd calls fail with TS2345 in `/tmp/dsh-local-pkg-consumer-negative.log`; no diagnostic directive is used.

The Vitest source package installs this archive as its explicit build dependency through normal pnpm resolution. No root application dependency changed.

## Other source and dependency repairs

- `js-tokens@8.0.2` and `9.0.1`: remove one obsolete `@ts-expect-error` from each authored declaration, using the package manager's normal patch workflow. Runtime bytes and dependency ranges remain intact. These two dependency suppressions are outside the repository scanner corpus and do not reduce its 643 count.
- `packages/vitest/src/node/hash.ts`: directly use Node's supported `crypto.hash`; remove the obsolete alternative implementation whose input contract disagrees with current Node declarations.
- `packages/utils/src/timers.ts`: `SafeTimers.setImmediate` refers to `typeof globalThis.setImmediate` instead of duplicating its outdated generic signature.
- `tsconfig.base.json`: resolve browser API, context, matchers, locators and vendor types to their actual workspace source owner. This removes conflicting source/published copies while retaining complete checking.

These Vitest source edits have strict compile evidence but still need the candidate's final build and native runtime suite before promotion.

## Browser snapshot dependency ownership

The authored `rrweb-snapshot@2.1.1` package manifest places `@rrweb/types` only in development dependencies, while five imports in its published declaration require that package for consumers. The current 2.1.4 package was also inspected and retains the same missing public dependency.

The exact upstream Vitest input is preserved. Its authored manifest comes from official commit `3deb6e7da4528ddb33b5b7ff6a3e805d4ed14930`, and the published archive is checked against its npm SHA-512 before use. The source metadata moves the existing `@rrweb/types` range into runtime dependencies. `/tmp/dsh-rrweb-snapshot-metadata/rebuild.mjs` requires the manifest to differ only by that ownership correction and reconstructs all 14 files, comparing every output byte. It produces `/tmp/dsh-rrweb-snapshot-2.1.1-metadata.tgz`.

Normal installation resolves `@rrweb/types@2.1.4` through the snapshot package's own edge. The existing upstream Vitest snapshot patch remains applied. Every installed non-manifest file matches the prior patched distribution byte for byte; the complete installed file set is unchanged. Evidence: `/tmp/dsh-rrweb-snapshot-metadata-build.log`, `/tmp/dsh-vitest-rrweb-metadata-install.log`, and the final strict compiler output.

This verifies declaration dependency ownership, not a browser behavior change. No browser runtime code is modified in this metadata repair.

## Remaining work

Two strict diagnostics remain:

1. `packages/mocker/src/node/parsers.ts:28`: calls native type stripping with a possible `mode: 'transform'`.
2. `packages/vitest/src/node/coverage.ts:752`: same removed mode during native source transformation.

A real Node 26.8.2 call rejects `mode: 'transform'` with `ERR_INVALID_ARG_VALUE`. The upstream test at `test/e2e/test/no-module-runner.test.ts:715` covers this mode on earlier Node releases that support its flag. Do not erase that test or silently drop its behavior to make compilation pass. Reconcile native transform ownership with the required Node platform matrix and the existing executed-source identity repair before finalizing the runner.

The candidate still needs complete strict compilation, source-built declarations and runtime artifacts, native cancellation/classification regressions, clean immutable installation, independent artifact reconstruction, repository integration, notices and documentation, and final mutation reason review. The current root Stryker distribution remains the previously verified version; this candidate has not replaced it.

Current primary references: [Vitest Node API](https://vitest.dev/api/advanced/vitest.html), [Node type-stripping API](https://nodejs.org/api/module.html#modulestriptypescripttypescode-options), [tsdown declaration generation](https://tsdown.dev/options/dts). Context7 returned a quota error; official sources and executed local probes supplied the evidence.

The subsequent [coverage failure repair](vitest-coverage-failure-propagation.md)
adds all coverage-v8 sources to the same strict compile, removes three error
concealment paths, and passes four native regressions. The current official
converter 1.0.6 resolves the newly exposed declaration dependency defect.
The final expanded compile retains the same two Node API diagnostics in
`/tmp/dsh-vitest-coverage-strict-current-converter.log`. The candidate remains
unpromoted and the executed-source ownership work remains incomplete.
