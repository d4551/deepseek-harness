# Empty invariant installer enforcement

Status: gate repair implemented; package implementations remain incomplete.

## Defect and repair

The package-invariant gate accepted an empty installer when a comment contained
`No runtime invariant:`. Native before-repair regressions show two commented
forms accepted with no findings. Three other empty forms required a different
diagnostic. The repaired gate rejects all five forms, including function
expressions and `Object.assign` injection declarations, without exemptions.

The package instructions permit explained empty installers, conflicting with
the root/user no-op ban. The stronger user requirement governs this repair.
No AGENTS file is edited. Existing mandatory package ownership/publication
checks remain; no companion is deleted or replaced with a synthetic assertion.

Boundary tests also establish missing source/publication rejection, self-owned
registry dependencies, cyclic/missing project references, absent Loader exports,
uninspectable installer declarations, and default export forms. The AST check
uses direct child syntax nodes rather than a VariableStatement assertion.
The reference walk terminates on the popped item instead of separately checking
the array length and then retaining an unreachable empty-pop branch.

## Evidence

| Check | Result | Log |
| --- | --- | --- |
| Before repair | Five failed, eight passed; two commented forms incorrectly accepted | `/tmp/dsh-empty-invariant-before-native.log` |
| First repaired suite | 13 passed | `/tmp/dsh-empty-invariant-after.log` |
| Initial strict gate coverage | 13 passed; 44 uncovered locations | `/tmp/dsh-empty-invariant-coverage.log` |
| Expanded boundary tests | 27 passed; three uncovered locations | `/tmp/dsh-empty-invariant-boundary-coverage.log` |
| Final strict gate coverage | 29 passed; all four metrics 100%; exit 0 | `/tmp/dsh-empty-invariant-final-coverage.log` |
| Full typed lint | Exit 0 before final boundary additions; final scoped typed lint also exit 0 | `/tmp/dsh-empty-invariant-full-lint.log`, `/tmp/dsh-empty-invariant-final-scoped-lint.log` |
| Quick documentation | 13 passed, two protected-file failures, zero skips | `/tmp/dsh-empty-invariant-doc-quick.log` |
| Full documentation | 30 passed, two protected-file failures, zero skips | `/tmp/dsh-empty-invariant-doc-sync.log` |
| Complete package gate | Both runs exit 1 with the same 217 empty-installer findings | `/tmp/dsh-empty-invariant-complete.log`, `/tmp/dsh-empty-invariant-final-complete.log` |
| Whitespace | Scoped diff passes; complete diff exits 2 on toolchain patch payloads | `/tmp/dsh-empty-invariant-scoped-whitespace.log`, `/tmp/dsh-empty-invariant-whitespace.log` |

Final coverage: 166/166 statements, 141/141 branches, 27/27 functions and
140/140 lines. These are gate-source coverage figures, not product coverage,
mutation, accessibility, or semantic completeness evidence.

The [complete empty-installer list](empty-invariant-installers.md) remains a
separate implementation blocker. A structurally nonempty installer still needs
review and valid/invalid runtime evidence; the static gate cannot prove its
semantic value. The two attachment companions remain among the violations.

The README, subsystem reference and prior contract note are paired in both
languages. A new process note owns the reversal of comment exemptions; the
older architecture note remains active for its meaningful-check requirements,
so this is partial supersession and no note is archived or deleted.

The existing CI/local gate graph already invokes `verify-package-invariants`.
No new suppression, catch, cast, source exclusion, retry, skip, deadline change,
or weaker assertion is added. The earlier accepted-empty assertion is replaced
with direct rejection assertions under the user's stronger requirement.

The final source scan is `source-20260916133426601.{json,md}`: 4,043 files,
2,460 findings, 658 directives (540 coverage and 118 lint), 1,445 catch clauses
and 357 static catch-handler accesses. Corpus SHA-256:
`a3d00480abbf867f620b30a7597e95ba8e68e7a215706c41b6baa857011de096`.
The directive count is unchanged. The 217 empty-installer findings belong to
the package gate and must not be added to the directive count.
