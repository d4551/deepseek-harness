# Native package metadata lookup

The source-built Node 26.9.0 binary returns `undefined` when package metadata
does not exist. This resolves packed TypeScript export analysis attempting to
parse a TypeScript source file as package JSON.

`lib/internal/modules/package_json_reader.js` checks the cached record's
`exists` field before returning its path. Its return documentation includes
`undefined`. No resolver replacement, runtime patch, error-swallowing handler,
or consumer exception is introduced.

## Verification

The official binary fails five of seven new native cases. The repaired binary
passes all seven: absolute paths, string/object file URLs, relative lookup,
cached absence across siblings/directories, present metadata and malformed
metadata rejection. Both absence and successful discovery use real files.

The unchanged existing lookup suite passes all eleven tests. Node's own runner
passes all three selected files, including its internal cache regression:

```sh
python3 tools/test.py -j 4 --progress=verbose \
  parallel/test-find-package-json \
  parallel/test-find-package-json-missing \
  parallel/test-module-nearest-parent-package-json-cache
```

Both packed consumers pass their two unchanged native tests under this binary:
the initial modern mocker artifact and the later browser-registration artifact.
Each proves TypeScript enums and parameter properties are analyzed, CommonJS
exports are found, invalid TypeScript rejects, runtime dependencies are declared,
and declared runtime/type entries exist. Browser acceptance remains in the
separate mocker browser report.

The first combined `node --test` launch collided in the upstream shared
`test/.tmp.0` directory. Its failure is retained. Sequential launches and the
official runner's isolated parallel launches both pass without test changes.
The internal cache test emits its existing internal-API warning; it is not
claimed as warning-free product execution.

The native build completed from the official source archive with the recorded
two-file patch. Binary SHA-256 is
`1749e88146ab954a5b5e7237b9c505d697b6fa244606ed05c2eb761cae04fe49`.
The patch SHA-256 is
`25489492d6e2bddb6ca23509f9d46c3931ed63cf54937724dc4cd088f43bea69`.
The source archive, changed inputs, build log, binary and test logs are
fingerprinted in `native-toolchain-repair-evidence.json`.

## Remaining acceptance

The native runtime is an isolated candidate, not the selected root runtime.
Full Node validation, source reconstruction and distribution for the required
platforms remain open. Neither packed package is promoted by this result.
The runner's broader type diagnostics and all repository-wide coverage,
mutation, source-prohibition and CI obligations remain open.
