# Preset mount failure ownership and host resolution

The preset mount requires the host composition's resolution base and resolves
bare package names through its native Loader. It refuses an unavailable native
resolver instead of importing a competing package from a preset directory.
Relative modules, absolute paths, file URLs and Cordis builtins retain their
verified resolution behavior.

Failed mounts retain the original cause, any synchronous disposal failure,
and any asynchronous unload failure. The caller waits for the owned unload
transition before receiving the failure. Successful mounts publish only after
the complete tree passes readiness and service-isolation checks.

Nine coverage directives and two catch clauses were removed from
`packages/preset/agent-presets/src/mount.ts`. No directive was added. This
module still contains an empty write override and a service-value assertion;
those remain debt. Removing directives does not establish full coverage.

## Evidence

- The complete owning suite passes 186 tests across 14 files, without skips:
  `/tmp/dsh-preset-mount-owning-native-final.log`.
- Native child processes exercise both normal Node and `--no-addons`, with
  competing real packages under the host and preset directories. A separate
  child proves that a mount without Loader leaves no deferred composition
  that can revive after Loader is installed.
- Real lifecycle tests retain aggregate primitive causes, wait for asynchronous
  resource disposal, and preserve a synchronous unloading-observer failure.
- Complete product build passes in `/tmp/dsh-preset-mount-build.log`. The
  existing oversized Web chunk warning remains.
- Complete typed lint passes in `/tmp/dsh-preset-mount-final-full-lint.log`.
- Strict coverage fails in `/tmp/dsh-preset-mount-final-coverage.log`:
  statements 107/117 (91.45%), branches 35/62 (56.45%), functions 18/18
  (100%), lines 87/95 (91.57%). There are 36 uncovered locations. Several
  point at type-only source and native-tested paths; the coverage mapping and
  native-child transport defects remain unpromoted and unresolved.
- Complete docs report 30 passed, two failed, zero skipped in
  `/tmp/dsh-preset-mount-doc-sync.log`. Protected AGENTS wrapping and the root
  AGENTS word budget remain blockers. The README and existing standing-mount
  note are paired and describe exercised behavior.
- Whole-module mutation finishes at 87.63%, below the unchanged 99 threshold,
  and exits 1: 160 reported killed, 23 survived, three timed out, 186 total.
  `/tmp/dsh-preset-mount-mutation.log` and `.json` retain the raw result.
  `preset-mount-mutation-review.json` lists every non-killed candidate and
  verifies that the report source matches the complete current module.
  All owning tests execute per candidate. The three timeout mutations make
  the fiber-ancestry loop nonterminating; their statuses are retained. No score
  is accepted, and complete killed-status reason review remains outstanding.
  `preset-mount-snapshot-test-inputs.json` verifies all 32 owning test inputs
  stayed identical to the captured sandbox throughout the run.

## Broader composition failures

`/tmp/dsh-preset-mount-web-composition.log` reports 24 passed and eight failed
of 32 shipped Web composition tests. Seven failures involve Team tools appearing
in the `minimal` preset, which promises exactly persistent bash and the string
editor. One is an exact standard-tool-list mismatch after Team tools became
part of the base composition. These assertions have not been weakened.

The focused minimal failure also reproduces in the preserved pre-repair
sandbox, whose original mount source SHA-256 is
`bb879525e52360a9b59f62665ea61d1c28ca87e43c7f02226c7ee7f5099c9ef9`.
The baseline log is `/tmp/dsh-preset-mount-baseline-web-composition.log`
(one failed, 31 unselected). This proves that specific defect predates this
mount repair; it does not independently establish the history of all eight.

`tool-agent-team` checks only the session header at initial installation.
`agentPresets.composedPreset(agent.ctx)` exposes the actual joined composition,
including setup before a session header carries the choice. Blank-session
switches and direct executor denial also need verification. A repair must
preserve Team functionality in enabled presets and the exact two-tool minimal
contract, with dynamic transitions tested through the shipped composition.

## Current inventory

`source-20260916164451437.json` reads all 4,056 source files and records 633
directives: 524 coverage and 109 lint. All remain violations. The separate
findings include 1,443 catch clauses and 357 static catch-handler accesses.
`suppression-inventory-diff-164451.json` compares exact path/kind/text
occurrences with the 903-directive baseline: 270 removed, zero added.
The complete remaining listing is `suppressions-outstanding.md`.

Current primary references: [Node permission behavior](https://nodejs.org/api/permissions.html)
and [Cordis lifecycle and effects](https://deepseek-harness.github.io/deepseek-harness/en/develop/cordis-tutorial/02-lifecycle-and-effects).
Source inspection and native execution determine the implementation evidence.

Repository-wide full-green acceptance remains open.
