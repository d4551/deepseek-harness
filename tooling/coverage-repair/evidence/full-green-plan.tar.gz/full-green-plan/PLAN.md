# Plan: close documented debt and prove complete green

Prepared 2026-09-16 for `/Users/brandon/Downloads/deepseek-harness`.

This is a plan, not a completion report. The worktree is not green. Existing
changes remain uncommitted. No repository source was changed while preparing
this plan. The inventories linked below record measured findings; they do not
establish that unmeasured areas are clean.

Evidence update: all prior command-runner storage mutation scores are withdrawn
as acceptance evidence because shared Vitest/Vite cache failures were counted
as kills. Preserve their raw counts for historical comparison only. The new
six-module, 440-mutant run at `/tmp/dsh-storage-mutation-cache-isolated.log`
is pending complete status-reason review; it has no accepted replacement score.
Current scoped evidence is recorded in [EXECUTION.md](EXECUTION.md): storage
131 tests pass; strict provider materialization is implemented (original
combined replay 1,011 passes and one native-Windows skip); the latest DeepSeek
run passes 388 tests and all four changed-source coverage metrics at 100%.
Latest measured full lint remains 383 errors. Latest documentation aggregate
is 29 passed and three failed; regenerated graph freshness subsequently passes,
but the aggregate has not been replayed and protected AGENTS blockers remain.

## 1. Objective and completion contract

Repair all outstanding documented debt, starting with defects that threaten
data integrity, isolation, cancellation, or reliable verification. Finish only
when implementation, documentation, and the complete required verification
matrix agree on one final worktree state.

Completion requires all of the following:

1. Every inventory item has a verified resolution. A real defect closes through
   a repair and evidence. A stale proposal closes only after source and runtime
   evidence prove its requirements already exist or were superseded. A disputed
   product boundary stays open until resolved; renaming debt is not closure.
2. No diagnostic or coverage suppression, weakened rule, skipped required gate,
   mutation exclusion, hidden failure, test-only production path, or lowered
   threshold is introduced or retained to obtain a passing result.
3. Coverage meets the existing **100% per-file statements, branches, functions,
   and lines** requirement for the complete executable source corpus. The
   user's mutation target of 99 does not lower this coverage requirement.
4. Stryker meets **at least 99%** across the complete required mutation corpus,
   with file-level results available so a strong aggregate cannot conceal a
   weak high-risk module. Every surviving or untested mutant remains listed.
   Equivalent-mutant claims do not authorize exclusions or score adjustments.
5. All required tests, lint, type checks, builds, package checks, documentation
   checks, security boundaries, and platform jobs pass. A canceled or skipped
   required job is incomplete. Platform cases must run on their actual target;
   a non-applicable host result cannot stand in for that execution.
6. Real browser journeys pass, with zero axe violations, no unresolved axe
   incomplete results, and no unresolved design-audit findings. Keyboard,
   focus, screen-reader semantics, contrast, zoom, localization, and page
   states receive checks beyond an automated score.
7. Generated artifacts reproduce from their authoritative inputs. EN/ZH docs,
   translation metadata, package references, and note lifecycle records match
   the verified implementation. Frozen archived records remain intact.
8. Final evidence identifies the worktree content, commands, tool versions,
   platforms, exit statuses, timestamps, and report locations. No later edit
   invalidates the evidence without the affected checks being rerun.

No partial milestone is the final green claim. A dependency, access, or
instruction conflict is reported as an open blocker while independent work
continues.

## 2. Measured starting point

| Area | Evidence | Interpretation |
| --- | --- | --- |
| Authored source audit baseline | 2,395 findings in a scan of 3,968 files | Historical scan awaiting resolution reconciliation; not a current outstanding count or complete audit |
| Catch clauses | 1,452 | Requires semantic error/lifecycle redesign, not syntax relocation |
| Coverage directives | 737 | Current reported coverage is not yet unsuppressed |
| Lint directives | 140 | Remove by repairing the underlying finding |
| TypeScript directives | 66 | Repair contracts and inference without cast escapes |
| Full lint baseline | 385 errors | Historical baseline; latest complete measurement is 383 errors, still failing |
| Last full test run | 19,781 passed; 8 failed; 93 skipped | Historical run predates some repairs; every skipped case needs reconciliation |
| Last full coverage | 84.40% statements; 78.43% branches; 84.40% functions; 85.50% lines | Historical aggregate; below unchanged per-file requirements |
| Coverage thresholds | 2,049 failed metric checks across 657 files | Complete extracted failure list from that historical run |
| Storage mutation baseline | 183 killed; 38 survived; 221 total; 82.81% | Historical raw output; acceptance validity withdrawn because infrastructure failures can count as kills; reported zero timeouts/errors does not prove valid detections |
| Trajectory CSS audit | 15 errors and 2 warnings in one file | Current scoped finding; wider UI remains unverified |
| Documentation | Latest aggregate 29 passed, 3 failed; historical pairing check passed 1,180 pairs | Generated graph freshness now passes separately; two immutable-file gate conflicts remain; aggregate must be replayed |
| Proposed notes baseline | 24; currently 23 active | Storage-root recovery moved to implemented with narrow per-record semantics; remaining proposals need reconciliation |
| README limitation sections | 260 | Includes intentional boundaries as well as possible defects; classify every section |
| Gate graph | 77 distinct commands | Union of exported modes; workflow-only jobs add further obligations |
| CI aggregate | 11 required job groups, with matrix expansion | No full passing evidence for this final worktree |

The source scan currently finds directives and catch clauses. It does not yet
fully detect Promise rejection evasions, unsafe assertions, empty callbacks,
barrel exports, duplicated schemas, direct route/environment/API access,
storage misuse, or architectural violations. Expanding this audit can increase
the count. That is discovery, not regression.

### Complete itemized evidence

- [Every source finding](source-audit.md), with [machine-readable data](source-audit.json).
- [Every lint error](lint.md), with [machine-readable data](lint.json).
- [Historical storage mutation output, invalid for acceptance](mutation-survivors.md), with [unchanged raw data](mutation-survivors.json); [later withdrawn output](mutation-current.md) is also historical.
- [Every failed coverage metric](coverage-threshold-failures.md), with [machine-readable data](coverage-threshold-failures.json).
- [All eight failures from the last full test run](full-run-test-failures.md).
- [All 24 proposed notes and their full text](proposed-work.md).
- [All 260 README limitation sections](readme-constraints.md).
- [All 77 gate commands, owning modes, and evidence status](gates.md).
- [Additional confirmed findings and blockers](additional-findings.md).

These counts overlap: a source finding can cause a lint failure, test failure,
and coverage gap. Do not add them into a misleading total defect count.

## 3. Work order and dependencies

The execution order is:

1. Establish source ownership, complete inventories, and resolve verification
   contradictions early.
2. Close gaps in the recent storage repair and fix the known Windows gate
   contract mismatch.
3. Repair data integrity, isolation, cancellation, attachment recovery, and
   derived-state recovery.
4. Complete architecture and product work in coherent end-to-end changes.
5. Remove remaining prohibited patterns through semantic repairs, while
   increasing behavioral coverage and mutation strength for each changed area.
6. Complete UI, accessibility, documentation, and all remaining measured debt.
7. Freeze inputs, execute the full platform and gate matrix, review the final
   diff independently, and repeat affected verification after every correction.

Coverage, mutation testing, documentation, and boundary tests are part of each
implementation step. They are not postponed until a large final cleanup.
Independent package work can proceed concurrently where permitted, but shared
configuration edits, generated output, fixture rewrites, builds, and mutation
snapshots must have a single owner and an explicit order.

## 4. Phase A — make the scope and evidence complete

### A1. Preserve and identify the current worktree

- Record the base revision and content fingerprints for tracked changes and
  untracked source. Distinguish earlier user work from changes made during this
  task without reverting either.
- Read full relevant files before each change, including governing package
  instructions and source consumers.
- Keep root `AGENTS.md` and `packages/client/AGENTS.md` unchanged under their
  current immutable instructions.
- Establish an item ledger: identifier, source location, observable defect,
  affected journey, dependency, implementation owner, reproduction, acceptance
  checks, evidence, and status.

**Exit:** every current edit and known finding has an owner and traceable
evidence. Nothing is silently discarded to simplify the branch.

### A2. Reconcile source, tests, and gate inventories

- Regenerate test discovery after the newly added storage suites. The earlier
  1,333-test-file inventory is no longer a final count.
- Prove every discovered suite is routed to its required execution environment
  exactly as intended; detect accidental omission and duplicate execution.
- Reconcile the previous 1,912 package-source coverage inventory against actual
  files and all eight supported source extensions. Explicitly inspect app,
  script, worker, vendor, and generated runtime surfaces for missing ownership.
  Do not define the denominator from files the tests happen to import.
- Reconcile the mutation corpus with executable source. The root utility-tier
  command alone does not prove repository-wide mutation quality.
- Inspect all workflow conditions and aggregate dependencies. Include native
  Windows, Linux sandbox, Python, Wine, built artifacts, browser, and applicable
  provider end-to-end jobs beyond the 77 local commands.
- Expand source enforcement to every requested category: assertions, rejection
  handlers, empty callbacks, async ownership, module boundaries, duplicate
  contracts, route/config/API ownership, unsafe storage, styling, ARIA, i18n,
  page contracts, complexity, and temporal dead zones.
- Test enforcement using isolated invalid inputs that must fail and valid
  inputs that must pass. Gate fixtures must not become production exceptions.

**Exit:** independent inventories agree; every source/test/workflow entry maps
to a required check; no exclusion or optional failure conceals a required area.

### A3. Resolve hard contradictions before expensive replay

1. **Immutable documentation:** markdown wrapping and documentation budgets
   fail on protected AGENTS files. Obtain owner-authored corrections or an
   explicit instruction revision before editing those files. Do not exempt
   them or weaken the checks. This blocks final green, not unrelated repairs.
2. **Subprocess isolation versus coverage:** automatic V8 collection adds
   `NODE_V8_COVERAGE` even to explicitly supplied child environments. Establish
   a supported instrumentation design that collects actual child execution
   without violating the exact environment contract. Validate a minimal real
   process reproduction before integration. Clearing the variable, filtering
   the assertion, or disabling child collection is not a solution.
3. **Bao authority:** no tracked `.bao` source was found. Locate the intended
   canonical archives, compiler, registry, and MCP/CLI tools. If absent, resolve
   the instruction/source mismatch explicitly and establish the required
   source of truth before claiming Bao compliance. Do not relabel existing
   CSS or registries as generated Bao output.
4. **Native verification:** identify actual Linux and Windows execution paths
   and required capabilities. Missing environments remain unverified; macOS
   success cannot substitute for native ACL or Landlock behavior.

**Exit:** each issue has an implemented and tested resolution or remains an
explicit blocker. No success claim is possible while one remains open.

## 5. Phase B — repair the highest-impact confirmed gaps

### B1. Prove storage import reaches durable disk

Primary files are `packages/storage/storage-json/src/index.ts`,
`src/per-record-unit.ts`, `tests/bootstrap-boundary.spec.ts`, and
`tests/root-location.spec.ts`.

- Strengthen the successful import test to inspect exact generated record
  paths and persisted contents, and prove the source record is unchanged.
- Remove only the test's source fixture before reopening, so reopening must
  consume the newly persisted records rather than import the source again.
- Verify unsafe keys and malformed later tables cannot publish earlier valid
  records or overwrite neighboring files.
- Verify a rejected import can recover after its input is corrected, without
  retained partial in-memory or on-disk state.
- Test close-during-open, duplicate opens, cleanup of reservations, root
  anchoring across cwd changes, global records, table detection, non-record
  files, and meaningful error contracts through actual public behavior.
- Treat the historical 38-survivor output as investigation leads, not a valid
  current mutation verdict. Review every status from the pending isolated-cache
  run, including kills, before identifying the accepted survivor set. Prioritize
  publishing loops and output filenames, then lifecycle and detection logic.
  Remove redundant implementation only after proving its redundancy through
  consumers and behavior.

**Acceptance:** real durable reopen succeeds without the import source;
neighboring data stays unchanged on rejection; lifecycle tests settle cleanly;
owning suites, lint, typecheck, coverage, and unsuppressed Stryker pass.
The latest 131 passing storage tests alone do not satisfy this acceptance.

### B2. Repair Windows gate reporting

The baseline mismatch was `exit code 1` in the assertion versus `exit 1` in
the implementation. The implementation now emits `exit code`; 61 owning tests
pass, including real failing-child regressions. Native Windows acceptance
remains open. The following obligations retain the intended diagnostic and
failure-propagation contract.

- Determine the intended public diagnostic contract from all consumers.
- Make implementation and direct assertions agree while retaining checks for
  nonzero status, failing gate identity, and failure propagation.
- Exercise the actual native Windows path and CI aggregation. Do not delete
  the assertion or normalize away a meaningful mismatch.

**Acceptance:** the targeted suite and native required job pass, and a real
failing child still causes the parent gate and aggregate to fail.

### B3. Protect authoritative data and recover derived state

The narrow per-record recovery implementation and its bilingual decision notes
are complete. The version-4 cache declares its derived table rebuildable;
authoritative tables and globals retain rejection without deletion. The items
below define the retained behavioral scope, not a claim that implementation is
absent. Source-loaded permission children pass locally; valid subprocess
coverage, native Windows/privileged POSIX branches and final acceptance remain
open as detailed in the execution ledger.

- Keep the implemented storage-root/recovery decision aligned with current
  source, including the version-4 per-record `session_projcache` implementation.
- Retain the reproduction for a current-version schema-invalid checkpoint that
  prevented `DomainFacility.open` from completing before the recovery repair.
- Verify record-level derived-cache recovery, reconstruction from authoritative
  session history, and observable diagnostics. Prove valid neighboring records
  remain usable and authoritative workspace/session data is never reset.
- Exercise corrupt, unreadable, stale-format, and schema-invalid records,
  interruption during rebuilding, and restart after recovery.

**Acceptance:** recoverable derived-state defects do not destroy authoritative
data or permanently block startup; genuinely unrecoverable authoritative
corruption produces an explicit failure with preserved evidence.

### B4. Cancellation, attachments, and access boundaries

The complete-reference key and shared strict materializer are implemented in
both provider paths; their original combined owning replay passes 1,011 tests
with one native-Windows skip. Eight later DeepSeek extension-failure cases
bring its owning replay to 388 passing tests and 100% changed-source coverage.
These repairs do not implement historical quarantine. The
[B4 execution slice](B4-attachment-recovery.md) and
[source-based replay-ordering analysis](/tmp/dsh-b4-replay-ordering.md) remain
open design: select execution ownership before preparation, retain verified
bytes, let the session owner finalize projection, and await a non-bypassable
final-request durability barrier before dispatch. Replay selection must not
consume a cursor or execute its terminal callback; reverse-order dispatch,
checkpoint failure, generation ownership and recorded preparation evidence
still require explicit contracts and real regressions.

- Trace required cancellation from every tool through the operations it owns.
  Migrate interfaces, providers, callers, and generated references together.
- Prove abort reaches real processes, workers, file operations, provider calls,
  and task waits; settlement means owned work has actually stopped.
- Make ownership transfer explicit for detached tasks, including cancellation
  immediately before and after publication.
- Implement attachment-read quarantine/recovery so unreadable historical
  attachments cannot permanently block later turns. Preserve append-only
  history, bounded retry and cancellation, restart, fork, and nested-image
  behavior through the correct projection owner.
- Audit real API, CLI, worker, websocket, and background boundaries for missing
  identity, workspace, registry, capability, and policy signals. Prove denial
  before side effects and absence of cross-workspace data leakage.

**Acceptance:** real cancellation and denied-access journeys leave no owned
processes or unauthorized writes; attachment failure is recoverable without
rewriting history or hiding data loss.

## 6. Phase C — close every documented proposal and limitation

For each proposal, read the full note and current source, verify its claims,
then implement outstanding requirements or prove supersession. Do not treat
historical proposal text as authority to introduce patterns now prohibited by
the operating contract. Update EN/ZH and sidecars together after verification.

| # | Baseline proposal | Current closure work or disposition |
| --- | --- | --- |
| 1 | Typed event schemas | Establish one runtime contract owner for durable and plugin boundaries; resolve the documented architecture choice without duplicating types and schemas; reject malformed input and preserve plugin extension behavior. |
| 2 | Required cancellation through capability seams | Complete the tool-to-side-effect inventory and required-signal migration with real abort/quiescence and ownership-transfer tests. |
| 3 | Domain KV storage and workspace | Reconcile already implemented storage/workspace pieces, then complete outstanding session deletion and ownership semantics without conflating registration removal with destruction of session logs. |
| 4 | Client locale and theme settings | Verify the entire preference journey, persistence, reload, cross-instance behavior, localization, theme application, and canonical UI/config ownership. |
| 5 | Session projection and command log | Reconcile current projections and command ownership; prove deterministic replay, ordering, persistence, and recovery for every unresolved criterion. |
| 6 | Storage root and derived-medium recovery | Implemented as stable root plus declared-derived per-record recovery; note moved to implemented. Native and complete verification remain open; see EXECUTION.md. |
| 7 | Durable last-activity index | Resolve authoritative/index consistency, cold listing, write ordering, crash recovery, and rebuild behavior before selecting the index implementation. |
| 8 | Cordis web dynamic packages | Complete registry-driven package discovery, lifecycle, access, loading, and failure behavior; verify real additions/removals without fixed availability lists. |
| 9 | Semantic composer chain phases | Establish phase ownership and ordering through actual composer behavior, including cancellation and composition/IME transitions. |
| 10 | Attachment-read quarantine | Complete the durable recovery journey described in B4, including restart and fork behavior. |
| 11 | Pre-tool input rewrite | Define and verify rewrite ordering, validated inputs, policy boundary, auditability, and cancellation before execution. |
| 12 | Recallable compaction | Verify recall, replay, persistence, interruption, and context restoration against the proposal's complete behavioral requirements. |
| 13 | Interactive side sessions | Complete lifecycle, user interaction, isolation, cancellation, and parent/child settlement through real sessions. |
| 14 | Task surface | Complete discovery, creation, progress, interaction, completion/error/cancel states, and correct owning lifecycle through the actual UI/API. |
| 15 | API extractor reports | Produce and validate source-derived public API reports; make real contract changes visible without maintaining a second contract definition. |
| 16 | Architectural conformance | Encode verified dependency and ownership rules, repair violations, and prove invalid architecture is rejected. |
| 17 | Supply-chain and vendor drift | Verify package-managed current dependencies, reproducible vendor provenance, licenses, patches, lockfiles, and drift enforcement. |
| 18 | Discover package inventory | Make tooling consume the actual workspace/package graph and detect missing, duplicate, and stale entries. |
| 19 | Human-review skill maintenance | Reconcile skill instructions and actual review workflow; preserve human-only decisions and remove stale process claims without bypassing review. |
| 20 | Artifact-first npm baseline publication | Complete reproducible pack/build/consumer validation and baseline provenance. Separate verification from real registry publication; publishing requires its own explicit authorization. |
| 21 | Audience-first documentation quality | Complete navigation, budgets, source-derived factual accuracy, bilingual pairing, and audience structure without exemptions for failing prose. |
| 22 | Prune dead core-spine API | Trace each listed symbol and model-visible consumer, remove only proven dead/duplicate surface, migrate callers, and verify behavior and public artifacts. |
| 23 | Directional JSON-RPC | Complete the coherent TypeScript/Python protocol migration, authoritative response settlement, notification ordering, overlap rejection, framing, and shutdown. |
| 24 | Deterministic and stress testing | Replace synchronization sleeps with observable events, verify replay broadly, and run race stress without retrying failures into success or introducing prohibited test escapes. |

For all 260 README limitation sections, record each distinct assertion and map
it to a proposal, implementation defect, current product boundary, or stale
claim. Verify boundaries against runtime and the requested product contract.
Implement missing promised behavior; remove stale text only after proving the
behavior changed. A disputed boundary requires a concrete product decision and
remains open until then. Do not convert every speculative wish into a feature,
and do not use “intentional” as a new exception for existing defects.

**Exit:** every proposal criterion and README assertion is accounted for with
source/runtime evidence; no outstanding required work is hidden by a status
change or archive move.

## 7. Phase D — eliminate prohibited patterns and close coverage gaps

- Work by coherent package boundary, not global replacement. Read the complete
  implementation, its consumers, and the error/lifecycle contract.
- Remove all 943 measured diagnostic/coverage directives through actual
  repairs. Preserve assertions and execution scope as the directives leave.
- Redesign the 1,452 measured catch-clause sites where necessary. Do not merely
  move them to `.catch`, empty rejection handlers, casts, or new helper layers.
  Preserve error visibility, cleanup, cancellation, and resource ownership.
- Resolve all 383 findings in the latest complete lint run (385 at baseline), including owned asynchronous operations
  currently discarded with `void`. Awaiting, returning, or transferring
  ownership must reflect the real lifecycle rather than satisfying syntax.
- Remove duplicated contracts, dead exports, and redundant branches only after
  tracing real and dynamically discovered consumers. Keep external behavior
  and boundary validation intact.
- Regenerate unsuppressed coverage after structural repairs. Prioritize the
  657 historically failing files by data/security risk, fan-out, and uncovered
  behavior, then exhaust the rest of the independently discovered corpus.
- Exercise failure, recovery, cancellation, ordering, empty and malformed
  inputs, and native branches through public behavior. Do not create tests
  that only execute lines or mirror implementation details.
- Repair the remaining full-run failures: exact child environments, live source
  enforcement, and real Linux Landlock behavior. Revalidate the previously
  repaired compiler fixture race and lint-corpus timing under the full run.

**Exit:** complete lint and source enforcement pass; all four coverage metrics
meet 100% per executable file; no unowned missing/zero-coverage file or omitted
test remains; native cases have actual platform evidence.

## 8. Phase E — make mutation evidence representative

- Preserve the unchanged 99% breaking threshold and complete file contents in
  mutation inputs. Reconcile scope against the source inventory before scoring.
- For each survivor, record the changed behavior, a real reachable trigger,
  and the missing assertion. Repair code or test behavior, then rerun.
- Start by finishing and reviewing the isolated-cache storage run over all six
  modules and 440 mutants. All prior command-runner scores, including 82.81%
  and 96.97%, are invalid acceptance evidence. Historical survivors are leads;
  a reported kill is not accepted until infrastructure failures are ruled out.
  The separately scoped 89/89 Markdown result is not repository evidence.
- Preserve process-based execution for suites that call `process.chdir`.
  The official command runner can execute all owning tests for each mutant;
  turning off coverage-based test selection is not permission to omit tests or
  source from mutation.
- Resolve test/runtime errors and timeouts directly. Do not allow them to
  inflate the apparent strength of assertions or disappear from reporting.
- Finish builds and generated writers before Stryker snapshots its input tree.
  Do not run concurrent writers against mutation sandboxes or shared reports.
- For a plausibly equivalent mutant, prove the semantic claim and investigate
  whether the code can be simplified without changing behavior. If it cannot,
  keep the survivor visible; do not exclude it or manually alter the score.

**Exit:** the complete required corpus meets at least 99%, high-risk file-level
results meet the same target, every status is reported, and no configuration
change manipulates the denominator or hides survivors.

## 9. Phase F — UI, accessibility, and canonical design

- Repair all 17 current Trajectory CSS findings through shared design tokens
  and primitives: five color-mix findings, six fixed-dimension findings, one
  radius, three spacing, and two directional-style warnings.
- Trace shared geometry with `TrajectoryTurnHeader`; avoid replacing repeated
  raw values with separately named local constants that retain duplication.
- Resolve canonical Bao ownership from A3 before declaring architecture
  compliance. Compile generated assets from their actual source; never hand
  patch generated output.
- Enumerate real pages and capabilities from routing/registry source. Cover
  loading, empty, populated, error, denied, disabled, and recovery states for
  supported user/workspace contexts.
- Run browser journeys against the actual server and model flow. Check route
  transitions, streaming, attachments, settings, composer input, task/session
  lifecycle, keyboard operation, focus restoration, and user-visible errors.
- Audit themes, narrow/wide viewports, zoom/reflow, supported locales, text
  direction, accessible names, announcements, contrast, and motion behavior.
- Run axe and applicable Bao/Brutalise validators across the inventoried states,
  then resolve incomplete results through manual review. Inspect console,
  network, assets, hydration, and runtime logs.
- Preserve real IME evidence: browser event replay does not prove OS-native IME
  behavior. Test native composition for supported systems where applicable.
- For a PR with changed user-visible GUI behavior, record the required GIF from
  the real flow under the repository skill. Creating this plan does not publish
  a PR or authorize unrelated external actions.

**Exit:** zero unresolved audit findings, actual journeys pass, and evidence
identifies the full state matrix. Four preview axe cases do not stand in for
the whole application.

## 10. Phase G — full gate and platform execution

The detailed [commit and CI/CD blocker plan](CI-CD-BLOCKERS.md) is mandatory
for this phase. It adds actual staged-hook behavior, release packaging,
independent workflows, live branch-rule observations, and delivery acceptance
criteria. Its inventory covers all 19 workflow definitions, beyond the main
aggregate's 11 groups. Current repair evidence is in [EXECUTION.md](EXECUTION.md);
the starting measurements above must not be read as current verdicts.

Use the exact commands and mode mapping in [gates.md](gates.md). Avoid assuming
that `check-all` alone covers every CI obligation.

Representative required commands already present in the gate graph include:

```sh
bun run build:lib:host
bun run typecheck:contracts-ready
bun run lint:contracts-ready
bun run test
bun x vitest run --coverage
bun run mutation
bun run test:snapshot
bun run test:expected
bun run build
bun run build:web
bun run docs:build
bun run verify-translation-pairing
bun run verify-md-wrap
bun run verify-doc-budgets
```

These are a readable subset, not an alternative reduced gate list. Execute all
77 inventoried commands in their required environments and dependency order,
plus workflow-only obligations.

| Required CI job group | Evidence required |
| --- | --- |
| `node-24` | Linux primary source/static/runtime gates |
| `node-24-coverage` | Complete unsuppressed coverage, tests, and reports |
| `node-24-consumers` | Built packages and real consumer contracts |
| `node-compat` | Configured Node 22.19 and 26 matrix |
| `python-sdk` | Python 3.10 SDK suite through the actual project environment |
| `python-runtime` | Reusable executable/runtime build and smoke workflow |
| `windows` | Required Windows workflow lane and failure propagation |
| `windows-build` | Native builds and generated artifacts |
| `windows-coverage` | Native coverage/test obligations |
| `windows-native-tests` | Real process, shell, ACL, confidentiality, hooks, and native behavior |
| `windows-observational` | All configured checks remain required despite the name |

Additional verified command surfaces include:

```sh
uv run --python 3.10 --group test --project python/sdk pytest
bash scripts/wine-windows-gates.sh
```

Inspect and include applicable `e2e`, provider, sandbox, E2B, Landlock,
expected-filenames, master, and packaging workflows. Separate release
publication from artifact verification. Do not trigger deployment or registry
publication merely to obtain a quality result.

Research current package releases and vendor documentation before toolchain
changes; use package-managed dependencies and reproducible lockfiles. Preserve
supported compatibility targets while adopting the required current tooling.
Do not claim “latest” from a training-data version guess.

**Exit:** every required job and matrix entry passes on the recorded source
state; aggregate status rejects failure/cancellation/required-job omission;
reports are available and consistent with the inventory.

## 11. Phase H — final review, replay, and delivery

1. Finish all source, test, documentation, and generated-output edits.
2. Reconcile all inventories. Confirm remaining counts against source, not
   against a manually edited status report.
3. Audit the entire diff and relevant prior changes for suppression additions,
   weakened assertions, exclusions, skipped tests, changed denominators,
   failure swallowing, deleted behavior, and concealed generated drift.
4. Run the mandated independent adversarial audit. A finding reopens the
   relevant work; do not commit or reformat to conceal edits. Maintain a factual
   audit/restart log and fix the underlying issue.
5. Freeze source inputs and settle all writers. Run full verification in the
   necessary dependency order, with mutation snapshots after build writers.
6. Record hashes before and after verification. Investigate unexpected source
   changes and regenerate outputs through their owners.
7. If a defect is repaired during validation, rerun its focused checks and every
   affected aggregate. Shared configuration or infrastructure changes require
   the full impacted matrix again. Unchanged passing evidence need not be
   repeated without a reason.
8. Deliver a complete result table: every gate/platform, actual exit status,
   coverage per-file summary, mutation status counts, accessibility state
   coverage, documentation status, and resolved item ledger. Explicitly list
   any remaining blocker; if one remains, state that the task is not green.

## 12. Evidence format and progress reporting

Each work item records:

```text
ID and priority:
Source/documentation locations:
Observed user or runtime failure:
Reproduction and failing evidence:
Consumers and ownership boundary:
Dependencies / unresolved decisions:
Implementation and value:
Behavioral tests and native/browser checks:
Coverage and mutation evidence:
Documentation/generated changes:
Diff audit for weakened enforcement:
Final source fingerprint and gate logs:
Status: open | in progress | blocked | verified
```

Report meaningful progress as defects closed, actual checks passed/failed, new
findings, and remaining blockers. Do not report an aggregate percentage that
combines unrelated counts, or infer project completion from a small passing
subset. Estimate elapsed execution only after measured gate durations and
architecture decisions; the current inventory does not support an honest
fixed completion time.

## 13. Primary references

Local source and runtime evidence decide implementation. Current external
references inform the tooling and accessibility work:

- [Vitest coverage configuration](https://vitest.dev/config/coverage): explicit
  include scope, per-file thresholds, failure reporting, and subprocess
  collection must be considered together.
- [Node child-process implementation at v26.8.2](https://github.com/nodejs/node/blob/v26.8.2/lib/child_process.js#L660-L662)
  and [Node V8 coverage environment behavior](https://nodejs.org/api/cli.html#node_v8_coveragedir):
  grounds the observed exact-environment conflict; verify the eventual
  selected runtime again when implementing the repair.
- [WCAG 2.2 Understanding documents](https://www.w3.org/WAI/WCAG22/Understanding/):
  grounds manual accessibility checks beyond automated axe results.

The plan preserves current strict acceptance requirements. It does not grant
new exceptions, permission to edit immutable instructions, or authorization to
publish artifacts to external registries.
