# Token-meter image pricing repair

The token meter rejects missing occurrence prices, invalid visual token counts,
and an overflowing route-priced surface total. This removes one lint directive
and its unchecked non-null assertion. The fresh repository scan records **642
remaining directives: 533 coverage and 109 lint**, all violations.

## Behavior

Matching array lengths no longer substitutes for checking the selected price.
Visual token counts must be non-negative safe integers. The complete priced
surface is checked after adding each node, including message framing, image
text and preceding nodes. Invalid prices throw before a measurement returns.
A subsequent valid response produces the correct measurement from the same
session without duplicate nodes. The exact maximum safe total remains valid.

Image collection is independent of the pricing-availability decision. Each
priced node starts with its image-free heuristic; an image-free node has that
same value as its full heuristic by construction in `surface-fold.ts`. These
changes remove two redundant conditions rather than exempt their mutants.

New tests verify sparse price arrays, six invalid numeric counts, recovery,
exact and overflowing totals, extra prices, ordered image batches, per-image
price alignment across nodes, and the absence of image pricing for text-only
requests. Existing assertions remain unchanged. The package README pair and
the existing route-pricing decision note describe the verified failure behavior;
their bilingual records are updated. No new Agent Note or archive is needed.

## Validation

- Complete owning suite: **121 passed**, five files, no skips.
  `/tmp/dsh-token-meter-pricing-final-simplified-coverage.log`.
- Complete changed module: **100% statements 29/29, branches 14/14,
  functions 4/4 and lines 27/27**, with unchanged per-file thresholds.
- Complete product build passes:
  `/tmp/dsh-token-meter-pricing-final-build.log`. The existing web chunk-size
  warning remains open.
- Final complete typed lint passes:
  `/tmp/dsh-token-meter-pricing-final-full-lint.log`.
- Freshly built ACP `image-compaction` replay passes through the shipped
  application path without changing recorded output:
  `/tmp/dsh-token-meter-pricing-final-composition.log`. The focused selection
  reports one pass and fourteen unselected cases; it is not the full ACP suite.
- Complete documentation: **30 passed, two failed, zero skipped** in
  `/tmp/dsh-token-meter-pricing-doc-sync.log`. The two failures remain protected
  AGENTS wrapping and the root AGENTS word budget. Quick docs report 13 passed
  and those same two failures.
- Whole-worktree whitespace passes. The index still contains older staged
  Stryker patch whitespace failures, retained in
  `/tmp/dsh-token-meter-pricing-index-whitespace.log`; no staging occurred.

## Mutation accounting

The first complete module run reports **58 killed, eight survived, no timeouts
or errors**, 87.88%, and fails the unchanged 99 threshold. Its raw outputs are
`/tmp/dsh-token-meter-pricing-mutation.json` and
`/tmp/dsh-token-meter-pricing-mutation.log`. The survivors expose redundant
conditions and missing tests for exact image input and text-only pricing.

After the source simplification and stronger tests, the final run reports
**57 killed, zero survived, zero timed out, zero no-coverage and zero errors**,
100%. The full module is mutated with the source-built instrumenter; no mutant
or source exclusion is added. The command runner executes all 121 owning tests
for every candidate. Its display counts each complete command as one test;
the individual failure reasons retain the actual suite totals.

All 57 contiguous candidate IDs and status reasons were reviewed. Each failure
comes from exercised behavior in the owning tests, rather than a startup,
import, cache or filesystem failure. The report contains the exact current
source bytes. Review and fingerprints are recorded in
`token-meter-pricing-mutation-review.json`; raw final output is
`/tmp/dsh-token-meter-pricing-final-mutation.json` and
`/tmp/dsh-token-meter-pricing-final-mutation.log`.

The first 57-candidate run overlapped a product build, violating the required
build-before-snapshot ordering. Its result is superseded by the sequential
replay in `/tmp/dsh-token-meter-pricing-sequential-mutation.json` and
`/tmp/dsh-token-meter-pricing-sequential-mutation.log`. That replay started
after all build writers finished and again reports 57 killed, zero survivors,
zero timeouts and zero errors. The exact source and candidate replacements
match the earlier report. Every failure reason was reviewed again;
`token-meter-pricing-sequential-review.json` records the evidence and hashes.

This accepts the sequential mutation result and coverage for this module only. It does not establish
repository-wide 99% mutation, unsuppressed full coverage, native platform CI,
or complete-green acceptance. The unpromoted coverage-runner candidate remains
red independently.

## Inventory

`source-20260916162205581.json` scans all 4,054 files: 2,444 findings, including
642 directives, 1,445 catch clauses and 357 static catch-handler accesses.
`suppression-inventory-diff-161811.json` proves this repair removes one directive
and adds none against the preceding 643-directive snapshot. The complete
remaining listing is `suppressions-outstanding.md`.

TypeScript's [indexed-access guidance](https://www.typescriptlang.org/tsconfig/noUncheckedIndexedAccess.html)
grounds the missing-value check; actual provider-contract tests establish the
runtime behavior.
