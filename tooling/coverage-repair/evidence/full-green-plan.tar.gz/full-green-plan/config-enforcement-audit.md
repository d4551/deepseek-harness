# Configuration enforcement audit

Read-only audit of `/Users/brandon/Downloads/deepseek-harness`, 2026-09-16.
HEAD observed: `057bf781eb6b458a08f3025fff6c8a8eb8c566e1`; the worktree contains concurrent, uncommitted repairs.
No repository file, threshold, configuration, dependency, or test was changed for this audit.
This inventory is additional to the parent's 703-directive inventory; that count was not independently recomputed here.

## Conclusions

The current configuration does contain suppressions beyond inline directives. Root lint excludes authored source classes, disables rules, permits name-based exceptions, and turns off its default correctness category. Knip and duplication checking have further exclusions. End-to-end tests retry failures. The macOS complete master job is disabled. Mutation is both source-limited and absent from the pull-request aggregate. `validate:strict` resolves to `check-all`, whose ordinary test invocation does not request coverage.

Root `vitest.config.ts` itself retains V8 subprocess coverage, an empty explicit coverage-exclusion list, and unconditional per-file 100% statement/branch/function/line thresholds. Its denominator is package `src` files, not every authored repository source. Splitting tests between its Node and browser projects is routing, not evidence of suppressed tests.

The accessibility package-presence gate has an executable false-positive: it accepts an audit whose complete body is unreachable or skipped. Native axe result handling retains violations and undecided results, but one narrowly coded popup review can discharge an incomplete result; this is a separate evidence path needing its own acceptance decision, not an axe pass.

Classification below:

- **Suppression:** a configured rule/result is disabled, a matched file is excluded, or an observed test failure can be retried away.
- **Selection/gap:** a gate's denominator or invocation does not cover a surface. This does not prove intentional concealment, but cannot support an all-repository pass claim.
- **Routing/strict:** work is assigned elsewhere or failures still propagate; no suppression established.
- **Uncertain:** the mechanism is real but its semantic validity needs an owner-specific proof. Comments are not accepted as proof.

## Lint: exact configured suppressions and gaps

| Location | Mechanism and consequence | Classification |
| --- | --- | --- |
| `.oxlintrc.json:3–6` | Empty base plugin list and `correctness: allow`; built-in default correctness rules are disabled unless explicitly enabled below. | Suppression |
| `.oxlintrc.json:8` | `reportUnusedDisableDirectives: error` rejects unused directives, not effective directives. There is no global ban on active disable comments in this profile. | Enforcement gap |
| `.oxlintrc.json:15–16` | `**/lib/**`, `**/node_modules/**`. Output/dependency selection, but broad names exclude matching authored trees too. | Selection; authored matches need inventory |
| `.oxlintrc.json:17–23` | `.sessions`, `.claude`, `.agents/worktrees`, `.doc-typecheck-*`, `.node-next-types-*`, `.oxlint-contract-*`, and `oxlint-contract-*` exclusions. | Explicit exclusions; runtime/probe ownership not independently re-proven |
| `.oxlintrc.json:24` | Entire `packages/typert/generator/tests/fixtures/type-model/**` tree omitted from normal typed lint. | Suppression |
| `.oxlintrc.json:25–29` | Generator `.probe-*`, `.generated-*`, `.rendered-*`, `.typert-*`, and `website/.generated` omitted. | Output/probe selection, not permission for authored source exceptions |
| `.oxlintrc.json:30` | Entire `vendor/**` tree omitted, including locally modified framework implementation. | Suppression |
| `.oxlintrc.json:31` | Entire `native/**` tree omitted. A comment claims independent gates; that does not establish equivalence to this rule set. | Suppression; independent enforcement unverified |
| `.oxlintrc.json:32–33` | All `.js` and `.mjs` omitted regardless of owner. | Suppression |
| `.oxlintrc.json:34–35` | All `*.config.ts` and `packages/client/tsdown.client.ts` omitted. | Suppression |
| `.oxlintrc.json:40–48,158–164` | Strict rule selectors cover TS/TSX only in listed directory shapes. Loose root TS, package files outside `src/tests`, snapshots, and `.mts/.cts/.cjs/.jsx` do not receive the same strict rule set. Broader style selectors at 225/238 do not restore those typed rules. | Selection gap |
| `.oxlintrc.json:60–62` | `_` prefixes exempt parameters, variables, and caught errors from unused-variable findings. | Name-based suppression |
| `.oxlintrc.json:75–79` | `ban-ts-comment` sets only minimum description length 10, not explicit `true` bans for each error-disabling directive. | Incomplete no-directive policy; exact inherited defaults not runtime-probed |
| `.oxlintrc.json:88` | `typescript/no-empty-object-type: off`. | Suppression |
| `.oxlintrc.json:89` | Rule is enabled, but its comment explicitly invites narrow suppressions. The comment is not authorization under the user's instruction. | Contradictory policy prose, not an extra rule disable |
| `.oxlintrc.json:96` | `typescript/no-invalid-void-type: off` for shared/source profile. | Suppression |
| `.oxlintrc.json:102` | `typescript/no-namespace: off`. | Suppression |
| `.oxlintrc.json:143–145` | `return-await` checks only error-handling correctness, not every async return style. | Rule policy selection, not proof of lost-work acceptance |
| `.oxlintrc.json:171` | Constant loop conditions exempted from unnecessary-condition checking. | Narrow configured relaxation |
| `.oxlintrc.json:179–180` | Numeric/boolean template interpolation allowed. | Explicit policy selection; not independently unsafe |
| `.oxlintrc.json:186` | A default branch counts as exhaustive for unions, so new union cases need not have explicit cases. | Exhaustiveness relaxation |
| `.oxlintrc.json:199` | `require-await: off` in examples. | Suppression |
| `.oxlintrc.json:207–218` | All listed package/app/example tests and script specs turn off non-null assertions, unnecessary-condition, only-throw-error, require-await, and restrict-template-expressions rules. | Test-wide suppressions |
| `.oxlintrc.json:299–301` | URL, string, and template literal contents exempted from maximum line length. | Formatting suppressions |
| `.oxlintrc.json:315` | Type-model fixture `no-explicit-any: off`. This affects the staged profile that re-includes the fixture. | Suppression |
| `.oxlintrc.json:324` | One fixture's quote rule is off. | File-specific suppression |
| `.oxlintrc.json:329–336` | Webworker-runtime Node/storage/module-loader/synthetic-http files turn off require-await and no-extraneous-class. | Source-specific suppressions |
| `.oxlintrc.staged.json:5–6` | Type-aware lint disabled; unused disable directives only warn. | Reduced enforcement |
| `.oxlintrc.staged.json:8–25` | Its explicit exclusion list repeats vendor/native/JS/MJS/config/build-preset exclusions and output/probe exclusions. | Suppressions/selection as above |
| `lefthook.yml:17–22` | Precommit excludes vendor source, uses the reduced staged profile, `--fix`, and `--no-error-on-unmatched-pattern`. A commit hook succeeding does not imply typed lint ran. | Local-gate scope relaxation |
| `package.json:33,35` | Ordinary lint uses root config; `lint:fix` separately runs fixture syntax lint with the reduced profile, then root lint (which excludes that fixture). | Exact invocation ownership; reduced fixture checking remains |
| `scripts/lint-scope-integrity.ts:8–14,49–54,72–74` | Hash pins current rule and discovery configuration, including exclusions. It detects drift but does not establish that the pinned rules satisfy the user's ban. | Enforcement integrity, not quality proof |

Only TypeScript and stylistic plugins are enabled in these lint overrides. There is no configured JSX accessibility, HTMX, page-contract, generic i18n, or cognitive-complexity rule set in this lint profile. Separate repository validators exist (`verify-client-ui-i18n`, configuration ownership, package constraints); this audit did not prove they cover every requested class. An absent lint plugin alone does not prove the application uses every framework mentioned by the user.

Oxlint directory traversal also respects repository `.gitignore`; direct explicitly named files have different discovery semantics. Therefore these files are enforcement inputs, not merely Git housekeeping:

- `.gitignore:1–55`: notably `lib/` (4), `.cache/` (7), `tmp/` (19), build/artifact roots (27–35), worktrees (37–39), generator probes (40–45), `.audit-tmp` (46), root `tmp-*`/scratch patterns (52–54), `.vitest` (55).
- `website/.gitignore:1–4`: dependency/cache/output/generated trees.
- `native/landlock-run/.gitignore:4–5`: nested package bin/lib output trees.
- `.agents/skills/.gitignore:2–8`: skill runtime/release/output/dependency/log/generated metadata trees.

`.oxlint-contract-typecheck.jsonc:2–15` deliberately selects the one unsafe-assignment fixture rule with type checking enabled; it is a focused rule probe, not the normal lint profile. No `.eslintignore` was discovered. Artifact-shaped authored files can be invisible to broad directory invocation; ownership of every such match was not exhaustively proven here.

## Coverage and test routing

| Location | Observed behavior | Classification |
| --- | --- | --- |
| `vitest.config.ts:80–92` | V8, subprocess auto-attachment, report on failures, empty explicit exclude, per-file 100% all four metrics. | Strict configured gate; no threshold override found |
| `scripts/coverage-debt.ts:8–11,18–29` | Canonical source denominator is `packages/*/*/src/**/*.{ts,tsx,js,jsx,mts,cts,mjs,cjs}`. Apps, scripts, snapshots, website, vendor, native and Python are outside it. | Source selection gap for an all-repository claim |
| `scripts/coverage-debt.ts:67–89,98–134` | Policy verifier rejects nonempty exclusion/method-ignore lists, changed-only mode, missing subprocess attachment, non-100 metrics, threshold overrides, wrong provider and missing report-on-failure. | Strict policy checks |
| `scripts/coverage-debt-measure.ts:154–193` | Measurement accepts positional test paths only, removes prior totals, requires every canonical file to be measured and all four metrics complete, plus successful process exit. | Strict measurement; positional test selection cannot change denominator |
| `scripts/run-gates.ts:237–257`; `package.json:56–57` | `check-all`/`validate:strict` invokes `test` at line 242, not `test:coverage`; it has no coverage gate. The name does not guarantee coverage enforcement. | Aggregate enforcement gap |
| `scripts/run-gates.ts:592–604`; `.github/workflows/ci.yml:145,464` | Dedicated CI coverage invokes `vitest run --coverage`. | Strict invocation |
| `vitest.config.ts:12–16,55–78` | Root unit selection is package `.spec.ts/.tsx`, app `.spec.ts`, script `.spec.ts`; excluded process/browser suites are included by their owning sibling projects. | Routing, not removal |
| `scripts/vitest-inventory.ts:2–25` | Explicit serial process-bound suite list. | Scheduling, not uninstrumented exemption |
| `vitest.client-browser.ts:10–30`; `vitest.client-browser.config.ts:16,25` | `.browser.spec` always routes to browser; `.client.spec` requires exact harness spelling then a value import. Browser instances are Chromium only. | Browser-selection boundary, not root-test suppression; other engines not implied |
| `vitest.e2e.config.ts:38–42`; `vitest.expected.config.ts:14–16`; `vitest.web.config.ts:20–24` | Expected-output and inspector-browser tests are routed to separate configurations. | Routing |
| `vitest.e2e.config.ts:48` | `retry: 2`; an initial failure can become final success. Applies to built-bin and Windows ACL callers of this config too, not just model calls. | Failure-softening mechanism |
| `vitest.snapshot.config.ts:41–47` | Web snapshot inclusion requires `DSH_EXAMPLE_MODE=lib`. Gate runner sets it at `scripts/run-gates.ts:608–613`; a direct default snapshot command omits that built-client subset. | Conditional selection, correctly enabled by CI owner |
| `vitest.built.config.ts:18`; `scripts/run-gates.ts:649–665` | Built suites use `.built.ts`, run after build, outside ordinary unit selection. | Artifact routing |
| `vitest.approval.config.ts:13`; `vitest.stability.local.ts:6,16–17` | Focused approval/stability inventories; not complete-root proof. | Diagnostic selection |
| `vitest.web.perf.config.ts:13–18`; `vitest.web-stress.config.ts:11` | Performance/stress inventories are opt-in; console interception disabled for performance reporting. | Explicit unexecuted default scope; console output is not discarded |
| `scripts/coverage-command.ts:5,34–41`; `.github/workflows/ci.yml:433` | Instrumented test/poll timeout override, 90s on Windows. It changes timing obligations but not coverage thresholds or assertion outcomes. | Timing policy; not coverage suppression |
| `scripts/coverage-uncovered-locations.cjs:58–84` | Human-readable reporter omits unusable source locations after seeking a usable alternate span. It does not alter Istanbul counts or Vitest threshold enforcement. | Diagnostic omission, not numerical coverage suppression |
| `scripts/coverage-file-totals.cjs:40–50` | Writes native per-file summary counts without owner filtering. | Strict reporting |

No package-local coverage/Vitest/Stryker configuration was found in the tracked/unignored discovery inventory. Generated directories and installed dependency trees were not treated as package-owned configuration. Type-only declarations and native transform/remap behavior remain measurement questions; an empty config exclude list does not prove a native coverage collector correctly measures every executed child.

## Mutation and CI

| Location | Observed behavior | Classification |
| --- | --- | --- |
| `stryker.config.mjs:15–27` | Mutates utilities, selected remotes/session-controller files, agent-team/tool-agent-team, ui-agent-team, one ui-subagent component, and two approval packages. Everything else is outside the mutation denominator. | Major source-selection gap |
| `stryker.config.mjs:28` | `high:100, low:99, break:99`. Scores under 99 fail; 99 can pass. High/low are report bands, not stronger break thresholds. | User's 99 floor, not a repository-wide guarantee |
| `stryker.config.mjs:9–11` | Native Vitest runner, related filtering disabled, per-test coverage selection, `disableTypeChecks:false`. | No configured checker disabling; per-test selection is normal mutation scheduling |
| `stryker.config.mjs:29` | Sandbox excludes `.claude`, `.agents/worktrees`, `.cache`, coverage, artifacts, dist-exe, `.dsh-build`, `.audit-tmp`. | Snapshot-copy selection; no proof every excluded tree is non-source |
| `vitest.mutation.config.ts:6–16,32,39` | Mutation test denominator mirrors selected owners and partitions them between Node/browser. | Restricted owner inventory; not all tests |
| `.github/workflows/ci.yml:82,145,222,419,464,564,592` with `scripts/run-gates.ts:214–236,413–459` | PR static/coverage/consumers/Windows graphs do not include mutation. PR success therefore does not enforce even the configured 99 mutation tier. | Required-gate omission |
| `.github/workflows/ci-master.yml:121`; `scripts/run-gates.ts:329` | Master Linux complete aggregate does run mutation. Manual complete modes also do. | Post-merge/local enforcement, not replacement for PR gate |
| `.github/workflows/ci-master.yml:127–160` | Complete macOS job is disabled by `if:false`. | Whole-job suppression |
| `.github/workflows/ci.yml:592–599` | PR verdict includes all listed native Windows jobs and fails failure/cancelled/skipped dependencies. No continue-on-error remains in this workflow. | Strict configured verdict; repository branch-protection settings not inspected |
| `scripts/run-gates.ts:106,879–912,979` | Failed/skipped gates produce aggregate failure; process success requires exit0/no signal/no spawn error. `after` sequencing does not pardon predecessor failures. | Strict propagation |
| `.github/workflows/ci.yml:361,368,377` | Best-effort dpkg repair, apt cache copy, wineserver shutdown use `|| true`. Subsequent installation/gates still fail normally. | Provisioning/cleanup error swallowing, not test-result approval |

The committed active Stryker patches were fully read:

- `patches/@stryker-mutator%2Fcore@10.0.0.patch:9–16,20–29` rewrites TS config parsing and reference resolution in compiled dependency JS. It imports `jsonc-parser` without changing the dependency package manifest. This is an existing unresolved dependency/clean-install contract, not an accepted suppression repair; source parity and ownership remain unresolved.
- `patches/@stryker-mutator%2Fvitest-runner@10.0.0.patch:10,23` changes test-name identity separators; `:35–36` avoids mutant-coverage reads only when coverage analysis is explicitly off; `:44–50` rejects mutation executions with no non-skipped tests. Root config uses perTest, not off. No new excluded-mutant policy was observed in these patches. Full runner correctness is not established by this read-only review.

## Accessibility enforcement

| Location | Observed behavior | Classification |
| --- | --- | --- |
| `packages/test-support/client-a11y/src/index.ts:21–29,67–77` | Selects WCAG2/2.1/2.2 A/AA and best-practice tags, explicitly enables WCAG2.2 rules; reports violations/incomplete/passes. | Standards selection; not all axe tags/AAA/experimental rules |
| `packages/test-support/client-a11y/src/index.ts:86–98` | Raw violations and incomplete results retained; context supplied by caller may be a subtree. | Surface selection; no whole-application claim implied |
| `packages/test-support/client-a11y/src/index.ts:107–111` | Score omits undecided checks and returns100 when no decided checks exist. | Score alone can conceal absence of evidence |
| `packages/test-support/client-a11y/src/index.ts:132–147` | Failure helper rejects empty audits, silent surfaces, all violations and unresolved checks regardless of numeric floor. | Strict result handling if callers use this helper with real results |
| `packages/test-support/client-a11y/src/index.ts:138–143`; `src/popup-review.ts:12–41,49–58` in same package | A specific aria-valid-attr-value/controlsWithinPopup incomplete result is counted complete after connected trigger, exact diagnostic payload, unique controls IDs, matching popup role, and expanded visibility/inert checks. Raw result remains incomplete. | Independent DOM-evidence discharge; **uncertain acceptance**, not native axe pass. No blanket rule-ID bypass found |
| `scripts/client-a11y-coverage.ts:28–34,235–250` | Requires one matching spec per `packages/client/ui-*` TSX package. Does not establish every component/state/route was audited; excludes other directory families by discovery. | Surface-selection gap |
| `scripts/client-a11y-coverage.ts:181–187,203–226` | Regex/source-presence proof is insensitive to dead branches and test.skip. | **Verified enforcement defect** |
| `scripts/client-a11y-coverage.ts:13–16` | Detects literal lower floors 0/99 and named lower constants only; not a general semantic validator of every floor call. | Static-check limitation; lowering numeric floor cannot itself pardon real violations in the helper |
| `apps/web/tests/accessibility.ts:14–18,48–50` | Whole-page builder explicitly enables WCAG2.2 rules; rejects all violations/incomplete and requires a pass. | Stronger page-level evidence |
| `apps/web/tests/sidebar-session-actions.e2e.ts:193,224,250` | Three direct builder calls omit shared WCAG2.2 enablement; their next two assertions do reject violations/incomplete. | Divergent rule configuration; not a violation-result filter |
| `vitest.client-browser.config.ts:25`; `apps/web/package.json:30–31` | Default browser lane and install scripts specify Chromium only. Sidebar suite also asks WebKit (`sidebar-session-actions.e2e.ts:12–15`), which these install scripts alone do not provision. | Platform coverage/provisioning gap, no run claimed |

Executable checker proof (no Vitest/browser run, no repo edits): imported the actual `specAuditsPackageSource` and supplied a spec with a real-looking component import/render/audit/assertion wholly under `if(false)`. It returned true. Replacing `test` with `test.skip` and removing the dead-branch condition also returned true. Source: `/tmp/dsh-full-green-plan/a11y-config-presence-probe.mjs`. Output: `/tmp/dsh-full-green-plan/a11y-config-presence-probe.log`.
This proves only the source-presence validator defect, not that a particular committed package's audit is skipped.

## Other enforcement configuration

`.jscpd.json:2–6` uses a 60-token/6-line minimum, mild mode, and only TS/TSX. These define the duplication detector's denominator and sensitivity; they are not zero-duplication proof for all code. Explicit ignored paths at `:8–12` are all tests, every tsdown config, and three catalog source paths. The command only traverses packages/scripts/apps/website (`package.json:36`), leaving vendor/native/Python/deploy outside that gate. Catalog generation ownership was not re-proven here.

Knip's full configuration was read. All ignore/exclude entries are enumerated in the appendix. They suppress findings for workspaces, binaries, dependencies, unresolved imports, or issue classes; no comment establishes that each is valid. Broad `@deepseek-ai/.+` dependency exceptions need special review. Root project selectors only include listed scripts/snapshot-MJS/deploy paths; many package selectors enumerate TS rather than TSX and explicit entry files are treated as roots. These are reachability selection choices, not assertions that their code is actually used.

`knip.json:3–5` disables the duplicates category. The separate `scripts/knip-duplicate-exports.ts` command re-runs that detector with `--no-exit-code` (`:118`) and filters results (`:69–71`). Every pair of export names containing `default` is accepted (`:48–49`) without checking that the binding is a Cordis plugin; one exact WebSocket alias is accepted at `:38–40`. This is narrower than dropping the whole category but still result filtering. The custom command is in `ciPrimaryGates` (`scripts/run-gates.ts:339`), **not** PR `ci-static`/`ci-consumers`, and not the actual `hygieneLeafGates` despite its introductory comment claiming the hygiene lane owns it.

`pytest.ini:4–5` collects only Python SDK tests and excludes node_modules/.git/dist-exe recursion. `python/sdk/pyproject.toml:28–30` uses quiet output and tests directory selection, without configured coverage or warning filters. This is Python test selection, not Python coverage/mutation proof. Runtime wheel packaging exclusions in `python/sdk-runtime/pyproject.toml:25–27` affect packaged artifacts, not a test suppression.

## Global test-runtime alteration requiring separate ownership review

The configured setup file `scripts/test-invariants.ts` is not merely observational: at `:70–104` it replaces `RegistryService.prototype.plugin`, changes plugin injection through `withInvariantReadiness` (`:252–264`), and returns joined fiber objects (`:266–290`). File-path branches bypass interception for manual invariant and native Fiber identity suites (`:49–57,72–76,112–125`). Ordinary tests load only their owner's companion; non-package tests get no companion (`:162–175`), and one topology suite requests all companions (`:128,165`). The attachment companion is supplied a rejecting test storage implementation (`:131–152,198–201`).

These are real runtime changes and exceptions behind the test configuration. They must not be described as unmodified native production execution. They do not directly lower numeric coverage thresholds, and this audit did not establish which individual defects they conceal. Their compatibility with the user's ban on monkeypatches/doubles remains unresolved. Existing directives/casts/catch in this file belong in the source-debt inventory as well.

## Limits and primary-source grounding

No full gate, browser, native-platform, mutation campaign, or dependency installation was run by this audit. No new score was computed. The existing child V8 transform/source-map measurement blocker, native Windows proof, and clean Stryker dependency ownership remain open; a strict-looking configuration cannot resolve them.

Primary documentation checked on 2026-09-16:

- [Oxlint configuration](https://oxc.rs/docs/guide/usage/linter/config): correctness is enabled by default; explicit configuration changes it.
- [Oxlint discovery](https://oxc.rs/docs/guide/usage/linter/ignore-files): config ignores and Git-ignore-based directory discovery differ from explicit file arguments.
- [Oxlint TypeScript comment rule](https://oxc.rs/docs/guide/usage/linter/rules/typescript/ban-ts-comment): per-directive controls can ban comments; minimum description length alone is not an explicit universal ban.
- [Vitest retry](https://vitest.dev/config/retry): failed tests can be retried.
- [Stryker configuration](https://stryker-mutator.io/docs/stryker-js/configuration/): break controls failure; high/low are report bands and coverageAnalysis selects tests.
- [axe-core API](https://github.com/dequelabs/axe-core/blob/develop/doc/API.md): runOnly selects rule tags and incomplete results require review.

Configuration files, supporting policy/runner modules, active Stryker patches, both CI workflows, and the axe owners named above were read in full. Discovery used tracked/unignored file inventory and package manifest searches, not an assumption that every file called config is relevant. Native imported subtree standalone build/lint workflows, external GitHub branch protection, every inline test option, and installed dependency source were not exhaustively audited. They remain explicit limits rather than approved exemptions.

## Knip exclusion appendix

Every configured ignore/exclude key and its values follows, with exact source line.
- `knip.json:3`: "exclude" = "duplicates"
- `knip.json:6`: "ignoreBinaries" = "bwrap", "icacls", "musl-gcc", "sandbox-exec", "where.exe"
- `knip.json:13`: "ignoreWorkspaces" = "vendor/*", "python/sdk-runtime"
- `knip.json:17`: "ignoreDependencies" = "@yarnpkg/cli-dist", "lightningcss"
- `knip.json:37`: "ignoreUnresolved" = "client-build-environment"
- `knip.json:47`: "ignoreDependencies" = "@deepseek-ai/.+"
- `knip.json:52`: "ignoreDependencies" = "@deepseek-ai/dsh-client-ui-directory-picker-browse", "@deepseek-ai/dsh-client-ui-directory-picker-native"
- `knip.json:104`: "ignoreDependencies" = "zod"
- `knip.json:145`: "ignoreDependencies" = "@deepseek-ai/dsh-client-ui-workspace"
- `knip.json:150`: "ignoreDependencies" = "@deepseek-ai/dsh-client-ui-workspace"
- `knip.json:155`: "ignoreDependencies" = "@deepseek-ai/dsh-client-ui-input-trigger"
- `knip.json:234`: "ignoreDependencies" = "@braintree/sanitize-url", "cytoscape", "cytoscape-cose-bilkent", "dayjs", "debug"
- `knip.json:261`: "ignoreDependencies" = "buffer", "@deepseek-ai/dsh-client-modules"
- `knip.json:318`: "ignoreDependencies" = "@deepseek-ai/dsh-agent-spine-demo", "@deepseek-ai/dsh-bash-local", "@deepseek-ai/dsh-session-checkpoint-policy", "@deepseek-ai/dsh-session-persistence-jsonl", "@deepseek-ai/dsh-subprocess-local"
- `knip.json:336`: "ignoreDependencies" = "typescript-language-server"
- `knip.json:360`: "ignoreDependencies" = "@deepseek-ai/cordis-plugin-logger-console", "@deepseek-ai/dsh-agent-spine-demo", "@deepseek-ai/dsh-bash-local", "@deepseek-ai/dsh-session-checkpoint-policy", "@deepseek-ai/dsh-session-persistence-jsonl", "@deepseek-ai/dsh-subprocess-local"
- `knip.json:419`: "ignoreDependencies" = "@deepseek-ai/dsh-agent-spine-demo", "@deepseek-ai/dsh-bash-local", "@deepseek-ai/dsh-session-checkpoint-policy", "@deepseek-ai/dsh-session-persistence-jsonl", "@deepseek-ai/dsh-subprocess-local"
- `knip.json:458`: "ignoreDependencies" = "zod"
- `knip.json:503`: "ignoreDependencies" = "zod"
- `knip.json:585`: "ignoreDependencies" = "zod"
- `knip.json:610`: "ignoreDependencies" = "@deepseek-ai/dsh-agent-spine-demo", "@deepseek-ai/dsh-session-checkpoint-policy", "@deepseek-ai/dsh-session-persistence-jsonl", "@deepseek-ai/dsh-tool-subagent"
- `knip.json:627`: "ignoreDependencies" = "@deepseek-ai/dsh-agent-spine-demo", "@deepseek-ai/dsh-session-checkpoint-policy", "@deepseek-ai/dsh-session-persistence-jsonl", "@deepseek-ai/dsh-tool-subagent"
- `knip.json:644`: "ignoreDependencies" = "@deepseek-ai/dsh-agent-spine-demo", "@deepseek-ai/dsh-session-checkpoint-policy", "@deepseek-ai/dsh-session-persistence-jsonl", "@deepseek-ai/dsh-subagent-codex", "@deepseek-ai/dsh-tool-subagent"
- `knip.json:672`: "ignoreDependencies" = "@modelcontextprotocol/server-everything", "@modelcontextprotocol/server-filesystem"
- `knip.json:706`: "ignoreDependencies" = "@deepseek-ai/dsh-client-store", "@deepseek-ai/dsh-client-ui-primitives", "@deepseek-ai/dsh-client-ui-slots"
- `knip.json:723`: "ignoreDependencies" = "@deepseek-ai/.+"
- `knip.json:737`: "ignoreDependencies" = "@deepseek-ai/dsh-agent-instructions", "@deepseek-ai/dsh-agent-spine-demo", "@deepseek-ai/dsh-llm-deepseek", "@deepseek-ai/dsh-session-checkpoint-policy", "@deepseek-ai/dsh-session-persistence-jsonl", "@deepseek-ai/dsh-skill-filesystem"
- `knip.json:757`: "ignoreDependencies" = "@deepseek-ai/.+"
- `knip.json:762`: "ignoreDependencies" = "@deepseek-ai/dsh-code-runtime-worker-thread"
- `knip.json:767`: "ignoreDependencies" = "@deepseek-ai/dsh-acp"
- `knip.json:772`: "ignoreDependencies" = "@deepseek-ai/dsh-sdk-jsonrpc-server"
- `knip.json:777`: "ignoreDependencies" = "@deepseek-ai/.+"
- `knip.json:788`: "ignoreDependencies" = "@deepseek-ai/.+"
