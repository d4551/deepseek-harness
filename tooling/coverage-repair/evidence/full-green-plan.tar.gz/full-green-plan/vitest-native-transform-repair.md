# Native TypeScript transformation repair

The isolated runner's established strict native-source compilation now passes
with no diagnostics. Its five new native regressions pass. The combined native
transformation and executed-source suites report **14 passed, one failed, zero
skipped**. The unchanged generated CommonJS helper assertion is the remaining
runtime failure. No candidate package is promoted to the root repository.

## Implementation

`packages/mocker/src/node/parsers.ts` calls Amaro's current transformation API
for `.ts`, `.mts`, and `.cts` module export analysis. JavaScript retains its
original bytes. Removed Node transform-mode flags and feature probes no longer
choose the transformation. Enums and parameter properties execute correctly;
enum reads retain mutations instead of being replaced with initial constants.

`packages/vitest/src/node/coverage.ts` uses the same transformer for native
unexecuted TypeScript files. It verifies the returned source identity, embeds
the original text, and constructs the source-map class expected by Vite. Source
file reads and syntax errors propagate. Both packages declare Amaro through one
catalog entry and the normal pnpm lockfile workflow.

The installed current official version is `amaro@1.2.0`, with registry integrity
`sha512-O6x8jjXT8dUu3KWBguGclU6QhjDgLHYHhUsWXyDlotYMi3TjNbuMETMKEcHhWXr2dl2lMlIoouxSlP6JI5iFug==`.
Native execution uses verified Node 26.9.0; strict compilation uses TypeScript
7.0.2. No compiler directive, cast, dependency override, or gate relaxation is
added by this repair.

The new file `test/native-typescript-transform.test.mjs` executes actual emitted
code and checks export names across all three extensions, mutable enum behavior,
original source content, exact return-statement coordinates through Node's
SourceMap, map serialization, syntax errors, and missing-file errors. The
original implementation fails four of its five initial cases. The final five
cases pass, including the additional enum-mutation and serialization assertions.

The executed-source test's diagnostic write to a fixed historical evidence path
is removed. Every assertion remains unchanged, including its failing exact
two-function assertion. The previously captured proof file is preserved.

## Verification

- `/tmp/dsh-native-typescript-before.log`: one pass, four failures.
- `/tmp/dsh-native-typescript-after.log`: four passes; missing original map text.
- `/tmp/dsh-native-typescript-mapped.log`: all five runtime tests pass.
- `/tmp/dsh-native-typescript-final.log`: all five strengthened tests pass.
- `/tmp/dsh-native-typescript-runtime-types-final.log`: strict native-source
  compilation passes with library checking enabled. This scope includes runner,
  Playwright provider, V8 provider, and their imported source dependencies.
- `/tmp/dsh-native-typescript-combined.log`: 14 passes, one unchanged helper
  attribution failure, no skipped tests.
- `/tmp/dsh-native-typescript-vitest-build.log`: runner runtime build passes;
  upstream circular-dependency warnings remain visible.

`vitest-native-transform-evidence.json` records source and log fingerprints.

## Outstanding build and complete-check requirements

The broader upstream `pnpm typecheck` remains red with **89 diagnostics** in
`/tmp/dsh-native-typescript-all-types-final.log`. Missing fixture/package
dependencies, missing generated declarations, and remaining test diagnostics
are not covered by the narrower native-source compile. No exclude or library
check was changed to hide them. The earlier 90-diagnostic result is retained.

The normal `@vitest/mocker` build fails because `scripts/build-utils.js` imports
an undeclared `rollup-plugin-dts`; the declaration-emitter dependency is also
absent. Its build script cleared that package's existing `dist` before failing.
The package must be rebuilt, not copied from an unrelated published artifact.
The current `unplugin-isolated-decl@0.17.0` declares a TypeScript peer range that
does not include 7. No peer exception or compiler downgrade is installed.
Current `rolldown-plugin-dts@0.28.6` declares native TypeScript 7 support and is
a concrete declaration-build migration candidate to inspect and validate.

Complete declaration/runtime reconstruction, full upstream lint/typecheck,
the generated-helper defect, Vite wrapper normalization, child source transport,
root integration, and the complete plan acceptance matrix remain open. The
converter from the preceding repair remains separate from the runner's installed
converter dependency. Root is clean at
`105a97ef9c776a2856118ee02609dc61a0fb9617`; its 633 directives are unchanged.

Primary references: [Node module API](https://nodejs.org/api/module.html#modulestriptypescripttypescode-options),
[Amaro](https://github.com/nodejs/amaro), and
[Rolldown declaration plugin](https://github.com/sxzz/rolldown-plugin-dts).
