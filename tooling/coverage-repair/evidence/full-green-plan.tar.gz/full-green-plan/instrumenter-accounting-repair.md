# Stryker mutation accounting repair

The published Stryker 10 instrumenter removes a call or throw deletion when
another mutation is present in its subtree. That drops both shutdown diagnostic
deletions from the mutation report. A complete score must include those
candidates; changing application code to avoid the filter is not a repair.

## Source and package changes

`tooling/stryker/patches/instrumenter-source.patch` removes the mutator's filter
method, its interface member, and the Babel transformer's subtree filtering
and placement-removal code. Mutation generation and candidate execution remain
enabled. It also removes the obsolete `importMeta` parser option, whose syntax
is built into Babel 8. A parser regression retains the actual module syntax.

The reconstruction pipeline now verifies the official instrumenter archive,
reconstructs its complete TypeScript source, deletes the published output and
compiles with TypeScript 7.0.2 before compiling core. Library checking remains
enabled. Its full Svelte parser typing graph requires the DOM library and the
recorded `estree-walker` build dependency. No parser source is excluded.

The maintained package patch contains source, generated JavaScript, declaration
files and maps. Bun generates the build/runtime lockfiles in isolated installs.
The runtime ownership check verifies that core resolves the same patched
instrumenter as the root of the isolated installation. The package inventory
contains all 337 instrumenter payload files, 626 core files and 43 runner files.
Generated artifacts and hashes are independently reproduced from fresh inputs.

No shared root dependency, application implementation, test threshold, source
selection or suppression directive was changed during this repair. Root
dependency integration remains an explicit CI-06 obligation. The isolated
runtime is used directly for the complete shutdown module measurement.

## Verification

- Original upstream instrumenter: four accounting tests fail because each
  reports one argument mutation and omits the call/throw removal; the parser
  test passes. Exact assertion failures are retained in
  `/tmp/dsh-instrumenter-source-sa2SC4/upstream-accounting-with-dependencies.log`.
  The first baseline launch lacked Babel dependencies and is retained separately
  as an infrastructure failure, not counted as regression evidence.
- Repaired instrumenter: five native tests pass. Diagnostic strings, nested
  calls, arithmetic arguments and throws each retain both candidates. Every
  candidate and the baseline execute in a real child; stderr and exit status
  distinguish their behavior. The package-installed replay also passes in
  `/tmp/dsh-instrumenter-source-sa2SC4/runtime-accounting.log`.
- Full canonical `rebuild` passes in `/tmp/dsh-instrumenter-rebuild.log`, with
  fresh digest-verified downloads, frozen isolated installs, strict compilation,
  dependency ownership, 23 JSONC tests, reporter consumer checks, 16 native
  runner scenarios, static activation and timeout-owner cleanup.
- Independent canonical `check` passes in
  `/tmp/dsh-instrumenter-rebuild-check.log`. It regenerates and compares the
  complete artifact set byte for byte and repeats the maintained regressions.
  Its full retained directory is
  `/var/folders/91/5qxhhcj142j402qfvs_twnh80000gn/T/dsh-stryker-build-BfEfvX`.
- Four archive/patch integrity tests pass in
  `/tmp/dsh-instrumenter-integrity.log`. Native Git application verifies both
  generated package patches; whitespace damage is rejected.
- Complete typed lint passes in `/tmp/dsh-instrumenter-full-lint.log`.
- Complete documentation reports 30 passing gates, two failures, zero skipped
  in `/tmp/dsh-instrumenter-doc-sync.log`. Remaining failures are immutable
  root/client AGENTS paragraph wrapping and root AGENTS at 2,346 words against
  a 1,950-word ceiling. Bilingual Stryker documentation and pairing pass.
- Complete working-tree whitespace, including the final delta against HEAD,
  passes. The externally staged older patches still fail index whitespace in
  `/tmp/dsh-instrumenter-index-whitespace.log`. The index was not modified.

Core archive SHA-256:
`bd65a007f18963956ae89e1e6545ef360ec37bcc0fcb3a7971dbb087f5432233`.
Instrumenter archive SHA-256:
`23c1e7674a858d33b89b67438c5666f95bdcb0dca0d9ea89366a832bb303aa76`.
Instrumenter package patch SHA-256:
`bd1aac9a07c2a3fa52e7bfcd570bc962cfe56d31ac0fb3db3d66c5d5a8d50cc9`.

## Complete shutdown mutation result

The final run completes in 5 minutes 17 seconds and exits zero. All 36 mutants
are killed, with zero survivors, timeouts, no-coverage outcomes or errors. IDs
0–35 are present, including recovered diagnostic deletions 9 and 20. Every
candidate runs the complete 16-case native shutdown suite. All status reasons
were reviewed and contain actual behavioral assertions: status, diagnostics,
event order, deadline or completion. No infrastructure failure is accepted as
detection. The command runner reports one command as its test count; that
command's retained Vitest output confirms all 16 cases execute.

The report source matches the current complete shutdown module byte for byte:
`2e77d9cbefff73b857c90c3b49f8b9896dc7f3922dc646454b1b084bdeda6680`.
The measured result is accepted for this module under the source-built
instrumenter. It is not repository-wide mutation acceptance or a coverage pass.

Evidence:

- `/tmp/dsh-process-shutdown-unfiltered.log`
- `/tmp/dsh-process-shutdown-unfiltered-mutation.json`
- `/tmp/dsh-process-shutdown-unfiltered-events/`
- `process-shutdown-unfiltered-review.json`

## Suppression inventory and remaining acceptance

`source-20260916143933059.json` records 651 directives across 4,045 authored
JavaScript/TypeScript files: 533 coverage and 118 lint. All remain violations.
The scan additionally records 1,445 catch clauses and 357 static catch-handler
member accesses. Configuration exclusions require their separate audit.

`suppression-inventory-diff-143933.md` compares the precise 903-directive
snapshot (`source-latest.json`) with the current inventory: 252 removals and
zero additions across 26 files. The older `source-audit.json` contains 943
directives and must not be mislabeled as the 903 snapshot. Line movement is
not counted as removal. Removal alone does not establish behavioral coverage.

The source corpus SHA-256 is
`93c1147f47ae357a86985874ed8c75c24c630670fa277f0ebd04112028319350`.
Every directive is listed in `suppressions-outstanding.md`.
Child transform coverage, complete repository mutation acceptance, dependency
integration, empty invariant installers, native CI matrices and other CI/CD
blockers remain open. This repair does not establish complete green.

## Primary references

- [Stryker configuration](https://stryker-mutator.io/docs/stryker-js/configuration/)
- [Babel 8 API migration](https://babeljs.io/docs/v8-migration-api)
- [Babel parser](https://babeljs.io/docs/babel-parser)
- [Bun package patches](https://bun.sh/docs/pm/cli/patch)
- Official npm instrumenter metadata is retained in
  `/tmp/dsh-instrumenter-registry.json`; version, archive integrity and commit
  are recorded in `tooling/stryker/provenance/upstream.json`.
