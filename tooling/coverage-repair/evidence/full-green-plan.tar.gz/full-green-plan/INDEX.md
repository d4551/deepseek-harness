# Complete-green planning package

Start with the [detailed execution plan](PLAN.md). Implementation progress and
current evidence are recorded in the [execution ledger](EXECUTION.md).
The [commit and CI/CD blocker plan](CI-CD-BLOCKERS.md) specifies local hooks,
all required CI groups, independent workflows, repair order, and the separate
commit-ready, push-ready, and full-green acceptance criteria. Its
[workflow inventory](workflow-inventory.json) records all 19 workflow definitions.
The verified next session-availability repair has its own
[attachment recovery execution slice](B4-attachment-recovery.md).

The repository is **not green**. This package separates current findings,
historical complete-run measurements, and unverified requirements.

All prior command-runner storage mutation scores are invalid acceptance
evidence: genuine shared-cache infrastructure failures were counted as kills.
The raw mutation reports remain unchanged historical records. The six-module,
440-mutant isolated-cache run completed at 97.27% (427 killed, 12 survived,
one timeout). It predates subsequent source changes and has not passed complete
status-reason review; no replacement acceptance score is established.
Storage initialization and durable deletion repairs are under final verification.
Provider materialization passes the complete scoped replay: 1,024 tests,
one native-Windows skip, and all eight included sources at 100% in all four
coverage metrics. Connection shutdown ownership passes its real HTTP regression
and 121 owning tests; the workspace transport consumer separately passes 12.
The earlier complete product build passes in
`/tmp/dsh-ownership-final-build.log`, including the reviewed ownership repairs.
Its oversized JavaScript chunk warning remains open. The earlier full typed lint
also passes in `/tmp/dsh-ownership-final-full-lint.log`.
The client typecheck aggregate also passes the rewritten UI type contracts.
Latest documentation aggregate is 30 passed/two failed, with no skipped gates,
in `/tmp/dsh-ownership-doc-sync-after-generation-native.log`: protected
root/client AGENTS wrapping and root AGENTS word budget. Both generated
catalogs and their bilingual pairs are current; no protected file or budget
is changed. The earlier 28-pass/four-failure log is retained.

The user's no-suppression requirement is not satisfied. A fresh complete scan
at 2026-09-17T01:25:20Z finds **633 directive suppressions**: 524 coverage and
109 lint; zero TypeScript or mutation directives. Earlier scans had 903
(736 coverage, 138 lint, 29 TypeScript), then 807, 754, 721, 714, 703, 699, 698, 685, 682, 671, 658, 652, 651, 643 and 642. All 633 remain violations. The same
scan finds another 1,442 prohibited catch clauses and 357 static catch-handler
member accesses. Handler detection broadens the scanner; these are not 357
newly introduced defects. Every directive is listed
in [outstanding suppressions](suppressions-outstanding.md); no exemption is
being accepted. Configuration exclusions require their separate audit.
That [configuration audit](config-enforcement-audit.md) now records broader
lint exclusions/disabled rules, incomplete aggregate enforcement and a
reproduced accessibility presence-check defect. These are additional blockers;
the directive count does not represent all enforcement debt.
The [directive inventory comparison](suppression-inventory-diff.md) verifies
200 removals and zero additions across 17 files since the 903-site snapshot;
directive removal alone is not completed behavioral or coverage acceptance.
The [HTTP checkpoint comparison](suppression-inventory-diff-113542.md) extends
that evidence to 204 removals and zero additions across 18 files. One further
sandbox constructor directive and all 13 profile-resolution directives are
removed in the latest source snapshot. Strict profile coverage remains red.
The [profile comparison](suppression-inventory-diff-115207.md)
verifies 218 removals and zero additions across 20 files against the baseline.
The next native boot repair removes the remaining three boot-entry coverage
directives; its native tests pass, but child coverage remapping is invalid.
The [boot checkpoint comparison](suppression-inventory-diff-121307.md)
verifies 221 removals and zero additions across 21 files against the baseline.
The [subprocess comparison](suppression-inventory-diff-124623.md) verifies
232 removals and zero additions across 22 files. All eleven launch-module
coverage directives are removed; [subprocess verification](subprocess-unsuppressed.md)
retains both the ordinary pass and the failing strict measurement.

The [latest complete comparison](suppression-inventory-diff-130633.md) verifies
245 removals and zero additions across 24 files. Attachment admission now owns
cancellation through queued and active preparation and pre-publication storage.
All twelve storage coverage directives and one encoding-test lint directive
are removed. [Attachment verification](attachment-admission-cancellation.md)
retains the strict coverage failure and the native Loader acceptance evidence.

| Inventory | Count | Complete listing |
| --- | --- | --- |
| Source findings | 2,395 at baseline; latest expanded scan 2,432 across 4,060 files | [Baseline](source-audit.md), [latest complete listing](source-composite-teardown.md) |
| Empty invariant installers | 217 rejected by the repaired package gate; separate from directive counts | [Every installer](empty-invariant-installers.md), [repair evidence](empty-invariant-gate-repair.md) |
| Full lint errors | Current complete typed lint passed; the separate source-prohibition gate remains red | [Lint baseline](lint.md), complete output `/tmp/dsh-profile-a11y-full-lint.log` |
| Historical storage mutation output | Earlier scores withdrawn; later isolated-cache snapshot reports 97.27%, below 99 and not final-state acceptance | [Unchanged raw baseline](mutation-survivors.md), [withdrawn later output](mutation-current.md) |
| Historical coverage metric failures | 2,049 across 657 files | [Coverage](coverage-threshold-failures.md) |
| Latest full-run test failures | Two, with 20,468 passing and 42 skipped; source prohibitions and the provenance-word gate remain open | [Current replay](composite-teardown.md), [prior failure inventory](full-run-root-integration-failures.md) |
| Active proposals | 24 at baseline; currently 23 | [Baseline full proposal text](proposed-work.md), [resolution evidence](EXECUTION.md) |
| README limitation sections | 260 | [Full section text](readme-constraints.md) |
| Distinct gate commands | 77 | [Commands and evidence](gates.md) |
| Additional confirmed defects and blockers | Itemized | [Additional findings](additional-findings.md) |
| Scoped storage static audit | 58 findings, requiring source review | [Complete Brutalise report](storage-brutalise.json) |

Machine-readable JSON accompanies the main inventories. Counts overlap and
must not be summed into a total defect count. Full native/platform workflow
obligations are detailed in the plan and extend beyond the 77 commands.

Raw source, lint, gate, coverage, README and proposal inventories are snapshots,
not live status. Preserve earlier failing reports. The latest source scan is
`source-composite-teardown.json`; the latest full-run failures are itemized
separately from repaired focused replays. Strict fs-local coverage still fails
with 29 uncovered locations; spill cleanup coverage also fails. Native child
coverage mapping remains open. Source-built Stryker packages now pass both
isolated and complete-root clean/frozen dependency-ownership probes; root
integration is verified in [its evidence record](stryker-root-integration.md). No accepted
repository-wide 99% mutation result or complete native/browser/axe/CI result exists.

With automatic E2E retries removed, built CLI acceptance reports 19 passed
and three failed in `/tmp/dsh-built-cli-no-retry.log`. The stale profile hint
now passes a stronger native recovery test that executes the recommended init
command and checks all generated configuration files. Two startup patch-reload
failures exposed a boot-to-watch provenance race. The repaired host artifacts
pass all 22 CLI cases, including the unchanged reload assertions. Final replay
after making build artifacts mandatory is `/tmp/dsh-built-cli-required-build.log`.
The final replay after the profile dependency repair also passes all 22 cases
in `/tmp/dsh-built-cli-final-profile.log`, with no retries.
The metadata ownership repair subsequently passes complete product build in
`/tmp/dsh-handoff-a11y-product-build.log`. Documentation replay is again
30 passed/two protected-file failures in `/tmp/dsh-handoff-a11y-doc-sync.log`.
The final accessibility-integrity and profile changes pass complete build in
`/tmp/dsh-profile-a11y-integrity-build.log` and complete typed lint in
`/tmp/dsh-profile-a11y-full-lint.log`. Native browser validation passes 698
tests with 67 actual audit tests verified; the owning accessibility suite
passes 49 tests. Profile owning tests pass 152, including real imports through
a nameless local bundle. Strict coverage remains red. Complete normal tests
finish with 20,313 passed, five failed and 42 skipped in
`/tmp/dsh-full-current-enforcement.log`; all 67 discovered audit tests execute
and validate. Complete docs again report 30 passed/two protected-file failures
in `/tmp/dsh-profile-a11y-final-doc-sync.log`. Further source repairs follow
these checkpoints. The earlier failed build remains retained.

Latest boot repair passes 156 owning tests and complete product build in
`/tmp/dsh-boot-resolver-product-build.log`. It denies host-based bare package
imports when the native resolver is unavailable, retaining supported URL and
relative imports. Configuration dump rows carry their own provenance.
The accessibility helper's complete four-file strict coverage now passes all
metrics at 100%, with 37 owning tests and real browser review cases; the Vite
warning remains. Ordinary verification no longer rewrites session fixtures,
and the native import sweep fails when build artifacts are missing. These are
bounded repairs, not complete-green acceptance.
Final native browser replay passes 707 tests and verifies all 67 audit tests
in `/tmp/dsh-a11y-popup-full-browser.log`. The current rebuilt CLI passes all
22 cases without retries in `/tmp/dsh-built-cli-final-resolver.log`.

The subsequent [native Worker repair](worker-sandbox-repair.md) resolves the
three sandbox setup failures with actual browser Workers and packed production
providers, preserving the original assertions. Its complete runtime package
replay passes 911 tests across 35 files. The CI and local gate graphs now require
the builds those tests consume; 79 gate tests and 20 workflow tests pass.
Complete typed lint passes in `/tmp/dsh-worker-ci-order-full-lint.log` before a
final fixture refinement whose scoped lint passes. The final runtime replay
passes all 911 tests with unchanged default timeouts and zero skips in
`/tmp/dsh-worker-runtime-timed-native-full.log`. Documentation finishes with
30 passing gates and two protected-file failures in
`/tmp/dsh-worker-ci-order-doc-sync.log`. No repository-wide full-green result
or accepted mutation score follows from these scoped repairs.

The attachment cancellation repair passes the full product build and complete
typed lint. Its strict owning replay passes 150 tests with one existing native-
Windows skip; the built Loader proves cancelled admission publishes nothing
and a later save remains readable. All eight affected files reach 100% lines
and functions, but six uncovered storage statement/branch locations keep
strict coverage red. A final additional native primitive-reason regression
passes all five limiter cases and scoped typed lint. Complete documentation
reports 30 passed, two protected-file failures and zero skipped in
`/tmp/dsh-admission-final-doc-sync.log`. Full green remains open.

The subsequent [shared request repair](shared-request-cancellation.md) fixes
blocked abort propagation, final-waiter settlement, queued request cancellation,
and cache read errors hidden as misses. Full build and typed lint pass. All
158 owning tests pass with one existing Windows skip, including the built
Loader. The broader whole-package coverage run retains 22 uncovered locations:
six in storage and sixteen in the two invariant companions. The repaired
request modules reach all four 100% metrics. No mutation score or complete-
green acceptance follows from that coverage evidence. Final complete docs report
30 passed, two protected-file failures and zero skipped in
`/tmp/dsh-shared-request-doc-sync-final.log`. All 658 directives remain violations.

The [empty-installer gate repair](empty-invariant-gate-repair.md) removes the
comment-based exemption from the package invariant checker. Its 29 tests pass
with all four gate-source coverage metrics at 100%. Complete typed lint passes,
followed by passing scoped typed lint for the final edits. Documentation reports
30 passed, two protected-file failures and zero skipped. The complete package
gate rejects 217 existing empty installers. These findings require implementation;
registration alone is not a runtime check, and no companion is deleted or excused.

The [source-owned Stryker patch repair](stryker-patch-whitespace-repair.md)
makes complete working-tree whitespace pass without patch exclusions. Native
Git and Bun application reproduce every verified source/package byte; fresh
canonical reconstruction, strict TS7 compilation, native runner regressions,
four integrity tests, and full typed lint pass. The staged index retains older
patch bytes and still fails whitespace. Small runner mutation fixtures do not
establish the repository's required score. All 658 directives remain violations.
Final full documentation reports 30 passed, two protected-file failures and
zero skipped in `/tmp/dsh-clean-stryker-patches-doc-sync.log`.

The [current image-pricing repair](image-pricing-repair.md) replaces the retired
experimental image geometry with the official V4.1 calculator and removes six
coverage directives. Native comparison matches 3,887,248 dimension pairs; the
live browser calculator confirms 1920×1080 estimates 968 tokens instead of the
old 369. All 652 tests in the final combined owning replay pass, but strict
coverage remains red on five solver failure-guard locations. Full product build,
typed lint and the built public-entry probe pass. Documentation reports 30 pass,
two protected-file failures, zero skipped. The latest source scan retains 652
directives, all violations. Default provider catalog names and capabilities
also need repair against current official documentation.

The [native shutdown repair](process-shutdown-repair.md) fixes zero-status exits
after failed or expired disposal, removes one coverage directive, and replaces
simulated exit callbacks and clocks with sixteen native child-process scenarios.
All sixteen pass; built CLI and real PTY acceptance pass 23 cases. Full build
and typed lint pass. The owning CLI suite passes 59 cases and skips its opt-in
built-Web smoke, which subsequently executes and passes against the fresh build.
Complete docs retain the two protected-file failures. Strict coverage remains
red; Inspector capture proves the collector uses different generated bytes
from those the child executes. There are 651 remaining directives, all violations.
The shutdown measurement detects all 34 reported mutants, but its score is not
accepted: the upstream instrumenter filters out two diagnostic-call deletion
candidates. Independent execution of its mutators reproduces both omissions.
The repair report records the required source-owned instrumenter correction;
all 34 actual detection reasons were reviewed, and the original report is retained.

The [instrumenter accounting repair](instrumenter-accounting-repair.md) removes
the subtree rule that drops call/throw deletions. A verified source build and
independent byte-for-byte reconstruction pass. Five native accounting tests
pass; the upstream instrumenter fails four of those tests on missing candidates.
Full typed lint passes; documentation remains 30 passed/two protected-file
failures. The [current directive comparison](suppression-inventory-diff-143933.md)
proves 252 removals and zero additions across 26 files against the exact
903-directive snapshot. All 651 remaining directives are violations.
The full shutdown rerun detects all 36 candidates including both lost deletions,
with zero survivors, timeouts or errors. All 36 status reasons contain reviewed
behavioral assertions, and the report source matches the complete current
module. This accepts the scoped mutation result. Root dependency integration and
repository-wide mutation, coverage and full-green acceptance remain open.

The [root integration](stryker-root-integration.md) installs the verified core
archive and instrumenter/runner patches through the root lock graph. Every one
of 1,006 package files matches the source-built inventory. A clean root copy
with a fresh dependency cache passes frozen installation with normal lifecycle
scripts and an unchanged lockfile; all five native accounting cases pass there.
The root owning tests pass 91 cases, and the new notices declaration helper
passes every 100% coverage threshold. Complete product build, typed lint and
workspace constraints pass. Documentation remains 30 passed/two protected-file
failures. The current normal full-suite run reports 20,407 passed, three failed
and 42 skipped, with all 67 accessibility audit tests verified; a discovered
SDK assertion drift is repaired and passes all 40 SDK/admission tests plus typed
lint. All 651 suppressions remain violations, with zero added against the
903-site baseline. Index reconciliation and complete-green acceptance remain open.

The [TypeScript AST contract repair](typescript-ast-contract-repair.md) removes
eight more lint directives while preserving missing-value checks. A source
schema correction and strict upstream API build reproduce all 364 distribution
files; every executable JavaScript file remains identical to the published
package. Independent reconstruction and a clean frozen root installation pass.
Corrected declarations also exposed unsafe slot catalog reads, now rejected
with explicit annotation errors. All 426 final owning tests pass; unchanged
strict coverage fails on 237 uncovered locations across the eight affected
sources. Full product build, final typed lint, workspace constraints and notices
freshness pass. Complete docs remain 30 passed/two protected-file failures.
The [baseline comparison](suppression-inventory-diff-152023.md) verifies 260
directive removals and zero additions across 32 files. All 643 remaining
directives are violations. Repository-wide full-green acceptance remains open.

The [strict Vitest build repair](vitest-strict-build-repairs.md) reduces the
isolated runner candidate's native compiler diagnostics from 20 to two without
disabling library checking. A source-built local-package declaration repair
passes independent frozen reconstruction, upstream source/ESM/CommonJS tests,
and strict packed-consumer checks. Two obsolete dependency declaration
suppressions are removed, browser source identity is unified, and the snapshot
package owns its missing declaration dependency while retaining every runtime
byte and the existing upstream patch. These changes remain in the isolated
candidate: two Node transformation API diagnostics and final runtime/artifact
verification still prevent promotion. The repository's 643 directives and
full-green requirements remain open.

The [coverage failure propagation repair](vitest-coverage-failure-propagation.md)
removes three ways the isolated V8 provider concealed broken source inputs.
Four real-project/native Inspector regressions pass, and three independent
published-provider controls reproduce the original defects. The complete
coverage source is added to strict compilation; the current official converter
release resolves its missing declaration import with all five package files
verified against the official archive. The expanded compile still fails on
the same two Node transformation API calls. Exact executed-source capture and
candidate promotion remain open; repository suppressions remain at 643.

The subsequent [executed-source candidate](vitest-executed-sources.md) captures
native generated code and maps during execution, preserves deleted mapped
files, and remaps distinct records before merging. Nine native cases pass;
one remains red because generated CommonJS helpers are attributed to original
export text. Full strict compilation retains the two existing Node API errors.
Vite wrapper normalization, child transport, complete artifact verification
and root integration remain open. The candidate is not promoted.

The [source-map conformance candidate](vitest-source-map-conformance.md)
reproduces and repairs forward attribution of unmapped generated positions.
All 28 owning location tests pass, but the complete upstream comparison proves
twelve new framework coverage failures; their assertions remain unchanged.
The native runner still reports nine passes and one helper-attribution failure,
and strict runner compilation retains two diagnostics. This change is not
accepted or promoted. The fresh 16:12:13Z source scan confirms the unchanged
643 repository directives, all violations, in `source-20260916161213790.json`.

The [token-meter pricing repair](token-meter-pricing-repair.md) removes another
lint directive through explicit missing-price and numeric validation. All 121
owning tests pass; the complete changed module reaches 100% in all four coverage
metrics. After retaining an 87.88% failed mutation run and repairing its findings,
the final run detects all 57 candidates. Every status reason is reviewed as an
actual behavioral failure, and the report source matches the current module.
Final full build, typed lint and built image-compaction replay pass. Complete
docs retain the two protected-file failures; index whitespace remains blocked.
The fresh inventory records 642 directives, all violations. Full-green acceptance
remains open.

The [preset mount repair](preset-mount-repair.md) removes nine coverage
directives and two catch clauses, verifies host package resolution in native
processes, and retains failed-mount cleanup causes until unload settles.
All 186 owning tests, full product build and typed lint pass. Strict coverage
remains red; full docs retain the two protected-file failures. Whole-module
mutation finishes at 87.63% and fails: 160 reported killed, 23 survivors and
three timeouts across 186 candidates. It has no accepted score. Broader Web composition
reports 24 passed and eight failed, including Team tools violating minimal's
exact two-tool contract; the focused minimal failure reproduces before this
repair. The latest comparison proves 270 directives removed and zero added
against the 903-site baseline. All 633 remaining directives are violations.
The token-meter report also records a sequential 57/57 mutation replay that
supersedes its earlier overlapping build/mutation run. Full green remains open.

The [Team admission repair](team-preset-admission-repair.md) makes preset
restrictions follow the live composition and revoke prepared calls before
dispatch. Both switch directions have reproduced shipped-executor failures.
The repaired source passes all 32 owning tests and complete-module 100%
coverage in every metric, plus scoped typed lint. Dependency reconciliation,
complete product build, full typed lint and catalog freshness pass. The rebuilt
Web replay passes both switch-executor regressions and reports 31 passed with
three failures: standard's exact catalog and two renamed minimal compositions.
The translation commit blocker is repaired: all 25 staged records and all 1,183
documentation pairs pass, together with staged whitespace. Full documentation
aggregate acceptance and Team mutation acceptance remain open. No suppression
or gate relaxation was added; the global 633-directive inventory remains unresolved.

Current committed HEAD is `ee24359f10f99c47b05ff75cb40426e7ea860505`.
The user committed the earlier work. The next cleanup test repair strengthens
the native event-loop settlement assertion, covers a final unload-observer
failure, and asserts complete multi-row missing-dependency diagnostics. All 189
preset tests pass and scoped typed lint passes. Complete mount coverage remains
red at 92.30% statements, 56.45% branches, 100% functions and 92.63% lines.
The [completed survivor replay](preset-mount-strengthened-tests.md) detects ten
of the 23 prior survivors with reviewed behavioral assertions; thirteen remain.
The final unmutated instrumented control passes. This diagnostic replay does
not establish a replacement full mutation score. The copied-minimal failures
remain product defects, and their exact assertions remain unchanged.

The [mount ownership repair](preset-mount-retention.md) proves and fixes retention
of the last disposed mount without another registry observation. Its 193 owning
tests, full product build and full typed lint pass. Six more original survivors
are detected by real Loader/service assertions, with passing unmutated controls;
these diagnostic replays are not a replacement full mutation score. Strict
coverage remains red. The stale event graph is regenerated and paired; final
full documentation reports 30 passed, two protected-file failures, zero skipped.
The rebuilt Web composition retains the three known catalog failures. A fresh
whole-module mutation run is active in `/tmp/dsh-preset-retention-mutation.log`,
started after every build/documentation writer completed. No replacement score
is established. The full-green objective remains active.

The [Team composition lifecycle repair](team-composition-lifecycle.md) fixes
cross-preset capability leakage and a ten-of-eleven tool handoff failure through
scope admission and awaited contribution teardown around preset relinking.
Web's Team grant belongs to its actual preset compositions. Final build, full
typed lint, lock reconciliation and all 35 built Web tests pass. All 1,183
documentation pairs pass. The final mount mutation campaign fails at 96.79%:
178 reported kills, three timeouts and six survivors; reason review remains open.

The [composite teardown repair](composite-teardown.md) additionally fixes ten
retained Team tools after an early removal observer throws. Native file and real
registration tests prove complete ordered cleanup and retained failures while
preserving synchronous cleanup contracts. The final full normal suite reports
20,468 passed, two existing enforcement failures and 42 skipped; all 67 actual
accessibility audits execute. The expanded owning replay passes 255 tests and
measures the complete Team entry module at 100% in all four metrics. Cordis
coverage remains unverified: the provider parses its raw TypeScript as JavaScript
and excludes the executed record. No source exclusion or threshold change is
accepted. Final documentation reports 30 passed, two protected-file failures and
zero skipped after canonical generation and bilingual source-link alignment.
The fresh inventory retains 633 directives, 1,442 catch clauses and 357 handlers.
Complete coverage, mutation, platform/CI and full-green acceptance remain open.

The [bounded source-range repair](vitest-source-range-repair.md) recovers an
authored statement inside generated syntax and fixes CRLF and unrelated-range
endpoint attribution. All 72 focused tests pass on verified Node 26.9.0 with
current dependencies, and an identical native Inspector control fails against
the previous converter artifact and passes against the rebuilt one. Full
converter lint, package validation, build and strict implementation compilation
pass. Complete-project compilation retains six diagnostics. The complete suite
reports 1,117 passed, 15 failed and four compiler errors, including twelve
unchanged framework failures. The candidate remains unaccepted and unpromoted;
the root repository's coverage, mutation, 633 directives and other plan work
remain open.

The [instrumentation declaration repair](vitest-instrumentation-declarations.md)
fixes the circular public declaration and missing declaration dependency at
their owning source package. All 455 upstream tests and strict compilation
pass, including a fresh frozen reconstruction and a clean packed consumer.
The instrumenter's executable remains byte-identical to the official package.

The [native fixture repair](vitest-native-fixture-repair.md) completes strict
converter compilation on TypeScript 7 and enables library checking in its
configuration. A verified historical compiler control proves that the old
fixture paired 240 out-of-bounds ranges with emitted code and falsely reported
273 covered functions from five actual calls. Real subprocess coverage and an
independent Istanbul execution agree on five functions, 20 statements and
15 branch outcomes. The repaired test checks every function, statement and
branch counter. Existing dependency overrides and release-age exceptions are
removed, and the repaired dependency archive uses a portable relative path.
Fresh frozen installation, strict typecheck, build and byte identity pass.
Both complete source and reconstructed suites report 1,119 passed, 13 failed,
and no compiler errors. The checker and framework assertions remain unchanged;
independent checker maps expose further attribution differences. The candidate
is not promoted. The root is clean at observed commit
`105a97ef9c776a2856118ee02609dc61a0fb9617`; no root files were changed by this
tooling slice. Repository-wide full-green acceptance remains open.

The [framework and logical-expression repair](vitest-framework-logical-repair.md)
restores all twelve framework failures without changing their assertions and
recovers callbacks omitted by nested logical-expression traversal. Native
Inspector cases prove declaration ownership, deferred-body counts, computed
keys, and exact logical-expression counters across four parsers. All 1,184
tests, strict compilation, lint, package validation and build pass. A fresh
frozen reconstruction also passes all 1,184 tests and reproduces both build
files byte for byte. The two large-fixture expectations are reconciled against
current emission and independent instrumentation, with complete maps retained.
The generated CommonJS getter still maps to authored export text; a replay of
the actual captured execution confirms that failure. The runner's two compiler
diagnostics and integration work remain open. No root changes or promotion are
made, and no repository-wide coverage, mutation or full-green acceptance follows.

The [native transformation repair](vitest-native-transform-repair.md) replaces
the runner's two removed Node transform-mode calls with the current Amaro API.
Five native regressions verify enums, parameter properties, export discovery,
mutable enum reads, source-map coordinates and error propagation. Strict
native-source compilation now passes. The combined runtime replay reports
14 passed, one unchanged helper-attribution failure, and zero skipped. Runner
runtime build passes, but the owning module-analysis declaration build fails
on missing build dependencies. The complete upstream typecheck retains 89
diagnostics outside the passing native-source scope. No gate is weakened and
no package is promoted; root directives and full-green acceptance remain open.

The [module-analysis build repair](vitest-mocker-build-repair.md) produces all
eight runtime/declaration entries with a current builder. Complete package
source compilation and packed public declaration imports pass with library
checking enabled. Fresh-cache frozen reconstruction reproduces all 28 generated
files byte for byte. The real packed runtime regression exposes an upstream
Node package lookup defect: missing metadata returns the source filename.
Seven native regressions reproduce five failures in the official binary.
A source-level Node correction is prepared and its native build is running;
corrected runtime acceptance is pending. Complete runner typecheck retains
89 diagnostics. Neither candidate is promoted, root is unchanged, and all
repository-wide acceptance requirements remain open.

The [packed browser registration repair](vitest-mocker-browser-repair.md) fixes
the automatic entry mapping and initialization metadata, browser dependency
emission, versioned registration transforms, a mismatched RPC response, and
inconsistent importer resolution. All five owning browser scenarios pass
against the packed artifact with explicit exception and warning/error checks.
Strict complete package-source and public declaration checks pass. Fresh-cache
frozen reconstruction reproduces all 28 generated files and preserves the
lockfile. The full upstream typecheck retains the same 89 diagnostics. The
native Node build remains live and unaccepted; root is unchanged and no
repository-wide acceptance claim or package promotion is made.

The owning `automock` fixture is additionally corrected to exercise automatic
substitution instead of spy mode. Its original return-value assertion remains,
and the new initial-result assertion rejects the old configuration in a real
browser control. The final full owning replay passes all five cases; both the
failed control and final pass are retained in the browser repair record.

The [source-map loading repair](vitest-source-map-integrity.md) propagates missing
and malformed map failures and preserves Unicode across inline and file URLs.
All 40 new regressions fail against the exact previous source. The repaired
fresh-cache frozen reconstruction passes all 1,224 tests, strict compilation,
lint, formatting and package checks, and reproduces both build artifacts byte
for byte. Native Git application reproduces all 21 recorded inputs. A separate
official esbuild 0.28.2 probe isolates the remaining getter attribution defect:
four ESM cases pass and four CommonJS cases map generated getters to authored
export text. The producer correction remains open; no coverage filter is added.
The converter is unpromoted, the native Node build remains live, and root plus
repository-wide full-green obligations remain unchanged.

The subsequent [generated-location repair](esbuild-generated-locations.md)
corrects namespace export provenance in the isolated compiler and rebases maps
whose first segment has no authored source. All 16 native cases pass, including
bundled authored getters and ES5/full-minification variants; the unchanged
official compiler fails 12 of those cases. Complete Go tests, static checks and
the unchanged upstream mapping suite pass. Native Git reconstruction reproduces
the source and a byte-identical executable, whose eight bundled native cases
also pass. The candidate remains unpromoted; complete mapping/coverage acceptance
and the repository plan remain open.

The [native Node lookup repair](node-package-json-native.md) has finished building.
Its seven regressions, eleven existing lookup cases and internal cache test pass,
including all three files through Node's own runner. Both packed consumers pass
their two unchanged native tests. The initial combined launch's shared-directory
collision remains recorded. Root is unchanged; runtime/package promotion and
the complete required validation matrix remain outstanding.

The [archive peer-version repair](pnpm-archive-peer-versions.md) corrects two
pnpm lookup paths that compare archive references with semantic version ranges.
Eleven new regressions expose five snapshot failures and three linked-consumer
failures before their respective repairs. The final owning crate passes all
50 tests, lint with warnings denied, and pinned formatting. Native Git
reconstruction reproduces the five changed or added source inputs exactly.
Official pnpm independently rejects a real compatible archive during both
strict installation and peer checking; the repaired release CLI is building
for comparison. Complete upstream validation and package promotion remain open.
The compiler/loader integration also isolates another mapping defect: all four
native cases using name preservation report an uncalled line as covered;
the four corresponding cases without name preservation pass. The integrated
runner retains its unchanged failing assertion. Root remains unchanged and
the full-green objective remains active.
