# Bounded source-range attribution

The isolated converter candidate contains a verified source-range repair. It
is **not accepted or promoted**: twelve unchanged framework assertions remain
red, and the complete project still has compiler and test failures.

## Reproduced defects and changes

The preceding candidate rejected a whole syntax node when its opening
position had no original mapping. A generated call surrounding an authored
conditional consequently lost the authored statement, even though native V8
coverage recorded its execution. The locator now searches for mapped positions
inside the node's half-open generated range. Unmapped code outside that range
cannot acquire a following authored position.

The endpoint lookup also had two independently reproduced defects. A range
ending at a line boundary produced column -1. An unmapped suffix could acquire
a later source position outside the range on the same generated line. The end
lookup now starts at the final included UTF-16 offset and searches backward
within the range. Empty ranges have no location.

Three new locator cases exercise generated syntax, multiline CRLF boundaries,
and a later unrelated mapping. Existing unmapped-prefix and middle-segment
assertions remain intact. A real Inspector regression executes a generated
script containing an authored conditional between unrelated generated calls.
It requires exactly one covered statement and one covered outcome out of two
branches. All four parser configurations execute this regression.

The test matcher declarations now extend Vitest's current `Matchers<R, T>`
contract, replacing the obsolete `Assertion<T>` declaration. Their actual
assertion implementations and expected results are unchanged. Native checks
explicitly await test completion. One obsolete lint directive is removed from
the converter source; no directive or gate relaxation is added.

The range interpretation is grounded in
[ECMA-426](https://tc39.es/ecma426/). Matcher declarations follow
[Vitest's current extension API](https://vitest.dev/guide/extending-matchers).
Context7 returned a quota error, so primary documentation was used directly.

## Current runtime and dependencies

The final verification uses official Node 26.9.0, downloaded from nodejs.org
and checked against its published SHASUMS256.txt. The Darwin arm64 archive
SHA-256 is
`6f3de7ed853ee283b4bf24b6e426618f1d357401ce5815db1866eb85eb4b05d9`.
The runtime is `/tmp/dsh-node26.9.0/node-v26.9.0-darwin-arm64/bin/node`.

An initial normal build reconciled the isolated source tree's dependency
installation against its pnpm lockfile. Registry inspection identified older
direct dependencies. `pnpm update --latest` then updated the manifest and
lockfile through the package manager. Final source and baseline runs use the
same current dependency installation, including Vitest 5.0.1, Vite 8.3.0,
TypeScript 7.0.2, OXC parser 0.150.0 and Istanbul packages 1.0.1. The root
application manifest, lockfile and installed dependencies are unchanged by
this work.

## Verification

| Check | Result | Complete output |
| --- | --- | --- |
| Initial range regressions | 8 fail, 28 pass | `/tmp/dsh-ast-v8-range-before.log` |
| Endpoint regressions before repair | 8 fail, 32 pass | `/tmp/dsh-ast-v8-range-end-before.log` |
| Focused locator and source-map suite | 72 pass, zero skips | `/tmp/dsh-ast-v8-range-native-tests.log` |
| Previous built converter, real Inspector control | Fails: authored statement missing | `/tmp/dsh-ast-v8-range-native-before-final.log` |
| Rebuilt converter, identical real Inspector assertions | Pass | `/tmp/dsh-ast-v8-range-native-after-final.log` |
| Three standalone unmapped-position cases | 3 pass, zero skips | `/tmp/dsh-ast-v8-range-native-location-final.log` |
| Complete upstream baseline, current dependencies | 1,101 pass, 3 fail, 4 compiler errors | `/tmp/dsh-ast-v8-range-baseline-current.log` |
| Complete changed-source suite, current dependencies | 1,117 pass, 15 fail, 4 compiler errors | `/tmp/dsh-ast-v8-range-complete-final.log` |
| Strict implementation import graph, library checking enabled | Pass | `/tmp/dsh-ast-v8-range-source-types-final.log` |
| Complete project, library checking enabled | 6 diagnostics | `/tmp/dsh-ast-v8-range-complete-types-final.log` |
| Full lint, formatting and package validation | Pass | `/tmp/dsh-ast-v8-range-full-lint-final.log` |
| Authored package build | Pass, experimental compiler API warning remains | `/tmp/dsh-ast-v8-range-final-artifact.log` |

The first standalone artifact probe used a wrong dependency entry point, and
the next probe incorrectly expected an ordinary object where the coverage
library returns a null-prototype dictionary. Those failing logs are retained.
The final native proof asserts that dictionary's prototype and exact entries,
as well as the original statement and branch counts. Both converter versions
execute the identical final proof; only the repaired version passes.

## Remaining blockers and next work

The twelve framework failures are still Svelte conditional, Svelte loop and
Vue loop cases across four parsers. Range repair restores their missing
statement and branch attribution, but it does not resolve their complete
function/location contracts: Svelte reports zero instead of one function and
three instead of six; Vue reports four instead of three statements. The
independent framework comparison retains actual and Istanbul maps, generated
code and source maps in `/tmp/dsh-ast-v8-range-framework-proof.json`.
No existing snapshot or assertion is changed.

Four compiler diagnostics and three end-to-end failures still originate in
the removed TypeScript JavaScript compiler API used by the test emitter.
The two other complete-project diagnostics are the missing Babel source-map
declaration dependency and a circular Istanbul instrumenter declaration.
These are separate from the two Node transformation API diagnostics in the
isolated Vitest runner.

The new converter has not been installed into the isolated Vitest runner or
the root application. Its CommonJS helper-attribution failure, Vite wrapper
normalization, subprocess source transport, full artifact reconstruction and
root integration remain open. The repository's last source scan still records
633 directives; this external candidate does not close that inventory.
No repository-wide coverage, mutation or full-green acceptance is claimed.

Source, dependency and result hashes are recorded in
`vitest-source-range-evidence.json`. All verification processes listed here
have terminated. The complete plan remains active.
