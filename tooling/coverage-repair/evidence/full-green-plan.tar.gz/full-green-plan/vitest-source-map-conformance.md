# Source-map conformance candidate

The converter change remains **unaccepted and unpromoted**. It repairs a
reproduced source-position error, but introduces twelve failing framework
coverage assertions. No assertion, snapshot, threshold or exclusion is changed.
The root repository still has 643 directive suppressions, all violations.

## Reproduced defect

The converter first asks for the original position at or before a generated
coordinate. When that coordinate has no original source, it retries against the
next mapping. This assigns unmapped generated code to later authored text.

Three native cases reproduce the defect before the change: an explicitly
unmapped prefix, an explicitly unmapped middle segment, and a prefix before the
first source mapping. Each also checks that authored positions remain intact.
The original two probes at exact unmapped segment boundaries passed; those
probes did not exercise positions inside the segments. Their passing output
is retained in `/tmp/dsh-ast-v8-location-before.log`.

The corrected interior-position cases fail three of three in
`/tmp/dsh-ast-v8-location-before-interior.log` and pass three of three after the
source change in `/tmp/dsh-ast-v8-location-after.log`.

`src/location.ts` removes only the retry toward a later original position.
The separate end-boundary lookup is unchanged. No helper-name exclusion,
source exclusion or coverage directive is added. The conformance cases are
also added to the owning `test/location.test.ts`; all 28 cases across the four
configured parser projects pass in `/tmp/dsh-ast-v8-location-final.log`.

The interpretation follows the mapping and unmapped-segment semantics in
[ECMA-426](https://tc39.es/ecma426/). This does not establish complete coverage
semantics for framework compilation; the failures below remain acceptance
blockers.

## Full-suite comparison

Both trees use the same installed dependency graph and Node 26.8.2. The baseline
tree was extracted independently from the official source archive at commit
`48f88c789411ce6e96137b16ec348d06ae6c2f6e`.

| Check | Unchanged source | Changed source |
| --- | --- | --- |
| Complete converter tests | 1,101 pass, 3 fail | 1,101 pass, 15 fail |
| Unhandled compiler API errors | 4 | 4 |
| Failed framework snapshots | 0 | 12 |

The changed tree includes twelve additional passing regression executions.
The complete logs are `/tmp/dsh-ast-v8-baseline-complete-tests.log` and
`/tmp/dsh-ast-v8-complete-final.log`. The earlier candidate run before adding
the regressions is retained in `/tmp/dsh-ast-v8-complete-tests.log`.

The twelve new failures are the Svelte conditional, Svelte loop and Vue loop
cases, each tested through four parsers. The changed mapping loses reported
functions, branches, statements or lines expected by those existing cases.
The assertions remain red. A correct repair must preserve coverage of authored
framework behavior while preventing attribution of unrelated generated code.

The three pre-existing end-to-end failures and four unhandled errors come from
the upstream test helper's removed TypeScript JavaScript compiler API. Native
TypeScript 7 compilation of every implementation source passes with strict
checking and library checking enabled. The separate complete-project strict
compile fails with ten diagnostics, including upstream dependency declarations
and the test helper. Logs: `/tmp/dsh-ast-v8-source-strict-types.log` and
`/tmp/dsh-ast-v8-strict-types.log`. A source-only pass does not replace that
complete-project failure.

## Built consumer

The converter builds through its authored tsdown configuration and is packed
normally. Build warnings about the experimental TypeScript API remain visible
in `/tmp/dsh-ast-v8-location-build.log`. The package is installed through pnpm
into the isolated Vitest candidate, with its normal lockfile updated; root
dependencies are unchanged. Installation output is retained in
`/tmp/dsh-vitest-mapping-converter-install.log`.

The complete native runner integrity file still reports nine passes and one
failure in `/tmp/dsh-vitest-executed-sources-mapping.log`. The loader's source
map explicitly assigns export getter helpers to the authored export keyword.
Removing the forward lookup does not resolve that false function attribution.
The exact two-function assertion remains unchanged and red. The current proof
is `/tmp/dsh-vitest-executed-source-deletion-proof.json`.

The full runner source compile retains its two removed Node transform-mode
errors in `/tmp/dsh-vitest-mapping-final-types.log`. Vite wrapper normalization,
subprocess artifact transport, complete build reconstruction, root integration,
and repository-wide coverage/mutation acceptance remain unfinished.

## Repository inventory

The fresh 2026-09-16T16:12:13.790Z scan reads 4,054 files and confirms the same
corpus SHA-256 as the preceding checkpoint. It finds 533 coverage directives,
110 lint directives, 1,445 catch clauses and 357 static catch-handler accesses.
The full inventory is `source-20260916161213790.json`; every remaining directive
is listed in `suppressions-outstanding.md`. This candidate removes none of
those 643 repository directives.
