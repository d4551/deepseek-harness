# Failures from the last complete run

The compiler fixture race and lint-corpus timeout have subsequent focused passing evidence. The full run has not been repeated after those fixes.

```text
 FAIL  |process-bound| packages/subprocess/subprocess-local/tests/spawn-env.spec.ts > environment hardening > starts an isolated process with exactly the supplied environment {}
 FAIL  |process-bound| packages/subprocess/subprocess-local/tests/spawn-env.spec.ts > environment hardening > starts an isolated process with exactly the supplied environment {"EXPLICIT":"kept","DSH_SESSION_ID":"intentional"}
 FAIL  |thread-safe| scripts/lint-scope-corpus.spec.ts > repository lint directory discovery > discovers every probe through the unchanged root configuration and exclusions
 FAIL  |thread-safe| scripts/suppression-justifications.spec.ts > live authored source > contains no diagnostic directives or catch clauses
 FAIL  |thread-safe| scripts/typescript7-unstable-api.spec.ts > mandated typescript 7 compiler API > keeps the 6.0 Strada compiler API out of every current tracked and untracked source file
 FAIL  |thread-safe| packages/experimental/webworker-runtime/tests/node/sandbox-stack.spec.ts > Worker Landlock through the production sandbox stack > allows workspace and temp writes while classifying an outside write as denied
 FAIL  |thread-safe| packages/experimental/webworker-runtime/tests/node/sandbox-stack.spec.ts > Worker Landlock through the production sandbox stack > keeps read-only confined and danger-full-access unwrapped
 FAIL  |thread-safe| packages/experimental/webworker-runtime/tests/node/sandbox-stack.spec.ts > Worker Landlock through the production sandbox stack > does not leak a concurrent command policy into another process
```

19,781 passed; 8 failed; 93 skipped. Each skipped case still needs platform and ownership reconciliation.
