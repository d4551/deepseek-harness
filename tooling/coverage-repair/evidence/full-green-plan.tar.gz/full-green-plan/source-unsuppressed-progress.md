# Complete source audit after directive repairs

Measured 2026-09-16T10:16:26.235Z; HEAD 057bf781eb6b458a08f3025fff6c8a8eb8c566e1; dirty worktree.

4008 files; 2254 findings. {"catch-clause":1447,"coverage-directive":675,"lint-directive":132}.

All findings remain violations. No grandfathering or narrowed discovery. Catch clauses are listed separately from directive suppressions.

| Location | Kind | Source |
| --- | --- | --- |
| apps/cli/src/args.ts:210 | catch-clause | catch (error) { |
| apps/cli/src/args.ts:213 | coverage-directive | v8 ignore next -- an action resolves or Commander throws |
| apps/cli/src/bin.ts:7 | coverage-directive | v8 ignore file -- built-bin acceptance exercises this self-executing dispatch. |
| apps/cli/src/dump-config.ts:21 | coverage-directive | v8 ignore start -- built-bin acceptance drives this boot-free dispatch |
| apps/cli/src/dump-config.ts:53 | coverage-directive | v8 ignore stop |
| apps/cli/src/plugin.ts:41 | catch-clause | catch { |
| apps/cli/src/process-shutdown.ts:34 | coverage-directive | v8 ignore else -- shutdown() arms the timer before any asynchronous exit path can run. |
| apps/cli/src/profile-boot.ts:297 | catch-clause | catch (error) { |
| apps/cli/tests/args.spec.ts:14 | catch-clause | catch { |
| apps/cli/tests/built-bin.e2e.ts:140 | catch-clause | catch { /* fresh dir */ } |
| apps/cli/tests/built-bin.e2e.ts:452 | catch-clause | catch { |
| apps/cli/tests/github-webhook-real.e2e.ts:232 | catch-clause | catch (error) { |
| apps/cli/tests/github-webhook-real.e2e.ts:292 | catch-clause | catch (error) { |
| apps/cli/tests/profiles/headless/tests/fixtures/team-llm.mjs:24 | catch-clause | catch { |
| apps/cli/tests/profiles/sdk/keyless-smoke.e2e.ts:32 | catch-clause | catch { |
| apps/cli/tests/web-auth.e2e.ts:201 | catch-clause | catch (error) { |
| apps/web/tests/assembled-boot.client.ts:118 | coverage-directive | v8 ignore next -- orderByModuleGraph returns the input row identities |
| apps/web/tests/chat-scroll-contract.e2e.ts:182 | catch-clause | catch (error) { |
| apps/web/tests/chat-scroll-contract.e2e.ts:216 | catch-clause | catch (error) { |
| apps/web/tests/chat-scroll-contract.e2e.ts:220 | catch-clause | catch { |
| apps/web/tests/chat-scroll-contract.e2e.ts:227 | catch-clause | catch (error) { |
| apps/web/tests/chat-scroll-contract.e2e.ts:453 | catch-clause | catch { |
| apps/web/tests/complex-history.perf.ts:715 | catch-clause | catch (error) { |
| apps/web/tests/complex-history.perf.ts:865 | catch-clause | catch (error) { |
| apps/web/tests/complex-history.perf.ts:870 | catch-clause | catch (cleanupError) { |
| apps/web/tests/complex-history.perf.ts:877 | catch-clause | catch (cleanupError) { |
| apps/web/tests/complex-history.perf.ts:884 | catch-clause | catch (cleanupError) { |
| apps/web/tests/complex-history.perf.ts:1416 | catch-clause | catch (error) { |
| apps/web/tests/complex-history.perf.ts:1422 | catch-clause | catch (cleanupError) { |
| apps/web/tests/hmr-live.e2e.ts:129 | catch-clause | catch (error) { |
| apps/web/tests/lifecycle-chrome.e2e.ts:151 | catch-clause | catch (error) { |
| apps/web/tests/minimal-preset.snapshot.ts:63 | catch-clause | catch (error: unknown) { |
| apps/web/tests/navigation-panes.e2e.ts:140 | catch-clause | catch (error) { |
| apps/web/tests/preview-boot.e2e.ts:193 | catch-clause | catch { |
| apps/web/tests/preview-boot.e2e.ts:419 | catch-clause | catch (error) { |
| apps/web/tests/preview-boot.e2e.ts:479 | catch-clause | catch (error) { |
| apps/web/tests/scaffold.ts:429 | catch-clause | catch (error) { |
| apps/web/tests/scaffold.ts:673 | catch-clause | catch { |
| apps/web/tests/scaffold.ts:720 | catch-clause | catch (error) { |
| apps/web/tests/scaffold.ts:777 | catch-clause | catch (error) { |
| apps/web/tests/scaffold.ts:788 | catch-clause | catch (error) { |
| apps/web/tests/sidebar-scrollbar.e2e.ts:79 | catch-clause | catch { |
| apps/web/tests/smoke-real.e2e.ts:162 | catch-clause | catch (error) { |
| apps/web/tests/support.ts:200 | catch-clause | catch { |
| native/landlock-run/packages/entry/src/index.ts:75 | catch-clause | catch { |
| native/landlock-run/scripts/repo.mjs:67 | catch-clause | catch { |
| native/landlock-run/scripts/verify-launcher-binary.mjs:27 | catch-clause | catch (error) { |
| packages/acp/acp/src/codec.ts:32 | coverage-directive | v8 ignore next 2 -- TurnEndReason is closed and every member is handled above |
| packages/acp/acp/src/content.ts:73 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/content.ts:101 | catch-clause | catch { |
| packages/acp/acp/src/content.ts:144 | coverage-directive | v8 ignore next 2 -- ACP ContentBlock is a closed generated union. |
| packages/acp/acp/src/content.ts:158 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/content.ts:189 | coverage-directive | v8 ignore start -- the validation pass above rejects both tags before reconstruction. |
| packages/acp/acp/src/content.ts:193 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/content.ts:194 | coverage-directive | v8 ignore next 2 -- validated by the first closed-union switch. |
| packages/acp/acp/src/content.ts:229 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:128 | coverage-directive | v8 ignore start -- the ACP SDK contains notification-handler failures; only a transport write failure reaches this guard. |
| packages/acp/acp/src/index.ts:129 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:132 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/index.ts:215 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:219 | coverage-directive | v8 ignore next 4 -- a real stdio close can race an in-flight create. |
| packages/acp/acp/src/index.ts:232 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:266 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:270 | coverage-directive | v8 ignore start -- the persisted header was checked before resume; the factory restores that exact header. |
| packages/acp/acp/src/index.ts:275 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/index.ts:276 | coverage-directive | v8 ignore next 4 -- a real stdio close can race an in-flight resume. |
| packages/acp/acp/src/index.ts:287 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:303 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:344 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:356 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/index.ts:376 | coverage-directive | v8 ignore next 4 -- production stdio wiring; tests inject config.stream. |
| packages/acp/acp/src/index.ts:407 | coverage-directive | v8 ignore next -- closed blocks concurrent handlers; each captured record remains mapped until this loop. |
| packages/acp/acp/src/index.ts:428 | coverage-directive | v8 ignore start -- production transport rejection and teardown failure. |
| packages/acp/acp/src/index.ts:437 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/index.ts:469 | coverage-directive | v8 ignore start -- Cordis applies the positive-integer Config schema; this protects direct apply callers. |
| packages/acp/acp/src/index.ts:473 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/index.ts:497 | catch-clause | catch (_invalidCursor) { |
| packages/acp/acp/src/index.ts:542 | catch-clause | catch (_unresolvablePath) { |
| packages/acp/acp/src/mcp.ts:91 | catch-clause | catch (_invalidHeader) { |
| packages/acp/acp/src/mcp.ts:129 | catch-clause | catch (_invalidUrl) { |
| packages/acp/acp/src/mcp.ts:138 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/mcp.ts:139 | coverage-directive | v8 ignore next -- Schemastery validation rejects with Error instances. |
| packages/acp/acp/src/model-control.ts:152 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/model-control.ts:174 | catch-clause | catch (_providerCatalogUnavailable) { |
| packages/acp/acp/src/session.ts:161 | coverage-directive | v8 ignore next -- Agent factory setup always carries its unpublished Agent. |
| packages/acp/acp/src/session.ts:171 | coverage-directive | v8 ignore start -- a fulfilled Agent resume necessarily ran setup to completion. |
| packages/acp/acp/src/session.ts:176 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/session.ts:243 | coverage-directive | v8 ignore start -- the bridge notifier contains transport failure. |
| packages/acp/acp/src/session.ts:247 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/session.ts:249 | coverage-directive | v8 ignore start -- option discovery contains per-provider failure. |
| packages/acp/acp/src/session.ts:253 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/session.ts:291 | coverage-directive | v8 ignore next -- the SDK dispatches a live signal, then notifies abort through its listener. |
| packages/acp/acp/src/session.ts:320 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/session.ts:325 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/session.ts:384 | coverage-directive | v8 ignore start -- the bridge notifier contains transport rejection. |
| packages/acp/acp/src/session.ts:388 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/session.ts:396 | coverage-directive | v8 ignore start -- supplemental-content conversion failure is contained and cannot fail Agent work. |
| packages/acp/acp/src/session.ts:400 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/session.ts:459 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/session.ts:465 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/session.ts:471 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/session.ts:476 | catch-clause | catch (error: unknown) { |
| packages/acp/acp/src/session.ts:481 | coverage-directive | v8 ignore start -- independent teardown failures can aggregate only under multiple simultaneous provider faults. |
| packages/acp/acp/src/session.ts:485 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/session.ts:512 | coverage-directive | v8 ignore next -- this prompt owns the slot until this exact settlement clears it. |
| packages/acp/acp/src/session.ts:536 | coverage-directive | v8 ignore start -- admissionDone only resolves; idle/output gates contain their own failures. |
| packages/acp/acp/src/session.ts:542 | coverage-directive | v8 ignore stop |
| packages/acp/acp/src/updates.ts:108 | catch-clause | catch (_invalidModelJson) { |
| packages/api/gateway/src/client/index.ts:224 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/index.ts:303 | coverage-directive | v8 ignore next -- Cordis effect disposers are idempotent and invoke this cleanup at most once. |
| packages/api/gateway/src/client/index.ts:335 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/index.ts:339 | coverage-directive | v8 ignore next 3 -- a settled namespace fiber synchronously constructs its Service and installs the group. |
| packages/api/gateway/src/client/index.ts:415 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/index.ts:569 | coverage-directive | v8 ignore next -- duplicate live variants are rejected before installation, so no newer token can replace this one. |
| packages/api/gateway/src/client/index.ts:610 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/index.ts:686 | catch-clause | catch (cause) { |
| packages/api/gateway/src/client/index.ts:714 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/journal-stream.ts:160 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/journal-stream.ts:235 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/journal-stream.ts:356 | coverage-directive | v8 ignore next -- a successful positive-cursor replacement page cannot be empty. |
| packages/api/gateway/src/client/remote-events.ts:157 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/remote-events.ts:183 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/remote-events.ts:190 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/remote-stream.ts:128 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/remote-stream.ts:137 | catch-clause | catch (retryError) { |
| packages/api/gateway/src/client/remote-stream.ts:207 | catch-clause | catch { |
| packages/api/gateway/src/client/snapshot-stream.ts:84 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/stream-client.ts:209 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors |
| packages/api/gateway/src/client/stream-client.ts:224 | catch-clause | catch (error) { |
| packages/api/gateway/src/client/stream-client.ts:243 | catch-clause | catch (error) { |
| packages/api/gateway/src/index.ts:314 | catch-clause | catch (error) { |
| packages/api/gateway/src/index.ts:337 | catch-clause | catch (error) { |
| packages/api/gateway/src/index.ts:370 | catch-clause | catch (error) { |
| packages/api/gateway/src/index.ts:489 | catch-clause | catch { |
| packages/api/gateway/src/index.ts:520 | catch-clause | catch (error) { |
| packages/api/gateway/src/index.ts:601 | catch-clause | catch (error) { |
| packages/api/gateway/src/index.ts:799 | catch-clause | catch (cause) { |
| packages/api/gateway/src/index.ts:832 | coverage-directive | v8 ignore next -- registry validation rejects strict descriptors without a key, and SRC derivation always supplies one. |
| packages/api/gateway/src/index.ts:862 | catch-clause | catch (cause) { |
| packages/api/gateway/src/index.ts:1098 | coverage-directive | v8 ignore next -- standard public class-method syntax always contains a parenthesized parameter list. |
| packages/api/gateway/src/index.ts:1156 | coverage-directive | v8 ignore next -- generated optional-input codecs are the only strict codecs that return undefined. |
| packages/api/gateway/src/index.ts:1161 | catch-clause | catch (cause) { |
| packages/api/gateway/src/index.ts:1195 | coverage-directive | v8 ignore next -- ownKeys() just returned this key; only a hostile same-process Proxy can delete it between operations. |
| packages/api/gateway/src/stream-protocol.ts:319 | catch-clause | catch (cause) { |
| packages/api/gateway/src/stream-server.ts:108 | catch-clause | catch { |
| packages/api/gateway/src/stream-server.ts:152 | catch-clause | catch (error) { |
| packages/api/gateway/src/stream-server.ts:156 | catch-clause | catch { |
| packages/api/gateway/src/stream-server.ts:169 | catch-clause | catch (cause) { |
| packages/api/gateway/tests/gateway.host.spec.ts:1470 | catch-clause | catch (error) { |
| packages/api/remotes/src/client/index.ts:167 | catch-clause | catch (error) { |
| packages/api/session-controller/src/agent.ts:128 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/agent.ts:199 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/agent.ts:407 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/agent.ts:469 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/agent.ts:477 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/catalog.ts:54 | catch-clause | catch (error) { |
| packages/api/session-controller/src/client/ordered-baseline.ts:26 | coverage-directive | v8 ignore next -- dense-array guard: index is bounded by baseline.length. |
| packages/api/session-controller/src/client/ordered-baseline.ts:31 | coverage-directive | v8 ignore next -- dense-array guard: following is bounded by baseline.length. |
| packages/api/session-controller/src/client/sessions/service.ts:516 | coverage-directive | v8 ignore next 3 -- defensive: current is always a listed id (open() |
| packages/api/session-controller/src/client/sessions/service.ts:699 | coverage-directive | v8 ignore next -- defensive: only the staged id ever defers, and every |
| packages/api/session-controller/src/client/sessions/service.ts:710 | coverage-directive | v8 ignore next -- defensive: prune deletes a scope and its deferral |
| packages/api/session-controller/src/client/sessions/session.ts:270 | catch-clause | catch (error) { |
| packages/api/session-controller/src/client/sessions/session.ts:312 | catch-clause | catch (error) { |
| packages/api/session-controller/src/client/sessions/session.ts:321 | catch-clause | catch (error) { |
| packages/api/session-controller/src/client/sessions/session.ts:359 | catch-clause | catch (error) { |
| packages/api/session-controller/src/client/sessions/session.ts:383 | catch-clause | catch (error) { |
| packages/api/session-controller/src/client/sessions/session.ts:422 | catch-clause | catch (error) { |
| packages/api/session-controller/src/client/sessions/session.ts:601 | catch-clause | catch (error) { |
| packages/api/session-controller/src/client/sessions/session.ts:706 | coverage-directive | v8 ignore next -- retiring latches before every schedule, so one settlement never finishes twice. |
| packages/api/session-controller/src/client/sessions/session.ts:783 | coverage-directive | v8 ignore next -- transportResult never returns an ok result. |
| packages/api/session-controller/src/commands.ts:107 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:113 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:152 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:158 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:212 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:237 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:274 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:299 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:309 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:368 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:389 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:413 | catch-clause | catch (error) { |
| packages/api/session-controller/src/commands.ts:632 | catch-clause | catch { |
| packages/api/session-controller/src/history.ts:64 | coverage-directive | v8 ignore next -- Session and persistence validation guarantee a dense zero-based event prefix. |
| packages/api/session-controller/src/history.ts:144 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/history.ts:188 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/history.ts:193 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/index.ts:307 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/list.ts:198 | catch-clause | catch { |
| packages/api/session-controller/src/list.ts:211 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/list.ts:270 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/list.ts:319 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/list.ts:344 | catch-clause | catch (error) { |
| packages/api/session-controller/src/skill-catalog.ts:53 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/skill-catalog.ts:93 | catch-clause | catch (error: unknown) { |
| packages/api/session-controller/src/skill-catalog.ts:109 | catch-clause | catch { |
| packages/api/session-controller/tests/test-remote.ts:135 | catch-clause | catch (error: unknown) { |
| packages/api/settings-controller/src/credentials.ts:147 | catch-clause | catch (error: unknown) { |
| packages/api/settings-controller/src/index.ts:208 | catch-clause | catch (error: unknown) { |
| packages/api/settings-controller/src/index.ts:219 | catch-clause | catch (error: unknown) { |
| packages/api/settings-controller/src/index.ts:257 | catch-clause | catch (error: unknown) { |
| packages/api/settings-controller/src/index.ts:264 | catch-clause | catch (error: unknown) { |
| packages/api/settings-controller/src/index.ts:290 | catch-clause | catch (error: unknown) { |
| packages/api/settings-controller/src/index.ts:297 | catch-clause | catch (error: unknown) { |
| packages/api/workspace-controller/src/client/index.ts:116 | coverage-directive | v8 ignore next -- the generated Remote codec validates this closed union |
| packages/api/workspace-controller/src/client/index.ts:122 | coverage-directive | v8 ignore next 3 -- closed-union backstop after generated Remote validation |
| packages/api/workspace-controller/src/client/model.ts:88 | catch-clause | catch (error) { |
| packages/api/workspace-controller/src/client/model.ts:138 | catch-clause | catch (error) { |
| packages/api/workspace-controller/src/commands.ts:48 | catch-clause | catch (error) { |
| packages/api/workspace-controller/src/commands.ts:118 | catch-clause | catch (error) { |
| packages/api/workspace-controller/src/commands.ts:133 | catch-clause | catch (error) { |
| packages/api/workspace-controller/src/commands.ts:158 | catch-clause | catch (error) { |
| packages/api/workspace-controller/src/directory-picker.ts:57 | catch-clause | catch (error: unknown) { |
| packages/api/workspace-controller/src/directory-picker.ts:74 | catch-clause | catch (error: unknown) { |
| packages/api/workspace-controller/src/directory-picker.ts:98 | catch-clause | catch (error: unknown) { |
| packages/api/workspace-controller/src/feed.ts:147 | coverage-directive | v8 ignore next -- closed followers are removed before later publication can reach them. |
| packages/api/workspace-controller/src/feed.ts:174 | coverage-directive | v8 ignore next -- one read owns the sole installed wait callback. |
| packages/api/workspace-controller/src/feed.ts:180 | coverage-directive | v8 ignore next -- native signals and the private queue cannot change during this synchronous setup. |
| packages/api/workspace-controller/tests/directory-picker.host.spec.ts:63 | catch-clause | catch (error: unknown) { |
| packages/api/workspace-controller/tests/transport.client.spec.ts:191 | catch-clause | catch { |
| packages/attachment/attachment-local/src/image.ts:94 | catch-clause | catch (error) { |
| packages/attachment/attachment-local/src/image.ts:126 | catch-clause | catch (error) { |
| packages/attachment/attachment-local/src/normalization.ts:119 | catch-clause | catch (error) { |
| packages/attachment/attachment-local/src/request-image.ts:134 | catch-clause | catch (error: unknown) { |
| packages/attachment/attachment-local/src/store.ts:161 | coverage-directive | v8 ignore next 4 -- native Windows coverage takes this arm; POSIX coverage takes the peer below. |
| packages/attachment/attachment-local/src/store.ts:166 | coverage-directive | v8 ignore start -- Windows takes the arm above; POSIX behavior tests enforce this peer. |
| packages/attachment/attachment-local/src/store.ts:174 | coverage-directive | v8 ignore next -- filesystem-root guard: callers pass a boundary that is an ancestor of path, so the walk reaches it first. |
| packages/attachment/attachment-local/src/store.ts:178 | coverage-directive | v8 ignore stop |
| packages/attachment/attachment-local/src/store.ts:194 | coverage-directive | v8 ignore next -- native Windows coverage takes this arm; POSIX coverage takes the peer. |
| packages/attachment/attachment-local/src/store.ts:200 | coverage-directive | v8 ignore next -- native Windows coverage skips this unlink; POSIX coverage takes it. |
| packages/attachment/attachment-local/src/store.ts:203 | catch-clause | catch (error) { |
| packages/attachment/attachment-local/src/store.ts:204 | coverage-directive | v8 ignore next -- Private same-filesystem directories make EEXIST the only recoverable publication race. |
| packages/attachment/attachment-local/src/store.ts:269 | coverage-directive | v8 ignore next 4 -- native Windows coverage skips these syncs; POSIX coverage takes them. |
| packages/attachment/attachment-local/src/store.ts:274 | catch-clause | catch (error) { |
| packages/attachment/attachment-local/src/store.ts:275 | coverage-directive | v8 ignore next -- A descriptor can remain open only when the underlying write/sync/close operation fails. |
| packages/attachment/attachment-local/src/store.ts:277 | coverage-directive | v8 ignore next -- Close failure is superseded by the storage operation that entered cleanup. |
| packages/attachment/attachment-local/src/store.ts:281 | coverage-directive | v8 ignore next -- The callback requires a second independent staging-unlink failure. |
| packages/attachment/attachment-local/src/store.ts:283 | coverage-directive | v8 ignore next -- Cleanup is best-effort only for a staging file already removed by a failed operation. |
| packages/attachment/attachment-local/src/store.ts:328 | catch-clause | catch (error) { |
| packages/attachment/attachment-local/tests/encoding.spec.ts:86 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- Native bindings can reject non-Error values. |
| packages/boot/app-boot/src/index.ts:91 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:153 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:293 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:326 | catch-clause | catch (rejection) { |
| packages/boot/app-boot/src/index.ts:344 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:365 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:401 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:438 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:500 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:506 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:538 | coverage-directive | v8 ignore next -- count iterates 1..length, so the slot exists |
| packages/boot/app-boot/src/index.ts:572 | coverage-directive | v8 ignore next -- this array is index-aligned with composed by construction |
| packages/boot/app-boot/src/index.ts:611 | coverage-directive | v8 ignore next -- Node supplies the internal loader; this preserves the |
| packages/boot/app-boot/src/index.ts:806 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/index.ts:888 | catch-clause | catch (cause) { |
| packages/boot/app-boot/src/profile.ts:303 | catch-clause | catch { |
| packages/boot/app-boot/src/profile.ts:314 | catch-clause | catch { |
| packages/boot/app-boot/src/profile.ts:337 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:342 | coverage-directive | v8 ignore next 4 |
| packages/boot/app-boot/src/profile.ts:354 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:356 | coverage-directive | v8 ignore next 2 -- a non-ENOENT realpath failure requires a host filesystem fault |
| packages/boot/app-boot/src/profile.ts:358 | coverage-directive | v8 ignore next -- see the host-filesystem exception above |
| packages/boot/app-boot/src/profile.ts:376 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:377 | coverage-directive | v8 ignore next -- a non-ENOENT lstat failure requires a host filesystem fault |
| packages/boot/app-boot/src/profile.ts:401 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:402 | coverage-directive | v8 ignore next -- a non-ENOENT lstat failure requires a host filesystem fault |
| packages/boot/app-boot/src/profile.ts:407 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:408 | coverage-directive | v8 ignore next -- concurrent identical cleanup may remove the link first |
| packages/boot/app-boot/src/profile.ts:442 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:482 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:535 | catch-clause | catch { |
| packages/boot/app-boot/src/profile.ts:603 | coverage-directive | v8 ignore next -- a real app manifest always declares its name |
| packages/boot/app-boot/src/profile.ts:614 | coverage-directive | v8 ignore next -- a real app manifest always declares dependencies |
| packages/boot/app-boot/src/profile.ts:661 | catch-clause | catch { |
| packages/boot/app-boot/src/profile.ts:731 | coverage-directive | v8 ignore next -- an installable package manifest always declares its name |
| packages/boot/app-boot/src/profile.ts:740 | coverage-directive | v8 ignore next -- an installable package manifest always declares dependencies or peers |
| packages/boot/app-boot/src/profile.ts:771 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:773 | coverage-directive | v8 ignore next 2 -- a non-ENOENT lstat failure requires a host filesystem fault |
| packages/boot/app-boot/src/profile.ts:775 | coverage-directive | v8 ignore next -- see the host-filesystem exception above |
| packages/boot/app-boot/src/profile.ts:804 | catch-clause | catch (error) { |
| packages/boot/app-boot/src/profile.ts:872 | coverage-directive | v8 ignore next |
| packages/boot/app-boot/tests/app-boot.spec.ts:786 | catch-clause | catch (error) { |
| packages/boot/app-boot/tests/config-reload.spec.ts:53 | catch-clause | catch (error) { |
| packages/boot/app-boot/tests/hmr-config.spec.ts:89 | catch-clause | catch (error) { |
| packages/boot/app-boot/tests/hmr-config.spec.ts:154 | catch-clause | catch (error) { |
| packages/boot/app-boot/tests/profile.spec.ts:254 | catch-clause | catch { |
| packages/boot/cmdline/src/index.ts:179 | catch-clause | catch (error) { |
| packages/bundle/headless/src/index.ts:139 | coverage-directive | v8 ignore next -- closed-union exhaustiveness guard |
| packages/bundle/web-app/src/index.ts:176 | catch-clause | catch { |
| packages/bundle/web-app/src/index.ts:177 | coverage-directive | v8 ignore next 2 -- reachable only when the frontend package is absent from the checkout |
| packages/client/connection/src/api-request-trust.ts:30 | catch-clause | catch { |
| packages/client/connection/src/api-request-trust.ts:115 | catch-clause | catch { |
| packages/client/connection/src/browser-auth.ts:75 | catch-clause | catch { |
| packages/client/connection/src/browser-auth.ts:150 | catch-clause | catch { |
| packages/client/connection/src/browser-auth.ts:241 | coverage-directive | v8 ignore next -- node:http always supplies url on server requests. |
| packages/client/connection/src/client/connection.ts:208 | catch-clause | catch { |
| packages/client/connection/src/client/connection.ts:233 | catch-clause | catch (error) { |
| packages/client/connection/src/client/fixture.ts:1382 | coverage-directive | v8 ignore next -- the advancing title event is in the log, so the key is present. |
| packages/client/connection/src/client/fixture.ts:1440 | coverage-directive | v8 ignore next -- dense-array guard: log seqs are array indexes, i stays within [0, end). |
| packages/client/connection/src/client/fixture.ts:2734 | coverage-directive | v8 ignore next -- the ?? arm needs a null match, but every fixture reply is non-empty. |
| packages/client/connection/src/client/fixture.ts:2823 | coverage-directive | v8 ignore next -- callers enter only when a target Workspace exists. |
| packages/client/connection/src/client/fixture.ts:3199 | coverage-directive | v8 ignore next -- the fixture never removes fx-gamma. |
| packages/client/connection/src/client/fixture.ts:3234 | coverage-directive | v8 ignore next -- existence was checked before the stream registered. |
| packages/client/connection/src/client/fixture.ts:3378 | coverage-directive | v8 ignore next -- source was resolved from the same array immediately above. |
| packages/client/connection/src/client/index.ts:164 | catch-clause | catch (error) { |
| packages/client/connection/src/http-bridge.ts:67 | coverage-directive | v8 ignore next 3 -- `??` arms: node:http always sets url/method on server |
| packages/client/connection/src/rpc-host.ts:222 | catch-clause | catch { |
| packages/client/connection/src/rpc-host.ts:242 | catch-clause | catch (error) { |
| packages/client/connection/tests/connection.client.spec.ts:149 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- the non-Error rejection is the scenario under test |
| packages/client/hmr/src/client/index.ts:171 | catch-clause | catch { |
| packages/client/hmr/src/index.ts:80 | catch-clause | catch (error) { |
| packages/client/hmr/src/index.ts:99 | catch-clause | catch (error) { |
| packages/client/hmr/src/index.ts:114 | catch-clause | catch (error) { |
| packages/client/hmr/src/invariant.ts:35 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises |
| packages/client/locale/src/client/index.ts:270 | catch-clause | catch (error) { |
| packages/client/locale/src/client/index.ts:325 | coverage-directive | v8 ignore next -- English is the only built-in terminal and every |
| packages/client/locale/src/client/index.ts:407 | coverage-directive | v8 ignore next -- defensive: a namespace's locales map is created on |
| packages/client/locale/src/client/index.ts:489 | catch-clause | catch (error) { |
| packages/client/modules/src/client/system.ts:177 | coverage-directive | v8 ignore next -- callers check the factory branch before dispatching here. |
| packages/client/modules/src/index.ts:323 | catch-clause | catch (error) { |
| packages/client/modules/src/index.ts:353 | coverage-directive | v8 ignore next -- callers add sections only for records with a source map. |
| packages/client/modules/src/index.ts:649 | catch-clause | catch (error) { |
| packages/client/modules/src/index.ts:732 | catch-clause | catch (error) { |
| packages/client/modules/src/index.ts:804 | catch-clause | catch { |
| packages/client/modules/src/index.ts:815 | catch-clause | catch { |
| packages/client/modules/src/index.ts:837 | catch-clause | catch { |
| packages/client/modules/src/index.ts:885 | catch-clause | catch (error) { |
| packages/client/modules/src/index.ts:895 | catch-clause | catch (error) { |
| packages/client/modules/src/index.ts:924 | catch-clause | catch (error) { |
| packages/client/modules/src/index.ts:980 | catch-clause | catch (error) { |
| packages/client/modules/src/index.ts:990 | catch-clause | catch (error) { |
| packages/client/modules/src/index.ts:1008 | coverage-directive | v8 ignore next -- `?? '/'` arm: node:http always sets url on server requests. |
| packages/client/modules/tests/node-half.client.spec.ts:447 | catch-clause | catch (error) { |
| packages/client/store/src/contract.ts:36 | lint-directive | oxlint-disable-next-line typescript/no-explicit-any -- |
| packages/client/store/src/contract.ts:110 | lint-directive | oxlint-disable-next-line typescript/no-explicit-any -- |
| packages/client/store/src/contract.ts:117 | lint-directive | oxlint-disable-next-line typescript/no-explicit-any -- same erased-constraint position as StoreFactory (see above). |
| packages/client/store/src/index.ts:54 | catch-clause | catch (error) { |
| packages/client/store/src/index.ts:156 | catch-clause | catch (error) { |
| packages/client/store/src/index.ts:162 | catch-clause | catch (error) { |
| packages/client/store/src/index.ts:252 | catch-clause | catch { |
| packages/client/ui-agent-preset/src/client/section-store.ts:212 | catch-clause | catch (error) { |
| packages/client/ui-agent-preset/src/client/section-store.ts:284 | catch-clause | catch (error) { |
| packages/client/ui-agent-preset/src/client/section-store.ts:306 | catch-clause | catch (error) { |
| packages/client/ui-agent-preset/src/client/section-store.ts:340 | catch-clause | catch (error) { |
| packages/client/ui-agent-preset/src/client/settings-store.ts:50 | catch-clause | catch (error) { |
| packages/client/ui-agent-preset/src/client/settings-store.ts:97 | catch-clause | catch (error) { |
| packages/client/ui-agent-preset/tests/section-store.client.spec.ts:87 | coverage-directive | v8 ignore next -- every test reads an id the fake store holds |
| packages/client/ui-agent-preset/tests/section-store.client.spec.ts:108 | coverage-directive | v8 ignore next -- every test copies a source the fake store holds |
| packages/client/ui-agent-preset/tests/section-store.client.spec.ts:135 | coverage-directive | v8 ignore next -- the controller only ever sets `default` |
| packages/client/ui-approval/tests/ui-approval.client.spec.tsx:75 | catch-clause | catch (error) { |
| packages/client/ui-attachment/src/AttachmentRail.tsx:43 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/client/ui-attachment/src/AttachmentRail.tsx:81 | coverage-directive | v8 ignore next -- defensive: every caller runs while the rail element is mounted. |
| packages/client/ui-attachment/src/AttachmentRail.tsx:92 | coverage-directive | v8 ignore next -- defensive: the rail div renders unconditionally, so the layout effect always finds it. |
| packages/client/ui-attachment/src/AttachmentRail.tsx:100 | coverage-directive | v8 ignore next -- defensive: the rail div renders unconditionally, so the mount effect always finds it. |
| packages/client/ui-attachment/src/AttachmentRail.tsx:142 | coverage-directive | v8 ignore next -- defensive: the arrows render only while the rail is mounted, so a click cannot find a null ref. |
| packages/client/ui-chat/src/client/chat/ApprovalCommand.tsx:21 | catch-clause | catch { |
| packages/client/ui-chat/src/client/chat/ChatView.tsx:386 | coverage-directive | v8 ignore next -- ref-null guard: React attaches the ref before layout effects run. |
| packages/client/ui-chat/src/client/chat/ChatView.tsx:426 | coverage-directive | v8 ignore next -- ?? arm: a prepend adds nodes, so the flow list here is never empty. |
| packages/client/ui-chat/src/client/chat/ChatView.tsx:452 | coverage-directive | v8 ignore next -- ref-null guard: the handler only fires while mounted. |
| packages/client/ui-chat/src/client/chat/ChatView.tsx:492 | coverage-directive | v8 ignore next -- ref-null guard: effect runs after the list node commits. |
| packages/client/ui-chat/src/client/chat/ChatView.tsx:542 | coverage-directive | v8 ignore next -- ref-null guard: the paging button renders inside the list tree. |
| packages/client/ui-chat/src/client/chat/ChatView.tsx:654 | coverage-directive | v8 ignore next -- ref-null guard: the button only renders alongside the mounted list. |
| packages/client/ui-chat/src/client/chat/ContextBody.tsx:394 | coverage-directive | v8 ignore next -- contextBody reads the sections before choosing this body. |
| packages/client/ui-chat/src/client/chat/ContextBody.tsx:443 | coverage-directive | v8 ignore next -- contextBody resolves the sender before choosing this body. |
| packages/client/ui-chat/src/client/chat/ContextBody.tsx:585 | coverage-directive | v8 ignore next 4 -- closed-union backstop; the compiler rejects a new |
| packages/client/ui-chat/src/client/details/DetailsPanel.tsx:36 | catch-clause | catch { |
| packages/client/ui-commands/src/client/popup.ts:261 | catch-clause | catch (error) { |
| packages/client/ui-commands/src/client/service.ts:433 | catch-clause | catch (error) { |
| packages/client/ui-commands/tests/service.client.spec.ts:55 | catch-clause | catch (error) { |
| packages/client/ui-conversation/src/client/apply.ts:123 | coverage-directive | v8 ignore next -- list registration validates id at load. |
| packages/client/ui-conversation/src/client/apply.ts:281 | catch-clause | catch (error: unknown) { |
| packages/client/ui-conversation/src/client/contract/conversation.ts:4 | lint-directive | oxlint-disable typescript/no-duplicate-type-constituents, typescript/no-redundant-type-constituents -- |
| packages/client/ui-conversation/src/client/input/editor/projection.ts:90 | coverage-directive | v8 ignore next 4 -- plain-text composition nests no block elements today; the walk stays total for imported states. |
| packages/client/ui-conversation/src/client/input/editor/span-map.ts:49 | coverage-directive | v8 ignore next -- non-gap segments always carry their node. |
| packages/client/ui-conversation/src/client/input/editor/span-map.ts:52 | coverage-directive | v8 ignore next -- a walked leaf always has a parent element. |
| packages/client/ui-conversation/src/client/input/editor/span-map.ts:73 | coverage-directive | v8 ignore next -- bounds were checked above; resolvePoint only fails out of bounds. |
| packages/client/ui-conversation/src/client/queue/QueueDock.tsx:56 | catch-clause | catch { |
| packages/client/ui-conversation/src/client/service.ts:238 | catch-clause | catch (error) { |
| packages/client/ui-conversation/src/client/skeleton/ConversationRoot.tsx:215 | coverage-directive | v8 ignore next -- handles render inside the root, so the ref is always attached. |
| packages/client/ui-conversation/src/client/skeleton/ConversationRoot.tsx:221 | coverage-directive | v8 ignore next -- handles render inside the root, so the ref is always attached. |
| packages/client/ui-conversation/src/client/skeleton/ConversationRoot.tsx:228 | coverage-directive | v8 ignore next -- handles render inside the root, so the ref is always attached. |
| packages/client/ui-conversation/src/client/skeleton/editor/keymap.ts:44 | lint-directive | oxlint-disable-next-line typescript/no-deprecated |
| packages/client/ui-conversation/src/client/skeleton/InputBar.tsx:322 | coverage-directive | v8 ignore next -- defensive: the primary button is disabled while empty\|\|disabled, so a click cannot reach the false arm. |
| packages/client/ui-conversation/src/client/skeleton/TodoPanel.tsx:21 | coverage-directive | v8 ignore next 3 -- closed-union backstop; only reached if status is forged |
| packages/client/ui-conversation/src/client/skeleton/TodoPanel.tsx:69 | coverage-directive | v8 ignore next -- closed TodoItem status union |
| packages/client/ui-deliverables/src/client/ProducedFiles.tsx:83 | coverage-directive | v8 ignore next -- React attaches both refs before the layout effect runs. |
| packages/client/ui-deliverables/src/client/turn-deliverables.ts:45 | catch-clause | catch { |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:436 | coverage-directive | v8 ignore next -- narrowing: a two-deep display chain implies a parent crumb (root-to-target inclusive). |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:555 | coverage-directive | v8 ignore next -- narrowing guard: the right column only renders with a child listing. |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:596 | coverage-directive | v8 ignore next -- reentry fence: the nested dialog only renders with a target and disables while creating. |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:621 | coverage-directive | v8 ignore next -- same fence as navigate/select; the modal blocks superseding input |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:627 | coverage-directive | v8 ignore next -- same fence as navigate/select; the modal blocks superseding input |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:719 | coverage-directive | v8 ignore next -- narrowing guard: the miller row is mounted whenever a pick just committed. |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:722 | coverage-directive | v8 ignore next -- narrowing guard: the pick that set the flag just rendered its aria-current row. |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:733 | coverage-directive | v8 ignore next -- narrowing guard: crumb mode renders the edit zone whenever the editor just closed. |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:796 | coverage-directive | v8 ignore next -- narrowing guard: this scope always renders inside the Modal card. |
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx:987 | coverage-directive | v8 ignore next -- narrowing guard: Open disables while no target exists. |
| packages/client/ui-input-trigger/src/client/controller.ts:421 | catch-clause | catch (error) { |
| packages/client/ui-input-trigger/src/client/controller.ts:538 | catch-clause | catch (error) { |
| packages/client/ui-input-trigger/src/client/service.ts:58 | catch-clause | catch (error) { |
| packages/client/ui-jobs/src/client/JobListAction.tsx:22 | coverage-directive | v8 ignore next 3 -- closed-union backstop; only reached if a status is forged |
| packages/client/ui-jobs/src/client/JobListAction.tsx:38 | coverage-directive | v8 ignore next -- closed wire status union |
| packages/client/ui-jobs/src/client/JobListAction.tsx:51 | coverage-directive | v8 ignore next -- closed wire status union |
| packages/client/ui-message-feedback/src/client/controller.ts:307 | catch-clause | catch (error) { |
| packages/client/ui-message-feedback/src/client/controller.ts:331 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- dispose() can run during the await. |
| packages/client/ui-message-feedback/src/client/controller.ts:336 | catch-clause | catch (error) { |
| packages/client/ui-message-feedback/src/client/controller.ts:373 | catch-clause | catch (error) { |
| packages/client/ui-message-feedback/tests/controller.client.spec.ts:348 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- the non-Error rejection is the scenario under test. |
| packages/client/ui-message-feedback/tests/controller.client.spec.ts:359 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- the non-Error rejection is the scenario under test. |
| packages/client/ui-permission-presets/src/client/settings-store.ts:148 | catch-clause | catch (error) { |
| packages/client/ui-permission-presets/src/client/settings-store.ts:203 | catch-clause | catch (error) { |
| packages/client/ui-primitives/src/clipboard.ts:14 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/client/ui-primitives/src/clipboard.ts:19 | catch-clause | catch { |
| packages/client/ui-primitives/src/clipboard.ts:27 | lint-directive | oxlint-disable typescript/no-deprecated |
| packages/client/ui-primitives/src/clipboard.ts:41 | catch-clause | catch { |
| packages/client/ui-primitives/src/DiffBlock.tsx:52 | coverage-directive | v8 ignore next 3 -- closed-union backstop; only reached if a row kind is forged |
| packages/client/ui-primitives/src/DiffBlock.tsx:129 | coverage-directive | v8 ignore next -- closed-union backstop; only reached if a row kind is forged |
| packages/client/ui-primitives/src/HoverCard.tsx:101 | coverage-directive | v8 ignore next -- the ref is attached before the layout effect runs and the listeners die with it. |
| packages/client/ui-primitives/src/HoverCard.tsx:122 | coverage-directive | v8 ignore next -- the card is mounted whenever pos is set, so the ref is attached here. |
| packages/client/ui-primitives/src/JsonTree.tsx:196 | coverage-directive | v8 ignore next -- JsonTree attaches expander handlers only beneath its owning role=tree. |
| packages/client/ui-primitives/src/JsonTree.tsx:200 | coverage-directive | v8 ignore next -- the current expander is a member of the queried non-empty set. |
| packages/client/ui-primitives/src/JsonTree.tsx:204 | coverage-directive | v8 ignore next -- modulo over the non-empty expander set always resolves a member. |
| packages/client/ui-primitives/src/JsonTree.tsx:438 | coverage-directive | v8 ignore next -- row events and viewport listeners run only after the root ref mounts. |
| packages/client/ui-primitives/src/JsonTree.tsx:457 | coverage-directive | v8 ignore next -- an active row and its copy target are installed together. |
| packages/client/ui-primitives/src/JsonTree.tsx:503 | coverage-directive | v8 ignore next -- browser mouse events delivered through React target an Element. |
| packages/client/ui-primitives/src/JsonTree.tsx:514 | coverage-directive | v8 ignore next -- copy controls only render while their target exists. |
| packages/client/ui-primitives/src/JsonTree.tsx:519 | catch-clause | catch { |
| packages/client/ui-primitives/src/markdown/cjkFriendlyStrong.ts:34 | coverage-directive | v8 ignore next -- this text construct is dispatched only for an asterisk. |
| packages/client/ui-primitives/src/markdown/JsonBlock.tsx:21 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/client/ui-primitives/src/markdown/JsonBlock.tsx:23 | catch-clause | catch { |
| packages/client/ui-primitives/src/markdown/katex.tsx:42 | coverage-directive | v8 ignore next 2 -- KaTeX output holds only elements and text; other |
| packages/client/ui-primitives/src/markdown/katex.tsx:70 | catch-clause | catch (error) { |
| packages/client/ui-primitives/src/markdown/katex.tsx:73 | catch-clause | catch { |
| packages/client/ui-primitives/src/markdown/katex.tsx:76 | coverage-directive | v8 ignore next 8 |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:9 | lint-directive | oxlint-disable typescript/no-this-alias -- micromark binds tokenizer context only on the outer callback. |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:14 | coverage-directive | v8 ignore next -- a previous code necessarily has a preceding event. |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:23 | coverage-directive | v8 ignore next -- the text construct is dispatched only for a backslash. |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:88 | coverage-directive | v8 ignore next -- this partial construct is attempted only at a backslash. |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:107 | coverage-directive | v8 ignore next -- the opening check follows a failed close attempt at a backslash. |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:135 | coverage-directive | v8 ignore next -- the flow construct is dispatched only for its marker. |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:263 | coverage-directive | v8 ignore next -- the opening check follows a failed close attempt at the marker. |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:292 | coverage-directive | v8 ignore next -- continuation constructs are attempted only after a line ending. |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts:294 | coverage-directive | v8 ignore next -- continuation constructs are attempted only after a line ending. |
| packages/client/ui-primitives/src/markdown/render.tsx:50 | catch-clause | catch { |
| packages/client/ui-primitives/src/markdown/render.tsx:61 | catch-clause | catch { |
| packages/client/ui-primitives/src/markdown/render.tsx:495 | catch-clause | catch { |
| packages/client/ui-primitives/src/WebBlock.tsx:91 | catch-clause | catch { |
| packages/client/ui-primitives/src/WebBlock.tsx:110 | catch-clause | catch { |
| packages/client/ui-projection/src/pending-composer.ts:19 | catch-clause | catch (error) { |
| packages/client/ui-renderer/src/client/registry.ts:12 | lint-directive | oxlint-disable typescript/no-redundant-type-constituents -- |
| packages/client/ui-renderer/src/client/registry.ts:213 | catch-clause | catch (error) { |
| packages/client/ui-renderer/src/client/registry.ts:227 | catch-clause | catch (error) { |
| packages/client/ui-renderer/src/client/registry.ts:280 | catch-clause | catch (error) { |
| packages/client/ui-renderer/src/client/registry.ts:471 | lint-directive | oxlint-disable-next-line typescript/no-this-alias |
| packages/client/ui-renderer/src/client/registry.ts:508 | catch-clause | catch (error) { |
| packages/client/ui-renderer/src/client/registry.ts:520 | catch-clause | catch (error) { |
| packages/client/ui-renderer/src/client/registry.ts:574 | coverage-directive | v8 ignore next -- defensive: release only runs from a disposer whose |
| packages/client/ui-renderer/src/client/registry.ts:611 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- synchronous cleanup; direct return preserves disposer identity |
| packages/client/ui-renderer/src/client/scoped-slots.tsx:813 | catch-clause | catch (error) { |
| packages/client/ui-renderer/src/invariant.ts:6 | lint-directive | oxlint-disable typescript/no-redundant-type-constituents -- |
| packages/client/ui-renderer/tests/session-provider.client.spec.tsx:154 | coverage-directive | v8 ignore next -- strict-mode double-invoke guard, not a branch under test |
| packages/client/ui-session/src/client/index.ts:301 | catch-clause | catch (error) { |
| packages/client/ui-session/src/client/index.ts:352 | catch-clause | catch (error) { |
| packages/client/ui-session/src/client/index.ts:370 | catch-clause | catch (error) { |
| packages/client/ui-settings-general/src/client/index.ts:115 | coverage-directive | v8 ignore next -- list-slot registration requires id (SlotCore rejects an entry without one) |
| packages/client/ui-settings-general/src/client/index.ts:140 | coverage-directive | v8 ignore next -- list-slot registration requires id |
| packages/client/ui-settings-general/src/client/settings-document-store.ts:68 | catch-clause | catch (error) { |
| packages/client/ui-settings-models/src/client/CustomProviderCard.tsx:181 | catch-clause | catch (error) { |
| packages/client/ui-settings-models/src/client/DeepSeekOnboardingDialog.tsx:41 | coverage-directive | v8 ignore next 3 -- closed-union defaults only defend future source widening |
| packages/client/ui-settings-models/src/client/DeepSeekOnboardingDialog.tsx:77 | coverage-directive | v8 ignore next -- every current readiness variant is handled above |
| packages/client/ui-settings-models/src/client/DeepSeekOnboardingDialog.tsx:87 | coverage-directive | v8 ignore next 2 -- credential-missing is derived only from this exact joined row. |
| packages/client/ui-settings-models/src/client/ModelListEditor.tsx:252 | catch-clause | catch (error) { |
| packages/client/ui-settings-models/src/client/ModelListEditor.tsx:267 | coverage-directive | v8 ignore next -- the dialog only renders with candidates loaded |
| packages/client/ui-settings-models/src/client/ModelsSection.tsx:128 | catch-clause | catch (error) { |
| packages/client/ui-settings-models/src/client/ModelsSection.tsx:265 | coverage-directive | v8 ignore next -- the action only renders with a target and is disabled while a deletion is pending |
| packages/client/ui-settings-models/src/client/ModelsSection.tsx:282 | coverage-directive | v8 ignore next -- an error status always carries text; the fallback satisfies the nullable type |
| packages/client/ui-settings-models/src/client/ModelsSection.tsx:340 | coverage-directive | v8 ignore next -- the join marks a row configured only when its namespace resolved |
| packages/client/ui-settings-models/src/client/ModelsSection.tsx:468 | coverage-directive | v8 ignore next -- the select only lists addable rows |
| packages/client/ui-settings-models/src/client/ModelsSection.tsx:506 | coverage-directive | v8 ignore next -- the card only opens from a button disabled without this namespace |
| packages/client/ui-settings-models/src/client/ModelsSection.tsx:530 | coverage-directive | v8 ignore next -- the button is disabled while nothing is addable |
| packages/client/ui-settings-models/src/client/ProviderEditor.tsx:265 | coverage-directive | v8 ignore next 3 -- unreachable from the card: the same failure disables submit |
| packages/client/ui-settings-models/src/client/ProviderEditor.tsx:270 | coverage-directive | v8 ignore next -- apply is only reachable from the rendered card, which required a resolved node |
| packages/client/ui-settings-models/src/client/store.ts:228 | catch-clause | catch (error) { |
| packages/client/ui-settings-models/src/client/store.ts:264 | catch-clause | catch (error) { |
| packages/client/ui-settings-models/src/client/welcome-store.ts:37 | coverage-directive | v8 ignore next 3 -- closed-union default only defends future source widening |
| packages/client/ui-settings-models/src/client/welcome-store.ts:136 | coverage-directive | v8 ignore next -- every current settings scope status is handled above |
| packages/client/ui-settings/src/client/schema.ts:64 | catch-clause | catch (error) { |
| packages/client/ui-settings/src/client/settings-mirror.ts:201 | catch-clause | catch (error) { |
| packages/client/ui-settings/src/client/settings-scope.ts:136 | catch-clause | catch (_settingsWriteFailure) { |
| packages/client/ui-settings/src/client/settings-scope.ts:222 | catch-clause | catch (_malformedSchemaEnvelope) { |
| packages/client/ui-sidebar/src/client/SidebarRoot.tsx:109 | coverage-directive | v8 ignore next -- the listener only exists while the column is mounted and revealed. |
| packages/client/ui-skill/src/client/index.ts:86 | catch-clause | catch (error) { |
| packages/client/ui-skill/src/client/SkillRow.tsx:36 | catch-clause | catch { |
| packages/client/ui-slots/src/index.ts:11 | lint-directive | oxlint-disable typescript/no-redundant-type-constituents -- |
| packages/client/ui-slots/src/index.ts:634 | lint-directive | oxlint-disable-next-line typescript/no-explicit-any -- |
| packages/client/ui-slots/src/index.ts:1143 | coverage-directive | v8 ignore next -- defensive: declaring always creates the record |
| packages/client/ui-theme/src/client/index.ts:326 | coverage-directive | v8 ignore next 2 -- needs a registry without light/dark, which register()/dispose() cannot produce |
| packages/client/ui-theme/src/client/index.ts:369 | coverage-directive | v8 ignore next -- needs a documentless run (node e2e booting the client tree), not constructible under jsdom |
| packages/client/ui-tool/src/client/tool/models/raw-tool-call.ts:28 | catch-clause | catch { |
| packages/client/ui-tool/src/client/tool/models/tool-call-model.ts:126 | catch-clause | catch { |
| packages/client/ui-tool/src/client/tool/toolviews/ask-question-row.tsx:43 | catch-clause | catch { |
| packages/client/ui-tool/src/client/tool/toolviews/todo-row.tsx:30 | catch-clause | catch { |
| packages/client/ui-trajectory/src/client/layout.ts:573 | coverage-directive | v8 ignore next -- findIndex proved the dense array position exists. |
| packages/client/ui-trajectory/src/client/layout.ts:583 | coverage-directive | v8 ignore next -- findIndex proved the dense array position exists. |
| packages/client/ui-trajectory/src/client/trajectory-search-index.ts:17 | catch-clause | catch { |
| packages/client/ui-trajectory/src/client/TrajectoryTable.tsx:1753 | catch-clause | catch { |
| packages/client/ui-trajectory/src/client/TrajectoryTable.tsx:1762 | catch-clause | catch { |
| packages/client/ui-trajectory/src/client/TrajectoryTable.tsx:2175 | coverage-directive | v8 ignore next -- jsdom lacks scrollIntoView; browsers always have it. |
| packages/client/ui-trajectory/src/client/TrajectoryTable.tsx:2205 | coverage-directive | v8 ignore next -- jsdom lacks scrollIntoView; browsers always have it. |
| packages/client/ui-trajectory/tests/client-bundle.client.spec.ts:28 | catch-clause | catch { |
| packages/client/ui-user-questions/tests/browser-plugin.client.spec.ts:71 | catch-clause | catch (error) { |
| packages/client/ui-workflow-run/src/client/workflow-definition.ts:68 | coverage-directive | v8 ignore next -- WorkflowStopReason is closed and every variant is handled above. |
| packages/client/ui-workflow-run/src/client/workflow-definition.ts:78 | coverage-directive | v8 ignore next -- WorkflowAgentOutcome is closed and every variant is handled above. |
| packages/client/ui-workflow-run/src/client/WorkflowRunPanel.tsx:45 | coverage-directive | v8 ignore next -- WorkflowRunStatus is closed and every variant is handled above. |
| packages/client/ui-workflow-run/src/client/WorkflowRunPanel.tsx:157 | coverage-directive | v8 ignore next -- mounted phase callbacks are created from this owner map. |
| packages/client/ui-workflow-run/src/client/WorkflowRunPanel.tsx:164 | coverage-directive | v8 ignore next -- DisclosureRow always renders its header before the content. |
| packages/client/ui-workspace/src/client/row-focus.ts:117 | coverage-directive | v8 ignore next -- the selector already required both attributes. |
| packages/client/ui-workspace/src/client/row-focus.ts:187 | coverage-directive | v8 ignore next -- the ref is attached to the element these rows render into. |
| packages/client/ui-workspace/src/client/row-focus.ts:201 | coverage-directive | v8 ignore next -- the row asking for the search rendered into this list. |
| packages/client/ui-workspace/src/client/row-focus.ts:221 | coverage-directive | v8 ignore next -- the row asking is the row rendered, so it is in the account. |
| packages/client/ui-workspace/src/client/row-focus.ts:226 | coverage-directive | v8 ignore next -- the row asking for the move rendered into this list. |
| packages/client/ui-workspace/src/client/rows/Rows.tsx:504 | coverage-directive | v8 ignore next -- Menu can emit only the rename and delete rows supplied above. |
| packages/client/ui-workspace/src/client/rows/Rows.tsx:565 | coverage-directive | v8 ignore next 3 -- closed-union backstop; only reached if the status is forged |
| packages/client/ui-workspace/src/client/rows/Rows.tsx:606 | coverage-directive | v8 ignore next -- closed PendingInteractionStatus union |
| packages/client/ui-workspace/src/client/rows/WorkspaceBrowser.tsx:759 | coverage-directive | v8 ignore next -- narrowing guard: the actions object exists only for real-workspace groups. |
| packages/client/ui-workspace/src/client/rows/WorkspaceBrowser.tsx:763 | coverage-directive | v8 ignore next -- narrowing guard: the actions object exists only for real-workspace groups. |
| packages/client/ui-workspace/src/client/rows/WorkspaceBrowser.tsx:783 | coverage-directive | v8 ignore next -- narrowing guard: Rows gates hover on `active`, which is false while the drag state is null. |
| packages/client/ui-workspace/src/client/rows/WorkspaceBrowser.tsx:787 | coverage-directive | v8 ignore next -- narrowing guard: Rows gates drop on `active`, which is false while the drag state is null. |
| packages/client/ui-workspace/src/client/rows/WorkspaceBrowser.tsx:1350 | coverage-directive | v8 ignore next -- the Modal is absent without a target and its button is disabled while deleting. |
| packages/client/web/src/boot.ts:81 | catch-clause | catch (reason) { |
| packages/code-runtime/code-runtime-python/tests/protocol-mirror.e2e.ts:31 | catch-clause | catch { |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:80 | coverage-directive | v8 ignore next -- truncateJsonStringBytes guarantees the returned prefix fits. |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:137 | lint-directive | oxlint-disable-next-line typescript/unbound-method |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:175 | catch-clause | catch { |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:225 | catch-clause | catch { |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:332 | catch-clause | catch { |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:348 | catch-clause | catch (error: unknown) { |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:394 | coverage-directive | v8 ignore next -- makeBindingErrorClasses covers every declaration in the same data. |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:404 | coverage-directive | v8 ignore next -- the arrow exists only to reach the AsyncFunction constructor; it is never invoked. |
| packages/code-runtime/code-runtime-worker-thread/src/bootstrap.ts:417 | catch-clause | catch (error: unknown) { |
| packages/code-runtime/code-runtime-worker-thread/src/index.ts:105 | coverage-directive | v8 ignore next -- the './worker.cjs' arm is the built-lib world, unreachable unbuilt by construction; the built-lib e2e pins it. |
| packages/code-runtime/code-runtime-worker-thread/src/index.ts:128 | coverage-directive | v8 ignore next -- this race cannot be scheduled deterministically between the adjacent state check and listener registration. |
| packages/code-runtime/code-runtime-worker-thread/src/index.ts:218 | coverage-directive | v8 ignore next -- truncateJsonStringBytes guarantees its returned prefix fits the same budget. |
| packages/code-runtime/code-runtime-worker-thread/src/index.ts:304 | catch-clause | catch (error: unknown) { |
| packages/code-runtime/code-runtime-worker-thread/src/index.ts:408 | coverage-directive | v8 ignore next -- a second post-overflow chunk races immediate worker termination; the first overflow path is covered. |
| packages/code-runtime/code-runtime-worker-thread/src/index.ts:502 | catch-clause | catch { |
| packages/code-runtime/code-runtime-worker-thread/src/index.ts:510 | catch-clause | catch (error: unknown) { |
| packages/code-runtime/code-runtime-worker-thread/src/output-json.ts:108 | coverage-directive | v8 ignore next -- an object frame is created and advanced only for an existing Object.keys entry. |
| packages/code-runtime/code-runtime-worker-thread/src/worker-json.ts:54 | catch-clause | catch { |
| packages/code-runtime/code-runtime-worker-thread/src/worker-json.ts:190 | coverage-directive | v8 ignore next -- the loop is bounded by the captured key count. |
| packages/code-runtime/code-runtime-worker-thread/src/worker-json.ts:243 | coverage-directive | v8 ignore next -- the loop is bounded by the captured key count. |
| packages/code-runtime/code-runtime-worker-thread/src/worker-json.ts:328 | coverage-directive | v8 ignore next -- completed frames are popped before another token can attach. |
| packages/code-runtime/code-runtime-worker-thread/src/worker-json.ts:334 | coverage-directive | v8 ignore next -- object frames are built from validated keys and their exact length. |
| packages/code-runtime/code-runtime-worker-thread/src/worker-json.ts:372 | coverage-directive | v8 ignore next -- the loop condition guarantees a final frame. |
| packages/code-runtime/code-runtime-worker-thread/src/worker-json.ts:379 | catch-clause | catch { |
| packages/code-runtime/code-runtime-worker-thread/tests/bootstrap.spec.ts:57 | catch-clause | catch (error: unknown) { |
| packages/compaction/command-compact/src/index.ts:16 | coverage-directive | v8 ignore start -- closed-union backstop is unreachable without violating the TypeScript contract |
| packages/compaction/command-compact/src/index.ts:20 | coverage-directive | v8 ignore stop |
| packages/compaction/command-compact/src/index.ts:52 | coverage-directive | v8 ignore next 2 -- ManualCompactionErrorCode is closed and every member is handled above |
| packages/compaction/command-compact/src/index.ts:73 | catch-clause | catch (error: unknown) { |
| packages/compaction/command-compact/tests/command-compact.spec.ts:58 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- exercise arbitrary backend rejection values. |
| packages/compaction/compaction-basic/src/lock.ts:67 | coverage-directive | v8 ignore next -- the scan walks down from `length - 1`, so every index is in bounds |
| packages/compaction/compaction-basic/src/selection.ts:142 | coverage-directive | v8 ignore next -- callers pass non-empty lists |
| packages/compaction/compaction-basic/src/selection.ts:170 | coverage-directive | v8 ignore next -- surface nodes are current seqs of a validated log, so every entry exists and matches |
| packages/compaction/compaction-basic/src/selection.ts:236 | coverage-directive | v8 ignore next -- shadowed seqs are current surface seqs of a validated log, so every entry exists and matches |
| packages/compaction/compaction-basic/src/selection.ts:241 | coverage-directive | v8 ignore next -- shadowed surface nodes always derive a message |
| packages/compaction/compaction-basic/src/selection.ts:346 | coverage-directive | v8 ignore next -- both sides slice the same validated span, so lengths always agree |
| packages/compaction/compaction-basic/tests/manual-compaction.spec.ts:150 | catch-clause | catch (error: unknown) { |
| packages/compaction/compaction-tool-result-pruner/src/index.ts:114 | coverage-directive | v8 ignore next -- totalChars > threshold and valid budgets guarantee a removed text span. |
| packages/compaction/compaction-tool-result-pruner/src/index.ts:117 | coverage-directive | v8 ignore next -- config validation fixes the emitted head + marker + tail budget. |
| packages/compaction/compaction-tool-result-pruner/src/index.ts:140 | coverage-directive | v8 ignore next -- surface seqs are validated contiguous log references. |
| packages/context/agent-instructions/src/files.ts:132 | catch-clause | catch (error: unknown) { |
| packages/context/agent-instructions/src/files.ts:156 | catch-clause | catch { |
| packages/context/agent-instructions/src/files.ts:182 | catch-clause | catch { |
| packages/context/agent-instructions/src/files.ts:192 | catch-clause | catch (error) { |
| packages/context/agent-instructions/src/files.ts:241 | coverage-directive | v8 ignore next -- discovery always supplies cwd or an ancestor root. |
| packages/context/agent-instructions/src/files.ts:343 | coverage-directive | v8 ignore next 2 -- StatFileProbe is closed; this arm only makes adding a kind a compile error. |
| packages/context/agent-instructions/src/files.ts:377 | coverage-directive | v8 ignore next 2 -- StatFileProbe is closed; this arm only makes adding a kind a compile error. |
| packages/context/agent-instructions/src/files.ts:472 | catch-clause | catch { |
| packages/context/agent-instructions/src/files.ts:607 | catch-clause | catch { |
| packages/context/agent-instructions/src/index.ts:129 | coverage-directive | v8 ignore next -- normal agents carry an absolute session cwd. |
| packages/context/agent-instructions/src/index.ts:220 | coverage-directive | v8 ignore next -- reconciliation constructs only agent-instructions contexts. |
| packages/context/agent-instructions/src/render.ts:143 | coverage-directive | v8 ignore next -- every scope key is produced by candidateScopeKey, which always inserts the separator. |
| packages/context/agent-instructions/src/render.ts:201 | coverage-directive | v8 ignore next -- the renderer receives exactly the files used to construct this map. |
| packages/context/agent-instructions/src/render.ts:297 | coverage-directive | v8 ignore next -- callers only reach this after a non-empty fullText was built. |
| packages/context/agent-instructions/src/state.ts:269 | coverage-directive | v8 ignore next -- normal agents carry an absolute session cwd. |
| packages/context/agent-instructions/src/state.ts:308 | coverage-directive | v8 ignore next -- the plugin passes its workspace-only pending projection. |
| packages/context/file-reference-local/src/search.ts:210 | coverage-directive | v8 ignore next -- disposal aborts this traversal, so it reaches the |
| packages/context/file-reference-local/src/search.ts:220 | coverage-directive | v8 ignore next -- dispose clears `generation` synchronously; this only protects an unexpected scan failure |
| packages/context/file-reference-local/src/search.ts:248 | coverage-directive | v8 ignore next 3 -- cursor is bounded by this exact queue's length. |
| packages/context/file-reference-local/src/search.ts:348 | coverage-directive | v8 ignore next -- only Windows can produce a cross-volume absolute relative path |
| packages/context/file-reference-local/src/search.ts:358 | catch-clause | catch (_error: unknown) { |
| packages/context/file-reference-local/src/search.ts:379 | catch-clause | catch (_error: unknown) { |
| packages/context/file-reference-local/src/search.ts:448 | coverage-directive | v8 ignore next -- `list()` checks this signal immediately before its synchronous call into this helper |
| packages/context/file-reference-local/tests/search.spec.ts:50 | catch-clause | catch { |
| packages/context/file-reference-local/tests/service.spec.ts:150 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors |
| packages/context/session-reference/src/index.ts:146 | coverage-directive | v8 ignore if -- a parsed canonical mention always leaves one normalized reference |
| packages/context/session-reference/src/index.ts:284 | catch-clause | catch (error: unknown) { |
| packages/context/session-reference/src/projection.ts:54 | coverage-directive | v8 ignore next 2 -- SurfaceEventType is closed and every variant is handled above. |
| packages/context/session-reference/src/projection.ts:92 | coverage-directive | v8 ignore next 3 -- dropIndex came from this exact array and is non-negative. |
| packages/context/session-reference/src/projection.ts:114 | coverage-directive | v8 ignore next 3 -- longestIndex was selected from this exact array's entries. |
| packages/context/session-reference/src/projection.ts:119 | coverage-directive | v8 ignore next -- strictly lowering the byte target must change a complete-string retention result. |
| packages/context/session-reference/src/projection.ts:145 | coverage-directive | v8 ignore next -- callers invoke this only with a target smaller than the selected original text. |
| packages/context/session-reference/src/projection.ts:158 | coverage-directive | v8 ignore next 3 -- complete-string TextRetainer input cannot report a lower bound. |
| packages/context/session-reference/src/uri.ts:37 | catch-clause | catch (error: unknown) { |
| packages/context/session-reference/src/uri.ts:78 | coverage-directive | v8 ignore next -- the two-alternative regex always captures exactly one URI group. |
| packages/context/time-context/src/index.ts:152 | catch-clause | catch (error: unknown) { |
| packages/context/time-context/src/invariant.ts:108 | coverage-directive | v8 ignore next 2 -- replay and dispatch callers select this exact package-owned source before validation. |
| packages/context/time-context/src/invariant.ts:138 | coverage-directive | v8 ignore next -- the preceding fixed regexp always supplies capture group three. |
| packages/context/time-context/src/invariant.ts:153 | catch-clause | catch (error: unknown) { |
| packages/context/time-context/src/request-zone.ts:33 | catch-clause | catch (error: unknown) { |
| packages/context/time-context/src/request-zone.ts:77 | coverage-directive | v8 ignore next 2 -- the closed BrowserTimeZoneContext union is exhausted above. |
| packages/context/tmux-context/src/index.ts:125 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/agent.ts:219 | catch-clause | catch (_error) { |
| packages/core/agent-loop/src/agent.ts:222 | coverage-directive | v8 ignore next -- kick owns a running phase until this driver boundary |
| packages/core/agent-loop/src/agent.ts:232 | coverage-directive | v8 ignore next -- private callers establish the running phase before proposing a step |
| packages/core/agent-loop/src/agent.ts:264 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/agent.ts:310 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/agent.ts:330 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- every exit assigns a turn ending |
| packages/core/agent-loop/src/agent.ts:332 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/agent.ts:345 | coverage-directive | v8 ignore next -- private callers establish the running phase before executing a step |
| packages/core/agent-loop/src/agent.ts:375 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/agent.ts:473 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- the instance logged the header it now folds |
| packages/core/agent-loop/src/agent.ts:494 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/index.ts:123 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/index.ts:124 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- the signal can abort while the operation is awaited. |
| packages/core/agent-loop/src/index.ts:401 | catch-clause | catch (listenerError: unknown) { |
| packages/core/agent-loop/src/index.ts:420 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/index.ts:466 | coverage-directive | v8 ignore next -- unreachable backstop, see above |
| packages/core/agent-loop/src/index.ts:532 | coverage-directive | v8 ignore start -- ctx.effect throws only on an inactive fiber, which assertActive() above already rejected |
| packages/core/agent-loop/src/index.ts:533 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/index.ts:539 | coverage-directive | v8 ignore stop |
| packages/core/agent-loop/src/index.ts:546 | coverage-directive | v8 ignore next -- unreachable String() arm, see above |
| packages/core/agent-loop/src/index.ts:574 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/index.ts:595 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/index.ts:642 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/tool-calls.ts:86 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- bounded by the loop condition |
| packages/core/agent-loop/src/tool-calls.ts:107 | catch-clause | catch { |
| packages/core/agent-loop/src/tool-calls.ts:154 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- bounded index |
| packages/core/agent-loop/src/tool-calls.ts:165 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- bounded index |
| packages/core/agent-loop/src/tool-calls.ts:192 | coverage-directive | v8 ignore next -- closed-union exhaustiveness guard |
| packages/core/agent-loop/src/tool-calls.ts:201 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- bounded by the loop condition |
| packages/core/agent-loop/src/tool-calls.ts:231 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/src/tool-calls.ts:243 | coverage-directive | v8 ignore next -- unreachable: a non-aborted group commits every started call |
| packages/core/agent-loop/tests/agent-initiator.spec.ts:102 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/tests/config-session-id.spec.ts:267 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors |
| packages/core/agent-loop/tests/scope-lifecycle.spec.ts:127 | catch-clause | catch (error: unknown) { |
| packages/core/agent-loop/tests/tool-calls.spec.ts:709 | lint-directive | eslint-disable-next-line @typescript-eslint/no-explicit-any -- FakeCodeRuntime is an internal test helper with an opaque type shape |
| packages/core/agent/src/consumed-work.ts:51 | coverage-directive | v8 ignore next 4 -- unreachable: the one unnamed built-in, `max-tokens`, requires a step, |
| packages/core/agent/src/dispatch.ts:133 | catch-clause | catch (error: unknown) { |
| packages/core/agent/src/dispatch.ts:139 | lint-directive | oxlint-disable-next-line typescript/unbound-method -- the events mixin accessor returns a pre-bound function |
| packages/core/agent/src/dispatch.ts:144 | lint-directive | oxlint-disable-next-line typescript/unbound-method -- the events mixin accessor returns a pre-bound function |
| packages/core/agent/src/inbox.ts:36 | catch-clause | catch (error: unknown) { |
| packages/core/agent/src/index.ts:380 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- synchronous cleanup; direct return preserves disposer identity |
| packages/core/agent/src/index.ts:407 | lint-directive | oxlint-disable-next-line typescript/unbound-method -- Reflect.apply intentionally supplies the caller-traced receiver |
| packages/core/agent/src/index.ts:422 | lint-directive | oxlint-disable-next-line typescript/unbound-method -- Reflect.apply intentionally supplies the caller-traced receiver |
| packages/core/agent/src/index.ts:449 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- synchronous cleanup; direct return preserves disposer identity |
| packages/core/agent/src/index.ts:510 | coverage-directive | v8 ignore next -- enter() rejects replacement while this single-shot detach capability is live. |
| packages/core/agent/src/index.ts:530 | catch-clause | catch (error: unknown) { |
| packages/core/agent/src/index.ts:644 | catch-clause | catch (error: unknown) { |
| packages/core/agent/src/index.ts:655 | catch-clause | catch { |
| packages/core/scope/src/store.ts:252 | catch-clause | catch (error) { |
| packages/core/scope/src/store.ts:264 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- exact synchronous disposer preserves Cordis effect identity |
| packages/core/session/src/chunk-run-codec.ts:414 | coverage-directive | v8 ignore next 4 -- a validated row carries one of the three row tags |
| packages/core/session/src/index.ts:206 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/core/session/src/index.ts:398 | catch-clause | catch (error: unknown) { |
| packages/core/session/src/index.ts:536 | catch-clause | catch (error: unknown) { |
| packages/core/session/src/index.ts:741 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/core/session/src/index.ts:959 | coverage-directive | v8 ignore next -- enter() rejects replacement while this single-shot detach capability is live. |
| packages/core/session/src/index.ts:1009 | catch-clause | catch (error: unknown) { |
| packages/core/session/src/invariant.ts:183 | coverage-directive | v8 ignore next -- validateEvent produces this closed transition union |
| packages/core/session/src/json.ts:24 | catch-clause | catch { |
| packages/core/session/src/json.ts:169 | coverage-directive | v8 ignore next -- the loop is bounded by the captured key count. |
| packages/core/session/src/surface.ts:448 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- bounded by the loop condition |
| packages/core/session/tests/session.spec.ts:1191 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:543 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:555 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:622 | catch-clause | catch { |
| packages/core/tools/src/index.ts:651 | catch-clause | catch { |
| packages/core/tools/src/index.ts:899 | coverage-directive | v8 ignore next -- requireCodeRuntime rejects an unknown language before this runs. |
| packages/core/tools/src/index.ts:1282 | coverage-directive | v8 ignore next -- registration already validated and retained this schema as lossless JSON. |
| packages/core/tools/src/index.ts:1320 | catch-clause | catch { |
| packages/core/tools/src/index.ts:1340 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1396 | coverage-directive | v8 ignore next -- closed-union exhaustiveness guard |
| packages/core/tools/src/index.ts:1490 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1548 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1556 | coverage-directive | v8 ignore next -- only registry-minted executions reach the staged scheduler methods |
| packages/core/tools/src/index.ts:1575 | coverage-directive | v8 ignore next -- only registry-minted executions reach the staged scheduler methods |
| packages/core/tools/src/index.ts:1589 | coverage-directive | v8 ignore next -- only registry-minted executions reach the staged scheduler methods |
| packages/core/tools/src/index.ts:1608 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1633 | coverage-directive | v8 ignore next -- dispatch only receives executions minted by this registry's prepare stage |
| packages/core/tools/src/index.ts:1650 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1672 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1689 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1695 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1726 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1854 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/index.ts:1863 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/json-schema.ts:100 | catch-clause | catch { |
| packages/core/tools/src/json-schema.ts:110 | catch-clause | catch { |
| packages/core/tools/src/json-schema.ts:137 | catch-clause | catch { |
| packages/core/tools/src/json-schema.ts:155 | coverage-directive | v8 ignore next -- JsonSchemaScalarType is closed; this retains compile-time exhaustiveness. |
| packages/core/tools/src/json-schema.ts:230 | catch-clause | catch { |
| packages/core/tools/src/json-schema.ts:303 | coverage-directive | v8 ignore next -- the loop is bounded by the captured entry count. |
| packages/core/tools/src/json-schema.ts:340 | coverage-directive | v8 ignore next -- schemaType was narrowed from the closed SCHEMA_TYPES table above. |
| packages/core/tools/src/json-schema.ts:379 | catch-clause | catch { |
| packages/core/tools/src/json-schema.ts:478 | coverage-directive | v8 ignore next -- the loop condition guarantees a current frame. |
| packages/core/tools/src/json-schema.ts:484 | coverage-directive | v8 ignore next -- childIndex is bounded by children.length. |
| packages/core/tools/src/json-schema.ts:602 | catch-clause | catch (error) { |
| packages/core/tools/src/json-schema.ts:610 | coverage-directive | v8 ignore next -- every root frame finishes or throws. |
| packages/core/tools/src/ptc.ts:158 | catch-clause | catch (error: unknown) { |
| packages/core/tools/src/ptc.ts:165 | coverage-directive | v8 ignore next -- snapshot is already a detached lossless JSON value. |
| packages/core/tools/src/ptc.ts:218 | coverage-directive | v8 ignore next -- canonical JsonValue arrays are dense. |
| packages/core/tools/src/ptc.ts:240 | coverage-directive | v8 ignore next -- the loop is bounded by the captured key count. |
| packages/core/tools/src/ptc.ts:243 | coverage-directive | v8 ignore next -- canonical JsonValue records contain no undefined properties. |
| packages/core/tools/src/ptc.ts:560 | coverage-directive | v8 ignore next -- commit() runs only after `settled` flipped, which set parked. |
| packages/core/tools/src/py-types.ts:533 | coverage-directive | v8 ignore next -- the ?? arm needs a childless array frame, which start never builds. |
| packages/core/tools/src/py-types.ts:541 | coverage-directive | v8 ignore next -- typeddict frames always set node and allocated at start. |
| packages/core/tools/src/py-types.ts:548 | coverage-directive | v8 ignore next -- entries and childResults correspond one-to-one. |
| packages/core/tools/src/py-types.ts:672 | coverage-directive | v8 ignore next -- allocated is always set before children are built. |
| packages/core/tools/src/py-types.ts:676 | coverage-directive | v8 ignore next 4 -- assertSupportedJsonSchema narrowed this closed type union. |
| packages/core/tools/src/py-types.ts:689 | coverage-directive | v8 ignore next -- every root frame produces one expression. |
| packages/core/tools/src/py-types.ts:691 | catch-clause | catch { |
| packages/core/tools/src/schema-render-stack.ts:82 | coverage-directive | v8 ignore next -- the loop condition guarantees a current frame. |
| packages/core/tools/src/schema-render-stack.ts:87 | coverage-directive | v8 ignore next -- childIndex is bounded by children.length. |
| packages/core/tools/src/schema.ts:318 | coverage-directive | v8 ignore next -- the loop is bounded by the captured entry count. |
| packages/core/tools/src/schema.ts:421 | coverage-directive | v8 ignore next -- the root task assigns before scheduling any descendants. |
| packages/core/tools/src/schema.ts:429 | coverage-directive | v8 ignore next -- the root task assigns before scheduling any descendants. |
| packages/core/tools/src/testing.ts:31 | lint-directive | oxlint-disable-next-line typescript/unbound-method |
| packages/core/tools/src/ts-types.ts:89 | coverage-directive | v8 ignore next -- the loop is bounded by the captured part count. |
| packages/core/tools/src/ts-types.ts:122 | coverage-directive | v8 ignore next -- child documents correspond one-to-one with children. |
| packages/core/tools/src/ts-types.ts:130 | coverage-directive | v8 ignore next -- array frames always schedule exactly one child. |
| packages/core/tools/src/ts-types.ts:143 | coverage-directive | v8 ignore next -- object entries and child documents have the same length. |
| packages/core/tools/src/ts-types.ts:196 | coverage-directive | v8 ignore next -- assertSupportedJsonSchema narrowed this closed type union. |
| packages/core/tools/src/ts-types.ts:209 | coverage-directive | v8 ignore next -- every root frame produces one document. |
| packages/core/tools/src/ts-types.ts:225 | catch-clause | catch { |
| packages/core/tools/tests/json-schema.spec.ts:26 | catch-clause | catch (error: unknown) { |
| packages/core/tools/tests/ptc.spec.ts:961 | catch-clause | catch (error: unknown) { |
| packages/core/tools/tests/ptc.spec.ts:1026 | catch-clause | catch (error: unknown) { |
| packages/core/tools/tests/ptc.spec.ts:1043 | catch-clause | catch (error: unknown) { |
| packages/credentials/authorization/src/index.ts:340 | catch-clause | catch (error) { |
| packages/credentials/authorization/src/index.ts:393 | catch-clause | catch (error) { |
| packages/credentials/authorization/src/index.ts:413 | catch-clause | catch (error) { |
| packages/credentials/credentials-local/src/index.ts:123 | catch-clause | catch (error) { |
| packages/credentials/credentials-local/src/index.ts:128 | coverage-directive | v8 ignore next 2 -- native Windows coverage takes this arm; POSIX coverage takes the peer below. |
| packages/credentials/credentials-local/src/index.ts:145 | coverage-directive | v8 ignore start -- runs only on win32; the win32-only credentials suite proves it there. |
| packages/credentials/credentials-local/src/index.ts:155 | coverage-directive | v8 ignore stop |
| packages/credentials/credentials-local/src/index.ts:165 | coverage-directive | v8 ignore next -- `prettyErrors` populates linePos on every error; the guard answers its optional type |
| packages/credentials/credentials-local/src/index.ts:260 | catch-clause | catch { |
| packages/credentials/credentials-local/src/index.ts:482 | coverage-directive | v8 ignore next -- both callers render a delete only for an entry they just |
| packages/credentials/credentials-local/src/index.ts:487 | coverage-directive | v8 ignore next -- a map that holds the entry has a first item, and the |
| packages/credentials/credentials-local/src/index.ts:757 | coverage-directive | v8 ignore next 2 -- the losing side of the cross-process migration race: |
| packages/credentials/credentials-local/tests/local.spec.ts:294 | catch-clause | catch (error) { |
| packages/credentials/credentials/src/index.ts:296 | catch-clause | catch (error) { |
| packages/e2b/e2b/src/index.ts:113 | catch-clause | catch (_sandboxSetupFailure) { |
| packages/e2b/e2b/src/index.ts:119 | catch-clause | catch (error: unknown) { |
| packages/e2b/e2b/src/index.ts:134 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- Awaiting readiness yields to disposal. |
| packages/e2b/e2b/src/index.ts:170 | catch-clause | catch (error: unknown) { |
| packages/e2b/e2b/src/index.ts:173 | catch-clause | catch (_sandboxSetupRollbackFailure) { |
| packages/e2b/e2b/tests/e2b.spec.ts:21 | lint-directive | oxlint-disable-next-line typescript/no-extraneous-class -- The SDK contract is a class with a static factory. |
| packages/e2b/fs-e2b/src/index.ts:63 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:91 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:150 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:208 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:238 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:244 | catch-clause | catch (_streamCancellationFailure) { |
| packages/e2b/fs-e2b/src/index.ts:280 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:286 | catch-clause | catch (_streamCancellationFailure) { |
| packages/e2b/fs-e2b/src/index.ts:321 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:389 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:402 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:432 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:444 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:504 | catch-clause | catch (_committedStagingCleanupFailure) { |
| packages/e2b/fs-e2b/src/index.ts:508 | catch-clause | catch (error: unknown) { |
| packages/e2b/fs-e2b/src/index.ts:512 | catch-clause | catch (_stagingDirectoryAlreadyAbsentOrCleanupFailed) { |
| packages/e2b/subprocess-e2b/src/environment.ts:47 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:282 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:334 | catch-clause | catch (cleanupError: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:347 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:350 | catch-clause | catch (cleanupError: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:367 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:373 | catch-clause | catch (cleanupError: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:423 | catch-clause | catch (_processClosedItsInput) { |
| packages/e2b/subprocess-e2b/src/process.ts:432 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:446 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:561 | catch-clause | catch (cleanupError: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:581 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/process.ts:614 | catch-clause | catch (_gracefulTerminationFailure) { |
| packages/e2b/subprocess-e2b/src/process.ts:625 | catch-clause | catch (_processGroupKillFailure) { |
| packages/e2b/subprocess-e2b/src/process.ts:630 | catch-clause | catch (_sdkKillFailure) { |
| packages/e2b/subprocess-e2b/src/process.ts:684 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/remote.ts:94 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:144 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:205 | catch-clause | catch (_sessionLookupFailure) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:218 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:223 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- Provider cleanup yields to completion. |
| packages/e2b/subprocess-e2b/src/terminal.ts:227 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:242 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:247 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- The callback mutates this after a race. |
| packages/e2b/subprocess-e2b/src/terminal.ts:259 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:352 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:380 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:409 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:425 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:430 | catch-clause | catch (_adapterPrivateStateRemovalFailure) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:516 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:527 | catch-clause | catch (cleanupError: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:536 | catch-clause | catch (stateError: unknown) { |
| packages/e2b/subprocess-e2b/src/terminal.ts:547 | catch-clause | catch (cleanupError: unknown) { |
| packages/e2b/subprocess-e2b/tests/subprocess.spec.ts:1422 | catch-clause | catch (error: unknown) { |
| packages/e2b/subprocess-e2b/tests/terminal.spec.ts:435 | catch-clause | catch (error: unknown) { |
| packages/experimental/inspector/src/client/bridge/controller.ts:17 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/bridge/transport.ts:85 | catch-clause | catch { |
| packages/experimental/inspector/src/client/bridge/transport.ts:202 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/bridge/transport.ts:256 | catch-clause | catch { |
| packages/experimental/inspector/src/client/bridge/transport.ts:304 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/console.ts:145 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/console.ts:160 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/objects.ts:209 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/objects.ts:229 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/objects.ts:240 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/objects.ts:305 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/objects.ts:325 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/objects.ts:332 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/objects.ts:354 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/objects.ts:362 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/objects.ts:384 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/properties.ts:118 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/properties.ts:126 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/properties.ts:134 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/runtime.ts:99 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/runtime.ts:184 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/runtime.ts:220 | catch-clause | catch (serializationError) { |
| packages/experimental/inspector/src/client/cdp/runtime.ts:343 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/runtime.ts:371 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/runtime.ts:387 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/cdp/sources.ts:230 | catch-clause | catch { |
| packages/experimental/inspector/src/client/cdp/stack.ts:32 | catch-clause | catch { |
| packages/experimental/inspector/src/client/index.ts:60 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/index.ts:63 | catch-clause | catch (cleanupError) { |
| packages/experimental/inspector/src/client/index.ts:80 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/index.ts:86 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/client/inspection/realm.ts:75 | catch-clause | catch { |
| packages/experimental/inspector/src/client/inspection/realm.ts:80 | catch-clause | catch { |
| packages/experimental/inspector/src/client/inspection/realm.ts:93 | catch-clause | catch { |
| packages/experimental/inspector/src/host/bridge/controller.ts:218 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/bridge/controller.ts:259 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/bridge/controller.ts:268 | catch-clause | catch (closeError) { |
| packages/experimental/inspector/src/host/bridge/controller.ts:329 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/bridge/controller.ts:334 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/bridge/controller.ts:339 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/bridge/lifecycle.ts:52 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/bridge/transport.ts:47 | catch-clause | catch { |
| packages/experimental/inspector/src/host/index.ts:54 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/index.ts:72 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/index.ts:78 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/inspection/network.ts:73 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/inspection/network.ts:96 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/inspection/network.ts:130 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/inspection/network.ts:202 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/host/inspection/network.ts:231 | catch-clause | catch { |
| packages/experimental/inspector/src/shared/bridge/control-codec.ts:111 | catch-clause | catch { |
| packages/experimental/inspector/src/shared/bridge/rpc.ts:103 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/shared/bridge/rpc.ts:123 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/shared/cordis/object-registry.ts:72 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/endpoint.ts:62 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/bridge/endpoint.ts:120 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/endpoint.ts:159 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/endpoint.ts:193 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/endpoint.ts:218 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/hub.ts:110 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/bridge/hub.ts:322 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/hub.ts:332 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts:120 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts:163 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts:230 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts:253 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts:330 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts:385 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts:405 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts:422 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/session.ts:23 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/bridge/source-rpc.ts:78 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/cdp/domains/debugger/session.ts:110 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/cdp/domains/debugger/session.ts:205 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/cdp/domains/dom/model.ts:215 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/cdp/domains/runtime/session.ts:459 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/cdp/domains/runtime/session.ts:490 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/cdp/realm-sessions.ts:123 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/cdp/session.ts:57 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/cdp/session.ts:98 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/entry.ts:45 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/entry.ts:53 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/inspection/cordis-store.ts:227 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/inspection/network-store.ts:113 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/inspection/network-store.ts:337 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/inspection/query-router.ts:145 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/inspection/query-router.ts:194 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/inspection/query-router.ts:205 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/inspection/query-router.ts:241 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/inspection/query-router.ts:250 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/inspection/realm-store.ts:111 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/realms/host/bridge.ts:47 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/realms/host/bridge.ts:81 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/realms/host/bridge.ts:95 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/realms/host/bridge.ts:117 | catch-clause | catch (error) { |
| packages/experimental/inspector/src/worker/realms/host/bridge.ts:181 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/realms/host/runtime.ts:303 | catch-clause | catch { |
| packages/experimental/inspector/src/worker/realms/host/sources.ts:90 | catch-clause | catch { |
| packages/experimental/webworker-packer/src/pack.ts:384 | catch-clause | catch { |
| packages/experimental/webworker-packer/src/pack.ts:408 | catch-clause | catch (reason) { |
| packages/experimental/webworker-packer/src/pack.ts:494 | lint-directive | eslint-disable-next-line @typescript-eslint/no-dynamic-delete -- the image is a plain path map |
| packages/experimental/webworker-runtime/src/async-context/als-runtime.ts:96 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/async-context/async-context-hooks.ts:45 | lint-directive | oxlint-disable-next-line typescript/unbound-method -- capturing it unbound is the point; `nativeThen.call` names the promise. |
| packages/experimental/webworker-runtime/src/client/client.ts:115 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/client/client.ts:250 | catch-clause | catch (cause) { |
| packages/experimental/webworker-runtime/src/client/client.ts:388 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/client/index.ts:108 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/src/client/index.ts:157 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/src/compile/transform.ts:479 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/src/compile/transform.ts:512 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/src/module-system/module-loader.ts:199 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/src/module-system/module-loader.ts:320 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/async_hooks.ts:53 | lint-directive | oxlint-disable-next-line typescript/unbound-method -- capturing it unbound is the point; `nativeThen.call` names the promise. |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/async_hooks.ts:113 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/async_hooks.ts:130 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs-watch.ts:67 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs-watch.ts:388 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs-watch.ts:424 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs.ts:176 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs.ts:568 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs.ts:590 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs.ts:661 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs.ts:684 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/stream.ts:26 | lint-directive | oxlint-disable typescript/unbound-method -- readable-stream's namespace statics do not read `this`. |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/url.ts:73 | lint-directive | oxlint-disable-next-line typescript/no-deprecated -- the module this worker stands in for exports it. |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/util.ts:53 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/node/globals/process.ts:103 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/node/notImplementedFail.ts:25 | lint-directive | eslint-disable-next-line @typescript-eslint/no-unnecessary-type-parameters -- only the return position carries the Node declaration |
| packages/experimental/webworker-runtime/src/shell/expand.ts:81 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/shell/fs-access.ts:82 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/shell/interpret.ts:80 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/interpret.ts:109 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/interpret.ts:276 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/interpret.ts:348 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/process/landlock.ts:180 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/process/landlock.ts:190 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/files.ts:96 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/files.ts:116 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/files.ts:145 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/files.ts:194 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/files.ts:215 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/files.ts:231 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts:38 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts:160 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts:186 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts:277 | lint-directive | oxlint-disable-next-line typescript/no-misused-spread -- a `tr` set names characters, and code points are that unit. |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts:305 | lint-directive | oxlint-disable-next-line typescript/no-misused-spread -- `tr` deletes per character, and code points are the unit it deletes. |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts:313 | lint-directive | oxlint-disable-next-line typescript/no-misused-spread -- `tr` translates per character, and code points are the unit it maps. |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts:335 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts:352 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/storage/memory.ts:231 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/transport/tunnel.ts:290 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/src/transport/tunnel.ts:348 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/src/transport/tunnel.ts:439 | catch-clause | catch { |
| packages/experimental/webworker-runtime/src/transport/tunnel.ts:481 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/src/worker-host.ts:265 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/tests/compile/transform-corpus-check.ts:63 | catch-clause | catch { |
| packages/experimental/webworker-runtime/tests/compile/transform-corpus-check.ts:78 | catch-clause | catch { |
| packages/experimental/webworker-runtime/tests/compile/transform-corpus-check.ts:109 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/tests/compile/transform.spec.ts:54 | catch-clause | catch (reason) { |
| packages/experimental/webworker-runtime/tests/compile/transform.spec.ts:81 | lint-directive | eslint-disable-next-line @typescript-eslint/no-implied-eval -- the wrapper contract under test is a `new Function` body |
| packages/experimental/webworker-runtime/tests/compile/transform.spec.ts:108 | lint-directive | eslint-disable-next-line @typescript-eslint/no-implied-eval -- proves the parameter names compile where the loader uses them |
| packages/experimental/webworker-runtime/tests/compile/transform.spec.ts:111 | catch-clause | catch { |
| packages/experimental/webworker-runtime/tests/node/fs-watch-stream.spec.ts:189 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/tests/node/fs.spec.ts:47 | catch-clause | catch (error) { |
| packages/experimental/webworker-runtime/tests/node/path-diff.spec.ts:56 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/src/client/evaluator.ts:121 | catch-clause | catch { |
| packages/extensions/cordis-client-runner/src/client/evaluator.ts:179 | lint-directive | oxlint-disable-next-line typescript/no-implied-eval -- see above |
| packages/extensions/cordis-client-runner/src/client/evaluator.ts:182 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/src/client/inspect-registry.ts:115 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/src/client/orchestrator.ts:348 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/src/client/orchestrator.ts:395 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/src/client/orchestrator.ts:427 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/src/client/orchestrator.ts:435 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/src/client/runtime.ts:364 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/src/client/runtime.ts:394 | catch-clause | catch (error) { |
| packages/extensions/cordis-client-runner/tests/orchestrator.client.spec.ts:8 | lint-directive | oxlint-disable typescript/no-unsafe-assignment -- Vitest asymmetric matchers are typed as any. |
| packages/extensions/cordis-client-runner/tests/orchestrator.client.spec.ts:411 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- the non-Error rejection is the case under test |
| packages/extensions/cordis-client-runner/tests/plugin.client.spec.ts:9 | lint-directive | oxlint-disable typescript/no-unsafe-assignment -- Vitest asymmetric matchers are typed as any. |
| packages/extensions/cordis-client-runner/tests/plugin.client.spec.ts:148 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- the non-Error rejection is a case under test |
| packages/extensions/cordis-client-runner/tests/runner.client.spec.ts:12 | lint-directive | oxlint-disable typescript/no-unsafe-assignment -- Vitest asymmetric matchers are typed as any. |
| packages/extensions/cordis-host-runner/src/guard.ts:150 | coverage-directive | v8 ignore next -- the loop is bounded by the captured entry count. |
| packages/extensions/cordis-host-runner/src/guard.ts:322 | coverage-directive | v8 ignore next -- the loop is bounded by the captured entry count. |
| packages/extensions/cordis-host-runner/src/guard.ts:452 | coverage-directive | v8 ignore next 2 -- SCHEMA_TYPES narrows this closed switch before dispatch. |
| packages/extensions/cordis-host-runner/src/guard.ts:457 | coverage-directive | v8 ignore next -- the root map task assigns before scheduling descendants. |
| packages/extensions/cordis-host-runner/src/index.ts:690 | catch-clause | catch (error) { |
| packages/extensions/cordis-host-runner/src/index.ts:840 | catch-clause | catch (error) { |
| packages/extensions/cordis-host-runner/src/inspect-registry.ts:149 | catch-clause | catch { |
| packages/extensions/cordis-host-runner/src/lifecycle.ts:31 | catch-clause | catch (error) { |
| packages/extensions/cordis-host-runner/src/sandbox.ts:216 | lint-directive | oxlint-disable-next-line typescript/no-implied-eval -- parse gate over model-written code; nothing is invoked |
| packages/extensions/cordis-host-runner/src/sandbox.ts:218 | catch-clause | catch (error) { |
| packages/extensions/cordis-host-runner/src/sandbox.ts:235 | catch-clause | catch (vmError) { |
| packages/extensions/cordis-host-runner/src/sandbox.ts:261 | catch-clause | catch (error) { |
| packages/extensions/cordis-host-runner/tests/sandbox-context.spec.ts:16 | catch-clause | catch (error) { |
| packages/extensions/cordis-host-runner/tests/sandbox-context.spec.ts:88 | catch-clause | catch (error) { |
| packages/extensions/cordis-host-runner/tests/sandbox.spec.ts:192 | catch-clause | catch (error) { |
| packages/extensions/tool-cordis/tests/cordis-lifecycle.spec.ts:105 | catch-clause | catch (error) { |
| packages/extensions/ui-cordis/src/client/card-model.ts:65 | catch-clause | catch { |
| packages/extensions/ui-cordis/src/client/CordisPanel.tsx:194 | catch-clause | catch (error) { |
| packages/extensions/ui-cordis/tests/inventory.client.spec.ts:82 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- the non-Error rejection is the scenario. |
| packages/feedback/command-feedback/src/index.ts:21 | coverage-directive | v8 ignore next 3 -- only the ignored default arm calls this; the closed union cannot reach it via the public API. |
| packages/feedback/command-feedback/src/index.ts:35 | coverage-directive | v8 ignore next 2 -- the seam's closed union cannot reach the default; a future status must be given a sentence here. |
| packages/feedback/message-feedback/tests/helpers.ts:203 | catch-clause | catch (error) { |
| packages/fs/fs-local/src/fsio.ts:64 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:149 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:175 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:203 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:271 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:280 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:298 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:315 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:329 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:340 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:401 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:437 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:452 | catch-clause | catch (cleanupError: unknown) { |
| packages/fs/fs-local/src/fsio.ts:467 | catch-clause | catch (metadataError: unknown) { |
| packages/fs/fs-local/src/fsio.ts:558 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:564 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:575 | catch-clause | catch (_committedStagingCleanupFailure) { |
| packages/fs/fs-local/src/fsio.ts:578 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:583 | catch-clause | catch (closeError: unknown) { |
| packages/fs/fs-local/src/fsio.ts:706 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/fsio.ts:710 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-local/src/index.ts:239 | coverage-directive | v8 ignore next 5 -- the post-write probe finding the file absent requires a |
| packages/fs/fs-local/tests/fsio.spec.ts:132 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-observation-policy/src/index.ts:39 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-type-assertion -- The analyzers disagree on this weak type. |
| packages/fs/fs-sandbox/src/containment.ts:34 | catch-clause | catch (error: unknown) { |
| packages/fs/fs-sandbox/src/containment.ts:35 | coverage-directive | v8 ignore else -- a non-missing stat failure requires a host permission or I/O fault after resolve reached this ancestor. |
| packages/fs/fs-sandbox/src/containment.ts:37 | coverage-directive | v8 ignore next -- requires a host permission or I/O fault after resolve already reached this ancestor. |
| packages/fs/fs/src/text.ts:65 | catch-clause | catch (error: unknown) { |
| packages/fs/fs/src/text.ts:131 | catch-clause | catch (error: unknown) { |
| packages/fs/fs/src/text.ts:138 | catch-clause | catch (error: unknown) { |
| packages/fs/network-drive-webdav/src/index.ts:358 | catch-clause | catch (error: unknown) { |
| packages/fs/network-drive-webdav/src/index.ts:375 | catch-clause | catch (error: unknown) { |
| packages/fs/network-drive-webdav/src/index.ts:482 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-fs-search/src/grep.ts:142 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-fs-search/src/index.ts:128 | lint-directive | oxlint-disable-next-line typescript/require-await -- async keeps a load-time config rejection a rejection, not a synchronous throw |
| packages/fs/tool-fs-search/src/search-core.ts:246 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-fs-search/src/search-core.ts:252 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/fs/tool-fs-search/src/search-core.ts:261 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-fs-search/src/search-core.ts:271 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/fs/tool-fs-search/src/search-core.ts:427 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-fs/src/edit.ts:134 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-fs/src/read-image.ts:221 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-fs/src/write.ts:115 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-str-replace-editor/src/index.ts:268 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-str-replace-editor/src/index.ts:322 | catch-clause | catch (error: unknown) { |
| packages/fs/tool-str-replace-editor/src/index.ts:364 | catch-clause | catch (error: unknown) { |
| packages/goal/command-goal/src/index.ts:27 | coverage-directive | v8 ignore start -- closed-union backstop is unreachable without violating the TypeScript contract |
| packages/goal/command-goal/src/index.ts:31 | coverage-directive | v8 ignore stop |
| packages/goal/command-goal/src/index.ts:53 | coverage-directive | v8 ignore next 2 -- GoalPhase is closed and every member is handled above |
| packages/goal/command-goal/src/index.ts:71 | coverage-directive | v8 ignore next 2 -- the active branch and every non-active phase are handled above |
| packages/goal/command-goal/src/index.ts:79 | coverage-directive | v8 ignore next -- durable replay guarantees every blocked goal carries its validated reason |
| packages/goal/command-goal/src/index.ts:175 | coverage-directive | v8 ignore next 2 -- GoalCommand is closed and every member is handled above |
| packages/goal/command-goal/src/index.ts:178 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:121 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:146 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:193 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:209 | coverage-directive | v8 ignore next -- teardown may race a final trigger after synchronously closing the step fence |
| packages/goal/goal-round-driver/src/index.ts:220 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:226 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:270 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:358 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:375 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:402 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/index.ts:433 | coverage-directive | v8 ignore next -- followup reserves the live agent before publishing a queued attempt |
| packages/goal/goal-round-driver/src/invariant.ts:21 | catch-clause | catch (error: unknown) { |
| packages/goal/goal-round-driver/src/invariant.ts:22 | coverage-directive | v8 ignore next -- the strict goal decoder throws Error instances |
| packages/goal/goal/src/fold.ts:207 | coverage-directive | v8 ignore next -- a current goal established by this fold always has an updatedAt |
| packages/goal/goal/src/fold.ts:245 | coverage-directive | v8 ignore start -- the caller excludes create and GoalOperation is closed; these arms retain fail-loud exhaustiveness |
| packages/goal/goal/src/fold.ts:251 | coverage-directive | v8 ignore stop |
| packages/goal/goal/src/fold.ts:277 | coverage-directive | v8 ignore next -- a current goal established by this fold always has an updatedAt |
| packages/goal/goal/src/fold.ts:316 | coverage-directive | v8 ignore next -- the event's declared payload always identifies itself as a goal change. |
| packages/goal/goal/src/index.ts:102 | catch-clause | catch (_invalidPersistedGoalChange) { |
| packages/goal/goal/src/index.ts:488 | coverage-directive | v8 ignore next -- strict replay and every snapshot commit set createdAt whenever a current goal exists |
| packages/goal/goal/src/index.ts:505 | coverage-directive | v8 ignore next -- strict replay and every snapshot commit set updatedAt whenever a current goal exists |
| packages/goal/goal/src/index.ts:532 | coverage-directive | v8 ignore next -- the durable goal event installs the snapshot before this read |
| packages/goal/goal/src/index.ts:562 | coverage-directive | v8 ignore next 3 -- strict replay and snapshot commits establish both timestamps with every current goal |
| packages/goal/goal/src/invariant.ts:33 | catch-clause | catch (error) { |
| packages/goal/goal/src/invariant.ts:34 | coverage-directive | v8 ignore next -- the strict goal decoder throws Error instances |
| packages/goal/goal/src/runtime.ts:26 | lint-directive | oxlint-disable-next-line typescript/no-useless-constructor -- type-only narrowing |
| packages/hooks/hook-protocol/src/codec.ts:79 | catch-clause | catch { |
| packages/hooks/hook-protocol/src/config.ts:133 | catch-clause | catch (error: unknown) { |
| packages/hooks/hook-protocol/src/matcher.ts:24 | catch-clause | catch (_syntaxError) { |
| packages/hooks/hook-protocol/src/payload.ts:35 | coverage-directive | v8 ignore next -- agent-present callers are tool/stop extension points inside an open turn. |
| packages/hooks/hook-protocol/src/runner.ts:96 | catch-clause | catch (error: unknown) { |
| packages/host/directory-picker-auto/src/index.ts:89 | catch-clause | catch (cause) { |
| packages/host/directory-picker-auto/src/probe.ts:23 | catch-clause | catch { |
| packages/host/directory-picker-browse/src/index.ts:81 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- a full window (length === keep >= 1) has a tail |
| packages/host/directory-picker-browse/src/index.ts:88 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- bounded by the loop condition |
| packages/host/directory-picker-browse/src/index.ts:141 | coverage-directive | v8 ignore start -- a close failure of an abandoned handle has no consumer, and forcing one needs a filesystem torn down mid-request. |
| packages/host/directory-picker-browse/src/index.ts:144 | coverage-directive | v8 ignore stop |
| packages/host/directory-picker-browse/src/index.ts:148 | coverage-directive | v8 ignore next -- node:fs rejects with Error instances; the String arm only satisfies the unknown narrowing. |
| packages/host/directory-picker-browse/src/index.ts:167 | catch-clause | catch { |
| packages/host/directory-picker-browse/src/index.ts:168 | coverage-directive | v8 ignore next 2 -- an abort landing mid-probe needs a stalled stat; the per-candidate check in list covers the settled path. |
| packages/host/directory-picker-browse/src/index.ts:270 | coverage-directive | v8 ignore next 3 -- an abort between open and close needs a stalled read; the abandoned-close arm has no observable outcome. |
| packages/host/directory-picker-browse/src/index.ts:277 | catch-clause | catch (error: unknown) { |
| packages/host/directory-picker-browse/src/index.ts:317 | catch-clause | catch (error: unknown) { |
| packages/host/directory-picker-browse/tests/service.spec.ts:27 | catch-clause | catch { |
| packages/host/directory-picker-native/src/index.ts:23 | coverage-directive | v8 ignore next -- pure forward to pickNativeDirectory (its spec owns behavior); invoking here opens a real chooser. |
| packages/host/directory-picker-native/src/native-picker.ts:62 | catch-clause | catch (error: unknown) { |
| packages/host/directory-picker-native/src/native-picker.ts:85 | catch-clause | catch (error: unknown) { |
| packages/host/directory-picker-native/src/native-picker.ts:96 | catch-clause | catch (error: unknown) { |
| packages/host/directory-picker-native/src/win32-dialog-bindings.ts:124 | catch-clause | catch { |
| packages/host/directory-picker-native/src/win32-dialog-host.ts:26 | coverage-directive | v8 ignore next 3 -- the built-output arm: tests always run unbuilt (src/) |
| packages/host/directory-picker-native/src/win32-dialog-worker.ts:33 | coverage-directive | v8 ignore next 3 -- disconnect needs a live IPC channel the unit lane must not sever (built-worker.e2e.ts owns the real close path). |
| packages/host/directory-picker-native/src/win32-dialog-worker.ts:38 | coverage-directive | v8 ignore next 3 -- the handler exits(0), which would kill the unit lane; built-worker.e2e.ts owns the real disconnect lifecycle. |
| packages/host/directory-picker-native/src/win32-dialog-worker.ts:54 | catch-clause | catch (error: unknown) { |
| packages/host/directory-picker-native/src/win32-dialog.ts:54 | coverage-directive | v8 ignore start -- closed-union backstop; unreachable without a TypeScript contract violation |
| packages/host/directory-picker-native/src/win32-dialog.ts:58 | coverage-directive | v8 ignore stop |
| packages/host/directory-picker-native/src/win32-dialog.ts:143 | coverage-directive | v8 ignore next 2 -- closed worker-owned union; a fourth kind becomes a compile error |
| packages/host/frontend-static/src/index.ts:96 | catch-clause | catch (error) { |
| packages/host/frontend-static/src/index.ts:132 | coverage-directive | v8 ignore next -- node:http always sets url on server requests |
| packages/host/webserver/src/index.ts:222 | coverage-directive | v8 ignore next -- `?? '/'` arm: node:http always sets url on server |
| packages/host/webserver/src/index.ts:269 | coverage-directive | v8 ignore next -- node:http always sets url on server requests. |
| packages/host/webserver/src/index.ts:271 | catch-clause | catch (error) { |
| packages/host/webserver/src/index.ts:286 | catch-clause | catch (error) { |
| packages/host/webserver/src/invariant.ts:45 | catch-clause | catch { |
| packages/host/webserver/tests/webserver.spec.ts:369 | catch-clause | catch (error) { |
| packages/identity/anonymous-user-id/src/index.ts:49 | catch-clause | catch { |
| packages/identity/anonymous-user-id/src/index.ts:81 | catch-clause | catch { |
| packages/identity/anonymous-user-id/src/index.ts:90 | catch-clause | catch { |
| packages/interaction/commands/src/index.ts:121 | coverage-directive | v8 ignore next -- the first capture is required whenever the regular expression matches |
| packages/interaction/commands/src/index.ts:141 | catch-clause | catch { |
| packages/interaction/commands/src/index.ts:370 | catch-clause | catch (error: unknown) { |
| packages/interaction/commands/src/index.ts:392 | catch-clause | catch (error: unknown) { |
| packages/interaction/commands/src/index.ts:406 | catch-clause | catch (appendError: unknown) { |
| packages/interaction/commands/src/index.ts:451 | catch-clause | catch (error: unknown) { |
| packages/interaction/commands/tests/commands.spec.ts:140 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- exercises rejected-listener containment |
| packages/interaction/commands/tests/commands.spec.ts:233 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- exercise untyped plugin normalization |
| packages/interaction/commands/tests/commands.spec.ts:243 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- exercise hostile plugin normalization |
| packages/interaction/user-questions/src/index.ts:143 | catch-clause | catch (error) { |
| packages/jobs/jobs-local/src/index.ts:402 | catch-clause | catch (error: unknown) { |
| packages/jobs/jobs-local/src/index.ts:436 | catch-clause | catch (error: unknown) { |
| packages/jobs/jobs-local/src/index.ts:525 | catch-clause | catch (error: unknown) { |
| packages/jobs/tool-jobs/tests/tool-jobs.spec.ts:148 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/src/adapter.ts:481 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/src/adapter.ts:499 | catch-clause | catch (_abortedTransportTeardown) { |
| packages/llm/llm-deepseek/src/adapter.ts:581 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/src/adapter.ts:597 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/src/adapter.ts:611 | catch-clause | catch (error) { |
| packages/llm/llm-deepseek/src/adapter.ts:633 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/src/adapter.ts:650 | catch-clause | catch { |
| packages/llm/llm-deepseek/src/adapter.ts:680 | catch-clause | catch (error) { |
| packages/llm/llm-deepseek/src/file-store.ts:219 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/src/file-store.ts:229 | catch-clause | catch { |
| packages/llm/llm-deepseek/src/files-api.ts:152 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/src/files-api.ts:160 | catch-clause | catch { |
| packages/llm/llm-deepseek/src/image-tokens.ts:54 | coverage-directive | v8 ignore: at the provider budget the one-column solve always lands on |
| packages/llm/llm-deepseek/src/image-tokens.ts:57 | coverage-directive | v8 ignore next |
| packages/llm/llm-deepseek/src/image-tokens.ts:61 | coverage-directive | v8 ignore start -- unreachable at the provider budget: idealGridWidth >= 1 |
| packages/llm/llm-deepseek/src/image-tokens.ts:71 | coverage-directive | v8 ignore stop |
| packages/llm/llm-deepseek/src/image-tokens.ts:102 | coverage-directive | v8 ignore next 4 -- the published solver's safety net; the closed-form |
| packages/llm/llm-deepseek/src/image-tokens.ts:151 | coverage-directive | v8 ignore next 2 -- the published solver's non-convergence guard; every |
| packages/llm/llm-deepseek/src/index.ts:416 | catch-clause | catch (error) { |
| packages/llm/llm-deepseek/src/translate.ts:132 | catch-clause | catch { |
| packages/llm/llm-deepseek/src/upload-index.ts:87 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/src/upload-index.ts:126 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-deepseek/tests/adapter.spec.ts:741 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-litert/src/config.ts:218 | catch-clause | catch (error) { |
| packages/llm/llm-litert/src/index.ts:166 | catch-clause | catch (error) { |
| packages/llm/llm-litert/src/server.ts:322 | coverage-directive | v8 ignore next -- start() resolves the executable before any spawn. |
| packages/llm/llm-litert/tests/deploy.spec.ts:63 | catch-clause | catch (failure: unknown) { |
| packages/llm/llm-pi-ai/src/adapter.ts:403 | catch-clause | catch (_abortedSdkTeardown) { |
| packages/llm/llm-pi-ai/src/adapter.ts:408 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-pi-ai/src/auth.ts:223 | catch-clause | catch { |
| packages/llm/llm-pi-ai/src/discovery.ts:104 | coverage-directive | v8 ignore next -- fetch always exposes a body stream on a 2xx Response; the null guard is defensive. |
| packages/llm/llm-pi-ai/src/discovery.ts:118 | coverage-directive | v8 ignore next 4 -- cancel() after a completed or abandoned read settles without rejecting; unobserved best-effort cleanup. |
| packages/llm/llm-pi-ai/src/discovery.ts:253 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-pi-ai/src/discovery.ts:268 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-pi-ai/src/discovery.ts:280 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-pi-ai/src/index.ts:312 | catch-clause | catch (error) { |
| packages/llm/llm-pi-ai/src/index.ts:323 | catch-clause | catch (error) { |
| packages/llm/llm-pi-ai/src/login.ts:124 | coverage-directive | v8 ignore next 3 -- every id here names an installed provider and every |
| packages/llm/llm-pi-ai/src/login.ts:128 | coverage-directive | v8 ignore next 7 -- every installed catalog id is a lowercase |
| packages/llm/llm-pi-ai/src/replay.ts:46 | catch-clause | catch { |
| packages/llm/llm-pi-ai/src/replay.ts:206 | coverage-directive | v8 ignore next -- readReplayState rejects unknown replay tags, so an equal plugin-added Harness tag cannot reach this switch |
| packages/llm/llm-pi-ai/src/replay.ts:242 | catch-clause | catch (error: unknown) { |
| packages/llm/llm-pi-ai/src/replay.ts:243 | coverage-directive | v8 ignore next -- replayedAssistant throws only INVALID_REPLAY_STATE LlmErrors; the |
| packages/llm/llm-retry/src/history.ts:28 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/llm/llm-retry/src/index.ts:53 | catch-clause | catch (error: unknown) { |
| packages/llm/llm/src/adapter-failure.ts:35 | catch-clause | catch (_hostileThrownValue) { |
| packages/llm/llm/src/adapter-failure.ts:45 | catch-clause | catch (_sdkPropertyTrap) { |
| packages/llm/llm/src/adapter-failure.ts:57 | catch-clause | catch (_sdkPropertyTrap) { |
| packages/llm/llm/src/adapter-failure.ts:85 | catch-clause | catch (_sdkFailureGetter) { |
| packages/llm/llm/src/adapter-failure.ts:95 | catch-clause | catch (_sdkMessageGetter) { |
| packages/llm/llm/src/call-config.ts:96 | coverage-directive | v8 ignore next -- the loop condition guarantees one pending task. |
| packages/llm/llm/src/call-config.ts:111 | coverage-directive | v8 ignore next -- the loop is bounded by the captured key count. |
| packages/llm/llm/src/error.ts:142 | catch-clause | catch { |
| packages/llm/llm/src/index.ts:370 | catch-clause | catch (error) { |
| packages/llm/llm/src/index.ts:646 | catch-clause | catch (error: unknown) { |
| packages/llm/llm/src/index.ts:1022 | catch-clause | catch (error: unknown) { |
| packages/llm/llm/src/index.ts:1036 | catch-clause | catch (error: unknown) { |
| packages/llm/llm/src/invariant.ts:97 | catch-clause | catch { |
| packages/llm/llm/tests/api-key.spec.ts:55 | catch-clause | catch (error) { |
| packages/llm/llm/tests/api-key.spec.ts:66 | catch-clause | catch (error) { |
| packages/llm/llm/tests/assembler.spec.ts:75 | lint-directive | oxlint-disable |
| packages/llm/llm/tests/service.spec.ts:387 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors |
| packages/llm/llm/tests/service.spec.ts:1286 | catch-clause | catch (error: unknown) { |
| packages/llm/plugin-package-inventory-deepseek/src/index.ts:79 | coverage-directive | v8 ignore next -- active non-builtin package entries always have Node package search paths |
| packages/llm/plugin-package-inventory-deepseek/src/index.ts:110 | coverage-directive | v8 ignore next -- Loader entry trees inherit a base URL; the fallback supports direct embedders. |
| packages/llm/token-meter/src/index.ts:207 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- contiguous session seqs index the durable log |
| packages/llm/token-meter/src/index.ts:262 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/llm/token-meter/src/index.ts:315 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/llm/token-meter/src/route-pricing.ts:58 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion -- length equality is asserted above |
| packages/lsp/lsp-stdio/src/framing.ts:82 | catch-clause | catch (error) { |
| packages/lsp/lsp-stdio/src/framing.ts:83 | coverage-directive | v8 ignore next -- JSON.parse throws a SyntaxError (an Error); the String() fallback is defensive. |
| packages/lsp/lsp-stdio/src/host.ts:41 | catch-clause | catch (error: unknown) { |
| packages/lsp/lsp-stdio/src/host.ts:86 | catch-clause | catch (error: unknown) { |
| packages/lsp/lsp-stdio/src/host.ts:106 | catch-clause | catch (error: unknown) { |
| packages/lsp/lsp-stdio/src/index.ts:165 | catch-clause | catch (error: unknown) { |
| packages/lsp/lsp-stdio/src/index.ts:243 | coverage-directive | v8 ignore next -- the seam unregisters this provider before disposal; direct in-flight calls |
| packages/lsp/lsp-stdio/src/index.ts:282 | catch-clause | catch (error) { |
| packages/lsp/lsp-stdio/src/index.ts:327 | coverage-directive | v8 ignore next -- mismatch requires another query to replace the slot before this finally runs. |
| packages/lsp/lsp-stdio/src/translate.ts:38 | coverage-directive | v8 ignore next -- exhaustive over the closed LspOperation union; unreachable. |
| packages/lsp/lsp-stdio/src/translate.ts:50 | coverage-directive | v8 ignore next -- exhaustive over the closed LspOperation union; unreachable. |
| packages/lsp/lsp-stdio/tests/instance.spec.ts:423 | catch-clause | catch (error) { |
| packages/lsp/lsp-stdio/tests/instance.spec.ts:432 | catch-clause | catch (error) { |
| packages/lsp/lsp-stdio/tests/instance.spec.ts:477 | catch-clause | catch (error) { |
| packages/lsp/lsp-stdio/tests/lifecycle.spec.ts:469 | catch-clause | catch (error) { |
| packages/lsp/tool-lsp/src/index.ts:176 | coverage-directive | v8 ignore next -- exhaustive over the output schema's closed union; unreachable. |
| packages/lsp/tool-lsp/src/index.ts:225 | coverage-directive | v8 ignore next -- exhaustive over the closed LspQueryResult union; unreachable. |
| packages/lsp/tool-lsp/src/render.ts:145 | catch-clause | catch { |
| packages/lsp/tool-lsp/src/render.ts:171 | catch-clause | catch { |
| packages/mcp/mcp-client/src/connection.ts:258 | catch-clause | catch (error) { |
| packages/mcp/mcp-client/src/connection.ts:273 | catch-clause | catch (error) { |
| packages/mcp/mcp-client/src/connection.ts:278 | catch-clause | catch { /* transport already gone */ } |
| packages/mcp/mcp-client/src/connection.ts:315 | coverage-directive | v8 ignore next -- defensive: firstAttemptError is always set when connect/sync fails |
| packages/mcp/mcp-client/src/connection.ts:332 | catch-clause | catch { /* transport already gone */ } |
| packages/mcp/mcp-client/src/tools.ts:193 | catch-clause | catch (error) { |
| packages/mcp/mcp-client/src/tools.ts:257 | catch-clause | catch { |
| packages/mcp/mcp-client/src/tools.ts:443 | catch-clause | catch { |
| packages/mcp/mcp-client/src/tools.ts:478 | catch-clause | catch (error: unknown) { |
| packages/mcp/mcp-client/src/tools.ts:496 | catch-clause | catch (error: unknown) { |
| packages/mcp/mcp-client/src/tools.ts:509 | catch-clause | catch (error: unknown) { |
| packages/plan/plan-mode/src/index.ts:233 | catch-clause | catch (error) { |
| packages/preset/agent-presets/src/authoring.ts:87 | catch-clause | catch { |
| packages/preset/agent-presets/src/authoring.ts:108 | coverage-directive | v8 ignore next -- Windows exposes no POSIX owner-execute bit; the POSIX lane covers both file modes. |
| packages/preset/agent-presets/src/authoring.ts:163 | catch-clause | catch (error) { |
| packages/preset/agent-presets/src/discovery.ts:236 | catch-clause | catch { |
| packages/preset/agent-presets/src/discovery.ts:244 | catch-clause | catch (error) { |
| packages/preset/agent-presets/src/discovery.ts:245 | coverage-directive | v8 ignore next -- js-yaml throws YAMLException (an Error) for every parse failure; the fallback keeps a hostile value readable |
| packages/preset/agent-presets/src/discovery.ts:274 | catch-clause | catch { |
| packages/preset/agent-presets/src/discovery.ts:306 | catch-clause | catch (error) { |
| packages/preset/agent-presets/src/index.ts:439 | catch-clause | catch (error: unknown) { |
| packages/preset/agent-presets/src/index.ts:489 | catch-clause | catch (error: unknown) { |
| packages/preset/agent-presets/src/index.ts:530 | catch-clause | catch (error: unknown) { |
| packages/preset/agent-presets/src/index.ts:590 | catch-clause | catch (error: unknown) { |
| packages/preset/agent-presets/src/index.ts:625 | catch-clause | catch (error: unknown) { |
| packages/preset/agent-presets/src/metadata.ts:60 | catch-clause | catch { |
| packages/preset/agent-presets/src/metadata.ts:68 | catch-clause | catch { |
| packages/preset/agent-presets/src/mount.ts:87 | coverage-directive | v8 ignore next -- every PresetTree is constructed by `mountPreset`, which records the base first |
| packages/preset/agent-presets/src/mount.ts:91 | coverage-directive | v8 ignore next -- Node always supplies the internal module loader; the branch keeps a |
| packages/preset/agent-presets/src/mount.ts:200 | coverage-directive | v8 ignore next -- cordis deletes a store slot on disposal rather than |
| packages/preset/agent-presets/src/mount.ts:271 | coverage-directive | v8 ignore next -- cordis deletes a store slot on disposal rather than clearing it |
| packages/preset/agent-presets/src/mount.ts:293 | coverage-directive | v8 ignore next 4 -- the loader rejects an entry whose module or plugin failed, |
| packages/preset/agent-presets/src/mount.ts:340 | coverage-directive | v8 ignore next -- every path into the mount's catch throws an Error: the loader |
| packages/preset/agent-presets/src/mount.ts:374 | coverage-directive | v8 ignore next -- the Loader sets `baseUrl` on the root before any scoped context derives from it |
| packages/preset/agent-presets/src/mount.ts:384 | coverage-directive | v8 ignore next -- the subclass constructor runs before `await()` settles for every mounted tree |
| packages/preset/agent-presets/src/mount.ts:399 | catch-clause | catch (error) { |
| packages/preset/agent-presets/src/mount.ts:402 | coverage-directive | v8 ignore next 5 -- teardown of a subtree nothing else references has no |
| packages/preset/agent-presets/src/mount.ts:405 | catch-clause | catch { |
| packages/preset/agent-presets/tests/remote.spec.ts:41 | catch-clause | catch (error: unknown) { |
| packages/runtime-diagnostics/invariants/src/index.ts:87 | catch-clause | catch (cause) { |
| packages/runtime-diagnostics/invariants/src/index.ts:172 | catch-clause | catch (error) { |
| packages/runtime-diagnostics/invariants/src/index.ts:184 | catch-clause | catch (error) { |
| packages/runtime-diagnostics/invariants/src/index.ts:189 | catch-clause | catch (error) { |
| packages/runtime-diagnostics/invariants/src/index.ts:195 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- the extra runtime shape stays private. |
| packages/runtime-diagnostics/invariants/tests/service.spec.ts:198 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-local/src/index.ts:391 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-local/src/index.ts:397 | catch-clause | catch (cleanupError) { |
| packages/sandbox/sandbox-local/src/index.ts:413 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-local/src/index.ts:418 | catch-clause | catch (cleanupError) { |
| packages/sandbox/sandbox-local/src/index.ts:424 | catch-clause | catch (cleanupError) { |
| packages/sandbox/sandbox-local/src/index.ts:452 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-local/src/index.ts:459 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-local/tests/local.spec.ts:334 | catch-clause | catch (error: unknown) { |
| packages/sandbox/sandbox-local/tests/local.spec.ts:348 | catch-clause | catch (error: unknown) { |
| packages/sandbox/sandbox-policy/src/index.ts:58 | coverage-directive | v8 ignore next 4 -- SandboxMode is a typed same-process closed union; this branch is only the static exhaustiveness guard. |
| packages/sandbox/sandbox-windows-acl/src/acl.ts:95 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/src/grant.ts:90 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/src/grant.ts:97 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/src/index.ts:143 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/src/index.ts:239 | coverage-directive | v8 ignore next -- constructor validation requires workspace-write to supply |
| packages/sandbox/sandbox-windows-acl/src/index.ts:298 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/src/index.ts:313 | catch-clause | catch (cleanupError) { |
| packages/sandbox/sandbox-windows-acl/src/index.ts:401 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/src/index.ts:410 | coverage-directive | v8 ignore next -- init assigns this.api only after this.token, so an initialized instance always |
| packages/sandbox/sandbox-windows-acl/src/index.ts:415 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/src/runner.ts:196 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/src/runner.ts:203 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:97 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:110 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:124 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:137 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:152 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:165 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:190 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:216 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:231 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:255 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:270 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:337 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/acl-failure-paths.spec.ts:450 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/ffi.spec.ts:65 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/probe.spec.ts:29 | catch-clause | catch { |
| packages/sandbox/sandbox-windows-acl/tests/runner.spec.ts:66 | catch-clause | catch { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:34 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:53 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:75 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:93 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:148 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:160 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:172 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:194 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:206 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:231 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:248 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:302 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:314 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:331 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:343 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:357 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:413 | catch-clause | catch (error) { |
| packages/sandbox/sandbox-windows-acl/tests/token-failure-paths.spec.ts:430 | catch-clause | catch (error) { |
| packages/sandbox/sandbox/src/index.ts:172 | coverage-directive | v8 ignore next -- abstract service construction is covered through concrete provider packages. |
| packages/sandbox/sandbox/src/roots.ts:37 | catch-clause | catch { |
| packages/schedule/schedule/src/domain.ts:159 | coverage-directive | v8 ignore next -- successful fixed regexes always provide every requested group. |
| packages/schedule/schedule/src/domain.ts:202 | coverage-directive | v8 ignore next -- an in-range integral Date always formats as the canonical UTC profile. |
| packages/schedule/schedule/src/domain.ts:258 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/domain.ts:265 | coverage-directive | v8 ignore next -- Intl returns the requested canonical zone or an IANA canonical alias. |
| packages/schedule/schedule/src/domain.ts:304 | coverage-directive | v8 ignore next -- a formatter configured with longOffset always emits this part. |
| packages/schedule/schedule/src/domain.ts:307 | coverage-directive | v8 ignore next -- the formatter requested longOffset, whose part is defined by Intl. |
| packages/schedule/schedule/src/domain.ts:312 | coverage-directive | v8 ignore next -- some Intl builds spell UTC as bare GMT instead of GMT+00:00. |
| packages/schedule/schedule/src/domain.ts:538 | coverage-directive | v8 ignore next -- bounded operands and a quotient-derived product stay safe. |
| packages/schedule/schedule/src/domain.ts:610 | coverage-directive | v8 ignore next 3 -- decodeScheduleChange returns a closed operation union. |
| packages/schedule/schedule/src/invariant.ts:22 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/invariant.ts:23 | coverage-directive | v8 ignore next -- foldScheduleEvents normalizes every rejected stream to ScheduleLogError. |
| packages/schedule/schedule/src/persistence.ts:27 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/runtime.ts:111 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/runtime.ts:152 | coverage-directive | v8 ignore next -- only the exact stored run installs this callback. |
| packages/schedule/schedule/src/runtime.ts:155 | coverage-directive | v8 ignore next -- covers a trigger in the promise-settlement microtask gap. |
| packages/schedule/schedule/src/runtime.ts:212 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/runtime.ts:224 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/runtime.ts:236 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/runtime.ts:276 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/runtime.ts:299 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/runtime.ts:307 | catch-clause | catch (_busy: unknown) { |
| packages/schedule/schedule/src/runtime.ts:316 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/tools.ts:225 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/tools.ts:247 | catch-clause | catch { |
| packages/schedule/schedule/src/tools.ts:311 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/tools.ts:376 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/src/tools.ts:387 | catch-clause | catch { |
| packages/schedule/schedule/src/tools.ts:445 | catch-clause | catch { |
| packages/schedule/schedule/src/tools.ts:456 | catch-clause | catch (error) { |
| packages/schedule/schedule/tests/domain.spec.ts:184 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/tests/domain.spec.ts:231 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/tests/domain.spec.ts:247 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/tests/domain.spec.ts:375 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/tests/domain.spec.ts:388 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/tests/domain.spec.ts:403 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/tests/domain.spec.ts:425 | catch-clause | catch (error: unknown) { |
| packages/schedule/schedule/tests/domain.spec.ts:458 | catch-clause | catch (error: unknown) { |
| packages/sdk/client/src/client.ts:155 | catch-clause | catch (error) { |
| packages/sdk/client/src/client.ts:233 | coverage-directive | v8 ignore next |
| packages/sdk/client/src/client.ts:331 | coverage-directive | v8 ignore next -- start() either sets the transport or throws |
| packages/sdk/client/src/client.ts:349 | catch-clause | catch (error) { |
| packages/sdk/client/src/client.ts:413 | catch-clause | catch (error) { |
| packages/sdk/client/src/client.ts:458 | coverage-directive | v8 ignore next |
| packages/sdk/client/src/client.ts:510 | coverage-directive | v8 ignore next -- the transport and dispose ladder reject only with Errors |
| packages/sdk/client/src/dispose.ts:64 | catch-clause | catch (error: unknown) { |
| packages/sdk/client/src/index.ts:110 | catch-clause | catch (error) { |
| packages/sdk/client/src/index.ts:114 | catch-clause | catch (cleanupError: unknown) { |
| packages/sdk/protocol/src/transport.ts:198 | catch-clause | catch (error) { |
| packages/sdk/protocol/src/transport.ts:270 | catch-clause | catch { |
| packages/sdk/server/src/index.ts:65 | coverage-directive | v8 ignore next -- production stdio wiring; tests always inject the runtime hooks |
| packages/sdk/server/src/index.ts:67 | coverage-directive | v8 ignore next -- production stdio wiring; tests always inject the runtime hooks |
| packages/sdk/server/src/index.ts:69 | coverage-directive | v8 ignore next -- production exit wiring; tests always inject the runtime hooks |
| packages/sdk/server/src/server.ts:232 | catch-clause | catch (error) { |
| packages/session-query/session-log-export/src/archive.ts:173 | catch-clause | catch { |
| packages/session-query/session-log-export/src/archive.ts:414 | coverage-directive | v8 ignore next 3 -- fflate reports only internal zip failures, unreachable for valid inputs |
| packages/session-query/session-log-export/src/archive.ts:419 | coverage-directive | v8 ignore next -- fflate may emit empty chunks; not controllable from tests |
| packages/session-query/session-log-export/src/archive.ts:436 | catch-clause | catch (error) { |
| packages/session-query/session-log-export/src/archive.ts:439 | coverage-directive | v8 ignore next -- typed backends reject with Error, and DOMException is one in Node |
| packages/session-query/session-log-export/src/client/controller.ts:126 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-log-export/src/index.ts:140 | catch-clause | catch { |
| packages/session-query/session-query-sqlite/src/index.ts:240 | coverage-directive | v8 ignore next -- a stale optional-service disposer cannot clear a replacement |
| packages/session-query/session-query-sqlite/src/index.ts:340 | catch-clause | catch { |
| packages/session-query/session-query-sqlite/src/index.ts:361 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query-sqlite/src/index.ts:379 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query-sqlite/src/index.ts:448 | coverage-directive | v8 ignore next -- observation loads every entry whose revision differs |
| packages/session-query/session-query-sqlite/src/index.ts:460 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query-sqlite/src/index.ts:461 | coverage-directive | v8 ignore next -- a BEGIN failure has no transaction to roll back; the common wrapper still reports it. |
| packages/session-query/session-query-sqlite/src/index.ts:463 | coverage-directive | v8 ignore next 5 -- ROLLBACK failure requires a SQLite double fault; the original failure remains actionable. |
| packages/session-query/session-query-sqlite/src/index.ts:466 | catch-clause | catch { |
| packages/session-query/session-query-sqlite/src/index.ts:521 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query-sqlite/src/index.ts:755 | coverage-directive | v8 ignore next -- callers await `_ready`; this guards lifecycle misuse |
| packages/session-query/session-query-sqlite/src/index.ts:971 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query-sqlite/src/schema.ts:56 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/config.ts:44 | lint-directive | oxlint-disable-next-line typescript/no-useless-constructor |
| packages/session-query/session-query/src/corpus.ts:44 | coverage-directive | v8 ignore next -- a stale optional-service disposer cannot clear a replacement |
| packages/session-query/session-query/src/corpus.ts:159 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/corpus.ts:190 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/corpus.ts:210 | coverage-directive | v8 ignore start -- per-id failures settle inside resolvePersisted; workers reject only on abort above |
| packages/session-query/session-query/src/corpus.ts:217 | coverage-directive | v8 ignore stop |
| packages/session-query/session-query/src/corpus.ts:234 | catch-clause | catch (reason: unknown) { |
| packages/session-query/session-query/src/corpus.ts:235 | coverage-directive | v8 ignore next -- the synchronous projector has no external cancellation yield |
| packages/session-query/session-query/src/corpus.ts:258 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/corpus.ts:275 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/documents.ts:60 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/documents.ts:62 | coverage-directive | v8 ignore next -- foldSurface throws Error instances |
| packages/session-query/session-query/src/observation.ts:68 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/observation.ts:112 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/observation.ts:143 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/tracing.ts:47 | coverage-directive | v8 ignore next 6 -- analyzeEventLog validated contiguous seqs and foldSurface returned only surface-event seqs. |
| packages/session-query/session-query/src/tracing.ts:94 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/session-query/session-query/src/tracing.ts:182 | catch-clause | catch (error: unknown) { |
| packages/session-query/session-query/src/tracing.ts:184 | coverage-directive | v8 ignore next -- foldSurface throws Error instances |
| packages/session-query/session-query/src/tracing.ts:228 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/session-query/session-query/src/tracing.ts:238 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/session-query/session-query/tests/observation.spec.ts:132 | lint-directive | oxlint-disable-line typescript/prefer-promise-reject-errors |
| packages/session-query/session-query/tests/session-query.spec.ts:142 | lint-directive | oxlint-disable-line typescript/prefer-promise-reject-errors |
| packages/session-query/tool-session-query/src/service-boundary.ts:110 | catch-clause | catch (error: unknown) { |
| packages/session-query/tool-session-query/src/service-boundary.ts:137 | catch-clause | catch { |
| packages/session-query/tool-session-query/src/service-boundary.ts:153 | catch-clause | catch { |
| packages/session-query/tool-session-query/src/service-boundary.ts:168 | coverage-directive | v8 ignore next -- defensive containment for a cyclic Error.cause graph |
| packages/session-query/tool-session-query/tests/tool-session-query.spec.ts:1447 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- hostile unknown rejection is the scenario |
| packages/session/session-checkpoint-policy/tests/crash-recovery.e2e.ts:61 | catch-clause | catch (error: unknown) { |
| packages/session/session-log-deepseek/tests/invariant.spec.ts:69 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/format.ts:289 | catch-clause | catch { |
| packages/session/session-persistence-jsonl/src/format.ts:385 | catch-clause | catch { |
| packages/session/session-persistence-jsonl/src/format.ts:441 | catch-clause | catch { |
| packages/session/session-persistence-jsonl/src/index.ts:207 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-jsonl/src/index.ts:307 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-jsonl/src/index.ts:339 | coverage-directive | v8 ignore next -- a non-empty structural frame list makes the decoder yield its first frame or throw. |
| packages/session/session-persistence-jsonl/src/index.ts:369 | catch-clause | catch { |
| packages/session/session-persistence-jsonl/src/index.ts:370 | coverage-directive | v8 ignore next -- decoder failure plus concurrent abort is timing-dependent |
| packages/session/session-persistence-jsonl/src/index.ts:387 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:388 | coverage-directive | v8 ignore next -- decoder failure plus concurrent abort is timing-dependent |
| packages/session/session-persistence-jsonl/src/index.ts:444 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-jsonl/src/index.ts:501 | coverage-directive | v8 ignore next -- native Windows coverage exercises this platform dispatch; Linux covers the POSIX peer |
| packages/session/session-persistence-jsonl/src/index.ts:509 | coverage-directive | v8 ignore start -- Windows uses the Win32 durable-publish path; POSIX coverage exercises this peer. |
| packages/session/session-persistence-jsonl/src/index.ts:535 | coverage-directive | v8 ignore next -- link failure is the TOCTOU/IO race guarded above; not reachable in test |
| packages/session/session-persistence-jsonl/src/index.ts:547 | catch-clause | catch { |
| packages/session/session-persistence-jsonl/src/index.ts:548 | coverage-directive | v8 ignore next -- redundant temp link; publish already durable, rm failure is an unreachable IO edge |
| packages/session/session-persistence-jsonl/src/index.ts:551 | coverage-directive | v8 ignore stop |
| packages/session/session-persistence-jsonl/src/index.ts:553 | coverage-directive | v8 ignore start -- native Windows coverage exercises this integration path |
| packages/session/session-persistence-jsonl/src/index.ts:568 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:573 | coverage-directive | v8 ignore stop |
| packages/session/session-persistence-jsonl/src/index.ts:581 | coverage-directive | v8 ignore next 3 -- createCore guards collisions before materialize; this is a TOCTOU backstop |
| packages/session/session-persistence-jsonl/src/index.ts:619 | coverage-directive | v8 ignore start -- Windows uses write-through namespace operations; POSIX coverage exercises directory fsync. |
| packages/session/session-persistence-jsonl/src/index.ts:628 | coverage-directive | v8 ignore stop |
| packages/session/session-persistence-jsonl/src/index.ts:651 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:655 | catch-clause | catch (rollbackError) { |
| packages/session/session-persistence-jsonl/src/index.ts:743 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:744 | coverage-directive | v8 ignore next -- decoder failure plus concurrent abort is timing-dependent |
| packages/session/session-persistence-jsonl/src/index.ts:785 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:805 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:825 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:827 | coverage-directive | v8 ignore else -- non-ENOENT realpath failures require an external permission or I/O fault |
| packages/session/session-persistence-jsonl/src/index.ts:829 | coverage-directive | v8 ignore next -- non-ENOENT realpath failures are external I/O faults, propagated unchanged |
| packages/session/session-persistence-jsonl/src/index.ts:841 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:918 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:923 | coverage-directive | v8 ignore else -- Windows reports file-valued parents as ENOENT; POSIX covers direct ENOTDIR. |
| packages/session/session-persistence-jsonl/src/index.ts:928 | coverage-directive | v8 ignore next -- Windows repairs ENOTDIR from ENOENT above; POSIX covers direct ENOTDIR. |
| packages/session/session-persistence-jsonl/src/index.ts:933 | coverage-directive | v8 ignore start -- native Windows coverage exercises this repair; POSIX open reports ENOTDIR before this point. |
| packages/session/session-persistence-jsonl/src/index.ts:943 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/index.ts:948 | coverage-directive | v8 ignore stop |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts:44 | coverage-directive | v8 ignore next -- one test runtime exposes one Node-private shape; the Node 22/24/26 matrix checks compatibility. |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts:86 | coverage-directive | v8 ignore next -- reached only when a supported Node release changes its private stream shape. |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts:90 | coverage-directive | v8 ignore next -- the active Node runtime passed the private-shape probe above. |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts:92 | coverage-directive | v8 ignore next -- the active Node runtime passed the private-shape probe above. |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts:105 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts:119 | coverage-directive | v8 ignore next -- decode() rejects closed instances before entering this private frame operation. |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts:149 | coverage-directive | v8 ignore next -- Buffer cannot materialize a frame beyond its own process-wide maximum length. |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts:156 | coverage-directive | v8 ignore next -- structurally scanned ranges contain exactly one complete frame and no trailing bytes. |
| packages/session/session-persistence-jsonl/src/zstd-public-decoder.ts:24 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/tests/jsonl.spec.ts:57 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/tests/jsonl.spec.ts:68 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/tests/jsonl.spec.ts:722 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/tests/zstd.spec.ts:80 | catch-clause | catch { |
| packages/session/session-persistence-jsonl/tests/zstd.spec.ts:255 | catch-clause | catch (error) { |
| packages/session/session-persistence-jsonl/tests/zstd.spec.ts:266 | catch-clause | catch (error) { |
| packages/session/session-persistence-sqlite/src/codec.ts:65 | coverage-directive | v8 ignore next -- accepted is set only with its same-branch candidate. |
| packages/session/session-persistence-sqlite/src/compression.ts:302 | catch-clause | catch { |
| packages/session/session-persistence-sqlite/src/compression.ts:314 | catch-clause | catch { |
| packages/session/session-persistence-sqlite/src/schema.ts:97 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/schema.ts:134 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/schema.ts:135 | coverage-directive | v8 ignore else -- a failed begin leaves no transaction to roll back. |
| packages/session/session-persistence-sqlite/src/schema.ts:137 | coverage-directive | v8 ignore next 5 -- retain the original ownership failure if rollback fails too. |
| packages/session/session-persistence-sqlite/src/schema.ts:140 | catch-clause | catch { |
| packages/session/session-persistence-sqlite/src/store.ts:119 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/store.ts:129 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/store.ts:197 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/store.ts:209 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/store.ts:210 | coverage-directive | v8 ignore next -- validate/write failure uses the same transaction rollback path covered by append and repair. |
| packages/session/session-persistence-sqlite/src/store.ts:251 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/store.ts:312 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/store.ts:324 | catch-clause | catch (rollbackError: unknown) { |
| packages/session/session-persistence-sqlite/src/store.ts:325 | coverage-directive | v8 ignore next -- requires SQLite to fail both an operation and its immediate rollback. |
| packages/session/session-persistence-sqlite/src/store.ts:334 | coverage-directive | v8 ignore next -- materialized writes follow coordinator create(); other writes upsert in this transaction. |
| packages/session/session-persistence-sqlite/src/store.ts:358 | catch-clause | catch { |
| packages/session/session-persistence-sqlite/src/store.ts:420 | coverage-directive | v8 ignore start -- Windows exposes neither process.getuid nor meaningful |
| packages/session/session-persistence-sqlite/src/store.ts:425 | coverage-directive | v8 ignore stop |
| packages/session/session-persistence-sqlite/src/store.ts:434 | coverage-directive | v8 ignore start -- Windows exposes neither process.getuid nor meaningful |
| packages/session/session-persistence-sqlite/src/store.ts:439 | coverage-directive | v8 ignore stop |
| packages/session/session-persistence-sqlite/src/store.ts:445 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence-sqlite/src/store.ts:461 | coverage-directive | v8 ignore start -- Node 22 alone emits this warning; primary coverage runs on Node 24. |
| packages/session/session-persistence-sqlite/src/store.ts:482 | coverage-directive | v8 ignore stop |
| packages/session/session-persistence-sqlite/tests/sql-resource-boundary.spec.ts:23 | lint-directive | eslint-disable-line @stylistic/max-len |
| packages/session/session-persistence-sqlite/tests/sqlite.spec.ts:57 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/coordinator.ts:392 | coverage-directive | v8 ignore next -- a non-record current envelope cannot match a legacy shape. |
| packages/session/session-persistence/src/coordinator.ts:656 | coverage-directive | v8 ignore next -- successful live flush always initializes the exact session state. |
| packages/session/session-persistence/src/coordinator.ts:835 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/coordinator.ts:889 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/coordinator.ts:932 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/coordinator.ts:1003 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/coordinator.ts:1059 | coverage-directive | v8 ignore next -- successful flush always publishes this live session's durable state |
| packages/session/session-persistence/src/coordinator.ts:1177 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/coordinator.ts:1183 | catch-clause | catch (closeError: unknown) { |
| packages/session/session-persistence/src/coordinator.ts:1187 | coverage-directive | v8 ignore start -- close failure racing disposal is a defensive teardown edge |
| packages/session/session-persistence/src/coordinator.ts:1189 | coverage-directive | v8 ignore stop |
| packages/session/session-persistence/src/coordinator.ts:1294 | coverage-directive | v8 ignore next -- a cursor > 0 means the session was materialized, so it exists |
| packages/session/session-persistence/src/coordinator.ts:1318 | coverage-directive | v8 ignore next -- initFor dedupes per session object; same-object re-entry can't occur |
| packages/session/session-persistence/src/coordinator.ts:1367 | coverage-directive | v8 ignore next -- create() always sets the state for the id |
| packages/session/session-persistence/src/coordinator.ts:1407 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/coordinator.ts:1433 | coverage-directive | v8 ignore next -- state is always set by the awaited initialization |
| packages/session/session-persistence/src/preparations.ts:94 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/preparations.ts:137 | coverage-directive | v8 ignore next -- committing/reserved transitions install this waiter synchronously. |
| packages/session/session-persistence/src/preparations.ts:151 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/preparations.ts:162 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/preparations.ts:301 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/src/preparations.ts:379 | catch-clause | catch (reason: unknown) { |
| packages/session/session-persistence/src/preparations.ts:383 | coverage-directive | v8 ignore next -- a native AbortSignal emits abort only after becoming aborted. |
| packages/session/session-persistence/src/write-behind.ts:126 | catch-clause | catch (error: unknown) { |
| packages/session/session-persistence/tests/persistence.spec.ts:172 | coverage-directive | v8 ignore next -- commitRepair only runs for a materialized (stored) session |
| packages/session/session-persistence/tests/persistence.spec.ts:341 | catch-clause | catch { |
| packages/session/session-persistence/tests/persistence.spec.ts:348 | catch-clause | catch { |
| packages/session/session-persistence/tests/persistence.spec.ts:354 | catch-clause | catch { |
| packages/session/session-projection-cache/src/index.ts:165 | catch-clause | catch { |
| packages/session/session-projection-cache/tests/cache.spec.ts:113 | catch-clause | catch { |
| packages/session/session-projection/src/index.ts:268 | coverage-directive | v8 ignore next -- the disposer runs once per successful registration, so the entry it counted is still here |
| packages/session/session-projection/src/index.ts:445 | catch-clause | catch { |
| packages/session/session-telemetry-otel/src/index.ts:81 | coverage-directive | v8 ignore next 2 -- resolveMode already rejected unknown values before this switch; the closed enum cannot reach the default. |
| packages/session/session-telemetry-otel/src/index.ts:177 | catch-clause | catch { |
| packages/session/session-telemetry-otel/src/index.ts:295 | coverage-directive | v8 ignore else -- the Promise executor assigns timer synchronously before this race starts. |
| packages/session/session-telemetry/src/coordinator.ts:122 | catch-clause | catch (error) { |
| packages/session/session-telemetry/src/coordinator.ts:264 | catch-clause | catch (error) { |
| packages/session/session-title-llm/tests/llm.spec.ts:39 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- exercise exact AbortSignal.reason propagation |
| packages/session/session-title/src/index.ts:215 | coverage-directive | v8 ignore next -- closed-union exhaustiveness guard |
| packages/session/session-title/src/index.ts:383 | coverage-directive | v8 ignore next -- unreachable: the append above just committed a session/title event. |
| packages/session/session-title/src/index.ts:484 | catch-clause | catch (error: unknown) { |
| packages/session/session-title/src/index.ts:536 | catch-clause | catch (error: unknown) { |
| packages/session/session-title/src/index.ts:642 | coverage-directive | v8 ignore next -- every supported supersession, provider disposal, and session disposal aborts |
| packages/settings/settings-file/src/index.ts:140 | catch-clause | catch (error) { |
| packages/settings/settings-file/src/index.ts:214 | coverage-directive | v8 ignore next -- `prettyErrors` populates linePos on every error; the guard answers its optional type |
| packages/settings/settings/src/index.ts:524 | catch-clause | catch { |
| packages/settings/settings/src/index.ts:694 | catch-clause | catch (error) { |
| packages/settings/settings/src/index.ts:721 | catch-clause | catch { |
| packages/settings/settings/src/index.ts:732 | catch-clause | catch (error) { |
| packages/settings/settings/src/index.ts:793 | catch-clause | catch (error) { |
| packages/settings/settings/src/index.ts:851 | catch-clause | catch (error) { |
| packages/shell/bash-sandbox/tests/partial-landlock.spec.ts:165 | catch-clause | catch (error) { |
| packages/shell/bash-sandbox/tests/sandbox.spec.ts:245 | catch-clause | catch (error) { |
| packages/shell/bash-sandbox/tests/sandbox.spec.ts:288 | catch-clause | catch (error) { |
| packages/shell/bash-sandbox/tests/sandbox.spec.ts:582 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors |
| packages/shell/pwsh-local/src/resolve.ts:50 | catch-clause | catch { |
| packages/shell/shell/src/confinement.ts:109 | catch-clause | catch (error) { |
| packages/shell/shell/src/confinement.ts:148 | catch-clause | catch (error) { |
| packages/shell/shell/src/sandbox-classify.ts:30 | catch-clause | catch { |
| packages/shell/shell/src/subprocess-executor.ts:202 | coverage-directive | v8 ignore start -- collect dispositions expose both readers by the seam contract; defensive. |
| packages/shell/shell/src/subprocess-executor.ts:206 | coverage-directive | v8 ignore stop |
| packages/shell/tool-shell-persistent/src/index.ts:282 | catch-clause | catch (error: unknown) { |
| packages/shell/tool-shell-persistent/src/index.ts:337 | catch-clause | catch (error: unknown) { |
| packages/skill/skill-filesystem/src/index.ts:189 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:332 | coverage-directive | v8 ignore next -- the loop condition proves one project exists. |
| packages/skill/skill-filesystem/src/index.ts:377 | coverage-directive | v8 ignore next -- Concurrent cwd observations can evict the same shared root before this release settles. |
| packages/skill/skill-filesystem/src/index.ts:389 | coverage-directive | v8 ignore next -- A scheduled rewatch can reach this guard only when teardown wins its await. |
| packages/skill/skill-filesystem/src/index.ts:411 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- watcher callbacks can mark unhealthy while the probe awaits |
| packages/skill/skill-filesystem/src/index.ts:421 | coverage-directive | v8 ignore next -- Teardown can win while an unhealthy watcher is still closing. |
| packages/skill/skill-filesystem/src/index.ts:425 | coverage-directive | v8 ignore next -- The loop returns no handle only when teardown wins between awaited probes. |
| packages/skill/skill-filesystem/src/index.ts:427 | coverage-directive | v8 ignore start -- Post-open teardown is timing-dependent; the disposal race has an explicit integration test. |
| packages/skill/skill-filesystem/src/index.ts:428 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- teardown can race awaited watcher startup |
| packages/skill/skill-filesystem/src/index.ts:433 | coverage-directive | v8 ignore stop |
| packages/skill/skill-filesystem/src/index.ts:436 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:437 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- teardown can race awaited watcher startup |
| packages/skill/skill-filesystem/src/index.ts:455 | coverage-directive | v8 ignore else -- A host path transition between the two probes is timing-dependent. |
| packages/skill/skill-filesystem/src/index.ts:457 | coverage-directive | v8 ignore next -- Covered by the same host path transition guard. |
| packages/skill/skill-filesystem/src/index.ts:460 | coverage-directive | v8 ignore next -- The loop exits only when teardown wins between awaited probes. |
| packages/skill/skill-filesystem/src/index.ts:489 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:490 | coverage-directive | v8 ignore start -- Non-absence stat failures need a platform permission or I/O fault. |
| packages/skill/skill-filesystem/src/index.ts:493 | coverage-directive | v8 ignore stop |
| packages/skill/skill-filesystem/src/index.ts:547 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:593 | coverage-directive | v8 ignore next -- Effect teardown can win this queued microtask before provider disposal emits. |
| packages/skill/skill-filesystem/src/index.ts:602 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:612 | catch-clause | catch { |
| packages/skill/skill-filesystem/src/index.ts:646 | coverage-directive | v8 ignore next -- candidate is a strict ancestor of root. |
| packages/skill/skill-filesystem/src/index.ts:650 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:651 | coverage-directive | v8 ignore next -- Non-absence stat failures are platform/permission-specific and propagate as incomplete discovery. |
| packages/skill/skill-filesystem/src/index.ts:655 | coverage-directive | v8 ignore next -- Traversal reaches the existing filesystem root before this fallback. |
| packages/skill/skill-filesystem/src/index.ts:767 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:786 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:787 | coverage-directive | v8 ignore else -- Native non-absence directory failures are provider-dependent; the ctx.fs path pins incomplete discovery. |
| packages/skill/skill-filesystem/src/index.ts:789 | coverage-directive | v8 ignore next -- Same native error branch as above. |
| packages/skill/skill-filesystem/src/index.ts:811 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:832 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:858 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:871 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:879 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:887 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:903 | coverage-directive | v8 ignore next -- Non-file directory entries such as FIFOs are platform-specific and intentionally skipped. |
| packages/skill/skill-filesystem/src/index.ts:908 | coverage-directive | v8 ignore else -- the special-file symlink branch relies on POSIX /dev/null. |
| packages/skill/skill-filesystem/src/index.ts:910 | coverage-directive | v8 ignore next -- The special-file symlink fixture relies on POSIX /dev/null. |
| packages/skill/skill-filesystem/src/index.ts:912 | catch-clause | catch (error) { |
| packages/skill/skill-filesystem/src/index.ts:969 | catch-clause | catch { |
| packages/skill/skill-filesystem/src/index.ts:975 | catch-clause | catch { |
| packages/skill/skill-filesystem/src/index.ts:985 | catch-clause | catch { |
| packages/skill/skill-filesystem/tests/skill-filesystem.spec.ts:66 | catch-clause | catch { |
| packages/skill/skill-filesystem/tests/skill-filesystem.spec.ts:80 | catch-clause | catch { |
| packages/skill/skill-filesystem/tests/skill-filesystem.spec.ts:116 | catch-clause | catch { |
| packages/skill/skill/src/index.ts:218 | coverage-directive | v8 ignore start -- SkillResourceBase is a closed union; a future kind must fail compilation here. |
| packages/skill/skill/src/index.ts:221 | coverage-directive | v8 ignore stop |
| packages/skill/skill/src/index.ts:433 | catch-clause | catch (error) { |
| packages/skill/skill/src/index.ts:613 | catch-clause | catch (error) { |
| packages/skill/skill/src/index.ts:638 | coverage-directive | v8 ignore else -- A definition load can outlive the exact provider registration it selected. |
| packages/skill/skill/src/index.ts:671 | catch-clause | catch (error: unknown) { |
| packages/skill/skill/src/index.ts:698 | coverage-directive | v8 ignore next -- Runtime skills are injected directly by the registry; this provider only owns `get()`. |
| packages/skill/skill/src/index.ts:868 | catch-clause | catch { |
| packages/skill/skill/src/index.ts:878 | catch-clause | catch { |
| packages/skill/skill/tests/skill.spec.ts:773 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- deliberate rejection proves notification containment |
| packages/skill/skill/tests/skill.spec.ts:939 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors |
| packages/skill/tool-skill/src/index.ts:383 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/spill/spill-local/src/cleanup.ts:40 | catch-clause | catch { |
| packages/spill/spill-local/src/cleanup.ts:142 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:158 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:165 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:217 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:242 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:251 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:292 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:310 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:322 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:334 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/cleanup.ts:362 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/store.ts:115 | catch-clause | catch (error: unknown) { |
| packages/spill/spill-local/src/store.ts:116 | coverage-directive | v8 ignore start -- requires another process to remove the directory |
| packages/spill/spill-local/src/store.ts:120 | coverage-directive | v8 ignore stop |
| packages/spill/spill-policy/src/index.ts:156 | catch-clause | catch (error: unknown) { |
| packages/storage/storage-domain/src/domain.ts:254 | catch-clause | catch (error) { |
| packages/storage/storage-domain/src/index.ts:158 | catch-clause | catch (error) { |
| packages/storage/storage-domain/src/index.ts:162 | catch-clause | catch (error) { |
| packages/storage/storage-json/src/format.ts:51 | catch-clause | catch (error) { |
| packages/storage/storage-json/src/format.ts:128 | catch-clause | catch { |
| packages/storage/storage-json/src/initialization.ts:103 | catch-clause | catch (error) { |
| packages/storage/storage-json/src/initialization.ts:110 | catch-clause | catch { |
| packages/storage/storage-json/src/per-record-unit.ts:73 | catch-clause | catch { |
| packages/storage/storage-json/src/single-unit.ts:37 | catch-clause | catch (error) { |
| packages/storage/storage-sqlite/src/index.ts:150 | catch-clause | catch { |
| packages/storage/storage-sqlite/src/schema.ts:74 | catch-clause | catch (error: unknown) { |
| packages/storage/storage-sqlite/src/unit.ts:90 | catch-clause | catch (error) { |
| packages/storage/storage-sqlite/src/unit.ts:136 | catch-clause | catch (error) { |
| packages/subagent/agent-team/src/index.ts:487 | catch-clause | catch (error) { |
| packages/subagent/agent-team/src/index.ts:546 | catch-clause | catch (error: unknown) { |
| packages/subagent/agent-team/src/invariant.ts:24 | catch-clause | catch (error: unknown) { |
| packages/subagent/agent-team/src/lifecycle.ts:61 | catch-clause | catch (error: unknown) { |
| packages/subagent/agent-team/src/mailbox.ts:285 | catch-clause | catch (error: unknown) { |
| packages/subagent/agent-team/src/mailbox.ts:351 | catch-clause | catch (error: unknown) { |
| packages/subagent/agent-team/src/roster.ts:118 | catch-clause | catch { |
| packages/subagent/agent-team/src/roster.ts:297 | catch-clause | catch (error: unknown) { |
| packages/subagent/agent-team/src/roster.ts:313 | catch-clause | catch (recordError: unknown) { |
| packages/subagent/agent-team/src/roster.ts:334 | catch-clause | catch (cleanupError: unknown) { |
| packages/subagent/agent-team/src/roster.ts:416 | catch-clause | catch (error: unknown) { |
| packages/subagent/agent-team/tests/persistence.spec.ts:53 | catch-clause | catch (error: unknown) { |
| packages/subagent/agent-team/tests/persistence.spec.ts:60 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-acp/src/index.ts:99 | catch-clause | catch { |
| packages/subagent/subagent-acp/src/index.ts:168 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-acp/src/run.ts:133 | coverage-directive | v8 ignore next -- Windows does not report POSIX child signals in SubprocessOutcome. |
| packages/subagent/subagent-acp/src/run.ts:281 | coverage-directive | v8 ignore next |
| packages/subagent/subagent-acp/src/run.ts:289 | catch-clause | catch { |
| packages/subagent/subagent-acp/src/run.ts:305 | coverage-directive | v8 ignore next -- Windows anonymous pipes cannot expose a live-child protocol close during startup. |
| packages/subagent/subagent-acp/src/run.ts:369 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-acp/src/run.ts:373 | coverage-directive | v8 ignore start -- 'pipe' dispositions expose both streams by the seam contract; defensive. |
| packages/subagent/subagent-acp/src/run.ts:377 | coverage-directive | v8 ignore stop |
| packages/subagent/subagent-acp/src/run.ts:389 | coverage-directive | v8 ignore next -- the success arm's never-settling executor is intentionally empty. |
| packages/subagent/subagent-acp/src/run.ts:400 | coverage-directive | v8 ignore next -- Windows cannot expose the live-child protocol close needed to await this abort. |
| packages/subagent/subagent-acp/src/run.ts:403 | coverage-directive | v8 ignore next -- closes the event-loop race between listener registration and the preceding derived-signal check. |
| packages/subagent/subagent-acp/src/run.ts:407 | catch-clause | catch { |
| packages/subagent/subagent-acp/src/run.ts:409 | coverage-directive | v8 ignore next -- a published child.done cannot reject; spawn rejection is consumed before publication. |
| packages/subagent/subagent-acp/src/run.ts:476 | coverage-directive | v8 ignore next |
| packages/subagent/subagent-acp/src/run.ts:532 | coverage-directive | v8 ignore next -- cancelSettled wins the startup race before this post-response guard can settle it. |
| packages/subagent/subagent-acp/src/run.ts:538 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-acp/src/run.ts:562 | catch-clause | catch (cleanupError: unknown) { |
| packages/subagent/subagent-acp/src/run.ts:584 | coverage-directive | v8 ignore next |
| packages/subagent/subagent-acp/src/run.ts:606 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-acp/src/run.ts:609 | coverage-directive | v8 ignore next -- Windows anonymous pipes cannot expose a live-child prompt transport failure. |
| packages/subagent/subagent-acp/src/run.ts:637 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-acp/tests/subagent-acp.spec.ts:72 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-claude-code/src/index.ts:96 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-claude-code/src/process.ts:21 | coverage-directive | v8 ignore next -- the subprocess seam rejects with Error. |
| packages/subagent/subagent-claude-code/src/run.ts:271 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-claude-code/src/run.ts:278 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-claude-code/src/run.ts:395 | catch-clause | catch { |
| packages/subagent/subagent-claude-code/src/run.ts:438 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-claude-code/src/run.ts:458 | catch-clause | catch (disposeError: unknown) { |
| packages/subagent/subagent-claude-code/src/run.ts:465 | catch-clause | catch (childError: unknown) { |
| packages/subagent/subagent-claude-code/src/run.ts:492 | catch-clause | catch (disposeError: unknown) { |
| packages/subagent/subagent-claude-code/src/run.ts:505 | catch-clause | catch (disposeError: unknown) { |
| packages/subagent/subagent-claude-code/src/run.ts:543 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-claude-code/src/run.ts:585 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/index.ts:90 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/run.ts:198 | coverage-directive | v8 ignore next -- a positive pid excludes spawn-level done rejection. |
| packages/subagent/subagent-codex/src/run.ts:203 | catch-clause | catch { |
| packages/subagent/subagent-codex/src/run.ts:209 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/run.ts:250 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/run.ts:269 | catch-clause | catch { |
| packages/subagent/subagent-codex/src/run.ts:328 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/run.ts:345 | catch-clause | catch (disposeError: unknown) { |
| packages/subagent/subagent-codex/src/run.ts:357 | catch-clause | catch { |
| packages/subagent/subagent-codex/src/run.ts:400 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/run.ts:415 | catch-clause | catch { |
| packages/subagent/subagent-codex/src/wire.ts:207 | coverage-directive | v8 ignore next -- typed protocol and stream failures reject with Error. |
| packages/subagent/subagent-codex/src/wire.ts:284 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/wire.ts:386 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/wire.ts:399 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-codex/src/wire.ts:703 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-dsh-sdk/src/index.ts:104 | catch-clause | catch { |
| packages/subagent/subagent-dsh-sdk/src/index.ts:152 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-dsh-sdk/src/run.ts:196 | coverage-directive | v8 ignore next |
| packages/subagent/subagent-dsh-sdk/src/run.ts:204 | catch-clause | catch { |
| packages/subagent/subagent-dsh-sdk/src/run.ts:289 | coverage-directive | v8 ignore next |
| packages/subagent/subagent-dsh-sdk/src/run.ts:291 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-dsh-sdk/src/run.ts:298 | catch-clause | catch (cleanupError: unknown) { |
| packages/subagent/subagent-dsh-sdk/src/run.ts:320 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-dsh-sdk/src/run.ts:346 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent-in-process-driver/src/structured.ts:122 | coverage-directive | v8 ignore else -- sequential agent-loop dispatch lets the guard block every later supported call |
| packages/subagent/subagent-in-process-driver/src/structured.ts:125 | coverage-directive | v8 ignore else -- PTC mode serializes sub-dispatches, so the guard blocks every later supported call |
| packages/subagent/subagent-in-process-driver/src/structured.ts:136 | coverage-directive | v8 ignore else -- PTC mode serializes outer executions, so the guard blocks every later supported call |
| packages/subagent/subagent/src/activation-setup-registry.ts:94 | coverage-directive | v8 ignore next -- only a synchronous re-entrant revocation of an |
| packages/subagent/subagent/src/activation-setup-registry.ts:116 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/activation-setup-registry.ts:120 | catch-clause | catch (_releaseFailure) { |
| packages/subagent/subagent/src/activation-setup-registry.ts:121 | coverage-directive | v8 ignore next -- requires independent installer and rollback faults. |
| packages/subagent/subagent/src/activation-setup-registry.ts:156 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/activation-setup-registry.ts:174 | coverage-directive | v8 ignore next 4 -- every live installation is indexed until this method removes it. |
| packages/subagent/subagent/src/continuation.ts:315 | coverage-directive | v8 ignore next 4 -- `SubagentResult['stopReason']` is merge-extensible, so this arm |
| packages/subagent/subagent/src/continuation.ts:520 | coverage-directive | v8 ignore next 3 -- the send-versus-dispose cutoff: reaching this arm needs a |
| packages/subagent/subagent/src/continuation.ts:529 | coverage-directive | v8 ignore start -- only the lost-cutoff arm above returns undefined, so only that |
| packages/subagent/subagent/src/continuation.ts:534 | coverage-directive | v8 ignore stop |
| packages/subagent/subagent/src/continuation.ts:634 | coverage-directive | v8 ignore next 6 -- only a synchronous re-entrant disposer can open this |
| packages/subagent/subagent/src/continuation.ts:648 | coverage-directive | v8 ignore next -- every continuation-managed child has direct-parent metadata. |
| packages/subagent/subagent/src/continuation.ts:716 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:857 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:961 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:999 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:1025 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:1026 | coverage-directive | v8 ignore next -- rollback disposal failures must not mask the |
| packages/subagent/subagent/src/continuation.ts:1127 | coverage-directive | v8 ignore next -- a claim of an id this manager never admitted needs |
| packages/subagent/subagent/src/continuation.ts:1139 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:1142 | coverage-directive | v8 ignore next -- rollback failure must not mask the admission failure |
| packages/subagent/subagent/src/continuation.ts:1239 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:1263 | coverage-directive | v8 ignore next 6 -- only a synchronous re-entrant disposer can change |
| packages/subagent/subagent/src/continuation.ts:1389 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:1407 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:1416 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:1515 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/continuation.ts:1533 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/control.ts:47 | coverage-directive | v8 ignore next -- Intl returns UTC or a canonical IANA Area/Location for accepted input. |
| packages/subagent/subagent/src/control.ts:50 | catch-clause | catch { |
| packages/subagent/subagent/src/index.ts:250 | coverage-directive | v8 ignore else -- one injected binding owns the slot until its fiber disposes. |
| packages/subagent/subagent/src/index.ts:450 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/index.ts:499 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/index.ts:527 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/index.ts:625 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/index.ts:639 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/invariant.ts:65 | coverage-directive | v8 ignore next -- internal/dispatch stages the same provider object |
| packages/subagent/subagent/src/invariant.ts:70 | coverage-directive | v8 ignore next -- internal/dispatch stages the same provider name |
| packages/subagent/subagent/src/invariant.ts:75 | coverage-directive | v8 ignore next -- internal/dispatch stages the same lifecycle object |
| packages/subagent/subagent/src/invariant.ts:80 | coverage-directive | v8 ignore next -- internal/dispatch stages the same lifecycle object |
| packages/subagent/subagent/src/lifecycle.ts:118 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/lifecycle.ts:256 | coverage-directive | v8 ignore next 3 -- `TurnEndReason` is merge-extensible, so this arm needs a |
| packages/subagent/subagent/src/lifecycle.ts:268 | catch-clause | catch { |
| packages/subagent/subagent/src/list-children.ts:159 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/list-children.ts:203 | catch-clause | catch { |
| packages/subagent/subagent/src/list-children.ts:257 | lint-directive | oxlint-disable-next-line typescript/no-non-null-assertion |
| packages/subagent/subagent/src/list-children.ts:297 | catch-clause | catch { |
| packages/subagent/subagent/src/list-children.ts:321 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/out-of-process.ts:196 | catch-clause | catch { |
| packages/subagent/subagent/src/out-of-process.ts:299 | coverage-directive | v8 ignore next |
| packages/subagent/subagent/src/out-of-process.ts:337 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/out-of-process.ts:343 | catch-clause | catch { |
| packages/subagent/subagent/src/projection.ts:145 | catch-clause | catch { |
| packages/subagent/subagent/src/run-settlement.ts:65 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/src/run-settlement.ts:70 | catch-clause | catch (error: unknown) { |
| packages/subagent/subagent/tests/continuation.spec.ts:60 | catch-clause | catch (error) { errors.push(error) } |
| packages/subagent/subagent/tests/list-children.spec.ts:355 | lint-directive | oxlint-disable-line typescript/prefer-promise-reject-errors |
| packages/subagent/subagent/tests/service.spec.ts:303 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- exercises rejected-listener containment |
| packages/subagent/tool-agent-team/src/index.ts:470 | catch-clause | catch (error: unknown) { |
| packages/subagent/tool-subagent-control/src/list-agents.ts:186 | coverage-directive | v8 ignore next 2 -- the resolver normalizes the schema-validated closed scope before dispatch. |
| packages/subagent/tool-subagent-report/src/index.ts:105 | catch-clause | catch (error: unknown) { |
| packages/subagent/tool-subagent-report/src/index.ts:108 | catch-clause | catch (rollbackError: unknown) { |
| packages/subagent/tool-subagent-report/src/index.ts:121 | catch-clause | catch (error: unknown) { |
| packages/subagent/tool-subagent-report/tests/tool-subagent-report.spec.ts:413 | catch-clause | catch (error: unknown) { |
| packages/subagent/tool-subagent-report/tests/tool-subagent-report.spec.ts:439 | catch-clause | catch (error: unknown) { |
| packages/subagent/tool-subagent/src/index.ts:147 | catch-clause | catch (error: unknown) { |
| packages/subagent/tool-subagent/src/index.ts:655 | coverage-directive | v8 ignore next -- Agent and preset scopes are minted only by the Agent registry. |
| packages/subagent/tool-subagent/src/index.ts:681 | coverage-directive | v8 ignore next 3 -- Cordis Fiber disposal contains registration cleanup failures; this is the final diagnostic sink. |
| packages/subagent/tool-subagent/src/model-selection-settings.ts:47 | coverage-directive | v8 ignore next |
| packages/subagent/tool-subagent/tests/tool-subagent.spec.ts:51 | catch-clause | catch (error: unknown) { |
| packages/subagent/tool-subagent/tests/tool-subagent.spec.ts:652 | catch-clause | catch { |
| packages/subprocess/subprocess-local/src/index.ts:121 | catch-clause | catch (_ordinaryTreeTerminationFailed) { |
| packages/subprocess/subprocess-local/src/index.ts:128 | catch-clause | catch (_terminalTerminationFailed) { |
| packages/subprocess/subprocess-local/src/index.ts:182 | catch-clause | catch { |
| packages/subprocess/subprocess-local/src/process-inspector.ts:112 | coverage-directive | v8 ignore start -- thin OS bindings; injected logic is unit-tested and real platform composition exercises them. |
| packages/subprocess/subprocess-local/src/process-inspector.ts:124 | coverage-directive | v8 ignore stop |
| packages/subprocess/subprocess-local/src/process-inspector.ts:163 | catch-clause | catch (_unreadableProcEntry) { |
| packages/subprocess/subprocess-local/src/process-inspector.ts:192 | catch-clause | catch (_unreadableStdinDevice) { |
| packages/subprocess/subprocess-local/src/process-inspector.ts:212 | catch-clause | catch (_unreadableProcDirectory) { |
| packages/subprocess/subprocess-local/src/process-inspector.ts:229 | catch-clause | catch (_unreadableProcDirectory) { |
| packages/subprocess/subprocess-local/src/process-inspector.ts:248 | catch-clause | catch (_unreadableSyscall) { |
| packages/subprocess/subprocess-local/src/process-inspector.ts:265 | catch-clause | catch (_unreadableProcessMemory) { |
| packages/subprocess/subprocess-local/src/process-inspector.ts:296 | catch-clause | catch (_unreadableFdInfo) { |
| packages/subprocess/subprocess-local/src/process-inspector.ts:484 | catch-clause | catch (_missingProcess) { |
| packages/subprocess/subprocess-local/src/spawn.ts:200 | catch-clause | catch { |
| packages/subprocess/subprocess-local/src/spawn.ts:208 | catch-clause | catch { |
| packages/subprocess/subprocess-local/src/spawn.ts:246 | catch-clause | catch { |
| packages/subprocess/subprocess-local/src/spawn.ts:279 | catch-clause | catch { |
| packages/subprocess/subprocess-local/src/spawn.ts:363 | catch-clause | catch (error) { |
| packages/subprocess/subprocess-local/src/spawn.ts:376 | catch-clause | catch (error) { |
| packages/subprocess/subprocess-local/src/spawn.ts:385 | catch-clause | catch (error) { |
| packages/subprocess/subprocess-local/src/spawn.ts:395 | catch-clause | catch (error) { |
| packages/subprocess/subprocess-local/src/spawn.ts:419 | coverage-directive | v8 ignore next -- kill/terminate gate on treeAlive(), which is false for pid -1; this guard protects direct callers only. |
| packages/subprocess/subprocess-local/src/spawn.ts:423 | catch-clause | catch { |
| packages/subprocess/subprocess-local/src/spawn.ts:424 | coverage-directive | v8 ignore start -- the fallback needs a live child whose group signal fails |
| packages/subprocess/subprocess-local/src/spawn.ts:428 | catch-clause | catch { |
| packages/subprocess/subprocess-local/src/spawn.ts:431 | coverage-directive | v8 ignore stop |
| packages/subprocess/subprocess-local/src/spawn.ts:515 | coverage-directive | v8 ignore next -- only a timer callback already queued when the observer settles can enter here; |
| packages/subprocess/subprocess-local/src/spawn.ts:536 | catch-clause | catch (error) { |
| packages/subprocess/subprocess-local/src/spawn.ts:538 | coverage-directive | v8 ignore next 2 -- POSIX reports an absent group as ESRCH; child-reaping timing |
| packages/subprocess/subprocess-local/src/spawn.ts:541 | coverage-directive | v8 ignore start -- EPERM and non-POSIX negative-pid failures are platform defenses; CI runs |
| packages/subprocess/subprocess-local/src/spawn.ts:545 | coverage-directive | v8 ignore stop |
| packages/subprocess/subprocess-local/src/spawn.ts:573 | coverage-directive | v8 ignore next -- the shared exit observer cancels the ordinary dead-tree timer; |
| packages/subprocess/subprocess-local/src/spawn.ts:665 | coverage-directive | v8 ignore next -- closes the event-loop race between the preceding aborted check and listener registration. |
| packages/subprocess/subprocess-local/src/spawn.ts:676 | coverage-directive | v8 ignore start -- pipe-mode fds exist on every spawn Node returns; the null-coalesces guard a nonconforming ChildProcess only. |
| packages/subprocess/subprocess-local/src/spawn.ts:680 | coverage-directive | v8 ignore stop |
| packages/subprocess/subprocess-local/src/terminal.ts:77 | lint-directive | oxlint-disable-next-line typescript/require-await -- Preserve promise rejection semantics at the async provider contract. |
| packages/subprocess/subprocess-local/src/terminal.ts:84 | lint-directive | oxlint-disable-next-line typescript/require-await -- Preserve promise rejection semantics at the async provider contract. |
| packages/subprocess/subprocess-local/src/terminal.ts:143 | catch-clause | catch (_rootExitedDuringHostExit) { |
| packages/subprocess/subprocess-local/src/terminal.ts:150 | catch-clause | catch (_unidentifiedShellExitedDuringHostExit) { |
| packages/subprocess/subprocess-local/src/terminal.ts:194 | catch-clause | catch (_alreadyExitedDuringSignal) { |
| packages/subprocess/subprocess-local/src/terminal.ts:204 | catch-clause | catch (_processTableUnavailableDuringHostExit) { |
| packages/subprocess/subprocess-local/src/terminal.ts:243 | catch-clause | catch (_topLevelAlreadyExitedDuringTerm) { |
| packages/subprocess/subprocess-local/src/terminal.ts:251 | catch-clause | catch (_topLevelAlreadyExitedDuringKill) { |
| packages/subprocess/subprocess-local/src/terminal.ts:277 | catch-clause | catch (_topLevelAlreadyExitedDuringKill) { |
| packages/subprocess/subprocess-local/src/terminal.ts:320 | coverage-directive | v8 ignore next -- stopShellWindows() verified the shell is gone or threw; |
| packages/subprocess/subprocess-local/src/windows-inspector.ts:210 | coverage-directive | v8 ignore start -- a layout-mismatch guard fires only on ABI breakage; the windows-native suites exercise the real struct. |
| packages/subprocess/subprocess-local/src/windows-inspector.ts:214 | coverage-directive | v8 ignore stop |
| packages/subprocess/subprocess-local/src/windows-job.ts:61 | catch-clause | catch (error) { |
| packages/subprocess/subprocess-local/tests/fixtures/process-exit-host.ts:25 | catch-clause | catch (_notReady) { |
| packages/subprocess/subprocess-local/tests/process-exit.spec.ts:24 | catch-clause | catch (error: unknown) { |
| packages/subprocess/subprocess-local/tests/process-exit.spec.ts:64 | catch-clause | catch (_alreadyGone) { |
| packages/subprocess/subprocess-local/tests/process-exit.spec.ts:74 | catch-clause | catch (_alreadyGone) { |
| packages/subprocess/subprocess-local/tests/process-exit.spec.ts:82 | catch-clause | catch (_alreadyGone) { |
| packages/subprocess/subprocess-local/tests/spawn-support.ts:61 | catch-clause | catch { |
| packages/subprocess/subprocess-local/tests/spawn-support.ts:102 | catch-clause | catch (error: unknown) { |
| packages/subprocess/subprocess-local/tests/windows-job.spec.ts:64 | catch-clause | catch { |
| packages/subprocess/subprocess-local/tests/windows-job.spec.ts:243 | catch-clause | catch { |
| packages/subprocess/subprocess-local/tests/windows-job.spec.ts:313 | catch-clause | catch { |
| packages/subprocess/subprocess-local/tests/windows-job.spec.ts:366 | catch-clause | catch { |
| packages/subprocess/win32-process/src/ffi.ts:128 | catch-clause | catch { |
| packages/subprocess/win32-process/src/ffi.ts:165 | coverage-directive | v8 ignore start -- ABI guards are pinned by native header probes. |
| packages/subprocess/win32-process/src/ffi.ts:172 | coverage-directive | v8 ignore stop |
| packages/subprocess/win32-process/src/ffi.ts:246 | coverage-directive | v8 ignore start -- exercised by native Windows ABI and sandbox jobs. |
| packages/subprocess/win32-process/src/ffi.ts:307 | coverage-directive | v8 ignore stop |
| packages/subprocess/win32-process/src/file-security.ts:223 | coverage-directive | v8 ignore start -- loads Win32 libraries; every decision above it takes an injected table. |
| packages/subprocess/win32-process/src/file-security.ts:239 | coverage-directive | v8 ignore stop |
| packages/subprocess/win32-process/src/file-security.ts:263 | coverage-directive | v8 ignore start -- runs only on win32 (it loads advapi32); the win32-only |
| packages/subprocess/win32-process/src/file-security.ts:278 | coverage-directive | v8 ignore stop |
| packages/subprocess/win32-process/src/job.ts:125 | coverage-directive | v8 ignore start -- loads Windows libraries; every operation above takes an injected table. |
| packages/subprocess/win32-process/src/job.ts:135 | coverage-directive | v8 ignore stop |
| packages/subprocess/win32-process/src/process.ts:127 | coverage-directive | v8 ignore next -- each successfully decoded pipe end is uniquely owned. |
| packages/subprocess/win32-process/src/process.ts:230 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/src/process.ts:358 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:56 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:114 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:130 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:142 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:207 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:220 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:232 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:264 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:280 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:295 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process-failure-paths.spec.ts:308 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process.spec.ts:136 | catch-clause | catch (error) { |
| packages/subprocess/win32-process/tests/process.spec.ts:156 | catch-clause | catch (error) { |
| packages/terminal/terminal-bash/src/index.ts:202 | catch-clause | catch (error) { |
| packages/terminal/terminal-bash/src/index.ts:205 | catch-clause | catch (closeError: unknown) { |
| packages/terminal/terminal-bash/src/session.ts:243 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal-bash/src/session.ts:298 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal-bash/src/session.ts:332 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- awaited provider writes can close the session. |
| packages/terminal/terminal-bash/src/session.ts:337 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal-bash/src/session.ts:513 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal-bash/src/session.ts:520 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition -- awaited inspection can replace the active send. |
| packages/terminal/terminal-bash/src/session.ts:585 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal-bash/src/session.ts:675 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal-bash/src/session.ts:697 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal-bash/tests/local.spec.ts:108 | catch-clause | catch (_missingProcess) { |
| packages/terminal/terminal-bash/tests/local.spec.ts:116 | catch-clause | catch (_unreadableProcEntry) { |
| packages/terminal/terminal-bash/tests/local.spec.ts:125 | catch-clause | catch (error) { |
| packages/terminal/terminal-bash/tests/local.spec.ts:271 | catch-clause | catch (_alreadyReaped) { |
| packages/terminal/terminal/src/index.ts:198 | catch-clause | catch (error) { |
| packages/terminal/terminal/src/index.ts:206 | catch-clause | catch (closeError: unknown) { |
| packages/terminal/terminal/src/index.ts:215 | catch-clause | catch (cancellation: unknown) { |
| packages/terminal/terminal/src/index.ts:299 | catch-clause | catch (error) { |
| packages/terminal/terminal/src/index.ts:413 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal/src/index.ts:419 | catch-clause | catch (error: unknown) { |
| packages/terminal/terminal/src/index.ts:465 | catch-clause | catch (error: unknown) { |
| packages/test-support/client-runtime/src/index.ts:13 | lint-directive | oxlint-disable typescript/no-redundant-type-constituents -- |
| packages/test-support/client-runtime/src/sessions.ts:536 | coverage-directive | v8 ignore next 2 -- bindingOf only runs for a live record, whose scope |
| packages/test-support/llm-mock-server/src/bin.ts:11 | coverage-directive | v8 ignore start -- thin process/signal glue; parser and server behavior are covered directly |
| packages/test-support/llm-mock-server/src/bin.ts:50 | catch-clause | catch (error: unknown) { |
| packages/test-support/llm-mock-server/src/bin.ts:54 | coverage-directive | v8 ignore stop |
| packages/test-support/llm-mock-server/src/index.ts:249 | catch-clause | catch { |
| packages/test-support/llm-mock-server/src/index.ts:294 | catch-clause | catch (_telemetryObserverFailure) { |
| packages/test-support/llm-mock-server/src/index.ts:382 | catch-clause | catch (_responseClosed) { |
| packages/test-support/llm-mock-server/src/index.ts:613 | coverage-directive | v8 ignore next -- seededRandom is strictly less than one; this guards floating-point residue only |
| packages/test-support/llm-mock-server/src/index.ts:649 | coverage-directive | v8 ignore next -- node:http server requests always carry a URL despite the shared optional type |
| packages/test-support/llm-mock-server/src/index.ts:668 | catch-clause | catch { |
| packages/test-support/llm-mock-server/src/index.ts:701 | coverage-directive | v8 ignore start -- last-resort containment for Node response failures after validated test inputs |
| packages/test-support/llm-mock-server/src/index.ts:712 | coverage-directive | v8 ignore stop |
| packages/test-support/llm-replay/src/index.ts:196 | catch-clause | catch (error) { |
| packages/test-support/llm-replay/src/index.ts:214 | catch-clause | catch (error) { |
| packages/test-support/llm-replay/src/index.ts:215 | coverage-directive | v8 ignore next -- decodeStorageRecord only throws Error instances; the String arm satisfies unknown narrowing. |
| packages/test-support/llm-replay/src/index.ts:367 | catch-clause | catch (error) { |
| packages/test-support/llm-replay/src/index.ts:466 | coverage-directive | v8 ignore next -- the fixed regular expression always has capture group 1. |
| packages/test-support/llm-replay/src/index.ts:661 | coverage-directive | v8 ignore next -- LlmRuntime only asks about routes registered from this same map. |
| packages/test-support/llm-replay/src/index.ts:668 | coverage-directive | v8 ignore next -- LlmRuntime only asks about routes registered from this same map. |
| packages/test-support/llm-replay/src/index.ts:689 | coverage-directive | v8 ignore next -- LlmRuntime only asks about routes registered from this same map. |
| packages/test-support/llm-replay/src/index.ts:702 | coverage-directive | v8 ignore next -- LlmRuntime only asks about routes registered from this same map. |
| packages/test-support/llm-replay/src/index.ts:787 | coverage-directive | v8 ignore next -- unreachable: the hang promise only ever rejects (on abort), never resolves; control never reaches here |
| packages/test-support/llm-replay/src/index.ts:789 | coverage-directive | v8 ignore next -- sidecar entries are validated before they reach the closed local union. |
| packages/test-support/llm-replay/src/index.ts:803 | coverage-directive | v8 ignore next -- override parsing and derived entries close the local union before replay. |
| packages/test-support/loader-smoke/tests/fixtures/headless-driver.ts:27 | catch-clause | catch (error: unknown) { |
| packages/test-support/session-snapshot/src/harness.ts:379 | coverage-directive | v8 ignore next 1 -- launch itself can only throw on a defensive synchronous spawn API failure |
| packages/test-support/session-snapshot/src/harness.ts:767 | catch-clause | catch { |
| packages/test-support/session-snapshot/src/launcher.ts:206 | coverage-directive | v8 ignore next 1 -- index is bounded by the array length |
| packages/test-support/session-snapshot/src/launcher.ts:211 | catch-clause | catch (error: unknown) { |
| packages/test-support/session-snapshot/src/launcher.ts:231 | coverage-directive | v8 ignore next -- exercised by the real-process ACP control-surface conformance e2e. |
| packages/test-support/session-snapshot/src/launcher.ts:233 | coverage-directive | v8 ignore next -- exercised by the real-process ACP control-surface conformance e2e. |
| packages/test-support/session-snapshot/src/launcher.ts:235 | coverage-directive | v8 ignore next -- exercised by the real-process ACP control-surface conformance e2e. |
| packages/test-support/session-snapshot/src/launcher.ts:237 | coverage-directive | v8 ignore next -- exercised by the real-process ACP control-surface conformance e2e. |
| packages/test-support/session-snapshot/src/launcher.ts:275 | catch-clause | catch (error: unknown) { |
| packages/test-support/session-snapshot/src/launcher.ts:404 | coverage-directive | v8 ignore next -- Windows uses directory junctions; the platform lane owns that branch. |
| packages/test-support/session-snapshot/src/manifest.ts:159 | catch-clause | catch (error) { |
| packages/test-support/session-snapshot/src/manifest.ts:352 | catch-clause | catch (error) { |
| packages/test-support/session-snapshot/src/manifest.ts:353 | coverage-directive | v8 ignore next -- every parser and validator above throws Error instances. |
| packages/test-support/session-snapshot/src/normalize.ts:72 | coverage-directive | v8 ignore next -- the filename capture is required and non-empty whenever the spill regex matches |
| packages/test-support/session-snapshot/src/suite.ts:621 | coverage-directive | v8 ignore next -- the authoritative predicate must fail loud when a new surface shape lands. |
| packages/test-support/session-snapshot/src/suite.ts:1091 | coverage-directive | v8 ignore next -- a title is turn-enclosed, so a preceding event time exists in every valid fixture. |
| packages/test-support/session-snapshot/src/suite.ts:1316 | coverage-directive | v8 ignore next -- registration guarantees every scenario class has resolved sources. |
| packages/test-support/session-snapshot/src/suite.ts:1330 | coverage-directive | v8 ignore next -- registration guarantees every scenario class has resolved sources. |
| packages/test-support/session-snapshot/src/suite.ts:1397 | coverage-directive | v8 ignore next -- construction guarantees the pin exists; a miss would fail the one-header assertion loudly. |
| packages/test-support/session-snapshot/src/suite.ts:1399 | coverage-directive | v8 ignore next -- registration guarantees every scenario class has resolved sources. |
| packages/test-support/session-snapshot/src/suite.ts:1401 | coverage-directive | v8 ignore next -- registration guarantees every scenario class has resolved sources. |
| packages/test-support/session-snapshot/src/suite.ts:1572 | coverage-directive | v8 ignore next -- registration guarantees every pin has resolved sources. |
| packages/test-support/session-snapshot/src/suite.ts:1574 | coverage-directive | v8 ignore next -- registration guarantees every pin has resolved sources. |
| packages/test-support/session-snapshot/src/suite.ts:1638 | coverage-directive | v8 ignore next -- registration guarantees every scenario class has resolved sources. |
| packages/typert/generator/src/analyzer-collect.ts:271 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/typert/generator/src/analyzer-collect.ts:378 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/typert/generator/src/analyzer-docs.ts:258 | catch-clause | catch (error) { |
| packages/typert/generator/src/analyzer-maps.ts:59 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/typert/generator/src/analyzer-maps.ts:91 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| packages/typert/loader/src/index.ts:321 | catch-clause | catch (cause) { |
| packages/typert/loader/src/index.ts:399 | catch-clause | catch (error) { |
| packages/typert/loader/tests/loader.spec.ts:181 | catch-clause | catch (error) { |
| packages/typert/registry/src/service.ts:100 | catch-clause | catch (error) { |
| packages/typert/registry/src/service.ts:155 | coverage-directive | v8 ignore next -- duplicate registration is rejected, so no later owner can replace this entry before its effect disposes. |
| packages/typert/registry/src/service.ts:158 | coverage-directive | v8 ignore next -- ids and endpoints are committed and withdrawn together under the same unique owner. |
| packages/typert/registry/src/service.ts:208 | coverage-directive | v8 ignore else -- duplicate package registration is rejected, so this effect remains the package's unique owner. |
| packages/typert/registry/src/service.ts:282 | coverage-directive | v8 ignore next -- duplicate configuration is rejected, so this effect remains the key's unique owner. |
| packages/typert/registry/src/service.ts:316 | coverage-directive | v8 ignore next -- duplicate registration is rejected, so this effect remains the key's unique owner. |
| packages/typert/registry/src/service.ts:411 | coverage-directive | v8 ignore next -- duplicate configuration is rejected, so this effect remains the key's unique owner. |
| packages/typert/registry/src/service.ts:445 | coverage-directive | v8 ignore next -- duplicate registration is rejected, so this effect remains the key's unique owner. |
| packages/typert/registry/src/service.ts:528 | coverage-directive | v8 ignore else -- duplicate package-face registration is rejected, so this effect remains its unique owner. |
| packages/typert/registry/src/service.ts:531 | coverage-directive | v8 ignore else -- duplicate schema registration is rejected, so this contribution remains each record's unique owner. |
| packages/util/atomic-write/src/index.ts:155 | catch-clause | catch (error) { |
| packages/util/atomic-write/src/win32.ts:163 | catch-clause | catch (error) { |
| packages/util/atomic-write/src/win32.ts:197 | catch-clause | catch (error) { |
| packages/util/atomic-write/tests/atomic-write.spec.ts:173 | catch-clause | catch { |
| packages/util/document-queue/src/index.ts:106 | catch-clause | catch (error) { |
| packages/util/document-queue/src/index.ts:252 | catch-clause | catch (error) { |
| packages/util/home-paths/src/index.ts:46 | catch-clause | catch (error) { |
| packages/util/native-command/src/path-opener.ts:59 | catch-clause | catch { |
| packages/util/sqlite-connection/src/index.ts:52 | catch-clause | catch (error) { |
| packages/util/sqlite-connection/src/index.ts:201 | catch-clause | catch (error: unknown) { |
| packages/web/tool-web/src/fetch.ts:251 | catch-clause | catch { |
| packages/web/tool-web/src/fetch.ts:259 | coverage-directive | v8 ignore next 2 -- WebFetchBody is a closed union; this arm is unreachable and only makes adding a kind a compile error. |
| packages/web/tool-web/src/search.ts:58 | catch-clause | catch { |
| packages/web/tool-web/src/search.ts:247 | catch-clause | catch (error) { |
| packages/web/web-fetch-http/src/network.ts:57 | catch-clause | catch { |
| packages/web/web-fetch-http/src/network.ts:200 | catch-clause | catch (error: unknown) { |
| packages/web/web-fetch-http/src/policy.ts:31 | catch-clause | catch (error: unknown) { |
| packages/web/web-fetch-http/src/policy.ts:117 | catch-clause | catch (error: unknown) { |
| packages/web/web-fetch-http/src/provider.ts:99 | catch-clause | catch (error: unknown) { |
| packages/web/web-fetch-http/src/provider.ts:123 | catch-clause | catch (error: unknown) { |
| packages/web/web-fetch-http/src/provider.ts:144 | catch-clause | catch (error: unknown) { |
| packages/web/web-fetch-http/src/provider.ts:181 | coverage-directive | v8 ignore next -- a 2xx Response from fetch always exposes a body stream; the null guard is defensive. |
| packages/web/web-fetch-http/src/provider.ts:206 | catch-clause | catch (error: unknown) { |
| packages/web/web-fetch-http/src/provider.ts:207 | coverage-directive | v8 ignore next -- mid-stream read fault needs a network drop after headers; translate path covered by request-phase tests. |
| packages/web/web-fetch-http/src/provider.ts:210 | coverage-directive | v8 ignore next 4 -- cancel() after a completed/broken read settles without rejecting; unobserved best-effort cleanup. |
| packages/web/web-fetch-http/src/provider.ts:236 | catch-clause | catch (error: unknown) { |
| packages/web/web-fetch-http/src/provider.ts:237 | coverage-directive | v8 ignore next 2 -- URL resolution against a valid absolute base effectively never throws; defensive guard. |
| packages/web/web-search-deepseek/src/provider.ts:235 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-deepseek/src/provider.ts:247 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-deepseek/src/provider.ts:262 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-deepseek/src/provider.ts:281 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-deepseek/tests/deepseek.spec.ts:524 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-exa/src/provider.ts:117 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-exa/src/provider.ts:129 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-exa/src/provider.ts:144 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-perplexity/src/provider.ts:116 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-perplexity/src/provider.ts:128 | catch-clause | catch (error: unknown) { |
| packages/web/web-search-perplexity/src/provider.ts:143 | catch-clause | catch (error: unknown) { |
| packages/webhook/webhook-github/src/body.ts:58 | catch-clause | catch (error: unknown) { |
| packages/webhook/webhook-github/src/body.ts:65 | catch-clause | catch { |
| packages/webhook/webhook-github/src/handler.ts:60 | catch-clause | catch { |
| packages/webhook/webhook-github/src/handler.ts:102 | catch-clause | catch { |
| packages/webhook/webhook-github/src/handler.ts:116 | catch-clause | catch { |
| packages/webhook/webhook-github/src/handler.ts:121 | catch-clause | catch (error: unknown) { |
| packages/webhook/webhook/src/index.ts:77 | coverage-directive | v8 ignore next -- caller-owned registration effects normally dispose first; this covers provider-first unload. |
| packages/webhook/webhook/src/index.ts:106 | coverage-directive | v8 ignore next -- no await separates the public liveness check from this initializer. |
| packages/webhook/webhook/src/session.ts:95 | coverage-directive | v8 ignore next -- AgentRegistry setup always provides the unpublished scoped Agent. |
| packages/webhook/webhook/src/session.ts:166 | catch-clause | catch (error: unknown) { |
| packages/webhook/webhook/src/session.ts:170 | catch-clause | catch (rollbackError: unknown) { |
| packages/webhook/webhook/src/session.ts:176 | catch-clause | catch (rollbackError: unknown) { |
| packages/workflow/tool-ralph/src/index.ts:343 | coverage-directive | v8 ignore start -- WorkflowStopReason is closed; a future variant must fail loud here. |
| packages/workflow/tool-ralph/src/index.ts:346 | coverage-directive | v8 ignore stop |
| packages/workflow/tool-workflow/src/index.ts:63 | catch-clause | catch { |
| packages/workflow/tool-workflow/src/index.ts:88 | catch-clause | catch (error: unknown) { |
| packages/workflow/tool-workflow/src/index.ts:185 | coverage-directive | v8 ignore start -- defensive: WorkflowStopReason is a closed union, exhaustive by construction; a future variant fails here loudly |
| packages/workflow/tool-workflow/src/index.ts:188 | coverage-directive | v8 ignore stop |
| packages/workflow/tool-workflow/src/index.ts:320 | coverage-directive | v8 ignore next -- WorkflowRun.result never rejects by contract, so result is assigned before finally. |
| packages/workflow/workflow-worker-thread/src/host.ts:68 | coverage-directive | v8 ignore next 3 -- the built-output arm: tests always run unbuilt (src/); the built-worker e2e exercises this shape for real |
| packages/workflow/workflow-worker-thread/src/host.ts:152 | coverage-directive | v8 ignore next -- messageerror: not constructible from the engine's own protocol (every payload is JSON data) |
| packages/workflow/workflow-worker-thread/src/host.ts:249 | coverage-directive | v8 ignore next -- result/quiescence never reject and Worker.terminate is the only external promise |
| packages/workflow/workflow-worker-thread/src/host.ts:260 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/host.ts:264 | coverage-directive | v8 ignore next -- postMessage teardown race (a throw between exit and its event): not constructible in-process |
| packages/workflow/workflow-worker-thread/src/host.ts:310 | coverage-directive | v8 ignore next 2 -- closed engine-owned union; the arm only makes adding a message type a compile error |
| packages/workflow/workflow-worker-thread/src/host.ts:344 | coverage-directive | v8 ignore next -- startChild contains provider and cleanup failures |
| packages/workflow/workflow-worker-thread/src/host.ts:367 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/host.ts:380 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/host.ts:401 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/host.ts:561 | coverage-directive | v8 ignore next -- a real end still in flight across the grace force-settle: not orderable in-process |
| packages/workflow/workflow-worker-thread/src/host.ts:587 | coverage-directive | v8 ignore next |
| packages/workflow/workflow-worker-thread/src/host.ts:606 | coverage-directive | v8 ignore next -- defensive fallback outside the claimed state machine |
| packages/workflow/workflow-worker-thread/src/index.ts:71 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/realm.ts:35 | catch-clause | catch { |
| packages/workflow/workflow-worker-thread/src/realm.ts:70 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:95 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:178 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:205 | coverage-directive | v8 ignore next |
| packages/workflow/workflow-worker-thread/src/runtime.ts:213 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:214 | coverage-directive | v8 ignore next -- defensive rethrow arm: materializeFromRealm only throws MaterializeError |
| packages/workflow/workflow-worker-thread/src/runtime.ts:258 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:279 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:334 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:335 | coverage-directive | v8 ignore next -- defensive rethrow arm: materializeFromRealm only throws MaterializeError |
| packages/workflow/workflow-worker-thread/src/runtime.ts:360 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:361 | coverage-directive | v8 ignore next -- defensive rethrow arm: assertObjectJsonSchema only throws JsonSchemaError |
| packages/workflow/workflow-worker-thread/src/runtime.ts:391 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/runtime.ts:425 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/session.ts:159 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/src/session.ts:191 | coverage-directive | v8 ignore next 2 -- closed engine-owned union; the arm only makes adding a message type a compile error |
| packages/workflow/workflow-worker-thread/tests/meta.spec.ts:10 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/tests/realm.spec.ts:14 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/tests/workflow-worker-thread.spec.ts:110 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/tests/workflow-worker-thread.spec.ts:281 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/tests/workflow-worker-thread.spec.ts:308 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/tests/workflow-worker-thread.spec.ts:350 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow-worker-thread/tests/workflow-worker-thread.spec.ts:563 | lint-directive | oxlint-disable-next-line typescript/prefer-promise-reject-errors -- the non-Error rejection IS the scenario under test |
| packages/workflow/workflow/src/index.ts:182 | catch-clause | catch (error: unknown) { |
| packages/workflow/workflow/src/index.ts:197 | catch-clause | catch { |
| packages/workflow/workflow/src/invariant.ts:107 | coverage-directive | v8 ignore next -- internal/dispatch stages the same run-info object |
| packages/workflow/workflow/src/invariant.ts:112 | coverage-directive | v8 ignore next -- internal/dispatch stages the same agent object |
| packages/workflow/workflow/src/invariant.ts:119 | coverage-directive | v8 ignore next -- internal/dispatch stages the same agent object |
| packages/workflow/workflow/src/invariant.ts:124 | coverage-directive | v8 ignore next -- internal/dispatch stages the same result object |
| packages/workflow/workflow/tests/workflow.spec.ts:77 | lint-directive | oxlint-disable-next-line typescript/no-misused-promises -- exercises rejected-listener containment |
| packages/workspace/workspace/src/entity.ts:127 | catch-clause | catch (error) { |
| packages/workspace/workspace/src/entity.ts:185 | catch-clause | catch { |
| packages/workspace/workspace/src/entity.ts:217 | catch-clause | catch (error) { |
| packages/workspace/workspace/src/index.ts:293 | catch-clause | catch (error) { |
| packages/workspace/workspace/src/index.ts:299 | catch-clause | catch (error) { |
| packages/workspace/workspace/src/index.ts:303 | catch-clause | catch (rollbackError) { |
| packages/workspace/workspace/src/index.ts:318 | catch-clause | catch (error) { |
| packages/workspace/workspace/src/index.ts:322 | catch-clause | catch (rollbackError) { |
| packages/workspace/workspace/src/index.ts:330 | catch-clause | catch (rollbackError) { |
| packages/workspace/workspace/src/index.ts:357 | catch-clause | catch (error) { |
| packages/workspace/workspace/src/index.ts:361 | catch-clause | catch (rollbackError) { |
| packages/workspace/workspace/src/index.ts:375 | catch-clause | catch (error) { |
| packages/workspace/workspace/src/index.ts:570 | catch-clause | catch { |
| scripts/build-exe-for-python-sdk.ts:172 | catch-clause | catch (error) { |
| scripts/change-scope.ts:77 | catch-clause | catch { |
| scripts/change-scope.ts:165 | catch-clause | catch { |
| scripts/change-scope.ts:243 | catch-clause | catch (error) { |
| scripts/clean.ts:16 | catch-clause | catch (error) { |
| scripts/clean.ts:26 | catch-clause | catch (error) { |
| scripts/clean.ts:202 | catch-clause | catch (error) { |
| scripts/client-build-environment.ts:98 | catch-clause | catch (error) { |
| scripts/client-build-environment.ts:337 | catch-clause | catch (error) { |
| scripts/cordis-walk.ts:95 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| scripts/doc-typecheck.ts:137 | catch-clause | catch (error: unknown) { |
| scripts/gen-client-catalog.ts:537 | catch-clause | catch { |
| scripts/gen-config-catalog-load.ts:127 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| scripts/gen-config-catalog-lookup.ts:127 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| scripts/gen-cordis-catalog.ts:1003 | catch-clause | catch { |
| scripts/gen-cordis-catalog.ts:1011 | catch-clause | catch (error) { |
| scripts/gen-cordis-catalog.ts:1039 | catch-clause | catch { |
| scripts/gen-cordis-catalog.ts:1081 | catch-clause | catch { |
| scripts/gen-cordis-catalog.ts:1101 | catch-clause | catch { |
| scripts/gen-module-graph.ts:105 | catch-clause | catch { |
| scripts/gen-persistence-catalog-scan.ts:135 | lint-directive | oxlint-disable-next-line typescript/no-unnecessary-condition |
| scripts/gen-third-party-notices.ts:643 | catch-clause | catch { |
| scripts/gen-third-party-notices.ts:783 | catch-clause | catch { |
| scripts/gen-tool-catalog.ts:765 | catch-clause | catch { |
| scripts/install-lefthook.mjs:185 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:194 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:310 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:319 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:341 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:373 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:411 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:471 | catch-clause | catch { |
| scripts/install-lefthook.mjs:664 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:669 | catch-clause | catch (rollbackError) { |
| scripts/install-lefthook.mjs:795 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:804 | catch-clause | catch (rollbackError) { |
| scripts/install-lefthook.mjs:810 | catch-clause | catch (rollbackError) { |
| scripts/install-lefthook.mjs:822 | catch-clause | catch (error) { |
| scripts/install-lefthook.mjs:828 | catch-clause | catch (releaseError) { |
| scripts/install-lefthook.mjs:842 | catch-clause | catch (error) { |
| scripts/install-lefthook.spec.ts:550 | catch-clause | catch (error) { |
| scripts/live-stack-floors.ts:530 | catch-clause | catch { |
| scripts/merge-translation-pairing.ts:45 | catch-clause | catch (error) { |
| scripts/project-doc-site.ts:80 | catch-clause | catch { |
| scripts/publint-all.ts:223 | catch-clause | catch (error: unknown) { |
| scripts/publish-npm-baseline.ts:217 | catch-clause | catch (error: unknown) { |
| scripts/publish-npm-baseline.ts:1085 | catch-clause | catch (error: unknown) { |
| scripts/session-fixture-layout.ts:85 | catch-clause | catch { |
| scripts/session-fixture-layout.ts:93 | catch-clause | catch (error) { |
| scripts/session-fixture-layout.ts:101 | catch-clause | catch (error) { |
| scripts/test-fixture-cleanup.ts:23 | catch-clause | catch (error) { |
| scripts/test-invariants.spec.ts:111 | catch-clause | catch (error) { |
| scripts/test-invariants.ts:69 | lint-directive | oxlint-disable-next-line typescript/unbound-method -- every call below supplies its RegistryService receiver explicitly. |
| scripts/test-invariants.ts:278 | catch-clause | catch (error) { |
| scripts/translation-links.ts:101 | catch-clause | catch { |
| scripts/translation-links.ts:110 | catch-clause | catch { |
| scripts/translation-pairing-merge.ts:390 | catch-clause | catch (error) { |
| scripts/verify-archived-agent-notes.ts:79 | catch-clause | catch (error: unknown) { |
| scripts/verify-archived-agent-notes.ts:91 | catch-clause | catch (error: unknown) { |
| scripts/verify-built-package-invariants.mjs:93 | catch-clause | catch (error) { |
| scripts/verify-doc-site-fragments.ts:67 | catch-clause | catch (error) { |
| scripts/verify-doc-site-fragments.ts:119 | catch-clause | catch (error) { |
| scripts/verify-md-links.ts:65 | catch-clause | catch { |
| scripts/verify-md-links.ts:80 | catch-clause | catch { |
| scripts/verify-mermaid.ts:92 | catch-clause | catch (error: unknown) { |
| scripts/verify-node-next-types.ts:155 | catch-clause | catch (error: unknown) { |
| scripts/verify-skill-invocation-metadata.ts:62 | catch-clause | catch (error) { |
| scripts/verify-skill-invocation-metadata.ts:71 | catch-clause | catch (error) { |
| scripts/verify-translation-pairing.ts:50 | catch-clause | catch (error) { |
| scripts/verify-translation-pairing.ts:279 | catch-clause | catch (error) { |
| scripts/verify-translation-prompt.ts:94 | catch-clause | catch (error) { |
| scripts/verify-vendored-links.ts:21 | catch-clause | catch { |
| snapshots/session/headless.snapshot.ts:591 | catch-clause | catch { |
| vendor/cordis/src/events.ts:36 | lint-directive | eslint-disable max-len |
| vendor/cordis/src/fiber.ts:125 | catch-clause | catch (error) { |
| vendor/cordis/src/fiber.ts:133 | catch-clause | catch (error) { |
| vendor/cordis/src/fiber.ts:252 | lint-directive | eslint-disable-next-line new-cap |
| vendor/cordis/src/fiber.ts:308 | catch-clause | catch (error) { |
| vendor/cordis/src/fiber.ts:494 | catch-clause | catch (error) { |
| vendor/cordis/src/fiber.ts:528 | catch-clause | catch (reason) { |
| vendor/cordis/src/fiber.ts:609 | catch-clause | catch (error) { |
| vendor/cordis/src/fiber.ts:664 | catch-clause | catch (reason) { |
| vendor/cordis/src/fiber.ts:688 | catch-clause | catch (reason) { |
| vendor/cordis/src/reflect.ts:168 | catch-clause | catch (e: any) { |
| vendor/cordis/src/reflect.ts:194 | catch-clause | catch (e: any) { |
| vendor/cordis/src/registry.ts:229 | catch-clause | catch {} |
| vendor/cordis/src/utils.ts:278 | catch-clause | catch (reason: any) { |
| vendor/cosmokit/src/string.ts:72 | lint-directive | eslint-disable @typescript-eslint/member-delimiter-style |
| vendor/cosmokit/src/string.ts:91 | lint-directive | eslint-disable @typescript-eslint/naming-convention |
| vendor/hmr/src/error.ts:32 | catch-clause | catch (e) { |
| vendor/hmr/src/index.ts:88 | catch-clause | catch (error) { |
| vendor/hmr/src/index.ts:109 | catch-clause | catch (error) { |
| vendor/hmr/src/index.ts:245 | catch-clause | catch (error) { |
| vendor/hmr/src/index.ts:374 | catch-clause | catch (reason) { |
| vendor/hmr/src/index.ts:380 | catch-clause | catch (rejection) { |
| vendor/hmr/src/index.ts:491 | catch-clause | catch (err) { |
| vendor/hmr/src/index.ts:544 | catch-clause | catch { |
| vendor/hmr/src/index.ts:564 | catch-clause | catch (e) { |
| vendor/hmr/src/index.ts:585 | catch-clause | catch (err) { |
| vendor/hmr/src/index.ts:593 | catch-clause | catch (err) { |
| vendor/hmr/src/index.ts:599 | catch-clause | catch { |
| vendor/hmr/src/index.ts:607 | catch-clause | catch (err) { |
| vendor/include/src/index.ts:239 | catch-clause | catch { |
| vendor/include/src/index.ts:248 | catch-clause | catch (error) { |
| vendor/include/src/index.ts:262 | catch-clause | catch (error) { |
| vendor/include/src/index.ts:281 | catch-clause | catch (error) { |
| vendor/include/src/index.ts:341 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:173 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:185 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:199 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:203 | catch-clause | catch (rollbackError) { |
| vendor/loader/src/config/entry.ts:219 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:227 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:234 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:238 | catch-clause | catch (rollbackError) { |
| vendor/loader/src/config/entry.ts:272 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:281 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:286 | catch-clause | catch (error) { |
| vendor/loader/src/config/entry.ts:298 | catch-clause | catch (error) { |
| vendor/loader/src/config/group.ts:31 | catch-clause | catch (error) { |
| vendor/loader/src/config/group.ts:85 | catch-clause | catch (error) { |
| vendor/loader/src/config/group.ts:91 | catch-clause | catch (rollbackError) { |
| vendor/loader/src/config/group.ts:98 | catch-clause | catch (rollbackError) { |
| vendor/loader/src/config/tree.ts:127 | catch-clause | catch (error) { |
| vendor/loader/src/config/tree.ts:134 | catch-clause | catch (rollbackError) { |
| vendor/loader/src/config/utils.ts:3 | lint-directive | eslint-disable-next-line no-new-func |
| vendor/loader/src/internal.ts:113 | catch-clause | catch {} |
| vendor/loader/src/internal.ts:117 | catch-clause | catch {} |
| vendor/logger-console/src/browser.ts:12 | lint-directive | eslint-disable-next-line no-console |
| vendor/logger-console/src/shared.ts:69 | lint-directive | eslint-disable-next-line no-console |
| vendor/schemastery/src/index.ts:202 | lint-directive | eslint-disable-next-line @typescript-eslint/naming-convention |
| vendor/schemastery/src/index.ts:260 | lint-directive | eslint-disable-next-line no-new-func |
| vendor/schemastery/src/index.ts:262 | catch-clause | catch {} |
| vendor/schemastery/src/index.ts:283 | catch-clause | catch (error) { |
| vendor/schemastery/src/index.ts:438 | catch-clause | catch {} |
| vendor/schemastery/src/index.ts:491 | catch-clause | catch (error) { |
| vendor/schemastery/src/index.ts:554 | catch-clause | catch (e: any) { |
| vendor/schemastery/src/index.ts:574 | catch-clause | catch (e: any) { |
| vendor/schemastery/src/index.ts:716 | catch-clause | catch (e) { |
| vendor/schemastery/src/index.ts:736 | catch-clause | catch (error) { |
| vendor/schemastery/src/index.ts:782 | catch-clause | catch (error) { |
