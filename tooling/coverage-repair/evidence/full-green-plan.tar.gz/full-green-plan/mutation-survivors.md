# All storage mutation survivors

Two complete source files; 221 mutants, 183 killed, 38 survived, zero timeouts and errors. Score 82.81%; required threshold 99%. All owning tests ran for every mutant using the official command runner.

## 3: [packages/storage/storage-json/src/index.ts:35](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:35)

ObjectLiteral

```typescript
{}
```

## 0: [packages/storage/storage-json/src/index.ts:19](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:19)

StringLiteral

```typescript
""
```

## 1: [packages/storage/storage-json/src/index.ts:21](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:21)

ArrayDeclaration

```typescript
[]
```

## 2: [packages/storage/storage-json/src/index.ts:21](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:21)

StringLiteral

```typescript
""
```

## 9: [packages/storage/storage-json/src/index.ts:56](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:56)

ConditionalExpression

```typescript
false
```

## 12: [packages/storage/storage-json/src/index.ts:56](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:56)

StringLiteral

```typescript
""
```

## 20: [packages/storage/storage-json/src/index.ts:63](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:63)

CallExpression

```typescript
;
```

## 31: [packages/storage/storage-json/src/index.ts:76](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:76)

ConditionalExpression

```typescript
false
```

## 32: [packages/storage/storage-json/src/index.ts:76](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:76)

BlockStatement

```typescript
{}
```

## 35: [packages/storage/storage-json/src/index.ts:80](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:80)

StringLiteral

```typescript
""
```

## 39: [packages/storage/storage-json/src/index.ts:87](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:87)

ConditionalExpression

```typescript
true
```

## 43: [packages/storage/storage-json/src/index.ts:90](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:90)

ArrayDeclaration

```typescript
[]
```

## 53: [packages/storage/storage-json/src/index.ts:99](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:99)

StringLiteral

```typescript
``
```

## 61: [packages/storage/storage-json/src/index.ts:103](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/index.ts:103)

StringLiteral

```typescript
``
```

## 91: [packages/storage/storage-json/src/per-record-unit.ts:82](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:82)

MethodExpression

```typescript
(await Promise.all(entries.map(async entry => {
  if (entry.isDirectory()) {
    const records = state.tables.get(entry.name);
    if (records !== undefined) {
      return loadTableRecords(records, descriptor.version, join(dir, entry.name));
    }
  }
  if (entry.name === 'global.json' && descriptor.hasGlobal) {
    const global = await readRecord(join(dir, entry.name), descriptor.version);
    if (global !== undefined) state.global = global;
    return true;
  }
  return false;
}))).every(Boolean)
```

## 93: [packages/storage/storage-json/src/per-record-unit.ts:83](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:83)

ConditionalExpression

```typescript
true
```

## 96: [packages/storage/storage-json/src/per-record-unit.ts:85](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:85)

ConditionalExpression

```typescript
true
```

## 100: [packages/storage/storage-json/src/per-record-unit.ts:89](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:89)

ConditionalExpression

```typescript
true
```

## 102: [packages/storage/storage-json/src/per-record-unit.ts:89](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:89)

LogicalOperator

```typescript
entry.name === 'global.json' || descriptor.hasGlobal
```

## 103: [packages/storage/storage-json/src/per-record-unit.ts:89](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:89)

ConditionalExpression

```typescript
true
```

## 111: [packages/storage/storage-json/src/per-record-unit.ts:94](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:94)

BooleanLiteral

```typescript
true
```

## 110: [packages/storage/storage-json/src/per-record-unit.ts:92](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:92)

BooleanLiteral

```typescript
false
```

## 118: [packages/storage/storage-json/src/per-record-unit.ts:115](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:115)

StringLiteral

```typescript
""
```

## 131: [packages/storage/storage-json/src/per-record-unit.ts:128](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:128)

ConditionalExpression

```typescript
false
```

## 132: [packages/storage/storage-json/src/per-record-unit.ts:128](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:128)

LogicalOperator

```typescript
typeof tables !== 'object' && tables === null
```

## 136: [packages/storage/storage-json/src/per-record-unit.ts:128](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:128)

ConditionalExpression

```typescript
false
```

## 133: [packages/storage/storage-json/src/per-record-unit.ts:128](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:128)

ConditionalExpression

```typescript
false
```

## 155: [packages/storage/storage-json/src/per-record-unit.ts:134](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:134)

StringLiteral

```typescript
``
```

## 159: [packages/storage/storage-json/src/per-record-unit.ts:141](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:141)

BlockStatement

```typescript
{}
```

## 161: [packages/storage/storage-json/src/per-record-unit.ts:143](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:143)

StringLiteral

```typescript
``
```

## 160: [packages/storage/storage-json/src/per-record-unit.ts:142](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:142)

BlockStatement

```typescript
{}
```

## 167: [packages/storage/storage-json/src/per-record-unit.ts:157](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:157)

MethodExpression

```typescript
files.every(file => file.name.endsWith('.json'))
```

## 170: [packages/storage/storage-json/src/per-record-unit.ts:157](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:157)

StringLiteral

```typescript
""
```

## 174: [packages/storage/storage-json/src/per-record-unit.ts:159](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:159)

ConditionalExpression

```typescript
false
```

## 176: [packages/storage/storage-json/src/per-record-unit.ts:159](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:159)

StringLiteral

```typescript
""
```

## 183: [packages/storage/storage-json/src/per-record-unit.ts:163](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:163)

ConditionalExpression

```typescript
true
```

## 193: [packages/storage/storage-json/src/per-record-unit.ts:174](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:174)

StringLiteral

```typescript
""
```

## 194: [packages/storage/storage-json/src/per-record-unit.ts:175](/Users/brandon/Downloads/deepseek-harness/packages/storage/storage-json/src/per-record-unit.ts:175)

BlockStatement

```typescript
{}
```
