# Preset mount cleanup and diagnostic regression repair

Current HEAD: `ee24359f10f99c47b05ff75cb40426e7ea860505`.
Only `packages/preset/agent-presets/tests/mount-cleanup.spec.ts` is changed
in the repository during this execution slice. Production source, gate policy,
thresholds, and the prior mutation report are unchanged.

## Repairs and evidence

The original cleanup test checked settlement immediately after an asynchronous
disposer started. A premature rejection could still be queued in microtasks,
so that assertion passed after the cleanup wait was removed. The repaired test
observes the next native event-loop checkpoint before releasing cleanup.
Original test plus mutant 170 passed in `/tmp/dsh-preset-cleanup-mutant170.log`;
the strengthened test rejects the same mutant at the settlement assertion in
`/tmp/dsh-preset-cleanup-mutant170-strengthened.log`.

The suite now also retains a failure from the final DISPOSED notification,
asserts every dependency in two inactive Loader rows, preserves the complete
unscoped-mount diagnostic, and verifies the indentation of nested aggregate
causes including a primitive cause. All lifecycle faults use real Cordis
listeners and owned effects; no clocks or lifecycle methods are replaced.

All 189 owning tests across 14 files pass without skips in
`/tmp/dsh-preset-mount-nested-final-owning.log`. Typed lint passes in
`/tmp/dsh-preset-mount-nested-final-lint.log`; `git diff --check` passes.

All 23 previous survivors were replayed in the preserved instrumented sandbox.
Nine fail the stronger cleanup/dependency assertions; mutant 113 then fails
the added nested-aggregate assertion. The ten detected ids are 97, 113, 128,
145, 170, 171, 172, 175, 177 and 178. Every failure was reviewed as the intended
behavioral assertion, rather than a compiler/cache/runtime-infrastructure error.
Thirteen still survive: 39, 52, 55, 63, 67, 70, 80, 82, 83, 84, 107, 153 and 169.

The original sandbox test files remain untouched. An additional test file
carries the strengthened suite, so sandbox runs execute 192 tests while the
repository runs execute 189. The final unmutated instrumented control passes
all 192 in `/tmp/dsh-preset-cleanup-nested-instrumented-control.log`.
The current production source exactly matches the original mutation report.
Hashes, raw paths and verdicts are recorded in
`preset-mount-strengthened-recheck.json`.

## Remaining acceptance work

This survivor replay is diagnostic evidence, not a new complete mutation score.
The raw 87.63% report remains failed; a fresh complete campaign and status-reason
review are still required after all survivors are repaired.

Strict complete-module coverage remains failed: 108/117 statements (92.30%),
35/62 branches (56.45%), 18/18 functions (100%), and 88/95 lines (92.63%).
`/tmp/dsh-preset-mount-strengthened-coverage.log` predates only the final nested
diagnostic assertion refinement. Native coverage mapping remains unresolved.

The three Web preset failures are unchanged. Reading the shipped minimal
composition and the preset-copy contract confirms that renamed copies must
preserve the exact two-tool behavior; name-based Team exclusion does not do so.
Their assertions were retained. No suppression, skip, retry, timeout increase,
test filter, source exclusion or weaker gate was introduced into the repository.

Primary lifecycle reference inspected:
[Cordis lifecycle and effects](https://deepseek-harness.github.io/deepseek-harness/en/develop/cordis-tutorial/02-lifecycle-and-effects).
Local Fiber source and real Loader execution establish the timing evidence.

Full-green acceptance remains open.
