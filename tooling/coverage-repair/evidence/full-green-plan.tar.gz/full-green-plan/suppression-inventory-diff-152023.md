# Directive comparison: 903 to 643

Removed occurrences: 260. Added occurrences: 0. Changed files: 32.

Identity is path, directive kind and exact text; line movement does not count as removal.
Removal is inventory evidence, not complete coverage or behavioral acceptance.
Latest complete snapshot: source-20260916152023138.json.

| File | Removed | Added |
| --- | ---: | ---: |
| `apps/cli/src/process-shutdown.ts` | 1 | 0 |
| `packages/acp/acp/src/session.ts` | 17 | 0 |
| `packages/attachment/attachment-local/src/store.ts` | 12 | 0 |
| `packages/attachment/attachment-local/tests/encoding.spec.ts` | 1 | 0 |
| `packages/boot/app-boot/src/index.ts` | 3 | 0 |
| `packages/boot/app-boot/src/profile.ts` | 13 | 0 |
| `packages/client/ui-primitives/src/markdown/mathCompatibility.ts` | 9 | 0 |
| `packages/client/ui-slots/tests/core.client.spec.ts` | 3 | 0 |
| `packages/core/agent-loop/src/agent.ts` | 5 | 0 |
| `packages/core/agent-loop/src/index.ts` | 5 | 0 |
| `packages/core/agent-loop/src/tool-calls.ts` | 6 | 0 |
| `packages/core/tools/tests/execution-signal-types.spec.ts` | 21 | 0 |
| `packages/core/tools/tests/schema.spec.ts` | 5 | 0 |
| `packages/credentials/credentials-local/src/index.ts` | 7 | 0 |
| `packages/extensions/cordis-client-runner/src/client/timer.ts` | 6 | 0 |
| `packages/fs/fs-local/src/fsio.ts` | 26 | 0 |
| `packages/fs/fs-observation-policy/src/index.ts` | 1 | 0 |
| `packages/llm/llm-deepseek/src/image-tokens.ts` | 6 | 0 |
| `packages/llm/llm-retry/src/history.ts` | 1 | 0 |
| `packages/sandbox/sandbox/src/index.ts` | 1 | 0 |
| `packages/session/session-persistence-jsonl/src/index.ts` | 20 | 0 |
| `packages/session/session-persistence/src/coordinator.ts` | 9 | 0 |
| `packages/skill/skill-filesystem/src/index.ts` | 24 | 0 |
| `packages/spill/spill-local/src/cleanup.ts` | 35 | 0 |
| `packages/subprocess/subprocess-local/src/spawn.ts` | 11 | 0 |
| `packages/typert/generator/src/analyzer-collect.ts` | 2 | 0 |
| `packages/typert/generator/src/analyzer-maps.ts` | 2 | 0 |
| `packages/web/web-fetch-http/src/provider.ts` | 4 | 0 |
| `scripts/cordis-walk.ts` | 1 | 0 |
| `scripts/gen-config-catalog-load.ts` | 1 | 0 |
| `scripts/gen-config-catalog-lookup.ts` | 1 | 0 |
| `scripts/gen-persistence-catalog-scan.ts` | 1 | 0 |
