# Archive peer-version repair

Status: isolated source repair verified; native release integration pending.
This does not establish repository-wide green or promote a package.

## Reproduced failure

The candidate runner's strict installation rejects `tsx` even though its
declared version, 4.23.13, satisfies Vite's `^4.8.1` peer range. pnpm 12.4.2
compares the archive reference with the range instead of reading the version
stored in lockfile package metadata. The initial install failure is retained
in `/tmp/dsh-runner-toolchain-install.log`.

The released pnpm source reproduces five failures in seven snapshot tests.
After correcting snapshot lookup, linked workspace consumers independently
reproduce three failures in four additional cases. The TypeScript v11 checker
already reads package metadata for these references; it is unchanged.

Real local archives reproduce both the installation and `peers check` failure
with the official executable. A compatible 4.23.13 archive and an incompatible
3.9.0 archive both report `file:provider.tgz` as the installed version.
Both installed consumers execute and return their actual package version.
These cases use `strictPeerDependencies: true` and explicitly declared peers.
Their fresh stores and command logs are recorded in
`/tmp/dsh-pnpm-peer-native-official-final.log` and its referenced JSON file.

## Source correction

Official source: [pnpm v12.4.2](https://github.com/pnpm/pnpm/releases/tag/v12.4.2).
The archive SHA-256 is
`2fca2c303b978c8177c13550b2d0f8e442cf32b833bea7878421f90c18a7c612`.

In `pnpm/crates/deps-inspection-peers/src/lib.rs`, snapshot resolution now
resolves the package key and uses the existing metadata version lookup.
In `src/linked.rs`, both archive and registry references consult package
metadata before interpreting the reference itself. Directory version lookup
and linked-manifest ownership remain exercised by the existing suite.

Eleven new regressions cover ordinary and aliased local archives, remote
archives, peer-suffixed references, linked consumers, missing version metadata,
and incompatible versions. No range exception, issue filter, dependency
override, skipped test, or suppression is added. The strict peer setting is
unchanged. The implementation changes two existing files and adds two test
modules plus a release changeset; all other archived source files match.

## Verification

| Evidence | Result | Log |
| --- | --- | --- |
| Original snapshot regressions | Two pass, five fail | `/tmp/dsh-pnpm-peer-versions-before.log` |
| Linked-consumer control after snapshot repair | 47 pass, three fail | `/tmp/dsh-pnpm-linked-versions-before.log` |
| Final complete owning crate | 50 pass, zero failed or skipped | `/tmp/dsh-pnpm-peer-versions-final-tests.log` |
| Final crate and test clippy | Pass, warnings denied | `/tmp/dsh-pnpm-peer-versions-final-clippy.log` |
| Pinned formatter check | Pass | `/tmp/dsh-pnpm-peer-format-check.log` |
| Native Git source reconstruction | Five changed/added inputs identical | `pnpm-archive-peer-reconstruction.json` |
| Official CLI strict installation and peer checking | Both archive versions rejected with path-valued diagnostics | `/tmp/dsh-pnpm-peer-native-official-final.log` |
| Initial debug CLI build | Completes with Darwin unwind-table warning | `/tmp/dsh-pnpm-peer-cli-build.log` |
| Normal release CLI build | Pending | `/tmp/dsh-pnpm-peer-cli-release.log` |

Commands run from `/tmp/dsh-pnpm-12.4.2-source`:

```sh
cargo test --locked --offline -p pnpm-deps-inspection-peers
cargo clippy --locked --offline -p pnpm-deps-inspection-peers --all-targets -- --deny warnings
node pnpm/scripts/rustfmt.mjs --rustfmt --check --edition 2024 pnpm/crates/deps-inspection-peers/src/lib.rs
cargo build --locked --offline --release -p pnpm-cli --bin pnpm
```

The source setup used its declared frozen pnpm dependency graph and managed
Cargo source directories. Rust is the repository-pinned 1.97.0. The formatter
is its pinned fork at `d6374b755f95faf8c0f90f63e6ba242b552321ab` with
`nightly-2026-08-27`. Formatter installation reports an existing dependency's
future-Rust compatibility warning; complete upstream tooling acceptance remains
open. The current source reconstruction proves patch application and byte
identity, not an independent fresh-cache build.

The full upstream `just ready`, native target matrix, reproducible release
build, actual runner installation, and promotion remain unverified. A frozen
installation alone cannot validate the original defect: this pnpm version
reports install-time peer errors only after resolution. Acceptance therefore
requires a fresh resolution and an explicit `peers check`, followed separately
by a frozen replay. Current [pnpm configuration documentation](https://pnpm.io/settings)
and the dispatch/reporting source were checked before selecting those commands.

## Compiler and loader integration

All 23 native esbuild platform builds and three managed JavaScript/WebAssembly
platform packages were packaged with the corrected compiler. This proves
artifact construction, not native execution on those platforms.
`/tmp/dsh-esbuild-packed-platforms.json` records package paths and hashes.
The repacked `tsx` modifies only its esbuild dependency reference; all 49 other
files match the official archive byte for byte, recorded in
`/tmp/dsh-tsx-integrated-identity.json`.

The provisional integrated runner passes 14 of 15 native regressions.
The generated anonymous function attribution is repaired, but the unchanged
next assertion exposes a separate defect: `__name(uncalled, "uncalled")` is
mapped to the uncalled function's declaration line and makes that line appear
covered. `/tmp/dsh-runner-integrated-deleted-line.json` preserves the exact
executed source, map, and counters. The compiler producer needs a further
provenance repair; the assertion remains unchanged. No coverage score is
accepted from this integration.

A separate native Inspector matrix isolates name preservation: all four
ESM/CommonJS and minified/unminified cases without name preservation pass;
all four with `--keep-names` fail on the uncalled statement count. Exact
execution records and maps are retained as `/tmp/dsh-esbuild-name-lines-*.json`,
with the complete result in `/tmp/dsh-esbuild-name-lines-before.log` and its
executable regression in `/tmp/dsh-esbuild-name-lines.mjs`.
