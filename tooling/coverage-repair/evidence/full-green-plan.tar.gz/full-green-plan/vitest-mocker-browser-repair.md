# Packed browser registration repair

All five owning public-browser scenarios pass against the rebuilt package,
including explicit failure on browser exceptions and console warnings/errors.
Complete package-source and packed declaration compilation pass with TypeScript
7 and library checking enabled. Fresh-cache frozen reconstruction reproduces
all 28 generated files byte for byte and retains the same lockfile.

This verifies the browser repair, not complete runner or repository acceptance.
The native Node source build remains active, and the complete upstream typecheck
still reports the same 89 diagnostics. No candidate is promoted to the product.

## Production changes

- `packages/mocker/package.json` maps `auto-register` to its actual runtime and
  declaration outputs. Its side-effect metadata preserves registration when
  the entry is imported for its initialization behavior.
- `packages/mocker/tsdown.config.ts` bundles the source-map dependency and its
  declared transitive dependencies, allowing the emitted browser code to load
  without an unconverted CommonJS import. Dependency ownership enforcement
  remains enabled, with every bundled dependency named.
- `packages/mocker/src/node/mockerPlugin.ts` keeps the automatic registration
  entry in Vite's normal transformation pipeline. The `optimizeDeps.exclude`
  entry controls dependency prebundling; the runtime entry still executes in
  every browser regression. The registration loader uses the existing shared
  URL-normalization function so versioned requests receive the configured
  accessor and root. The server's `resolveId` response event now matches the
  event awaited by the browser.
- `packages/mocker/src/node/resolver.ts` uses one client-environment resolution
  path for interception and original imports. Browser importer paths receive
  the same normalization in both operations. The duplicate private resolution
  method is removed, and root-prefix matching respects directory boundaries.

No generated distribution is edited by hand. No assertion, coverage threshold,
mutation configuration, test selection, or diagnostic directive is weakened.

## Browser regression and preserved failures

The standalone packed consumer launches a real Vite server and Chromium. It
imports the automatic registration entry, intercepts a real local module using
the package's autospy API, checks the returned value and exact call history,
imports the original implementation, and verifies that original function is
not a spy. Browser exceptions and warning/error messages fail the test.

The failure sequence is preserved in separate logs and package archives:

| Log | Observed result |
| --- | --- |
| `/tmp/dsh-mocker-browser-before.log` | Browser rejects an unconverted CommonJS dependency import. |
| `/tmp/dsh-mocker-browser-repaired-first.log` | Registration runs but its injected accessor is undefined. |
| `/tmp/dsh-mocker-browser-transform-runtime.log` | Versioned registration request still misses the loader transform. |
| `/tmp/dsh-mocker-browser-query-runtime.log` | Browser waits for the mismatched `resolveId` response until the existing timeout fails. |
| `/tmp/dsh-mocker-browser-rpc-runtime.log` | Response arrives, but the browser importer is not normalized for the original import. |
| `/tmp/dsh-mocker-browser-resolver-runtime.log` | Complete standalone browser regression passes, with no skipped cases. |

The current archive is
`/tmp/dsh-mocker-browser-resolver-artifact/vitest-mocker-5.0.1.tgz`.
Earlier artifacts remain in their distinct `modern`, `browser`,
`browser-transform`, `browser-query`, and `browser-rpc` artifact directories.

The regression is also added to the owning source test at
`test/e2e/test/public-mocker.test.ts`, with actual fixtures in
`test/e2e/fixtures/mocker/auto-register`. The existing four expected results are
unchanged. All five scenarios now inspect browser diagnostics. The setup removes
an unnecessary teardown cast and rejects a missing server URL explicitly.

`/tmp/dsh-mocker-browser-consumer` executes an exact copy of that owning test
and its five real fixtures against the packed repair. Its published Vitest
5.0.1 runner is separate from the still-unaccepted source runner candidate.
The consumer retains the owning suite's 60-second test timeout, with no retries
or skipped cases. Results:

- `/tmp/dsh-mocker-public-browser-tests.log`: five passed.
- `/tmp/dsh-mocker-public-browser-diagnostics-tests.log`: all five pass after
  adding explicit browser exception and warning/error checks.

Source review also found that the existing case named `automock` requested
`spy: true`. Its fixture now requests actual automatic substitution and records
the function's result before assigning a return value. The existing `42`
assertion remains; an additional assertion requires the initial result to be
`undefined`. A native browser control restores the previous spy option and
reports four passes and the expected one failure (`3` versus `undefined`) in
`/tmp/dsh-mocker-public-browser-spy-control.log`. After restoring automatic
substitution, `/tmp/dsh-mocker-public-browser-final.log` reports all five passed.
This distinguishes the two behaviors without replacing the implementation or
filtering the test suite.

The browser checks cover factory interception, automatic substitution,
autospy, redirect, automatic registration, and original implementation imports.
They do not establish the full browser/platform or accessibility matrix.

## Strict compilation and reconstruction

- `/tmp/dsh-mocker-browser-source-types.log`: complete package source passes
  with `--skipLibCheck false`.
- `/tmp/dsh-mocker-browser-consumer-types.log`: all eight packed public
  declaration entry imports pass with strict checking and no source conditions.
- `/tmp/dsh-mocker-browser-consumer-invalid-types.log`: invalid format and
  accessor arguments are rejected with TS2345 and TS2322.
- `/tmp/dsh-mocker-browser-full-types.log`: complete upstream typecheck fails
  with 89 diagnostics, identical to the preceding complete check.

`/tmp/dsh-mocker-browser-reconstruct.py` extracts the same verified official
Vitest source archive and applies `vitest-mocker-browser-candidate.patch`,
recording 31 changed or added inputs. The patch includes the preceding source
repairs and this browser slice. No built distribution or dependency installation
is copied into the reconstruction.

Fresh frozen install, build, and strict package-source compilation pass:

- `/tmp/dsh-mocker-browser-frozen-install.log`
- `/tmp/dsh-mocker-browser-frozen-build.log`
- `/tmp/dsh-mocker-browser-frozen-types.log`

`/tmp/dsh-mocker-browser-byte-identity.json` records all 28 matching output
hashes and the unchanged lockfile. Reconstruction inputs and its location are
in `/tmp/dsh-mocker-browser-frozen-location.json`. The two existing whitespace
findings inside earlier nested dependency patches remain visible during patch
application. Existing absolute artifact dependencies, upstream configuration
exceptions, full runner lint/build, and unused old package build configuration
remain unaccepted integration work.

The final three strengthened test inputs are reconstructed with the separate
`vitest-mocker-browser-automock-regression.patch`, applied after the 31-input
candidate patch. `/tmp/dsh-mocker-browser-automock-inputs.json` records their
before/after hashes. These changes affect the owning test and two fixtures;
the production and build inputs used for the 28-file byte comparison are
unchanged. The final packed-consumer fixture and owning test copies match the
reconstructed source byte for byte.

## Native build and complete objective

The Node package-lookup repair described in
[the preceding record](vitest-mocker-build-repair.md) is still compiling in
session `83623`, with output in `/tmp/dsh-node-package-json-build.log`.
The handle is polled and remains live. No restart or replacement process is
started. The seven native cases, existing Node loader tests, and packed
TypeScript export analysis must run against the completed runtime.

Root is clean at `105a97ef9c776a2856118ee02609dc61a0fb9617`.
The 633 recorded repository directives, full coverage/mutation targets,
generated-helper attribution, child-process coverage ownership, full native
platform/CI verification, and the complete plan remain open.

Primary references: [Vite JavaScript API](https://vite.dev/guide/api-javascript.html),
[Playwright library](https://playwright.dev/docs/library), and
[tsdown dependency ownership](https://tsdown.dev/options/dependencies).
