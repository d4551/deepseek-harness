# Source-owned Stryker patch whitespace repair

The working-tree patch whitespace defect is repaired. The externally staged
copy still contains the older patch bytes and fails the index whitespace gate.
No index, commit, hook, branch, root dependency, or protected AGENTS file was
changed by this repair. Full-green acceptance remains open.

## Repair and native proof

`tooling/stryker/src/artifacts.mjs` generates a two-context-line Git patch with
empty context lines serialized without leading spaces. This is Git's documented
patch format; no diagnostic rule, source, test, or mutation is excluded.
Generation additionally rejects whitespace errors using native `git diff
--no-index --check`. Its ordinary difference exit status is 1; a clean result
must also have empty stdout and stderr and no child error or signal.

The integrity regression applies a generated patch with native Git and compares
the complete resulting source bytes. The same test then introduces trailing
whitespace into packed source and proves generation rejects it. Before-repair
evidence used the same final valid fixture and failed the whitespace assertion.

Both source patches were reconstructed from digest-verified upstream archives,
applied with Git, regenerated, and applied to separate fresh upstream copies.
Complete source trees compare identically. The runner package patch also passes
an independent clean Bun installation whose every recorded packed file matches
its expected hash. A zero-context experiment is retained as failed evidence:
Bun applied it incorrectly, so that format is not used.

The generated core archive, runner archive, and complete file inventory remain
byte-identical. The runner patch hash changes from
`5669236412334f4264961fc9fa13de54df65cb2c0de231f4af95ad69de576d19`
to `9a9c8c4c88b4edc3f17466308ffdd5049096330abfd4e9492176d48aa5e65d98`.
The frozen private runtime lock is unchanged.

## Verification

| Check | Result | Evidence |
| --- | --- | --- |
| Final valid fixture against old generator | Fails whitespace assertion | `/tmp/dsh-patch-format-before-final-fixture.log` |
| Independent native Git and Bun application | Every recorded installed file matches | `/tmp/dsh-patch-format-probe-native.log` |
| Source-patch regeneration/application | Both entire source trees match; packed inventory and core archive unchanged | `/tmp/dsh-clean-stryker-patches-regenerate.log` |
| Fresh canonical reconstruction | Exit 0; strict TS7 compilation, frozen installation, ownership proof, 23 JSONC tests, reporter consumer, 16 native runner cases, static activation and child-timeout checks | `/tmp/dsh-clean-stryker-patches-rebuild-check.log` |
| Final integrity suite | Four passed, zero failed, including rejection of newly introduced trailing whitespace | `/tmp/dsh-clean-stryker-patches-final-tests.log` |
| Complete typed lint | Exit 0; separate final MJS owner lint also passes | `/tmp/dsh-clean-stryker-patches-full-lint.log`, `/tmp/dsh-clean-stryker-patches-final-owner-lint.log` |
| Quick documentation | 13 passed, two protected-file failures, zero skipped | `/tmp/dsh-clean-stryker-patches-doc-quick.log` |
| Full documentation | 30 passed, two protected-file failures, zero skipped | `/tmp/dsh-clean-stryker-patches-doc-sync.log` |
| Working-tree whitespace | `git diff HEAD --check` exit 0 | Native command result |
| Staged whitespace | Exit 2; older externally staged patch bytes | `/tmp/dsh-clean-stryker-patches-final-index-whitespace.log` |

Fresh reconstruction retains all command and browser logs under
`/var/folders/91/5qxhhcj142j402qfvs_twnh80000gn/T/dsh-stryker-build-bLq7hT`.
Its two-mutant static fixture score is runner regression evidence only, not
repository mutation acceptance. Browser framework warnings remain documented.
The later phase-cancellation candidate remains separate and unpromoted.

The bilingual maintenance README records the generation and byte-comparison
contract. No new suppression, exclusion, retry, skip, timeout extension, or
weaker acceptance assertion is introduced.

Final complete source inventory at 2026-09-16T13:50:01Z scans 4,043 files and
retains 658 directives: 540 coverage and 118 lint. It also records 1,445 catch
clauses and 357 static catch-handler accesses. All remain violations. The
complete snapshot is `source-20260916135001115.{json,md}`, with corpus SHA-256
`51ae79c565f70499064e6144ac13e7ff106189aaf067364e0bb8b65f963ad474`.
The patch-format slice changes no directive count. The separate package gate's
217 empty installers remain outstanding. Full documentation's two failures are
protected root/client AGENTS wrapping and the protected root word budget.

## Primary references

- [Git diff configuration](https://git-scm.com/docs/git-diff) documents empty
  context serialization and ordinary unified context.
- [Git patch application](https://git-scm.com/docs/git-apply) and
  [Git's application source](https://raw.githubusercontent.com/git/git/master/apply.c)
  establish native empty-context handling.
- [Bun archive API](https://bun.com/docs/runtime/archive) owns the package archive
  extraction used in the independent native application probe.
