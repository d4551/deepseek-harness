# Complete composite effect teardown

The full-green objective remains active. This repair is a bounded part of it.

## Reproduced failure

The real Team composition test installs eleven tools in each of two Agents.
An actual `tools/change` observer throws during removal. Before this repair,
each composite stops after its first disposer, leaving ten tools and the policy
registered. The unchanged empty-catalog assertion fails in
`/tmp/dsh-team-early-disposal-before.log`.

Cordis collected the complete disposer list but let either a synchronous throw
or a rejected promise terminate the serial chain. The remaining resource owners
were removed from the list before they could run.

## Implementation

`vendor/cordis/src/fiber.ts` drains the collected list in reverse order. Each
composite cleanup outcome is observed, remaining cleanup continues after a
failure, and all failures are reported after the drain. A single failure keeps
its identity; multiple failures produce an AggregateError. Successful synchronous
cleanup remains synchronous. A single disposer retains its synchronous throw
contract. The existing effect-inertia ownership still lets a parent join an
already-running cleanup.

The native resource regression holds a disposer at a real promise barrier,
starts owner teardown, and verifies the owner remains pending. After release,
the file receives ordered writes, closes, and both the synchronous and
asynchronous failures remain in the resulting error. The Team regression
requires every tool and policy to disappear and every observer failure to be
reported. A replacement plugin must register complete catalogs for both Agents.

No assertion, threshold, directive, test selection gate or retry setting was
weakened. The implementation adds no catch clause, catch-handler access or type
assertion, and removes one existing type assertion from the disposal loop.
The vendor divergence is recorded in `vendor/README.md`.

## Evidence and limits

- The first candidate failed two synchronous lifecycle assertions; retained in
  `/tmp/dsh-composite-teardown-owning.log`.
- The next candidate passed 253 owning cases, then full tests exposed two
  synchronous-error callers. Their existing assertions are retained.
- The final focused replay passes 60 lifecycle/resource/Team/report-tool cases.
  Its release suite does not initialize under direct Node invocation because
  it requires Bun script metadata. That invocation failure remains in
  `/tmp/dsh-composite-teardown-final-focused.log`.
- Final complete build passes in
  `/tmp/dsh-composite-teardown-final-build.log`; the existing chunk warning remains.
- Final complete typed lint passes in
  `/tmp/dsh-composite-teardown-complete-lint.log`.
- The canonical complete `bun run test` finishes with **20,468 passed,
  two failed and 42 skipped**, in 209.64 seconds. All 67 actual accessibility
  audit tests execute. No unhandled errors are reported. All fourteen release
  tests pass. The remaining failures are the unchanged source-prohibition gate
  and provenance-word gate. Log:
  `/tmp/dsh-composite-teardown-canonical-full-tests.log`.
- Final built Web replay passes all **35 tests** in
  `/tmp/dsh-composite-teardown-built-web.log`.
- Expanded coverage runs all **255 tests successfully**. The complete Team
  entry module reaches 100% statements (123/123), branches (87/87), functions
  (32/32) and lines (107/107). The aggregate fails: V8 coverage attempts to
  parse raw `fiber.ts` as JavaScript and rejects `import type` at line 2, then
  excludes its executed record. Its resulting zero coverage is not a valid
  execution measurement. No vendor exclusion or reduced threshold is added.
  Complete log: `/tmp/dsh-composite-teardown-coverage.log`.
- The first documentation aggregate reports 29 passes and three failures:
  stale generated Fiber source links and the two protected AGENTS gates.
  Canonical generation updates all four stale links; the reviewed Chinese
  counterpart and pair record are synchronized. Final complete documentation
  reports **30 passed, two protected-file failures and zero skipped** in
  `/tmp/dsh-composite-teardown-paired-doc-sync.log`. Translation pairing and
  generated catalogs pass. Root/client AGENTS wrapping and root AGENTS word
  budget remain failures; neither protected file nor gate is changed.
- Complete Cordis coverage and mutation acceptance remain open.

The exact source hashes are in `composite-teardown-evidence.json`. The fresh
complete source inventory contains 633 directives, 1,442 catch clauses and
357 catch-handler accesses across 4,060 files. Every finding remains listed in
`source-composite-teardown.md`; none is treated as acceptable.

The lifecycle contract was checked against the local source and the current
[official Cordis lifecycle guide](https://deepseek-harness.github.io/deepseek-harness/en/develop/cordis-tutorial/02-lifecycle-and-effects).

No staging, commit or push was performed.
