# Coverage input failures remain failures

This repair is implemented and exercised in the isolated source candidate at
`/tmp/dsh-vitest-5.0.1-source`. It is **not installed in the repository** and
does not establish full coverage, mutation, or complete-green acceptance.
The repository still has 643 directive violations.

## Verified defects and repair

The published V8 provider can complete coverage generation despite three
distinct failures: invalid native JavaScript is dropped after a parser error;
a rejected Vite transform is replaced by the original file text; and a missing
executed file is replaced by synthesized slash characters before its record
disappears. These are failures of coverage evidence, not test assertions.

The candidate's `packages/coverage-v8/src/provider.ts` now propagates all
three failures. It removes the parser rejection handler, the transform
rejection handler, the missing-file rejection handler, and the helper that
constructed source length from coverage ranges. No file selection, threshold,
assertion, retry, or exception directive is added or relaxed.

The complete source diff against the official Vitest archive is retained in
`vitest-coverage-failure-propagation.patch`.

## Actual verification

The four native tests in `test/coverage-source-integrity.test.mjs` use actual
Vitest/Vite projects and the public coverage provider methods. They verify:

1. Invalid native source rejects coverage generation.
2. A real Vite plugin's transform failure reaches the caller.
3. Valid unexecuted source remains in the report with an uncovered function
   and statement inventory.
4. A function actually runs under native Inspector coverage; deleting its
   source before reporting causes an explicit missing-file failure.

All four pass with no skipped tests in
`/tmp/dsh-vitest-coverage-source-integrity-final.log`. The initial fixture
path assertion exposed macOS's `/var` symlink; the fixture now obtains its
actual filesystem path with `realpath`, preserving exact path comparison.
Earlier failing logs remain available.

Independent controls run the same three failure conditions against the
installed, unmodified published provider. All three reproduce the original
failure swallowing in `/tmp/dsh-vitest-coverage-baseline-control.log`.
The parser diagnostic is retained in that output rather than silenced.
The control program is `/tmp/dsh-vitest-coverage-baseline-control.mjs`.

## Complete coverage source compilation

`tsconfig.runtime-native.json` now includes all coverage-v8 sources in addition
to the existing complete Vitest and browser-playwright source scopes, with
`skipLibCheck: false` unchanged. The expanded check exposed a missing public
`istanbul-lib-coverage` declaration import in `ast-v8-to-istanbul@1.0.5`.

The current official converter release is 1.0.6. Its declaration bundles the
required coverage types and removes the missing external import. Normal pnpm
installation updates the candidate's catalog, manifest, and lockfile. All five
installed files match the official archive, whose SHA-512 matches npm's
published integrity. Exact inputs and hashes are recorded in
`vitest-coverage-failure-inventory.json`.

The final complete expanded compile retains exactly two diagnostics, both
pre-existing uses of Node's removed transform mode. Exit status remains 1 in
`/tmp/dsh-vitest-coverage-strict-current-converter.log`. No additional coverage
source diagnostic remains. The earlier three-diagnostic result is retained in
`/tmp/dsh-vitest-coverage-strict-native.log`.

The dependency installation reports existing deprecated transitive packages
`glob@10.4.1`, `tar@6.2.0`, and `whatwg-encoding@3.1.1`; these warnings remain
visible in `/tmp/dsh-vitest-coverage-converter-update.log`.

## Outstanding acceptance

Failure propagation does not provide the missing executed-source artifacts.
CI-04 still needs exact generated JavaScript and source maps captured during
execution, distinct-transform remapping before aggregation, and the full
native/browser/worker matrix. Deleted generated files must eventually remain
measurable from captured artifacts. Explicit rejection without those artifacts
is an interim truthful failure, not completion of that journey.

CI-03's exact-environment transport and CI-06's runner lifecycle remain open.
The candidate also requires the two Node API repairs, complete strict builds,
source-built declarations, immutable installation and reproduction, root
integration, notices, and final product measurements.

Primary inputs: [official converter source manifest](https://github.com/AriPerkkio/ast-v8-to-istanbul/blob/48f88c789411ce6e96137b16ec348d06ae6c2f6e/package.json),
`/tmp/dsh-ast-v8-latest-registry.json`, `/tmp/dsh-ast-v8-1.0.6.tgz`, and
`/tmp/dsh-vitest-5.0.1-source.tgz`.
